export type ColumnType =
  | 'text'
  | 'amount'
  | 'percent'
  | 'date'
  | 'jpeg'
  | 'pdf'
  | 'status'
  | 'legal-checklist'
  | 'day-by-day';

export type SaqProcessStatus =
  | 'Site Hunting'
  | 'Pro Docs'
  | 'Pre-Con'
  | 'Post-Con'
  | 'FAC'
  | 'Billing';

export interface DayByDayUpdateEntry {
  id: string;
  date: string; // YYYY-MM-DD (real-time date or date of site survey)
  status: SaqProcessStatus;
  progressNotes: string; // Day-by-Day Progress / Updates
  remarks?: string; // Details / Remarks
  slaRuleApplied?: string; // SLA Tracking Rule (e.g., "Official Site Hunting Start", "21d Property Docs SLA")
  updatedBy?: string;
  surveyDate?: string; // Date of Site Survey
  attachmentsCount?: number;
  createdAt?: string;
}

export interface LegalChecklistItem {
  id: string;
  requirement: string;
  category: 'Legal' | 'Permit' | 'Social' | 'Clearance';
  status: 'Completed' | 'In Progress' | 'Submitted' | 'Pending' | 'Waived';
  amount: number;
  assignedStaff?: string;
  submissionDate?: string;
  completionDate?: string;
  sopRef?: string;
  receiptDoc?: string;
  receiptDocUrl?: string;
  receiptDocType?: 'jpeg' | 'pdf';
  attachedPictureUrl?: string;
  remarks?: string;
}

export type UserRole = 'admin' | 'staff' | 'guest';
export type UserStatus = 'approved' | 'pending' | 'rejected';
export type UserPermission = 'editor' | 'viewer';
export type FieldAccessLevel = 'edit' | 'view' | 'no_access';

export interface User {
  id: string;
  username: string;
  email: string;
  password?: string;
  role: UserRole;
  department?: string;
  status: UserStatus;
  permission: UserPermission; // legacy fallback
  createdAt: string;
}

export interface Column {
  id: string;
  name: string;
  type: ColumnType;
  width?: number;
  visible: boolean;
  color?: 'slate' | 'blue' | 'emerald' | 'amber' | 'rose' | 'cyan' | 'purple' | 'indigo';
  options?: string[]; // for status type choices
  currencySymbol?: string; // for amount type, defaults to $
}

export type CalcType = 'sum' | 'average' | 'count' | 'count-completed' | 'min' | 'max';
export type MetricFormat = 'currency' | 'percent' | 'number';

export interface SummaryCard {
  id: string;
  title: string;
  columnId: string;
  calcType: CalcType;
  format: MetricFormat;
  tag: string;
  color: 'emerald' | 'indigo' | 'slate' | 'purple' | 'amber' | 'cyan' | 'rose' | 'blue';
}

export interface Row {
  id: string;
  [key: string]: any;
}

export interface TrackerFolder {
  id: string;
  name: string;
  icon?: string;
  color?: 'blue' | 'amber' | 'emerald' | 'purple' | 'rose' | 'indigo' | 'cyan' | 'slate';
  isCollapsed?: boolean;
  parentId?: string | null;
  createdAt?: string;
}

export interface Tracker {
  id: string;
  name: string;
  description: string;
  icon?: string;
  color?: string;
  folderId?: string; // Associated folder ID
  isPinned?: boolean; // Pinned to top of sidebar
  isArchived?: boolean; // Archived tracker
  summaryCardsCollapsed: boolean;
  summaryCards: SummaryCard[];
  columns: Column[];
  rows: Row[];
}

export interface TrackerPermission {
  id: string;
  userId: string;
  trackerId: string;
  canView: boolean;
  canAdd: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canExport: boolean;
  // Field-level editing control: columnId -> 'edit' | 'view' | 'no_access'
  fieldPermissions: Record<string, FieldAccessLevel>;
  approvedBy?: string;
  updatedAt: string;
}

export interface AccessRequest {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userRole: UserRole;
  trackerId: string;
  trackerName: string;
  requestedPermissions: {
    view: boolean;
    add: boolean;
    edit: boolean;
    delete: boolean;
    export: boolean;
  };
  requestedFields: string[]; // columnIds user requests edit rights for
  reason: string;
  status: 'pending' | 'approved' | 'rejected' | 'revoked';
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
  adminNote?: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  userEmail?: string;
  userRole?: UserRole;
  trackerId?: string;
  trackerName?: string;
  action: string; // e.g. 'VIEW' | 'ADD_ROW' | 'EDIT_CELL' | 'DELETE_ROW' | 'EXPORT' | 'APPROVE_REQUEST' | 'REJECT_REQUEST' | 'REVOKE_PERMISSION' | 'UPDATE_PERMISSION' | 'UPDATE_ROLE' | 'CREATE_USER'
  changedField?: string;
  columnId?: string;
  rowId?: string;
  oldValue?: string | number | null;
  newValue?: string | number | null;
  approvedBy?: string;
  timestamp: string;
  details?: string;
}

export type AppTheme = 'slate' | 'navy' | 'emerald' | 'dark' | 'amber' | 'purple';

export interface AppState {
  appName: string;
  appSubtitle: string;
  theme: AppTheme;
  activeTrackerId: string;
  folders?: TrackerFolder[];
  trackers: Tracker[];
  users: User[];
  trackerPermissions: TrackerPermission[];
  accessRequests: AccessRequest[];
  activityLogs: ActivityLog[];
  lastSyncedAt?: string;
}
