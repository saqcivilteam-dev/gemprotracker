import React, { useState } from 'react';
import { Download, FileText, Image as ImageIcon, X, ZoomIn, ZoomOut, RotateCcw, Check, Sparkles } from 'lucide-react';
import { createOfficialDocumentSvg } from '../utils/referencePictures';

interface LightboxModalProps {
  media: {
    type: 'jpeg' | 'pdf';
    url: string;
    title: string;
    stage?: string;
  } | null;
  onClose: () => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({ media, onClose }) => {
  const [zoom, setZoom] = useState(1);
  const [copied, setCopied] = useState(false);

  if (!media) return null;

  // Resolve valid image source (SVG, base64, or fallback generated official reference document)
  const isVisualImage =
    media.type === 'jpeg' ||
    media.url.startsWith('data:image/') ||
    media.url.startsWith('blob:') ||
    media.url.startsWith('http') ||
    media.url.endsWith('.png') ||
    media.url.endsWith('.jpg') ||
    media.url.endsWith('.jpeg') ||
    media.url.endsWith('.svg');

  const resolvedUrl = isVisualImage
    ? media.url
    : createOfficialDocumentSvg(
        media.title,
        'Site Acquisition, Regulatory Affairs & Building Permitting Dossier',
        'Official Clearance',
        'DOC-REF-' + Math.abs(media.title.split('').reduce((a, b) => (a << 5) - a + b.charCodeAt(0), 0)).toString(16).toUpperCase(),
        'Telecommunications Site Acquisition Milestone',
        'Active 2026 Audit'
      );

  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = resolvedUrl;
    a.download = `${media.title.replace(/[^a-zA-Z0-9_-]/g, '_')}.${media.type === 'pdf' && !isVisualImage ? 'pdf' : 'png'}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleCopyLink = () => {
    navigator.clipboard?.writeText?.(resolvedUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative max-w-5xl w-full bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-3.5 sm:px-5 border-b border-zinc-800 flex items-center justify-between text-zinc-100 bg-zinc-900/90">
          <div className="flex items-center gap-2.5 truncate pr-2">
            <div className="w-8 h-8 rounded-lg bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400 shrink-0">
              {media.type === 'jpeg' || isVisualImage ? (
                <ImageIcon className="w-4 h-4 text-cyan-400" />
              ) : (
                <FileText className="w-4 h-4 text-purple-400" />
              )}
            </div>
            <div className="truncate">
              <h3 className="text-xs sm:text-sm font-bold truncate text-white">{media.title}</h3>
              <p className="text-[10px] text-zinc-400 flex items-center gap-1.5">
                <span className="font-mono text-cyan-400 font-bold uppercase">Attached Reference Picture / Document</span>
                <span>•</span>
                <span>Click & zoom for high-resolution examination</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Zoom Controls */}
            <div className="hidden sm:flex items-center bg-zinc-800/80 rounded-lg p-0.5 border border-zinc-700">
              <button
                type="button"
                onClick={() => setZoom(z => Math.max(0.5, z - 0.2))}
                className="p-1 text-zinc-300 hover:text-white rounded hover:bg-zinc-700"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-[10px] font-mono px-1.5 text-zinc-300">{Math.round(zoom * 100)}%</span>
              <button
                type="button"
                onClick={() => setZoom(z => Math.min(2.5, z + 0.2))}
                className="p-1 text-zinc-300 hover:text-white rounded hover:bg-zinc-700"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setZoom(1)}
                className="p-1 text-zinc-300 hover:text-white rounded hover:bg-zinc-700 ml-0.5"
                title="Reset Zoom"
              >
                <RotateCcw className="w-3 h-3" />
              </button>
            </div>

            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-sky-600 hover:bg-sky-500 text-white transition-colors shadow-2xs"
              title="Download file"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Download</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              title="Close viewer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Viewer */}
        <div className="flex-1 p-3 sm:p-6 flex items-center justify-center overflow-auto bg-black/60 custom-scrollbar">
          <div
            style={{ transform: `scale(${zoom})`, transformOrigin: 'center center', transition: 'transform 0.15s ease-out' }}
            className="flex items-center justify-center"
          >
            <img
              src={resolvedUrl}
              alt={media.title}
              className="max-h-[75vh] w-auto max-w-full rounded-xl object-contain shadow-2xl border border-zinc-800 bg-white"
            />
          </div>
        </div>

        {/* Footer info bar */}
        <div className="p-2.5 px-4 bg-zinc-900 border-t border-zinc-800 flex items-center justify-between text-[11px] text-zinc-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>High-Fidelity Official Reference Attachment verified for Telecom Audit & Legal Compliance</span>
          </div>
          <button
            type="button"
            onClick={handleCopyLink}
            className="text-[11px] text-zinc-400 hover:text-zinc-200 flex items-center gap-1"
          >
            {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Sparkles className="w-3 h-3 text-sky-400" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy Reference Picture'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
