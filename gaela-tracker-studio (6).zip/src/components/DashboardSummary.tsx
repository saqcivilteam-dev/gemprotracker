import React, { useState, useMemo } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Edit2,
  TrendingUp,
  Layers,
  Search,
  X,
  Filter,
  ArrowUpDown,
  FileSpreadsheet,
  CheckCircle2,
  CheckSquare,
  Square,
  Calculator,
  Copy,
  PlusCircle,
  Download,
  Check,
  RotateCcw
} from 'lucide-react';
import { Tracker, SummaryCard, Column } from '../types/tracker';
import { formatCurrency, formatPercent } from '../utils/storage';

interface DashboardSummaryProps {
  tracker: Tracker;
  allTrackers?: Tracker[];
  isDark: boolean;
  onUpdateSummaryCards: (cards: SummaryCard[]) => void;
  onToggleCollapse: () => void;
  activeFilterTerm?: string;
  onFilterChange?: (term: string) => void;
}

export const DashboardSummary: React.FC<DashboardSummaryProps> = ({
  tracker,
  allTrackers = [],
  isDark,
  onUpdateSummaryCards,
  onToggleCollapse,
  activeFilterTerm = '',
  onFilterChange
}) => {
  // Mode: 'current' (Active tracker) or 'all' (Cross-Tracker Consolidated Subtotals)
  const [dashboardScope, setDashboardScope] = useState<'current' | 'all'>('current');
  const [internalSearch, setInternalSearch] = useState<string>(activeFilterTerm);
  
  // Multi-Tracker Checkboxes for Subtotals
  const [checkedTrackerIds, setCheckedTrackerIds] = useState<string[]>(() =>
    allTrackers.length > 0 ? allTrackers.map(t => t.id) : [tracker.id]
  );
  const [copied, setCopied] = useState<boolean>(false);
  const [generatedFlash, setGeneratedFlash] = useState<string | null>(null);

  const [editingCard, setEditingCard] = useState<SummaryCard | null>(null);
  const [isAddingCard, setIsAddingCard] = useState(false);
  const [isBreakdownCollapsed, setIsBreakdownCollapsed] = useState(false);

  // Form state for custom metric cards
  const [cardTitle, setCardTitle] = useState('');
  const [cardColumnId, setCardColumnId] = useState('');
  const [cardCalcType, setCardCalcType] = useState<SummaryCard['calcType']>('sum');
  const [cardFormat, setCardFormat] = useState<SummaryCard['format']>('currency');
  const [cardTag, setCardTag] = useState('');
  const [cardColor, setCardColor] = useState<SummaryCard['color']>('indigo');

  // Keep internal search synced with external filter if provided
  React.useEffect(() => {
    setInternalSearch(activeFilterTerm);
  }, [activeFilterTerm]);

  // Keep checked tracker IDs updated when allTrackers changes
  React.useEffect(() => {
    if (allTrackers.length > 0) {
      setCheckedTrackerIds(prev => {
        const validIds = allTrackers.map(t => t.id);
        const filtered = prev.filter(id => validIds.includes(id));
        return filtered.length > 0 ? filtered : validIds;
      });
    }
  }, [allTrackers]);

  const searchDebounceRef = React.useRef<NodeJS.Timeout | null>(null);

  const handleSearchChange = (val: string) => {
    setInternalSearch(val);
    if (onFilterChange) {
      if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
      searchDebounceRef.current = setTimeout(() => {
        onFilterChange(val);
      }, 200);
    }
  };

  const handleClearSearch = () => {
    setInternalSearch('');
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    if (onFilterChange) {
      onFilterChange('');
    }
  };

  // Toggle single tracker checkbox
  const handleToggleTracker = (trackerId: string) => {
    setCheckedTrackerIds(prev => {
      if (prev.includes(trackerId)) {
        return prev.filter(id => id !== trackerId);
      } else {
        return [...prev, trackerId];
      }
    });
  };

  const handleSelectAllTrackers = () => {
    setCheckedTrackerIds(allTrackers.map(t => t.id));
  };

  const handleDeselectAllTrackers = () => {
    setCheckedTrackerIds([]);
  };

  // Safe number parser
  const parseNum = (v: any): number => {
    if (v === undefined || v === null || v === '') return 0;
    if (typeof v === 'number') return isNaN(v) ? 0 : v;
    const cleaned = String(v).replace(/[^0-9.-]+/g, '');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
  };

  // Check if a row matches search query
  const rowMatchesSearch = (row: any, q: string): boolean => {
    if (!q) return true;
    const lower = q.toLowerCase();
    for (const key of Object.keys(row)) {
      if (key === 'id') continue;
      const val = row[key];
      if (val !== undefined && val !== null && String(val).toLowerCase().includes(lower)) {
        return true;
      }
    }
    return false;
  };

  // Consolidated Cross-Tracker Subtotals calculation based on checked trackers
  const crossTrackerSubtotals = useMemo(() => {
    const list = allTrackers.length > 0 ? allTrackers : [tracker];
    const q = internalSearch.trim();

    let totalCost = 0;
    let totalExpenses = 0;
    let totalSettled = 0;
    let totalBillingReq = 0;
    let totalRows = 0;
    let completedCount = 0;

    const trackerBreakdowns = list.map(t => {
      const isChecked = checkedTrackerIds.includes(t.id);
      const rows = t.rows.filter(r => rowMatchesSearch(r, q));

      let tAmount = 0;
      let tSettled = 0;
      let tBillingReq = 0;
      let tCompleted = 0;

      rows.forEach(r => {
        // Find amount columns
        t.columns.forEach(col => {
          if (col.type === 'amount') {
            const val = parseNum(r[col.id]);
            tAmount += val;

            const colName = col.name.toLowerCase();
            if (colName.includes('req') || colName.includes('billing')) {
              tBillingReq += val;
            } else if (colName.includes('settled') || colName.includes('paid')) {
              tSettled += val;
            } else if (colName.includes('expense') || colName.includes('invoice') || t.id.includes('budget')) {
              // Expense item
            }
          }
        });

        // Status check
        t.columns.forEach(col => {
          if (col.type === 'status' || col.id.includes('status')) {
            const s = String(r[col.id] || '').toLowerCase();
            if (s === 'completed' || s === 'done' || s === 'approved' || s === 'settled') {
              tCompleted += 1;
            }
          }
        });
      });

      // Accumulate only if checked
      if (isChecked) {
        totalRows += rows.length;
        completedCount += tCompleted;
        totalSettled += tSettled;
        totalBillingReq += tBillingReq;

        // Categorize for financial KPI
        rows.forEach(r => {
          t.columns.forEach(col => {
            if (col.type === 'amount') {
              const val = parseNum(r[col.id]);
              const colName = col.name.toLowerCase();
              if (colName.includes('expense') || colName.includes('invoice') || t.id.includes('budget')) {
                totalExpenses += val;
              } else if (!colName.includes('req') && !colName.includes('billing') && !colName.includes('settled')) {
                totalCost += val;
              }
            }
          });
        });
      }

      return {
        id: t.id,
        name: t.name,
        color: t.color || 'indigo',
        isChecked,
        matchedRows: rows.length,
        totalRows: t.rows.length,
        subtotalAmount: tAmount,
        settledAmount: tSettled,
        billingReqAmount: tBillingReq,
        completedCount: tCompleted
      };
    });

    // Grand Subtotal of only the checked trackers
    const grandSubtotal = trackerBreakdowns
      .filter(item => item.isChecked)
      .reduce((acc, curr) => acc + curr.subtotalAmount, 0);

    const pendingBalance = Math.max(0, grandSubtotal - totalSettled);

    return {
      grandSubtotal,
      totalCost: totalCost > 0 ? totalCost : grandSubtotal,
      totalExpenses: totalExpenses > 0 ? totalExpenses : totalBillingReq,
      totalBilling: totalBillingReq > 0 ? totalBillingReq : totalSettled,
      totalSettled,
      pendingBalance,
      totalRows,
      completedCount,
      completionRate: totalRows > 0 ? Math.round((completedCount / totalRows) * 100) : 0,
      breakdowns: trackerBreakdowns
    };
  }, [allTrackers, tracker, internalSearch, checkedTrackerIds]);

  // Copy Summary Report to clipboard
  const handleCopySubtotalReport = () => {
    const query = internalSearch.trim();
    const checkedBreakdowns = crossTrackerSubtotals.breakdowns.filter(b => b.isChecked);
    
    let reportText = `=========================================\n`;
    reportText += `GAELA TRACKER STUDIO - CONSOLIDATED SUMMARY\n`;
    reportText += `Generated: ${new Date().toLocaleString()}\n`;
    if (query) reportText += `Search Query: "${query}"\n`;
    reportText += `Checked Trackers: ${checkedBreakdowns.length} of ${allTrackers.length}\n`;
    reportText += `-----------------------------------------\n`;
    reportText += `GRAND TOTAL: ${formatCurrency(crossTrackerSubtotals.grandSubtotal, '₱')}\n`;
    reportText += `Total Settled: ${formatCurrency(crossTrackerSubtotals.totalSettled, '₱')}\n`;
    reportText += `Pending / Balance: ${formatCurrency(crossTrackerSubtotals.pendingBalance, '₱')}\n`;
    reportText += `Total Matched Records: ${crossTrackerSubtotals.totalRows}\n`;
    reportText += `Finalized / Completed: ${crossTrackerSubtotals.completedCount} (${crossTrackerSubtotals.completionRate}%)\n`;
    reportText += `-----------------------------------------\n`;
    reportText += `BREAKDOWN BY TRACKER:\n`;
    checkedBreakdowns.forEach(b => {
      reportText += `• ${b.name}: ${formatCurrency(b.subtotalAmount, '₱')} (${b.matchedRows} records, ${b.completedCount} done)\n`;
    });
    reportText += `=========================================`;

    navigator.clipboard.writeText(reportText);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  // Export Summary Report as CSV
  const handleExportSubtotalCSV = () => {
    const checkedBreakdowns = crossTrackerSubtotals.breakdowns.filter(b => b.isChecked);
    let csv = `Tracker Name,Matched Records,Total Rows,Total Amount (PHP),Settled Amount (PHP),Completed Items\n`;
    checkedBreakdowns.forEach(b => {
      csv += `"${b.name.replace(/"/g, '""')}",${b.matchedRows},${b.totalRows},${b.subtotalAmount},${b.settledAmount},${b.completedCount}\n`;
    });
    csv += `"GRAND TOTAL",${crossTrackerSubtotals.totalRows},-,${crossTrackerSubtotals.grandSubtotal},${crossTrackerSubtotals.totalSettled},${crossTrackerSubtotals.completedCount}\n`;

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `tracker_summary_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Active tracker filtered rows for single-tracker metrics
  const activeTrackerRows = useMemo(() => {
    const q = internalSearch.trim();
    if (!q) return tracker.rows;
    return tracker.rows.filter(r => rowMatchesSearch(r, q));
  }, [tracker.rows, internalSearch]);

  // Compute metric value for active tracker custom cards
  const computeValue = (card: SummaryCard) => {
    const col = tracker.columns.find(c => c.id === card.columnId);
    const rows = activeTrackerRows;

    if (card.calcType === 'count') {
      return rows.length;
    }

    if (card.calcType === 'count-completed') {
      return rows.filter(r => {
        const val = String(r[card.columnId] || '').toLowerCase();
        return val === 'completed' || val === 'done' || val === 'approved' || val === 'settled' || val === '100' || val === '100%';
      }).length;
    }

    const numbers = rows
      .map(r => {
        const v = r[card.columnId];
        if (typeof v === 'number') return v;
        if (!v) return 0;
        return parseNum(v);
      })
      .filter(n => !isNaN(n));

    if (numbers.length === 0) return 0;

    switch (card.calcType) {
      case 'sum':
        return numbers.reduce((acc, curr) => acc + curr, 0);
      case 'average':
        return numbers.reduce((acc, curr) => acc + curr, 0) / numbers.length;
      case 'min':
        return Math.min(...numbers);
      case 'max':
        return Math.max(...numbers);
      default:
        return 0;
    }
  };

  const formatValue = (value: number, card: SummaryCard) => {
    const col = tracker.columns.find(c => c.id === card.columnId);
    if (card.format === 'currency') {
      return formatCurrency(value, col?.currencySymbol || '₱');
    }
    if (card.format === 'percent') {
      return formatPercent(value);
    }
    return Number(value).toLocaleString();
  };

  const handleStartAdd = () => {
    setCardTitle('New Metric');
    setCardColumnId(tracker.columns[0]?.id || '');
    setCardCalcType('sum');
    setCardFormat('currency');
    setCardTag('Total');
    setCardColor('indigo');
    setIsAddingCard(true);
    setEditingCard(null);
  };

  const handleStartEdit = (card: SummaryCard) => {
    setEditingCard(card);
    setCardTitle(card.title);
    setCardColumnId(card.columnId);
    setCardCalcType(card.calcType);
    setCardFormat(card.format);
    setCardTag(card.tag);
    setCardColor(card.color);
    setIsAddingCard(false);
  };

  const handleSaveCard = () => {
    if (!cardTitle.trim()) return;

    if (editingCard) {
      const updated = tracker.summaryCards.map(c =>
        c.id === editingCard.id
          ? {
              ...c,
              title: cardTitle.trim(),
              columnId: cardColumnId,
              calcType: cardCalcType,
              format: cardFormat,
              tag: cardTag.trim(),
              color: cardColor
            }
          : c
      );
      onUpdateSummaryCards(updated);
      setEditingCard(null);
    } else {
      const newCard: SummaryCard = {
        id: 'card-' + Date.now(),
        title: cardTitle.trim(),
        columnId: cardColumnId,
        calcType: cardCalcType,
        format: cardFormat,
        tag: cardTag.trim() || 'Total',
        color: cardColor
      };
      onUpdateSummaryCards([...tracker.summaryCards, newCard]);
      setIsAddingCard(false);
    }
  };

  const handleDeleteCard = (id: string) => {
    onUpdateSummaryCards(tracker.summaryCards.filter(c => c.id !== id));
  };

  const getColorClasses = (color: SummaryCard['color']) => {
    switch (color) {
      case 'emerald':
        return 'border-emerald-500/30 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400';
      case 'indigo':
        return 'border-indigo-500/30 bg-indigo-500/5 text-indigo-600 dark:text-indigo-400';
      case 'purple':
        return 'border-purple-500/30 bg-purple-500/5 text-purple-600 dark:text-purple-400';
      case 'amber':
        return 'border-amber-500/30 bg-amber-500/5 text-amber-600 dark:text-amber-400';
      case 'cyan':
        return 'border-cyan-500/30 bg-cyan-500/5 text-cyan-600 dark:text-cyan-400';
      case 'rose':
        return 'border-rose-500/30 bg-rose-500/5 text-rose-600 dark:text-rose-400';
      case 'blue':
        return 'border-blue-500/30 bg-blue-500/5 text-blue-600 dark:text-blue-400';
      default:
        return 'border-slate-500/30 bg-slate-500/5 text-slate-700 dark:text-slate-300';
    }
  };

  const isCollapsed = tracker.summaryCardsCollapsed;
  const isSearchActive = Boolean(internalSearch.trim());

  return (
    <div className="mb-4">
      {/* Executive Summary Bar & Scope Switcher */}
      <div className="flex flex-wrap items-center justify-between pb-2 mb-2 border-b border-slate-200 dark:border-zinc-800 gap-2">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          <h2 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-zinc-300 flex items-center gap-2">
            <span>Executive Dashboard</span>
            {isSearchActive && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-bold border border-amber-300 dark:border-amber-800 animate-pulse">
                Filtered: "{internalSearch}"
              </span>
            )}
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Search in Dashboard (e.g. philtower) */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search (e.g. Philtower, Civil)..."
              value={internalSearch}
              onChange={e => handleSearchChange(e.target.value)}
              className="text-xs pl-7 pr-6 py-1 rounded-md border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-zinc-200 w-44 sm:w-52 outline-none focus:border-indigo-500 transition-colors"
            />
            {internalSearch && (
              <button
                onClick={handleClearSearch}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200"
                title="Clear filter"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Scope Toggle: Active Tracker vs All Trackers Consolidated */}
          <div className="flex items-center bg-slate-100 dark:bg-zinc-800 p-0.5 rounded-lg border border-slate-200 dark:border-zinc-700">
            <button
              onClick={() => setDashboardScope('current')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                dashboardScope === 'current'
                  ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                  : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
              }`}
              title="View metrics for the active tracker"
            >
              Current Tracker ({activeTrackerRows.length})
            </button>
            <button
              onClick={() => setDashboardScope('all')}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                dashboardScope === 'all'
                  ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                  : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
              }`}
              title="Consolidate totals across all different trackers (BP, Civil, Budget, Equipment)"
            >
              <Layers className="w-3 h-3" />
              <span>All Trackers ({allTrackers.length || 1})</span>
            </button>
          </div>

          {dashboardScope === 'current' && (
            <button
              onClick={handleStartAdd}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Card</span>
            </button>
          )}

          <button
            onClick={onToggleCollapse}
            className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 hover:bg-slate-50 dark:hover:bg-zinc-700 shadow-2xs transition-colors"
            title={isCollapsed ? 'Expand Dashboard KPIs (Show metric cards)' : 'Collapse Dashboard KPIs (Maximize vertical space for data table)'}
          >
            {isCollapsed ? (
              <>
                <span>Expand Dashboard</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </>
            ) : (
              <>
                <span>Collapse Dashboard</span>
                <ChevronUp className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      </div>

      {/* Compact Mini Summary Bar when Dashboard KPIs are collapsed (keeps key totals accessible while maximizing vertical space for many data rows) */}
      {isCollapsed && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 rounded-xl border border-indigo-100 dark:border-zinc-800 bg-indigo-50/50 dark:bg-zinc-900/60 text-xs">
          <div className="flex flex-wrap items-center gap-2 sm:gap-4">
            <span className="font-semibold text-slate-500 dark:text-zinc-400">
              {dashboardScope === 'all' ? 'All Trackers Total:' : 'Active Tracker Total:'}
            </span>
            <span className="font-extrabold font-mono text-sm text-emerald-700 dark:text-emerald-400">
              {dashboardScope === 'all'
                ? formatCurrency(crossTrackerSubtotals.grandSubtotal, '₱')
                : formatCurrency(
                    activeTrackerRows.reduce((acc, r) => {
                      const amountCols = tracker.columns.filter(c => c.type === 'amount');
                      return acc + amountCols.reduce((sum, col) => sum + parseNum(r[col.id]), 0);
                    }, 0),
                    '₱'
                  )}
            </span>
            <span className="text-[11px] px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-semibold border border-indigo-200 dark:border-indigo-800">
              {dashboardScope === 'all'
                ? `${crossTrackerSubtotals.totalRows} active records`
                : `${activeTrackerRows.length} active records`}
            </span>
            {dashboardScope === 'all' && (
              <span className="text-[11px] text-slate-500 dark:text-zinc-400">
                Settled: <strong className="text-slate-800 dark:text-zinc-200">{formatCurrency(crossTrackerSubtotals.totalSettled, '₱')}</strong>
              </span>
            )}
          </div>
          <button
            onClick={onToggleCollapse}
            className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
            title="Expand full KPI cards"
          >
            <span>Show full KPI cards & breakdown</span>
            <ChevronDown className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Cards Grid */}
      {!isCollapsed && (
        <>
          {dashboardScope === 'all' ? (
            /* CONSOLIDATED CROSS-TRACKER DASHBOARD WITH TRACKER CHECKBOXES & GENERATOR */
            <div className="space-y-3">
              {/* Tracker Checklist Toolbar */}
              <div className="p-3.5 rounded-xl border border-indigo-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/90 shadow-2xs space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span className="text-xs font-bold text-slate-800 dark:text-zinc-200">
                      Select Trackers to Include in Summary:
                    </span>
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                      {checkedTrackerIds.length} of {allTrackers.length || 1} Selected
                    </span>
                  </div>

                  {/* Quick Selection */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={handleSelectAllTrackers}
                      className="px-2.5 py-1 text-[11px] rounded-lg font-medium border border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
                    >
                      Select All
                    </button>
                    <button
                      type="button"
                      onClick={handleDeselectAllTrackers}
                      className="px-2.5 py-1 text-[11px] rounded-lg font-medium border border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-300 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
                    >
                      Clear All
                    </button>
                  </div>
                </div>

                {/* Tracker Checkbox Pills */}
                <div className="flex flex-wrap gap-2">
                  {allTrackers.map(t => {
                    const isChecked = checkedTrackerIds.includes(t.id);
                    const b = crossTrackerSubtotals.breakdowns.find(item => item.id === t.id);
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => handleToggleTracker(t.id)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                          isChecked
                            ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-400 dark:border-indigo-600 text-indigo-900 dark:text-indigo-200 shadow-2xs ring-1 ring-indigo-400/40'
                            : 'bg-slate-50 dark:bg-zinc-800/50 border-slate-200 dark:border-zinc-700 text-slate-400 dark:text-zinc-500 hover:border-slate-300'
                        }`}
                      >
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-400 dark:text-zinc-600" />
                        )}
                        <span>{t.name}</span>
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                            isChecked
                              ? 'bg-indigo-200/70 dark:bg-indigo-900/70 text-indigo-800 dark:text-indigo-200 font-bold'
                              : 'bg-slate-200/60 dark:bg-zinc-700 text-slate-500'
                          }`}
                        >
                          {formatCurrency(b?.subtotalAmount || 0, '₱')}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Four Main KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {/* Total Across Checked Trackers */}
                <div
                  className={`rounded-xl p-3.5 border transition-all shadow-2xs ${
                    isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400">
                      Grand Total ({checkedTrackerIds.length} Checked)
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                      Consolidated
                    </span>
                  </div>
                  <div className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                    {formatCurrency(crossTrackerSubtotals.grandSubtotal, '₱')}
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500 dark:text-zinc-400 font-medium">
                    <span>Active records: {crossTrackerSubtotals.totalRows}</span>
                    <span className="text-emerald-600 font-semibold">
                      {isSearchActive ? 'Filtered by search' : 'Grand Total'}
                    </span>
                  </div>
                </div>

                {/* Total Settled / Paid */}
                <div
                  className={`rounded-xl p-3.5 border transition-all shadow-2xs ${
                    isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400">
                      Total Settled / Paid
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-500/30 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                      Settled
                    </span>
                  </div>
                  <div className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight text-indigo-600 dark:text-indigo-400">
                    {formatCurrency(crossTrackerSubtotals.totalSettled, '₱')}
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500 dark:text-zinc-400 font-medium">
                    <span>Cost & Invoices:</span>
                    <span className="font-semibold text-slate-700 dark:text-zinc-200">
                      {formatCurrency(crossTrackerSubtotals.totalCost, '₱')}
                    </span>
                  </div>
                </div>

                {/* Pending / Balance */}
                <div
                  className={`rounded-xl p-3.5 border transition-all shadow-2xs ${
                    isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400">
                      Pending / Remaining Balance
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-500/30 bg-amber-500/10 text-amber-600 dark:text-amber-400">
                      Balance
                    </span>
                  </div>
                  <div className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight text-amber-600 dark:text-amber-400">
                    {formatCurrency(crossTrackerSubtotals.pendingBalance, '₱')}
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500 dark:text-zinc-400 font-medium">
                    <span>Billing Requests:</span>
                    <span className="font-semibold text-amber-600">
                      {formatCurrency(crossTrackerSubtotals.totalBilling, '₱')}
                    </span>
                  </div>
                </div>

                {/* Overall Operational Completion */}
                <div
                  className={`rounded-xl p-3.5 border transition-all shadow-2xs ${
                    isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400">
                      Cross-Tracker Completion
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border border-indigo-500/30 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                      Status Rate
                    </span>
                  </div>
                  <div className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                    {crossTrackerSubtotals.completionRate}%
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-zinc-800 h-1.5 rounded-full mt-2 overflow-hidden">
                    <div
                      className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${crossTrackerSubtotals.completionRate}%` }}
                    />
                  </div>
                  <div className="mt-1 text-[10px] text-slate-400 font-medium">
                    {crossTrackerSubtotals.completedCount} of {crossTrackerSubtotals.totalRows} items finalized
                  </div>
                </div>
              </div>

              {/* Action Toolbar for Cross-Tracker Totals */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50/80 dark:bg-zinc-900/60">
                <div className="text-xs text-slate-600 dark:text-zinc-400 font-medium">
                  Total for <strong className="text-slate-900 dark:text-zinc-100">{checkedTrackerIds.length}</strong> checked trackers
                  {isSearchActive ? ` matching "${internalSearch}"` : ''}:{' '}
                  <strong className="text-emerald-600 dark:text-emerald-400">
                    {formatCurrency(crossTrackerSubtotals.grandSubtotal, '₱')}
                  </strong>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopySubtotalReport}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 shadow-2xs transition-colors"
                    title="Copy formatted summary to clipboard"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy Summary'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleExportSubtotalCSV}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 shadow-2xs transition-colors"
                    title="Export CSV of summary breakdown"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export CSV</span>
                  </button>
                </div>
              </div>

              {/* Detailed Breakdown Cards by Tracker */}
              <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900/60">
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsBreakdownCollapsed(prev => !prev)}
                      className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-zinc-300 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                      title={isBreakdownCollapsed ? 'Expand tracker breakdown' : 'Collapse tracker breakdown'}
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5 text-indigo-600" />
                      <span>Detailed Breakdown by Tracker {isSearchActive ? `(Filtered for "${internalSearch}")` : ''}</span>
                      {isBreakdownCollapsed ? (
                        <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                      ) : (
                        <ChevronUp className="w-3.5 h-3.5 text-slate-400" />
                      )}
                    </button>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-200 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400 font-semibold">
                      {crossTrackerSubtotals.breakdowns.length} trackers
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-500 dark:text-zinc-400 hidden sm:inline">
                      Click any card to toggle inclusion in total
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsBreakdownCollapsed(prev => !prev)}
                      className="px-2 py-0.5 text-[11px] font-semibold rounded bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-300 hover:bg-slate-100"
                    >
                      {isBreakdownCollapsed ? 'Expand' : 'Collapse'}
                    </button>
                  </div>
                </div>

                {!isBreakdownCollapsed && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 text-xs">
                    {crossTrackerSubtotals.breakdowns.map(item => (
                      <div
                        key={item.id}
                        onClick={() => handleToggleTracker(item.id)}
                        className={`p-3 rounded-xl border cursor-pointer transition-all ${
                          item.isChecked
                            ? 'border-indigo-500 bg-white dark:bg-zinc-900 shadow-xs ring-1 ring-indigo-400/50'
                            : 'border-slate-200 dark:border-zinc-800 bg-slate-100/60 dark:bg-zinc-800/40 opacity-70 hover:opacity-100'
                        }`}
                      >
                        <div className="flex items-center justify-between font-semibold text-slate-800 dark:text-zinc-200 truncate mb-1.5">
                          <div className="flex items-center gap-1.5 truncate">
                            {item.isChecked ? (
                              <CheckSquare className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                            ) : (
                              <Square className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            )}
                            <span className="truncate">{item.name}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono shrink-0">
                            {item.matchedRows} rows
                          </span>
                        </div>

                        <div className="flex items-baseline justify-between mb-1">
                          <span className="text-base font-extrabold text-slate-900 dark:text-white">
                            {formatCurrency(item.subtotalAmount, '₱')}
                          </span>
                          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold">
                            {item.completedCount} done
                          </span>
                        </div>

                        <div className="pt-1.5 border-t border-slate-100 dark:border-zinc-800 flex items-center justify-between text-[10px] text-slate-500 dark:text-zinc-400">
                          <span>Settled: {formatCurrency(item.settledAmount, '₱')}</span>
                          <span className={item.billingReqAmount > item.settledAmount ? 'text-amber-600 font-semibold' : ''}>
                            Req: {formatCurrency(item.billingReqAmount, '₱')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* CURRENT TRACKER METRIC CARDS */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {tracker.summaryCards.map(card => {
                const rawVal = computeValue(card);
                const displayVal = formatValue(rawVal, card);

                return (
                  <div
                    key={card.id}
                    className={`relative group rounded-xl p-3.5 border transition-all shadow-2xs hover:shadow-sm ${
                      isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-slate-200'
                    }`}
                  >
                    {/* Top: Title & Tag */}
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <span className="text-xs font-semibold text-slate-500 dark:text-zinc-400 truncate">
                        {card.title}
                      </span>
                      {card.tag && (
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getColorClasses(
                            card.color
                          )}`}
                        >
                          {card.tag}
                        </span>
                      )}
                    </div>

                    {/* Metric Value */}
                    <div className="flex items-baseline justify-between mt-1">
                      <div className="text-xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                        {displayVal}
                      </div>
                      <span className="text-[10px] text-slate-400 font-medium capitalize">
                        {card.calcType}
                      </span>
                    </div>

                    {/* Progress bar visual for percent cards */}
                    {card.format === 'percent' && (
                      <div className="w-full bg-slate-100 dark:bg-zinc-800 h-1.5 rounded-full mt-2.5 overflow-hidden">
                        <div
                          className="bg-indigo-600 h-full rounded-full transition-all duration-500"
                          style={{ width: `${Math.min(100, Math.max(0, rawVal))}%` }}
                        />
                      </div>
                    )}

                    {/* Filter info badge if search query is present */}
                    {isSearchActive && (
                      <div className="mt-2 pt-1 border-t border-slate-100 dark:border-zinc-800 text-[10px] text-amber-600 dark:text-amber-400 font-medium flex items-center justify-between">
                        <span>Total for matches</span>
                        <span>{activeTrackerRows.length} rows</span>
                      </div>
                    )}

                    {/* Card hover actions */}
                    <div className="absolute top-2 right-2 hidden group-hover:flex items-center gap-1 bg-white/90 dark:bg-zinc-800/90 rounded px-1.5 py-0.5 shadow-xs border border-slate-200 dark:border-zinc-700">
                      <button
                        onClick={() => handleStartEdit(card)}
                        title="Edit Card & Tag"
                        className="p-1 text-slate-500 hover:text-indigo-600"
                      >
                        <Edit2 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleDeleteCard(card.id)}
                        title="Delete Card"
                        className="p-1 text-slate-500 hover:text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Add / Edit Summary Card Modal/Drawer */}
      {(isAddingCard || editingCard) && (
        <div className="mt-3 p-4 rounded-xl border border-indigo-200 dark:border-indigo-900 bg-indigo-50/40 dark:bg-indigo-950/20 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-800 dark:text-zinc-200">
              {editingCard ? 'Edit Summary Card' : 'Add New Summary Card'}
            </h4>
            <button
              onClick={() => {
                setIsAddingCard(false);
                setEditingCard(null);
              }}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 text-xs"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase">Card Title</label>
              <input
                type="text"
                value={cardTitle}
                onChange={e => setCardTitle(e.target.value)}
                placeholder="e.g. Total Amount"
                className="w-full text-xs px-2.5 py-1.5 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase">Target Column</label>
              <select
                value={cardColumnId}
                onChange={e => setCardColumnId(e.target.value)}
                className="w-full text-xs px-2 py-1.5 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
              >
                {tracker.columns.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.type})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase">Calculation</label>
              <select
                value={cardCalcType}
                onChange={e => setCardCalcType(e.target.value as any)}
                className="w-full text-xs px-2 py-1.5 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
              >
                <option value="sum">Sum (Total)</option>
                <option value="average">Average</option>
                <option value="count">Count (Rows)</option>
                <option value="count-completed">Count (Completed)</option>
                <option value="min">Minimum</option>
                <option value="max">Maximum</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase">Format</label>
              <select
                value={cardFormat}
                onChange={e => setCardFormat(e.target.value as any)}
                className="w-full text-xs px-2 py-1.5 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
              >
                <option value="currency">Currency (₱ Peso)</option>
                <option value="percent">Percentage (%)</option>
                <option value="number">Plain Number</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase">Tag / Badge</label>
              <input
                type="text"
                value={cardTag}
                onChange={e => setCardTag(e.target.value)}
                placeholder="e.g. Total"
                className="w-full text-xs px-2.5 py-1.5 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-500 uppercase">Color Accent</label>
              <select
                value={cardColor}
                onChange={e => setCardColor(e.target.value as any)}
                className="w-full text-xs px-2 py-1.5 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
              >
                <option value="indigo">Indigo</option>
                <option value="emerald">Emerald</option>
                <option value="blue">Blue</option>
                <option value="purple">Purple</option>
                <option value="amber">Amber</option>
                <option value="rose">Rose</option>
                <option value="cyan">Cyan</option>
                <option value="slate">Slate</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              onClick={() => {
                setIsAddingCard(false);
                setEditingCard(null);
              }}
              className="px-3 py-1.5 text-xs text-slate-600 dark:text-zinc-300 hover:text-slate-900"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveCard}
              className="px-4 py-1.5 text-xs font-semibold rounded bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
            >
              Save Metric Card
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
