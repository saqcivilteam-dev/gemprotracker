import React, { useState } from 'react';
import { Share2, Copy, Check, Users, Database, Globe } from 'lucide-react';

interface ShareModalProps {
  isDark: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ isDark, onClose }) => {
  const [copied, setCopied] = useState(false);
  const shareUrl = window.location.href;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-md rounded-2xl border shadow-xl flex flex-col overflow-hidden ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="font-bold text-sm">Share Workspace with Team</h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Co-workers and friends can access the live shared database
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-slate-600">
            ✕
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <div>
            <label className="font-bold text-slate-700 dark:text-zinc-300 block mb-1.5">
              Live Cloud App URL
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="w-full text-xs font-mono px-3 py-2 rounded-lg border border-slate-300 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
              />
              <button
                onClick={handleCopy}
                className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold flex items-center gap-1.5 shrink-0 shadow-xs"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <div className="p-3.5 rounded-xl border border-indigo-100 dark:border-indigo-900/60 bg-indigo-50/50 dark:bg-indigo-950/20 space-y-2">
            <div className="flex items-center gap-2 font-bold text-indigo-900 dark:text-indigo-300">
              <Users className="w-4 h-4 text-indigo-600" />
              <span>How your teammates join:</span>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-slate-600 dark:text-zinc-300 text-[11px] leading-relaxed">
              <li>Send this link to your co-workers or team members.</li>
              <li>They click <strong>"Register"</strong> and input their email and department.</li>
              <li>You (as the <strong>Administrator</strong>) will see their request in <strong>Guest Approvals</strong>.</li>
              <li>Approve them as <strong>Editor</strong> or <strong>Viewer</strong>.</li>
              <li>They can instantly view or update the live cloud tracker!</li>
            </ol>
          </div>
        </div>

        <div className="p-4 border-t border-slate-200 dark:border-zinc-800 flex justify-end bg-slate-50/50 dark:bg-zinc-800/40">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-900 dark:bg-zinc-700 text-white"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
