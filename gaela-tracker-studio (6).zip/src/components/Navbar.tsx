import React from 'react';
import {
  Cloud,
  CloudOff,
  RefreshCw,
  Users,
  FileText,
  Palette,
  LogOut,
  Shield,
  UserCheck,
  Share2,
  Sliders,
  ChevronDown,
  Key,
  Search,
  Undo2,
  Redo2,
  Lock,
  Unlock,
  ShieldCheck,
  Presentation,
  HardDrive,
  Zap,
  Bell,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';
import { AppState, User } from '../types/tracker';
import { themes } from '../utils/theme';

interface NavbarProps {
  state: AppState;
  currentUser: User | null;
  isSidebarOpen?: boolean;
  onToggleSidebar?: () => void;
  isOnline: boolean;
  isSyncing: boolean;
  canUndo?: boolean;
  canRedo?: boolean;
  onUndo?: () => void;
  onRedo?: () => void;
  isDataProtected?: boolean;
  onToggleDataProtection?: () => void;
  onSync: () => void;
  onOpenGlobalSearch: () => void;
  onOpenGoogleDrive?: () => void;
  onOpenSiteGenerator?: () => void;
  onOpenSaqWarnings?: () => void;
  saqWarningCount?: number;
  onOpenGuestApprovals: () => void;
  onOpenReport: () => void;
  onOpenPresentation?: () => void;
  onOpenTheme: () => void;
  onOpenSettings: () => void;
  onOpenShare: () => void;
  onOpenChangePassword?: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  state,
  currentUser,
  isSidebarOpen,
  onToggleSidebar,
  isOnline,
  isSyncing,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  isDataProtected,
  onToggleDataProtection,
  onSync,
  onOpenGlobalSearch,
  onOpenGoogleDrive,
  onOpenSiteGenerator,
  onOpenSaqWarnings,
  saqWarningCount,
  onOpenGuestApprovals,
  onOpenReport,
  onOpenPresentation,
  onOpenTheme,
  onOpenSettings,
  onOpenShare,
  onOpenChangePassword,
  onLogout
}) => {
  const currentTracker = state.trackers.find(t => t.id === state.activeTrackerId) || state.trackers[0];
  const pendingGuestsCount = state.users.filter(u => u.status === 'pending').length;
  const currentTheme = themes[state.theme] || themes.slate;
  const isDark = state.theme === 'dark';

  return (
    <header className={`h-15 border-b px-4 flex items-center justify-between gap-3 sticky top-0 z-30 transition-colors ${
      isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-800 shadow-xs'
    }`}>
      {/* Brand & Tracker Name */}
      <div className="flex items-center gap-3 min-w-0">
        {onToggleSidebar && (
          <button
            type="button"
            onClick={onToggleSidebar}
            className="p-1.5 rounded-lg border border-slate-200 dark:border-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-600 dark:text-zinc-300 transition-colors cursor-pointer"
            title={isSidebarOpen ? 'Collapse Folder Explorer Sidebar' : 'Expand Folder Explorer Sidebar'}
          >
            {isSidebarOpen ? <PanelLeftClose className="w-4 h-4 text-indigo-500" /> : <PanelLeftOpen className="w-4 h-4" />}
          </button>
        )}

        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-indigo-600 to-blue-500 text-white font-black flex items-center justify-center shadow-sm text-sm">
            G
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-tight">{state.appName}</span>
              <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/60 dark:bg-indigo-950/60 dark:text-indigo-300 dark:border-indigo-800">
                Studio
              </span>
            </div>
          </div>
        </div>

        <div className="hidden md:flex items-center text-slate-300 dark:text-zinc-700">/</div>

        {/* Current Active Tracker Label */}
        <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-md bg-slate-100 dark:bg-zinc-800 text-xs font-semibold text-slate-700 dark:text-zinc-200 border border-slate-200/80 dark:border-zinc-700">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="truncate max-w-[200px]">{currentTracker?.name || 'General Tracker'}</span>
        </div>
      </div>

      {/* Center / Cloud Sync & Offline Status */}
      <div className="flex items-center gap-2">
        <button
          onClick={onSync}
          disabled={isSyncing}
          title={isOnline ? "Free Cloud Database Synchronized" : "Working in Offline Mode"}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border transition-all ${
            isOnline
              ? isDark 
                ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800 hover:bg-emerald-900/40'
                : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
              : isDark
                ? 'bg-amber-950/40 text-amber-300 border-amber-800 hover:bg-amber-900/40'
                : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
          }`}
        >
          {isOnline ? (
            <Cloud className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          ) : (
            <CloudOff className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          )}
          <span className="hidden lg:inline">
            {isOnline ? 'Cloud Synced' : 'Offline Mode (Local)'}
          </span>
          <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
        </button>

        {/* Undo and Redo History Controls */}
        <div className="flex items-center gap-1 border-r border-slate-200 dark:border-zinc-800 pr-1.5 mr-0.5">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            title="Undo last change (Ctrl+Z)"
            className={`p-1.5 rounded-lg text-xs font-semibold border transition-all ${
              canUndo
                ? isDark
                  ? 'bg-zinc-800 text-zinc-200 border-zinc-700 hover:bg-zinc-700'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50 shadow-2xs'
                : 'opacity-35 cursor-not-allowed border-transparent text-slate-400'
            }`}
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            title="Redo change (Ctrl+Y)"
            className={`p-1.5 rounded-lg text-xs font-semibold border transition-all ${
              canRedo
                ? isDark
                  ? 'bg-zinc-800 text-zinc-200 border-zinc-700 hover:bg-zinc-700'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50 shadow-2xs'
                : 'opacity-35 cursor-not-allowed border-transparent text-slate-400'
            }`}
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Data Protection Lock / Edit Mode Switch */}
        {onToggleDataProtection && (
          <button
            onClick={onToggleDataProtection}
            title={
              isDataProtected
                ? 'Data Protection Mode Active: Prevents accidental deletes and typo changes. Click to Unlock.'
                : 'Edit Mode Active: Changes are permitted. Click to Lock and protect data.'
            }
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold border transition-all ${
              isDataProtected
                ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800 shadow-2xs'
                : 'bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-800 shadow-2xs'
            }`}
          >
            {isDataProtected ? (
              <>
                <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span className="hidden md:inline">Protected</span>
              </>
            ) : (
              <>
                <Unlock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span className="hidden md:inline">Edit Mode</span>
              </>
            )}
          </button>
        )}

        <button
          onClick={onOpenGlobalSearch}
          title="Search sites, BP payment requests, dates, and amounts across all trackers"
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
            isDark
              ? 'bg-indigo-950/40 text-indigo-300 border-indigo-800 hover:bg-indigo-900/60'
              : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100 shadow-2xs'
          }`}
        >
          <Search className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
          <span className="hidden sm:inline">Search All Trackers</span>
          <span className="sm:hidden">Search</span>
        </button>

        {/* SAQ Process SLA Warning Center Button */}
        {onOpenSaqWarnings && (
          <button
            onClick={onOpenSaqWarnings}
            title="SAQ Process SLA Warning Center & Day-by-Day Reports (21d Prop Docs / 44d Pre-Con / 21d Post-Con / 7d FAC)"
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
              (saqWarningCount || 0) > 0
                ? 'bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-700 shadow-2xs hover:bg-amber-100'
                : 'bg-slate-50 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300 border-slate-200 dark:border-zinc-700 hover:bg-slate-100'
            }`}
          >
            <Bell className={`w-3.5 h-3.5 ${(saqWarningCount || 0) > 0 ? 'text-amber-600 dark:text-amber-400 animate-pulse' : 'text-slate-500'}`} />
            <span className="hidden md:inline">SAQ SLA Warnings</span>
            <span className="md:hidden">SLA</span>
            {(saqWarningCount || 0) > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-500 text-white leading-none">
                {saqWarningCount}
              </span>
            )}
          </button>
        )}

        {/* Google Drive Integration Button */}
        <button
          onClick={onOpenGoogleDrive}
          title="Connect to Google Drive to backup, save, and sync tracker files directly in the cloud"
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
            isDark
              ? 'bg-blue-950/40 text-blue-300 border-blue-800 hover:bg-blue-900/60'
              : 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100 shadow-2xs'
          }`}
        >
          <HardDrive className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          <span className="hidden md:inline">Google Drive</span>
          <span className="md:hidden">Drive</span>
        </button>

        {/* Rapid 100K Site Generator Button */}
        <button
          onClick={onOpenSiteGenerator}
          title="Rapid site generator: generate 1,000 to 100,000 site records with milestone & budget KPIs in seconds"
          className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
            isDark
              ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800 hover:bg-emerald-900/60'
              : 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100 shadow-2xs'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 fill-current" />
          <span className="hidden sm:inline">⚡ 100K Sites</span>
          <span className="sm:hidden">⚡ 100K</span>
        </button>

        <button
          onClick={onOpenShare}
          title="Share live cloud tracker link with team"
          className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors ${
            isDark 
              ? 'bg-zinc-800 border-zinc-700 hover:bg-zinc-700 text-zinc-200' 
              : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700 shadow-2xs'
          }`}
        >
          <Share2 className="w-3.5 h-3.5 text-indigo-500" />
          <span>Share</span>
        </button>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2">
        {/* Guest Approvals Button (Prominent for Admin) */}
        {currentUser?.role === 'admin' && (
          <button
            onClick={onOpenGuestApprovals}
            className={`relative flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              pendingGuestsCount > 0
                ? 'bg-amber-500 text-white border-amber-600 hover:bg-amber-600 animate-pulse'
                : isDark
                  ? 'bg-zinc-800 border-zinc-700 text-zinc-200 hover:bg-zinc-700'
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 shadow-2xs'
            }`}
            title="Manage registered guests and assign Editor/Viewer roles"
          >
            <Users className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Guest Approvals</span>
            {pendingGuestsCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center">
                {pendingGuestsCount}
              </span>
            )}
          </button>
        )}

        {/* Executive Presentation Deck Button */}
        {onOpenPresentation && (
          <button
            onClick={onOpenPresentation}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              isDark
                ? 'bg-indigo-950/50 text-indigo-300 border-indigo-800 hover:bg-indigo-900/60'
                : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100 shadow-2xs'
            }`}
            title={`Launch Executive Presentation Deck • Connected to Dashboard (${currentTracker?.summaryCards?.length || 0} KPIs available to report)`}
          >
            <Presentation className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            <span className="hidden md:inline">Presentation</span>
            {(currentTracker?.summaryCards?.length || 0) > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-indigo-200/80 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200 leading-none" title="Connected to Dashboard KPIs">
                {currentTracker.summaryCards.length} KPIs
              </span>
            )}
          </button>
        )}

        {/* Generate Report to PDF */}
        <button
          onClick={onOpenReport}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors"
          title="Generate clean, printable PDF report with preserved highlights"
        >
          <FileText className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">PDF Report</span>
        </button>

        {/* Theme button */}
        <button
          onClick={onOpenTheme}
          title="Change theme color"
          className={`p-1.5 rounded-lg border transition-colors ${
            isDark ? 'bg-zinc-800 border-zinc-700 hover:bg-zinc-700' : 'bg-white border-slate-200 hover:bg-slate-50 shadow-2xs'
          }`}
        >
          <Palette className="w-4 h-4 text-slate-600 dark:text-zinc-300" />
        </button>

        {/* Settings button */}
        <button
          onClick={onOpenSettings}
          title="Tracker settings"
          className={`p-1.5 rounded-lg border transition-colors ${
            isDark ? 'bg-zinc-800 border-zinc-700 hover:bg-zinc-700' : 'bg-white border-slate-200 hover:bg-slate-50 shadow-2xs'
          }`}
        >
          <Sliders className="w-4 h-4 text-slate-600 dark:text-zinc-300" />
        </button>

        {/* Admin Change Password shortcut */}
        {currentUser?.role === 'admin' && onOpenChangePassword && (
          <button
            onClick={onOpenChangePassword}
            title="Change Admin Password"
            className={`p-1.5 rounded-lg border transition-colors ${
              isDark
                ? 'bg-zinc-800 border-zinc-700 hover:bg-zinc-700 text-indigo-400'
                : 'bg-white border-slate-200 hover:bg-slate-50 text-indigo-600 shadow-2xs'
            }`}
          >
            <Key className="w-4 h-4" />
          </button>
        )}

        {/* Current User Badge */}
        <div className="flex items-center gap-2 pl-1 border-l border-slate-200 dark:border-zinc-800">
          <div className="flex flex-col text-right">
            <span className="text-xs font-bold leading-tight truncate max-w-[130px]">
              {currentUser?.role === 'admin'
                ? (currentUser.username && currentUser.username.toLowerCase().includes('malonzo') ? 'Administrator' : (currentUser.username || 'Admin'))
                : (currentUser?.username || 'User')}
            </span>
            <span className="text-[10px] font-medium leading-none text-slate-500 dark:text-zinc-400 capitalize flex items-center justify-end gap-1">
              {currentUser?.role === 'admin' ? (
                <>
                  <Shield className="w-2.5 h-2.5 text-amber-500" />
                  Admin
                </>
              ) : (
                <>
                  <UserCheck className="w-2.5 h-2.5 text-blue-500" />
                  Guest ({currentUser?.permission || 'viewer'})
                </>
              )}
            </span>
          </div>

          <button
            onClick={onLogout}
            title="Sign out"
            className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
