import React, { useState, useMemo } from 'react';
import {
  LayoutDashboard,
  Users,
  Database,
  ShieldCheck,
  KeyRound,
  FileSpreadsheet,
  CheckCircle2,
  XCircle,
  Clock,
  Trash2,
  Edit,
  Plus,
  Search,
  Filter,
  Download,
  AlertCircle,
  Eye,
  PlusCircle,
  Edit3,
  Columns,
  EyeOff,
  UserCheck,
  UserX,
  UserPlus,
  RefreshCw,
  Sliders,
  ShieldAlert,
  ChevronRight,
  ArrowUpDown
} from 'lucide-react';
import {
  AppState,
  User,
  Tracker,
  TrackerPermission,
  AccessRequest,
  ActivityLog,
  FieldAccessLevel,
  UserRole
} from '../types/tracker';
import { exportToCSV } from '../utils/storage';
import * as XLSX from 'xlsx';

type AdminTab = 'dashboard' | 'users' | 'trackers' | 'requests' | 'permissions' | 'logs';

interface AdminPortalModalProps {
  state: AppState;
  currentUser: User;
  isDark: boolean;
  initialTab?: AdminTab;
  onClose: () => void;
  onSavePermission: (permission: TrackerPermission) => Promise<boolean>;
  onRevokePermission: (userId: string, trackerId: string) => Promise<boolean>;
  onReviewAccessRequest: (
    requestId: string,
    action: 'approve' | 'reject' | 'edit-approve' | 'revoke',
    permissions?: Partial<TrackerPermission>,
    adminNote?: string
  ) => Promise<boolean>;
  onManageUser: (payload: {
    targetUserId?: string;
    action: 'create' | 'update-role' | 'update-status' | 'reset-password' | 'delete';
    role?: UserRole;
    status?: 'approved' | 'pending' | 'rejected';
    department?: string;
    password?: string;
    username?: string;
    email?: string;
  }) => Promise<boolean>;
  onNotify?: (message: string, type?: 'success' | 'info' | 'error') => void;
}

export const AdminPortalModal: React.FC<AdminPortalModalProps> = ({
  state,
  currentUser,
  isDark,
  initialTab = 'dashboard',
  onClose,
  onSavePermission,
  onRevokePermission,
  onReviewAccessRequest,
  onManageUser,
  onNotify
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>(initialTab);

  // --- Users Tab State ---
  const [userSearch, setUserSearch] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<'all' | UserRole>('all');
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState<UserRole>('staff');
  const [newUserDept, setNewUserDept] = useState('');
  const [newUserPass, setNewUserPass] = useState('user123');

  // --- Permissions Tab State ---
  const eligibleUsers = useMemo(() => {
    return state.users.filter(u => u.role !== 'admin');
  }, [state.users]);

  const [selectedUserId, setSelectedUserId] = useState<string>(
    eligibleUsers[0]?.id || state.users[1]?.id || ''
  );
  const [selectedTrackerId, setSelectedTrackerId] = useState<string>(
    state.activeTrackerId || state.trackers[0]?.id || ''
  );

  // Current permission draft for (selectedUserId, selectedTrackerId)
  const existingPerm = useMemo(() => {
    return (state.trackerPermissions || []).find(
      p => p.userId === selectedUserId && p.trackerId === selectedTrackerId
    );
  }, [state.trackerPermissions, selectedUserId, selectedTrackerId]);

  const [permCanView, setPermCanView] = useState<boolean>(true);
  const [permCanAdd, setPermCanAdd] = useState<boolean>(false);
  const [permCanEdit, setPermCanEdit] = useState<boolean>(true);
  const [permCanDelete, setPermCanDelete] = useState<boolean>(false);
  const [permCanExport, setPermCanExport] = useState<boolean>(false);
  const [fieldPermsDraft, setFieldPermsDraft] = useState<Record<string, FieldAccessLevel>>({});

  // Sync draft when user or tracker changes
  React.useEffect(() => {
    if (existingPerm) {
      setPermCanView(existingPerm.canView);
      setPermCanAdd(existingPerm.canAdd);
      setPermCanEdit(existingPerm.canEdit);
      setPermCanDelete(existingPerm.canDelete);
      setPermCanExport(existingPerm.canExport);
      setFieldPermsDraft(existingPerm.fieldPermissions || {});
    } else {
      const targetUser = state.users.find(u => u.id === selectedUserId);
      const isStaff = targetUser?.role === 'staff';
      setPermCanView(isStaff);
      setPermCanAdd(false);
      setPermCanEdit(isStaff);
      setPermCanDelete(false);
      setPermCanExport(false);
      setFieldPermsDraft({});
    }
  }, [existingPerm, selectedUserId, selectedTrackerId]);

  const targetTracker = state.trackers.find(t => t.id === selectedTrackerId) || state.trackers[0];
  const targetUserObj = state.users.find(u => u.id === selectedUserId);

  // --- Access Requests Tab State ---
  const [reqStatusFilter, setReqStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected' | 'revoked'>('all');
  const [editingRequest, setEditingRequest] = useState<AccessRequest | null>(null);
  const [editReqView, setEditReqView] = useState<boolean>(true);
  const [editReqAdd, setEditReqAdd] = useState<boolean>(false);
  const [editReqEdit, setEditReqEdit] = useState<boolean>(true);
  const [editReqDelete, setEditReqDelete] = useState<boolean>(false);
  const [editReqExport, setEditReqExport] = useState<boolean>(false);
  const [editReqFields, setEditReqFields] = useState<Record<string, FieldAccessLevel>>({});
  const [editReqNote, setEditReqNote] = useState<string>('');

  const openEditRequestModal = (req: AccessRequest) => {
    setEditingRequest(req);
    setEditReqView(req.requestedPermissions.view ?? true);
    setEditReqAdd(req.requestedPermissions.add ?? false);
    setEditReqEdit(req.requestedPermissions.edit ?? true);
    setEditReqDelete(req.requestedPermissions.delete ?? false);
    setEditReqExport(req.requestedPermissions.export ?? false);
    setEditReqNote(req.adminNote || '');

    const tracker = state.trackers.find(t => t.id === req.trackerId);
    const initialFieldMap: Record<string, FieldAccessLevel> = {};
    for (const col of tracker?.columns || []) {
      if (req.requestedFields.includes(col.id)) {
        initialFieldMap[col.id] = 'edit';
      } else {
        initialFieldMap[col.id] = 'view';
      }
    }
    setEditReqFields(initialFieldMap);
  };

  // --- Activity Log Tab State ---
  const [logSearch, setLogSearch] = useState('');
  const [logActionFilter, setLogActionFilter] = useState<string>('all');
  const [logTrackerFilter, setLogTrackerFilter] = useState<string>('all');

  const filteredLogs = useMemo(() => {
    let logs = state.activityLogs || [];
    if (logTrackerFilter !== 'all') {
      logs = logs.filter(l => l.trackerId === logTrackerFilter);
    }
    if (logActionFilter !== 'all') {
      logs = logs.filter(l => l.action.toLowerCase().includes(logActionFilter.toLowerCase()));
    }
    if (logSearch.trim()) {
      const q = logSearch.toLowerCase();
      logs = logs.filter(
        l =>
          l.userName?.toLowerCase().includes(q) ||
          l.action?.toLowerCase().includes(q) ||
          l.trackerName?.toLowerCase().includes(q) ||
          l.changedField?.toLowerCase().includes(q) ||
          l.details?.toLowerCase().includes(q) ||
          String(l.newValue || '').toLowerCase().includes(q) ||
          String(l.oldValue || '').toLowerCase().includes(q)
      );
    }
    return logs;
  }, [state.activityLogs, logTrackerFilter, logActionFilter, logSearch]);

  const pendingRequestsCount = useMemo(() => {
    return (state.accessRequests || []).filter(r => r.status === 'pending').length;
  }, [state.accessRequests]);

  // Handlers
  const handleSaveCurrentPermission = async () => {
    if (!selectedUserId || !selectedTrackerId) return;

    const newPerm: TrackerPermission = {
      id: existingPerm?.id || `perm-${selectedUserId}-${selectedTrackerId}`,
      userId: selectedUserId,
      trackerId: selectedTrackerId,
      canView: permCanView,
      canAdd: permCanAdd,
      canEdit: permCanEdit,
      canDelete: permCanDelete,
      canExport: permCanExport,
      fieldPermissions: fieldPermsDraft,
      approvedBy: `${currentUser.username} (${currentUser.email})`,
      updatedAt: new Date().toISOString()
    };

    const success = await onSavePermission(newPerm);
    if (success && onNotify) {
      onNotify(`Permissions saved for ${targetUserObj?.username || 'user'} on ${targetTracker?.name || 'tracker'}.`, 'success');
    }
  };

  const handleRevokeCurrentPermission = async () => {
    if (!selectedUserId || !selectedTrackerId) return;
    const success = await onRevokePermission(selectedUserId, selectedTrackerId);
    if (success && onNotify) {
      onNotify(`Access revoked for ${targetUserObj?.username || 'user'}.`, 'info');
    }
  };

  const handleCreateUserSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserEmail.trim()) {
      if (onNotify) onNotify('Name and Email are required.', 'error');
      return;
    }

    const success = await onManageUser({
      action: 'create',
      username: newUserName.trim(),
      email: newUserEmail.trim(),
      role: newUserRole,
      department: newUserDept.trim(),
      password: newUserPass.trim()
    });

    if (success) {
      if (onNotify) onNotify(`User account created for ${newUserName} (${newUserRole})!`, 'success');
      setShowAddUserModal(false);
      setNewUserName('');
      setNewUserEmail('');
      setNewUserDept('');
      setNewUserPass('user123');
    }
  };

  const handleExportLogsExcel = () => {
    if (filteredLogs.length === 0) {
      if (onNotify) onNotify('No logs to export.', 'info');
      return;
    }

    const dataRows = filteredLogs.map(l => ({
      Timestamp: new Date(l.timestamp).toLocaleString(),
      User: l.userName,
      Email: l.userEmail || '',
      Role: l.userRole || '',
      Tracker: l.trackerName || '',
      Action: l.action,
      'Changed Field': l.changedField || '',
      'Old Value': l.oldValue ?? '',
      'New Value': l.newValue ?? '',
      'Approved By': l.approvedBy || '',
      Details: l.details || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Activity Logs');
    XLSX.writeFile(workbook, `Gaela-ActivityLogs-${new Date().toISOString().slice(0, 10)}.xlsx`);

    if (onNotify) onNotify('Activity Logs exported to Excel.', 'success');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/65 backdrop-blur-xs overflow-y-auto">
      <div
        className={`w-full max-w-5xl rounded-2xl border shadow-2xl flex flex-col h-[90vh] overflow-hidden ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Top Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between shrink-0 bg-slate-50/50 dark:bg-zinc-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-blue-600 text-white flex items-center justify-center shadow-sm">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-extrabold text-base tracking-tight">Security & Access Management</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 uppercase tracking-wider">
                  Admin Control Panel
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Logged in as <span className="font-semibold text-indigo-600 dark:text-indigo-400">{currentUser.username}</span> · Role-based access & field-level editing control
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-zinc-800 cursor-pointer transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Navigation Tabs Menu (Exact prompt specification: Dashboard | Users | Trackers | Access Requests | Permissions | Activity Log) */}
        <div className="px-5 border-b border-slate-200 dark:border-zinc-800 flex items-center gap-1 overflow-x-auto shrink-0 bg-white dark:bg-zinc-900">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-3.5 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`px-3.5 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'users'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Users</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400">
              {state.users.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('trackers')}
            className={`px-3.5 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'trackers'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Trackers</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400">
              {state.trackers.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('requests')}
            className={`px-3.5 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap relative ${
              activeTab === 'requests'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>Access Requests</span>
            {pendingRequestsCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white animate-pulse">
                {pendingRequestsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('permissions')}
            className={`px-3.5 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'permissions'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Permissions</span>
          </button>

          <button
            onClick={() => setActiveTab('logs')}
            className={`px-3.5 py-3 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap ${
              activeTab === 'logs'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-zinc-400 dark:hover:text-zinc-200'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Activity Log</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400">
              {(state.activityLogs || []).length}
            </span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="flex-1 overflow-y-auto p-5 text-xs">
          {/* ======================================================== */}
          {/* TAB 1: DASHBOARD */}
          {/* ======================================================== */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Summary Stats Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
                <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/60 shadow-2xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-zinc-400">
                    <span className="font-semibold">Total Users</span>
                    <Users className="w-4 h-4 text-indigo-500" />
                  </div>
                  <div className="text-2xl font-black mt-2 text-slate-900 dark:text-zinc-100">
                    {state.users.length}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1.5">
                    <span>{state.users.filter(u => u.role === 'admin').length} Admin</span> ·{' '}
                    <span>{state.users.filter(u => u.role === 'staff').length} Staff</span> ·{' '}
                    <span>{state.users.filter(u => u.role === 'guest').length} Guest</span>
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/60 shadow-2xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-zinc-400">
                    <span className="font-semibold">Trackers</span>
                    <Database className="w-4 h-4 text-blue-500" />
                  </div>
                  <div className="text-2xl font-black mt-2 text-slate-900 dark:text-zinc-100">
                    {state.trackers.length}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    {state.trackers.reduce((acc, t) => acc + t.rows.length, 0)} total records managed
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/60 shadow-2xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-zinc-400">
                    <span className="font-semibold">Pending Requests</span>
                    <Clock className="w-4 h-4 text-amber-500" />
                  </div>
                  <div className="text-2xl font-black mt-2 text-amber-600 dark:text-amber-400">
                    {pendingRequestsCount}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    {pendingRequestsCount > 0 ? (
                      <button
                        onClick={() => setActiveTab('requests')}
                        className="text-amber-600 dark:text-amber-400 font-bold hover:underline cursor-pointer flex items-center gap-1"
                      >
                        Review pending requests →
                      </button>
                    ) : (
                      'All requests reviewed'
                    )}
                  </div>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/60 shadow-2xs">
                  <div className="flex items-center justify-between text-slate-500 dark:text-zinc-400">
                    <span className="font-semibold">Active Permissions</span>
                    <KeyRound className="w-4 h-4 text-emerald-500" />
                  </div>
                  <div className="text-2xl font-black mt-2 text-emerald-600 dark:text-emerald-400">
                    {(state.trackerPermissions || []).filter(p => p.canView).length}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    With granular field editing controls
                  </div>
                </div>
              </div>

              {/* Roles & Security Architecture Overview */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-800/30 space-y-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-zinc-300 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Enforced Security & Access Architecture</span>
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="p-3 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-indigo-700 dark:text-indigo-400">Admin</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 font-semibold">
                        Full Control
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-zinc-400 mt-1.5 leading-relaxed">
                      Complete authority across all trackers, user accounts, approvals, field permissions, database sync, and audit logs.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-blue-700 dark:text-blue-400">Staff</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-semibold">
                        Approved Trackers Only
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-zinc-400 mt-1.5 leading-relaxed">
                      Restricted exclusively to trackers approved by Admin. Governed strictly by View, Add, Edit, Delete, Export and Column-level permissions.
                    </p>
                  </div>

                  <div className="p-3 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-700 dark:text-amber-400">Guest</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-semibold">
                        View Only Unless Approved
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-zinc-400 mt-1.5 leading-relaxed">
                      Read-only access by default upon registration approval. Must submit an Access Request to edit fields or add records.
                    </p>
                  </div>
                </div>
              </div>

              {/* Recent Activity Log Preview */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-zinc-300 flex items-center gap-1.5">
                    <FileSpreadsheet className="w-4 h-4 text-slate-500" />
                    <span>Recent Security & Data Audit Logs</span>
                  </h4>
                  <button
                    onClick={() => setActiveTab('logs')}
                    className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                  >
                    View All Logs ({state.activityLogs?.length || 0}) →
                  </button>
                </div>

                <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden divide-y divide-slate-100 dark:divide-zinc-800">
                  {(state.activityLogs || []).slice(0, 5).map(log => (
                    <div key={log.id} className="p-3 flex items-center justify-between gap-3 bg-white dark:bg-zinc-800/40">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="px-2 py-0.5 rounded-md font-mono text-[10px] font-bold bg-slate-100 dark:bg-zinc-700 text-slate-700 dark:text-zinc-300 shrink-0">
                          {log.action}
                        </span>
                        <div className="truncate">
                          <span className="font-bold text-slate-900 dark:text-zinc-100">{log.userName}</span>{' '}
                          <span className="text-slate-500 dark:text-zinc-400">
                            {log.details || `Modified ${log.changedField || 'data'}`}
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] text-slate-400 shrink-0">
                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 2: USERS */}
          {/* ======================================================== */}
          {activeTab === 'users' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2 flex-1 max-w-md">
                  <div className="relative flex-1">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search users by name, email, department..."
                      value={userSearch}
                      onChange={e => setUserSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                  <select
                    value={userRoleFilter}
                    onChange={e => setUserRoleFilter(e.target.value as any)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs outline-none"
                  >
                    <option value="all">All Roles</option>
                    <option value="admin">Admin</option>
                    <option value="staff">Staff</option>
                    <option value="guest">Guest</option>
                  </select>
                </div>

                <button
                  onClick={() => setShowAddUserModal(true)}
                  className="px-3.5 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-2xs cursor-pointer self-start sm:self-auto shrink-0"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Add New User</span>
                </button>
              </div>

              {/* Users Table */}
              <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden shadow-2xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-zinc-800/80 border-b border-slate-200 dark:border-zinc-800 font-bold text-slate-600 dark:text-zinc-300 uppercase tracking-wider text-[10px]">
                      <tr>
                        <th className="p-3">User & Email</th>
                        <th className="p-3">Department</th>
                        <th className="p-3">Role</th>
                        <th className="p-3">Status</th>
                        <th className="p-3">Joined</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-zinc-800 bg-white dark:bg-zinc-900">
                      {state.users
                        .filter(u => {
                          if (userRoleFilter !== 'all' && u.role !== userRoleFilter) return false;
                          if (userSearch.trim()) {
                            const q = userSearch.toLowerCase();
                            return (
                              u.username.toLowerCase().includes(q) ||
                              u.email.toLowerCase().includes(q) ||
                              (u.department || '').toLowerCase().includes(q)
                            );
                          }
                          return true;
                        })
                        .map(user => (
                          <tr key={user.id} className="hover:bg-slate-50/50 dark:hover:bg-zinc-800/40 transition-colors">
                            <td className="p-3">
                              <div className="font-bold text-slate-900 dark:text-zinc-100">{user.username}</div>
                              <div className="text-[11px] text-slate-400">{user.email}</div>
                            </td>
                            <td className="p-3 text-slate-600 dark:text-zinc-400">
                              {user.department || 'General'}
                            </td>
                            <td className="p-3">
                              {user.role === 'admin' ? (
                                <span className="px-2 py-0.5 rounded-full font-bold text-[10px] bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                                  Admin
                                </span>
                              ) : (
                                <select
                                  value={user.role}
                                  onChange={e =>
                                    onManageUser({
                                      targetUserId: user.id,
                                      action: 'update-role',
                                      role: e.target.value as UserRole
                                    })
                                  }
                                  className={`px-2 py-1 rounded-md text-xs font-semibold outline-none border cursor-pointer ${
                                    user.role === 'staff'
                                      ? 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800'
                                      : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                                  }`}
                                >
                                  <option value="staff">Staff</option>
                                  <option value="guest">Guest</option>
                                  <option value="admin">Admin</option>
                                </select>
                              )}
                            </td>
                            <td className="p-3">
                              <select
                                value={user.status}
                                onChange={e =>
                                  onManageUser({
                                    targetUserId: user.id,
                                    action: 'update-status',
                                    status: e.target.value as any
                                  })
                                }
                                className={`px-2 py-0.5 rounded-md text-[11px] font-bold outline-none border cursor-pointer ${
                                  user.status === 'approved'
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800'
                                    : user.status === 'pending'
                                    ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800'
                                    : 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950 dark:text-rose-300 dark:border-rose-800'
                                }`}
                              >
                                <option value="approved">Approved</option>
                                <option value="pending">Pending</option>
                                <option value="rejected">Rejected</option>
                              </select>
                            </td>
                            <td className="p-3 text-[11px] text-slate-400">
                              {new Date(user.createdAt).toLocaleDateString()}
                            </td>
                            <td className="p-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                {user.role !== 'admin' && (
                                  <button
                                    onClick={() => {
                                      setSelectedUserId(user.id);
                                      setActiveTab('permissions');
                                    }}
                                    className="px-2 py-1 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-semibold hover:bg-indigo-100 cursor-pointer"
                                    title="Configure Tracker & Field Permissions for this user"
                                  >
                                    Permissions
                                  </button>
                                )}
                                {user.id !== currentUser.id && (
                                  <button
                                    onClick={() => onManageUser({ targetUserId: user.id, action: 'delete' })}
                                    className="p-1 rounded text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950 cursor-pointer"
                                    title="Delete user"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 3: TRACKERS */}
          {/* ======================================================== */}
          {activeTab === 'trackers' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {state.trackers.map(tracker => {
                  const assignedPerms = (state.trackerPermissions || []).filter(
                    p => p.trackerId === tracker.id && p.canView
                  );
                  return (
                    <div
                      key={tracker.id}
                      className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/50 shadow-2xs space-y-3"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="font-bold text-sm text-slate-900 dark:text-zinc-100 flex items-center gap-2">
                            <span>{tracker.name}</span>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-100 dark:bg-zinc-700 text-slate-600 dark:text-zinc-300">
                              {tracker.columns.length} cols · {tracker.rows.length} rows
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 dark:text-zinc-400 mt-1 line-clamp-2">
                            {tracker.description}
                          </p>
                        </div>

                        <button
                          onClick={() => {
                            setSelectedTrackerId(tracker.id);
                            setActiveTab('permissions');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shrink-0 cursor-pointer shadow-2xs"
                        >
                          Manage Access
                        </button>
                      </div>

                      {/* Columns preview */}
                      <div className="pt-2 border-t border-slate-100 dark:border-zinc-800">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                          Tracker Columns ({tracker.columns.length})
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {tracker.columns.map(col => (
                            <span
                              key={col.id}
                              className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300 border border-slate-200/60 dark:border-zinc-700"
                            >
                              {col.name}{' '}
                              <span className="text-[9px] text-slate-400 font-mono">({col.type})</span>
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Approved Users */}
                      <div className="pt-2 border-t border-slate-100 dark:border-zinc-800">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                          Approved Users With Access ({assignedPerms.length})
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {assignedPerms.length === 0 ? (
                            <span className="text-slate-400 italic text-[11px]">
                              No Staff or Guest accounts approved for this tracker yet.
                            </span>
                          ) : (
                            assignedPerms.map(p => {
                              const u = state.users.find(usr => usr.id === p.userId);
                              return (
                                <span
                                  key={p.userId}
                                  className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800 flex items-center gap-1"
                                >
                                  <UserCheck className="w-3 h-3" />
                                  <span>{u?.username || p.userId}</span>
                                </span>
                              );
                            })
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 4: ACCESS REQUESTS */}
          {/* ======================================================== */}
          {activeTab === 'requests' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-slate-500">Filter Status:</span>
                  {(['all', 'pending', 'approved', 'rejected', 'revoked'] as const).map(st => (
                    <button
                      key={st}
                      onClick={() => setReqStatusFilter(st)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold capitalize cursor-pointer transition-all ${
                        reqStatusFilter === st
                          ? 'bg-indigo-600 text-white shadow-2xs'
                          : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400 hover:bg-slate-200'
                      }`}
                    >
                      {st} {st === 'pending' && pendingRequestsCount > 0 && `(${pendingRequestsCount})`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Requests List */}
              <div className="space-y-3">
                {(state.accessRequests || [])
                  .filter(r => (reqStatusFilter === 'all' ? true : r.status === reqStatusFilter))
                  .length === 0 ? (
                  <div className="p-8 rounded-xl border border-dashed border-slate-200 dark:border-zinc-800 text-center text-slate-400">
                    No access requests found matching this filter.
                  </div>
                ) : (
                  (state.accessRequests || [])
                    .filter(r => (reqStatusFilter === 'all' ? true : r.status === reqStatusFilter))
                    .map(req => {
                      const trackerObj = state.trackers.find(t => t.id === req.trackerId);
                      return (
                        <div
                          key={req.id}
                          className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-800/60 shadow-2xs space-y-3"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-sm text-slate-900 dark:text-zinc-100">
                                  {req.userName}
                                </span>
                                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-100 dark:bg-zinc-700 text-slate-700 dark:text-zinc-300">
                                  {req.userRole}
                                </span>
                                <span
                                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                                    req.status === 'approved'
                                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                      : req.status === 'rejected'
                                      ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                                      : req.status === 'revoked'
                                      ? 'bg-zinc-200 text-zinc-700 dark:bg-zinc-700 dark:text-zinc-300'
                                      : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse'
                                  }`}
                                >
                                  {req.status}
                                </span>
                              </div>
                              <div className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                                Requested access to tracker:{' '}
                                <span className="font-bold text-slate-800 dark:text-zinc-200">
                                  {req.trackerName}
                                </span>
                              </div>
                            </div>

                            <div className="text-[10px] text-slate-400 sm:text-right">
                              <div>Submitted: {new Date(req.createdAt).toLocaleString()}</div>
                              {req.reviewedBy && <div>Reviewed by: {req.reviewedBy}</div>}
                            </div>
                          </div>

                          {/* Reason Quote */}
                          <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-zinc-900/60 border border-slate-100 dark:border-zinc-800 text-xs italic text-slate-700 dark:text-zinc-300">
                            &ldquo;{req.reason}&rdquo;
                          </div>

                          {/* Requested Permissions Badges */}
                          <div className="flex flex-wrap items-center gap-3 pt-1">
                            <div className="flex items-center gap-1.5">
                              <span className="text-[11px] font-semibold text-slate-500">Actions:</span>
                              {req.requestedPermissions.view && (
                                <span className="px-1.5 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-bold">
                                  View
                                </span>
                              )}
                              {req.requestedPermissions.add && (
                                <span className="px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold">
                                  Add
                                </span>
                              )}
                              {req.requestedPermissions.edit && (
                                <span className="px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold">
                                  Edit
                                </span>
                              )}
                              {req.requestedPermissions.delete && (
                                <span className="px-1.5 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200 text-[10px] font-bold">
                                  Delete
                                </span>
                              )}
                              {req.requestedPermissions.export && (
                                <span className="px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200 text-[10px] font-bold">
                                  Export
                                </span>
                              )}
                            </div>

                            {/* Requested Fields Badges */}
                            {req.requestedFields && req.requestedFields.length > 0 && (
                              <div className="flex items-center gap-1.5">
                                <span className="text-[11px] font-semibold text-slate-500">Fields to edit:</span>
                                {req.requestedFields.map(fId => {
                                  const col = trackerObj?.columns.find(c => c.id === fId);
                                  return (
                                    <span
                                      key={fId}
                                      className="px-2 py-0.5 rounded bg-slate-100 dark:bg-zinc-700 font-semibold text-[10px]"
                                    >
                                      {col?.name || fId}
                                    </span>
                                  );
                                })}
                              </div>
                            )}
                          </div>

                          {/* Admin Action Buttons */}
                          <div className="pt-2 border-t border-slate-100 dark:border-zinc-800 flex items-center justify-end gap-2">
                            {req.status === 'pending' ? (
                              <>
                                <button
                                  onClick={() => onReviewAccessRequest(req.id, 'approve')}
                                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 shadow-2xs cursor-pointer"
                                >
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  <span>Quick Approve</span>
                                </button>

                                <button
                                  onClick={() => openEditRequestModal(req)}
                                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1 shadow-2xs cursor-pointer"
                                >
                                  <Sliders className="w-3.5 h-3.5" />
                                  <span>Edit & Approve</span>
                                </button>

                                <button
                                  onClick={() => onReviewAccessRequest(req.id, 'reject')}
                                  className="px-3 py-1.5 rounded-lg border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950 font-bold text-xs flex items-center gap-1 cursor-pointer"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span>Reject</span>
                                </button>
                              </>
                            ) : req.status === 'approved' ? (
                              <>
                                <button
                                  onClick={() => openEditRequestModal(req)}
                                  className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-slate-800 dark:text-zinc-200 font-bold text-xs flex items-center gap-1 cursor-pointer"
                                >
                                  <Sliders className="w-3.5 h-3.5" />
                                  <span>Modify Permissions</span>
                                </button>
                                <button
                                  onClick={() => onReviewAccessRequest(req.id, 'revoke')}
                                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>Revoke Access</span>
                                </button>
                              </>
                            ) : null}
                          </div>
                        </div>
                      );
                    })
                )}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 5: PERMISSIONS (Granular Matrix & Field-Level Editor) */}
          {/* ======================================================== */}
          {activeTab === 'permissions' && (
            <div className="space-y-6">
              {/* Selector Bar */}
              <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-800/40 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-xs text-slate-700 dark:text-zinc-300 mb-1.5">
                    1. Select User to Configure:
                  </label>
                  <select
                    value={selectedUserId}
                    onChange={e => setSelectedUserId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs font-semibold outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {eligibleUsers.map(u => (
                      <option key={u.id} value={u.id}>
                        {u.username} ({u.email}) — [{u.role.toUpperCase()}]
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-xs text-slate-700 dark:text-zinc-300 mb-1.5">
                    2. Select Target Tracker:
                  </label>
                  <select
                    value={selectedTrackerId}
                    onChange={e => setSelectedTrackerId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs font-semibold outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    {state.trackers.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Tracker-level Access Toggles (View, Add, Edit, Delete, Export) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-zinc-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-indigo-600" />
                    <span>Tracker-Level Access Permissions</span>
                  </h4>
                  <span className="text-[11px] text-slate-400">
                    Configuring for <strong className="text-slate-800 dark:text-zinc-200">{targetUserObj?.username}</strong> on{' '}
                    <strong className="text-slate-800 dark:text-zinc-200">{targetTracker?.name}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                  <label className="flex items-center gap-2 p-3 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 cursor-pointer shadow-2xs hover:bg-slate-50 dark:hover:bg-zinc-800/80">
                    <input
                      type="checkbox"
                      checked={permCanView}
                      onChange={e => setPermCanView(e.target.checked)}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="flex items-center gap-1.5 font-bold">
                      <Eye className="w-4 h-4 text-blue-500" />
                      <span>View</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 cursor-pointer shadow-2xs hover:bg-slate-50 dark:hover:bg-zinc-800/80">
                    <input
                      type="checkbox"
                      checked={permCanAdd}
                      onChange={e => setPermCanAdd(e.target.checked)}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="flex items-center gap-1.5 font-bold">
                      <PlusCircle className="w-4 h-4 text-emerald-500" />
                      <span>Add</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 cursor-pointer shadow-2xs hover:bg-slate-50 dark:hover:bg-zinc-800/80">
                    <input
                      type="checkbox"
                      checked={permCanEdit}
                      onChange={e => setPermCanEdit(e.target.checked)}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="flex items-center gap-1.5 font-bold">
                      <Edit3 className="w-4 h-4 text-amber-500" />
                      <span>Edit</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 cursor-pointer shadow-2xs hover:bg-slate-50 dark:hover:bg-zinc-800/80">
                    <input
                      type="checkbox"
                      checked={permCanDelete}
                      onChange={e => setPermCanDelete(e.target.checked)}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="flex items-center gap-1.5 font-bold">
                      <Trash2 className="w-4 h-4 text-rose-500" />
                      <span>Delete</span>
                    </div>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 cursor-pointer shadow-2xs hover:bg-slate-50 dark:hover:bg-zinc-800/80">
                    <input
                      type="checkbox"
                      checked={permCanExport}
                      onChange={e => setPermCanExport(e.target.checked)}
                      className="rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div className="flex items-center gap-1.5 font-bold">
                      <Download className="w-4 h-4 text-purple-500" />
                      <span>Export</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* FIELD-LEVEL EDITING CONTROL (Prompt: Admin can choose exactly which columns user can edit) */}
              <div className="space-y-3 pt-2">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 dark:text-zinc-300 flex items-center gap-1.5">
                      <Columns className="w-4 h-4 text-indigo-600" />
                      <span>Field-Level Column Permissions (Exact Column Access)</span>
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-zinc-400">
                      Configure each column as Edit, View Only, or No Access (Hidden). Whenever a new column is added, you can also control it here.
                    </p>
                  </div>

                  {/* Preset quick actions */}
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        const allEdit: Record<string, FieldAccessLevel> = {};
                        targetTracker?.columns.forEach(c => (allEdit[c.id] = 'edit'));
                        setFieldPermsDraft(allEdit);
                      }}
                      className="px-2 py-1 rounded bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 text-[10px] font-bold cursor-pointer"
                    >
                      All Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const allView: Record<string, FieldAccessLevel> = {};
                        targetTracker?.columns.forEach(c => (allView[c.id] = 'view'));
                        setFieldPermsDraft(allView);
                      }}
                      className="px-2 py-1 rounded bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 text-[10px] font-bold cursor-pointer"
                    >
                      All View Only
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        // User prompt example preset: Date -> View Only, Status -> Edit, Remarks -> Edit, Amount -> No Access
                        const preset: Record<string, FieldAccessLevel> = {};
                        targetTracker?.columns.forEach(c => {
                          const n = c.name.toLowerCase();
                          if (n.includes('amount') || n.includes('price') || n.includes('cost') || n.includes('budget')) {
                            preset[c.id] = 'no_access';
                          } else if (n.includes('date')) {
                            preset[c.id] = 'view';
                          } else if (n.includes('status') || n.includes('notes') || n.includes('remark')) {
                            preset[c.id] = 'edit';
                          } else {
                            preset[c.id] = 'view';
                          }
                        });
                        setFieldPermsDraft(preset);
                      }}
                      className="px-2 py-1 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-100 text-[10px] font-bold cursor-pointer"
                    >
                      Apply Sample Preset
                    </button>
                  </div>
                </div>

                {/* Columns Table */}
                <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden shadow-2xs">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-zinc-800/80 border-b border-slate-200 dark:border-zinc-800 font-bold text-slate-600 dark:text-zinc-300 uppercase tracking-wider text-[10px]">
                      <tr>
                        <th className="p-3">Column Name</th>
                        <th className="p-3">Data Type</th>
                        <th className="p-3 text-right">Access Level</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-zinc-800 bg-white dark:bg-zinc-900">
                      {targetTracker?.columns.map(col => {
                        const currentAccess: FieldAccessLevel =
                          fieldPermsDraft[col.id] || (permCanEdit ? 'edit' : 'view');

                        return (
                          <tr key={col.id} className="hover:bg-slate-50/50 dark:hover:bg-zinc-800/40">
                            <td className="p-3">
                              <span className="font-bold text-slate-800 dark:text-zinc-200">{col.name}</span>
                              <span className="font-mono text-[10px] text-slate-400 ml-1.5">({col.id})</span>
                            </td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-300">
                                {col.type}
                              </span>
                            </td>
                            <td className="p-3 text-right">
                              <div className="inline-flex rounded-lg border border-slate-200 dark:border-zinc-700 p-0.5 bg-slate-50 dark:bg-zinc-800 text-xs">
                                <button
                                  type="button"
                                  onClick={() =>
                                    setFieldPermsDraft(prev => ({ ...prev, [col.id]: 'edit' }))
                                  }
                                  className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                                    currentAccess === 'edit'
                                      ? 'bg-emerald-600 text-white shadow-2xs'
                                      : 'text-slate-500 hover:text-slate-800 dark:text-zinc-400'
                                  }`}
                                >
                                  Edit
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setFieldPermsDraft(prev => ({ ...prev, [col.id]: 'view' }))
                                  }
                                  className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                                    currentAccess === 'view'
                                      ? 'bg-blue-600 text-white shadow-2xs'
                                      : 'text-slate-500 hover:text-slate-800 dark:text-zinc-400'
                                  }`}
                                >
                                  View Only
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setFieldPermsDraft(prev => ({ ...prev, [col.id]: 'no_access' }))
                                  }
                                  className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                                    currentAccess === 'no_access'
                                      ? 'bg-rose-600 text-white shadow-2xs'
                                      : 'text-slate-500 hover:text-slate-800 dark:text-zinc-400'
                                  }`}
                                >
                                  No Access
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Bottom Actions */}
              <div className="pt-4 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleRevokeCurrentPermission}
                  className="px-4 py-2 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <UserX className="w-3.5 h-3.5" />
                  <span>Revoke All Access for this User</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveCurrentPermission}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-2xs cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Save Permission Configuration</span>
                </button>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* TAB 6: ACTIVITY LOG */}
          {/* ======================================================== */}
          {activeTab === 'logs' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2 flex-1">
                  <div className="relative flex-1 min-w-[180px]">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search logs by user, action, field, values..."
                      value={logSearch}
                      onChange={e => setLogSearch(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs outline-none"
                    />
                  </div>

                  <select
                    value={logActionFilter}
                    onChange={e => setLogActionFilter(e.target.value)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs outline-none"
                  >
                    <option value="all">All Actions</option>
                    <option value="EDIT">Cell Edits</option>
                    <option value="ADD">Row Additions</option>
                    <option value="DELETE">Deletions</option>
                    <option value="PERMISSION">Permissions</option>
                    <option value="REQUEST">Access Requests</option>
                    <option value="ROLE">Role Changes</option>
                    <option value="EXPORT">Exports</option>
                  </select>

                  <select
                    value={logTrackerFilter}
                    onChange={e => setLogTrackerFilter(e.target.value)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs outline-none"
                  >
                    <option value="all">All Trackers</option>
                    {state.trackers.map(t => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  onClick={handleExportLogsExcel}
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-2xs cursor-pointer shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export to Excel</span>
                </button>
              </div>

              {/* Logs Table (Prompt: Record: User, Tracker, Action, Date/time, Changed field, Old value, New value, Approved by) */}
              <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden shadow-2xs">
                <div className="overflow-x-auto max-h-[58vh]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-zinc-800/80 border-b border-slate-200 dark:border-zinc-800 font-bold text-slate-600 dark:text-zinc-300 uppercase tracking-wider text-[10px] sticky top-0 z-10">
                      <tr>
                        <th className="p-3">Date / Time</th>
                        <th className="p-3">User</th>
                        <th className="p-3">Tracker</th>
                        <th className="p-3">Action</th>
                        <th className="p-3">Changed Field</th>
                        <th className="p-3">Old Value</th>
                        <th className="p-3">New Value</th>
                        <th className="p-3">Approved By / Actor</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-zinc-800 bg-white dark:bg-zinc-900">
                      {filteredLogs.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="p-6 text-center text-slate-400">
                            No activity logs found.
                          </td>
                        </tr>
                      ) : (
                        filteredLogs.map(log => (
                          <tr key={log.id} className="hover:bg-slate-50/50 dark:hover:bg-zinc-800/40">
                            <td className="p-3 whitespace-nowrap text-slate-500 dark:text-zinc-400 font-mono text-[11px]">
                              {new Date(log.timestamp).toLocaleString()}
                            </td>
                            <td className="p-3">
                              <div className="font-bold text-slate-900 dark:text-zinc-100">{log.userName}</div>
                              {log.userRole && (
                                <span className="text-[9px] font-semibold px-1.5 py-0.2 rounded bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400 uppercase">
                                  {log.userRole}
                                </span>
                              )}
                            </td>
                            <td className="p-3 font-semibold text-slate-700 dark:text-zinc-300">
                              {log.trackerName || 'System'}
                            </td>
                            <td className="p-3">
                              <span className="px-2 py-0.5 rounded font-mono text-[10px] font-bold bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300">
                                {log.action}
                              </span>
                            </td>
                            <td className="p-3 text-slate-700 dark:text-zinc-300">
                              {log.changedField || '—'}
                            </td>
                            <td className="p-3 text-slate-500 font-mono text-[11px] max-w-[140px] truncate" title={String(log.oldValue || '')}>
                              {log.oldValue !== null && log.oldValue !== undefined ? String(log.oldValue) : '—'}
                            </td>
                            <td className="p-3 text-indigo-700 dark:text-indigo-400 font-mono text-[11px] font-semibold max-w-[140px] truncate" title={String(log.newValue || '')}>
                              {log.newValue !== null && log.newValue !== undefined ? String(log.newValue) : '—'}
                            </td>
                            <td className="p-3 text-slate-600 dark:text-zinc-400 font-medium">
                              {log.approvedBy || log.userName || 'System'}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between bg-slate-50/50 dark:bg-zinc-950/40 shrink-0">
          <div className="text-[11px] text-slate-500 dark:text-zinc-400 flex items-center gap-2">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Database-enforced permission protection active</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer shadow-2xs"
          >
            Done
          </button>
        </div>
      </div>

      {/* Modal: Create User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div
            className={`w-full max-w-md rounded-2xl border p-5 shadow-2xl space-y-4 ${
              isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-indigo-600" />
                <span>Create New User Account</span>
              </h3>
              <button onClick={() => setShowAddUserModal(false)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateUserSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Full Name</label>
                <input
                  type="text"
                  placeholder="e.g. Maria Santos"
                  value={newUserName}
                  onChange={e => setNewUserName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="maria@team.com"
                  value={newUserEmail}
                  onChange={e => setNewUserEmail(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Role (Permission Tier)</label>
                <select
                  value={newUserRole}
                  onChange={e => setNewUserRole(e.target.value as UserRole)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none"
                >
                  <option value="staff">Staff (Access only to approved trackers)</option>
                  <option value="guest">Guest (View only unless approved)</option>
                  <option value="admin">Admin (Full Control)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Department</label>
                <input
                  type="text"
                  placeholder="e.g. Site Quality & Civil Works"
                  value={newUserDept}
                  onChange={e => setNewUserDept(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Temporary Password</label>
                <input
                  type="text"
                  value={newUserPass}
                  onChange={e => setNewUserPass(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold"
                >
                  Create User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Edit & Approve Access Request */}
      {editingRequest && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
          <div
            className={`w-full max-w-xl rounded-2xl border p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto ${
              isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-600" />
                <span>Fine-Tune & Approve Permissions</span>
              </h3>
              <button onClick={() => setEditingRequest(null)} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                ✕
              </button>
            </div>

            <div className="text-xs text-slate-600 dark:text-zinc-400 space-y-1">
              <div>
                User: <strong className="text-slate-900 dark:text-zinc-100">{editingRequest.userName}</strong> ({editingRequest.userRole})
              </div>
              <div>
                Tracker: <strong className="text-slate-900 dark:text-zinc-100">{editingRequest.trackerName}</strong>
              </div>
              <div>Reason: &ldquo;{editingRequest.reason}&rdquo;</div>
            </div>

            {/* Actions */}
            <div className="space-y-2">
              <label className="block font-bold text-xs">Granted Actions:</label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 text-xs">
                <label className="flex items-center gap-1.5 p-2 rounded-lg border border-slate-200 dark:border-zinc-700">
                  <input type="checkbox" checked={editReqView} onChange={e => setEditReqView(e.target.checked)} />
                  <span>View</span>
                </label>
                <label className="flex items-center gap-1.5 p-2 rounded-lg border border-slate-200 dark:border-zinc-700">
                  <input type="checkbox" checked={editReqAdd} onChange={e => setEditReqAdd(e.target.checked)} />
                  <span>Add</span>
                </label>
                <label className="flex items-center gap-1.5 p-2 rounded-lg border border-slate-200 dark:border-zinc-700">
                  <input type="checkbox" checked={editReqEdit} onChange={e => setEditReqEdit(e.target.checked)} />
                  <span>Edit</span>
                </label>
                <label className="flex items-center gap-1.5 p-2 rounded-lg border border-slate-200 dark:border-zinc-700">
                  <input type="checkbox" checked={editReqDelete} onChange={e => setEditReqDelete(e.target.checked)} />
                  <span>Delete</span>
                </label>
                <label className="flex items-center gap-1.5 p-2 rounded-lg border border-slate-200 dark:border-zinc-700">
                  <input type="checkbox" checked={editReqExport} onChange={e => setEditReqExport(e.target.checked)} />
                  <span>Export</span>
                </label>
              </div>
            </div>

            {/* Field Permissions */}
            <div className="space-y-2">
              <label className="block font-bold text-xs">Field-Level Column Rights:</label>
              <div className="border border-slate-200 dark:border-zinc-800 rounded-lg max-h-48 overflow-y-auto divide-y divide-slate-100 dark:divide-zinc-800">
                {state.trackers.find(t => t.id === editingRequest.trackerId)?.columns.map(col => {
                  const access = editReqFields[col.id] || 'view';
                  return (
                    <div key={col.id} className="p-2 flex items-center justify-between text-xs">
                      <span className="font-semibold">{col.name}</span>
                      <div className="flex gap-1">
                        {(['edit', 'view', 'no_access'] as const).map(lvl => (
                          <button
                            key={lvl}
                            type="button"
                            onClick={() => setEditReqFields(prev => ({ ...prev, [col.id]: lvl }))}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold capitalize cursor-pointer ${
                              access === lvl
                                ? lvl === 'edit'
                                  ? 'bg-emerald-600 text-white'
                                  : lvl === 'view'
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-rose-600 text-white'
                                : 'bg-slate-100 dark:bg-zinc-800 text-slate-500'
                            }`}
                          >
                            {lvl === 'no_access' ? 'No Access' : lvl}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block font-bold text-xs mb-1">Admin Approval Note (Optional):</label>
              <input
                type="text"
                placeholder="e.g. Approved for QA inspections until project signoff."
                value={editReqNote}
                onChange={e => setEditReqNote(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs outline-none"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setEditingRequest(null)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={async () => {
                  await onReviewAccessRequest(
                    editingRequest.id,
                    'edit-approve',
                    {
                      canView: editReqView,
                      canAdd: editReqAdd,
                      canEdit: editReqEdit,
                      canDelete: editReqDelete,
                      canExport: editReqExport,
                      fieldPermissions: editReqFields
                    },
                    editReqNote
                  );
                  setEditingRequest(null);
                }}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
              >
                Save & Approve Access
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
