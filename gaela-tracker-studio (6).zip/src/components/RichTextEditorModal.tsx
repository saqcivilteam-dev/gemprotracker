import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Bold,
  Underline,
  Highlighter,
  CheckSquare,
  Square,
  Bookmark,
  List,
  ListOrdered,
  Sparkles,
  Save,
  RotateCcw,
  Tag,
  Check,
  Plus,
  Trash2,
  Eye,
  FileText,
  ChevronDown
} from 'lucide-react';
import {
  renderFormattedContent,
  insertFormatting,
  HighlightColor
} from '../utils/textFormatter';

interface RichTextEditorModalProps {
  isOpen: boolean;
  rowId: string;
  rowNumber: number;
  rowTitle?: string;
  columnId: string;
  columnName: string;
  initialValue: string;
  isDark?: boolean;
  onClose: () => void;
  onSave: (rowId: string, colId: string, updatedValue: string) => void;
}

export const RichTextEditorModal: React.FC<RichTextEditorModalProps> = ({
  isOpen,
  rowId,
  rowNumber,
  rowTitle,
  columnId,
  columnName,
  initialValue,
  isDark = false,
  onClose,
  onSave
}) => {
  const [content, setContent] = useState<string>(initialValue || '');
  const [activeTab, setActiveTab] = useState<'editor' | 'errandManager'>('editor');
  const [selectedHighlightColor, setSelectedHighlightColor] = useState<HighlightColor>('yellow');
  const [showColorPicker, setShowColorPicker] = useState<boolean>(false);
  const [showTagMenu, setShowTagMenu] = useState<boolean>(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setContent(initialValue || '');
  }, [initialValue, isOpen]);

  if (!isOpen) return null;

  // Handle Toolbar Format Action
  const applyFormat = (
    type: 'bold' | 'underline' | 'highlight' | 'errand' | 'completedErrand' | 'badge' | 'bullet',
    payload?: string
  ) => {
    if (!textareaRef.current) return;
    const { newText, newCursor } = insertFormatting(textareaRef.current, type, payload);
    setContent(newText);
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(newCursor, newCursor);
      }
    }, 10);
  };

  // Keyboard shortcut listener inside textarea
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
      e.preventDefault();
      applyFormat('bold');
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'u') {
      e.preventDefault();
      applyFormat('underline');
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'h') {
      e.preventDefault();
      applyFormat('highlight', selectedHighlightColor);
    } else if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      // Auto-continue errand checkboxes on new line if current line starts with [ ]
      const textarea = textareaRef.current;
      if (!textarea) return;
      const start = textarea.selectionStart;
      const currentVal = textarea.value;
      const currentLine = currentVal.substring(0, start).split('\n').pop() || '';

      if (currentLine.match(/^(\s*)\[\s*\]\s+/)) {
        e.preventDefault();
        const indentMatch = currentLine.match(/^(\s*)\[\s*\]\s+/);
        const prefix = `\n${indentMatch ? indentMatch[1] : ''}[ ] `;
        const newText = currentVal.substring(0, start) + prefix + currentVal.substring(start);
        setContent(newText);
        setTimeout(() => {
          if (textareaRef.current) {
            textareaRef.current.setSelectionRange(start + prefix.length, start + prefix.length);
          }
        }, 0);
      } else if (currentLine.match(/^(\s*)•\s+/)) {
        e.preventDefault();
        const prefix = '\n• ';
        const newText = currentVal.substring(0, start) + prefix + currentVal.substring(start);
        setContent(newText);
        setTimeout(() => {
          if (textareaRef.current) {
            textareaRef.current.setSelectionRange(start + prefix.length, start + prefix.length);
          }
        }, 0);
      }
    }
  };

  // Quick Preset Templates for Errands and Operations
  const insertErrandPreset = (presetType: 'operation' | 'siteHunting' | 'docsNotary' | 'liquidate') => {
    let presetText = '';
    if (presetType === 'operation') {
      presetText = `* FOR OPERATION - \n(TRANSPORTATION, DOCUMENTATION, CTC, PRINTING, NOTARY, LOAD, MEAL, CARGO/LBC)\n[ ] Transpo to site\n[ ] Securing documents\n[ ] Meal for team\n[ ] Cargo / LBC transit`;
    } else if (presetType === 'siteHunting') {
      presetText = `SITE HUNTING & FOLLOW UP POSITIVE OPTIONS:\n[ ] 1. G1304 - Landowner negotiation\n[ ] 2. G1131 - Positive option follow-up\n[ ] 3. G4491 - Site inspection & survey\n[ ] 4. G3127 - Locational clearance`;
    } else if (presetType === 'docsNotary') {
      presetText = `DOCUMENTATION & PERMITTING ERRANDS:\n[ ] Locational Clearance submission\n[ ] CTC of Title & Property Documents\n[ ] Notary of Lease / Consent Agreement\n[ ] Barangay LOI endorsement`;
    } else if (presetType === 'liquidate') {
      presetText = `[CLOSED CAL] [EXPENSE] LIQUIDATION DETAILS:\n• Receipts validated\n• Amount settled: ₱\n• Remaining balance: ₱0.00`;
    }

    if (!content.trim()) {
      setContent(presetText);
    } else {
      setContent(content + '\n\n' + presetText);
    }
  };

  // Extract errand items for dedicated Errand Manager tab
  const getErrandItems = () => {
    const lines = content.split('\n');
    return lines
      .map((line, idx) => {
        const unchecked = line.match(/^(\s*)\[\s*\]\s+(.*)$/);
        const checked = line.match(/^(\s*)\[[xX]\]\s+(.*)$/);
        if (unchecked) {
          return { lineIndex: idx, rawLine: line, isChecked: false, text: unchecked[2] };
        }
        if (checked) {
          return { lineIndex: idx, rawLine: line, isChecked: true, text: checked[2] };
        }
        return null;
      })
      .filter(Boolean) as { lineIndex: number; rawLine: string; isChecked: boolean; text: string }[];
  };

  const toggleErrandInManager = (lineIndex: number, currentChecked: boolean) => {
    const lines = content.split('\n');
    if (lines[lineIndex] !== undefined) {
      if (currentChecked) {
        // Toggle to unchecked
        lines[lineIndex] = lines[lineIndex].replace(/^(\s*)\[[xX]\]/, '$1[ ]');
      } else {
        // Toggle to checked
        lines[lineIndex] = lines[lineIndex].replace(/^(\s*)\[\s*\]/, '$1[x]');
      }
      setContent(lines.join('\n'));
    }
  };

  const addNewErrandToContent = (taskText: string) => {
    if (!taskText.trim()) return;
    const newLine = `[ ] ${taskText.trim()}`;
    setContent(content ? `${content}\n${newLine}` : newLine);
  };

  const deleteErrandLine = (lineIndex: number) => {
    const lines = content.split('\n');
    lines.splice(lineIndex, 1);
    setContent(lines.join('\n'));
  };

  const errandList = getErrandItems();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-4xl bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-800 flex flex-col max-h-[92vh] overflow-hidden">
        {/* Modal Header */}
        <div className="px-5 py-3.5 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between bg-slate-50/80 dark:bg-zinc-800/60">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-sm text-slate-900 dark:text-white">
                  Manage & Format Cell / Errand Editor
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  {columnName}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Row #{rowNumber} {rowTitle ? `• ${rowTitle}` : ''} — Rich text formatting for presentation & reporting
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Tab switchers */}
            <div className="flex items-center bg-slate-200/80 dark:bg-zinc-800 p-0.5 rounded-lg text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveTab('editor')}
                className={`px-3 py-1 rounded-md transition-all ${
                  activeTab === 'editor'
                    ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
                }`}
              >
                Text & Formatter
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('errandManager')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
                  activeTab === 'errandManager'
                    ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
                }`}
              >
                <CheckSquare className="w-3.5 h-3.5" />
                <span>Errands ({errandList.length})</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Formatting Toolbar */}
        <div className="px-5 py-2 border-b border-slate-200 dark:border-zinc-800 bg-slate-100/70 dark:bg-zinc-900/90 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-1">
            {/* Bold */}
            <button
              type="button"
              onClick={() => applyFormat('bold')}
              title="Bold selection (**text**) — Ctrl+B"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-bold bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 hover:bg-indigo-50 dark:hover:bg-zinc-700 text-slate-800 dark:text-zinc-100 shadow-2xs"
            >
              <Bold className="w-3.5 h-3.5" />
              <span>Bold</span>
            </button>

            {/* Underline */}
            <button
              type="button"
              onClick={() => applyFormat('underline')}
              title="Underline selection (<u>text</u>) — Ctrl+U"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-medium bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 hover:bg-indigo-50 dark:hover:bg-zinc-700 text-slate-800 dark:text-zinc-100 shadow-2xs"
            >
              <Underline className="w-3.5 h-3.5" />
              <span>Underline</span>
            </button>

            {/* Highlighter with Color Selector */}
            <div className="relative">
              <div className="flex items-center rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 shadow-2xs overflow-hidden">
                <button
                  type="button"
                  onClick={() => applyFormat('highlight', selectedHighlightColor)}
                  title={`Highlight text in ${selectedHighlightColor} (Ctrl+H)`}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 hover:bg-yellow-50 dark:hover:bg-zinc-700 text-slate-800 dark:text-zinc-100"
                >
                  <Highlighter className="w-3.5 h-3.5 text-amber-500" />
                  <span className="font-semibold capitalize">Highlight</span>
                  <span
                    className={`w-3 h-3 rounded-full border border-black/20 ${
                      selectedHighlightColor === 'yellow'
                        ? 'bg-yellow-300'
                        : selectedHighlightColor === 'green'
                        ? 'bg-emerald-400'
                        : selectedHighlightColor === 'cyan'
                        ? 'bg-cyan-400'
                        : selectedHighlightColor === 'pink'
                        ? 'bg-rose-400'
                        : 'bg-amber-400'
                    }`}
                  />
                </button>
                <button
                  type="button"
                  onClick={() => setShowColorPicker(!showColorPicker)}
                  className="px-1.5 py-1.5 border-l border-slate-200 dark:border-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-700 text-slate-500"
                >
                  <ChevronDown className="w-3 h-3" />
                </button>
              </div>

              {/* Color Swatch Dropdown */}
              {showColorPicker && (
                <div className="absolute left-0 top-full mt-1.5 z-30 p-2 rounded-xl bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 shadow-xl flex items-center gap-2">
                  {[
                    { id: 'yellow', label: 'Yellow Marker', bg: 'bg-yellow-300' },
                    { id: 'green', label: 'Emerald Marker', bg: 'bg-emerald-400' },
                    { id: 'cyan', label: 'Cyan Marker', bg: 'bg-cyan-400' },
                    { id: 'pink', label: 'Pink Marker', bg: 'bg-rose-400' },
                    { id: 'amber', label: 'Amber Marker', bg: 'bg-amber-400' }
                  ].map(c => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        setSelectedHighlightColor(c.id as HighlightColor);
                        setShowColorPicker(false);
                        applyFormat('highlight', c.id);
                      }}
                      className={`w-6 h-6 rounded-full border-2 transition-transform hover:scale-110 flex items-center justify-center ${c.bg} ${
                        selectedHighlightColor === c.id ? 'border-slate-900 ring-2 ring-indigo-500' : 'border-transparent'
                      }`}
                      title={c.label}
                    >
                      {selectedHighlightColor === c.id && <Check className="w-3.5 h-3.5 text-slate-900" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Errand Checkbox */}
            <button
              type="button"
              onClick={() => applyFormat('errand')}
              title="Add errand task checklist item ([ ] Item)"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-semibold bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 hover:bg-indigo-50 dark:hover:bg-zinc-700 text-indigo-700 dark:text-indigo-300 shadow-2xs"
            >
              <CheckSquare className="w-3.5 h-3.5 text-indigo-500" />
              <span>[ ] Errand Task</span>
            </button>

            {/* Bullets */}
            <button
              type="button"
              onClick={() => applyFormat('bullet')}
              title="Add bullet points"
              className="p-1.5 rounded-lg bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 shadow-2xs"
            >
              <List className="w-3.5 h-3.5" />
            </button>

            {/* Priority & Tags Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowTagMenu(!showTagMenu)}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg font-semibold bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 shadow-2xs"
              >
                <Bookmark className="w-3.5 h-3.5 text-rose-500" />
                <span>Important Tags</span>
                <ChevronDown className="w-3 h-3" />
              </button>

              {showTagMenu && (
                <div className="absolute left-0 top-full mt-1.5 z-30 p-2 rounded-xl bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 shadow-xl flex flex-col gap-1 w-48">
                  <button
                    type="button"
                    onClick={() => {
                      applyFormat('badge', 'IMPORTANT');
                      setShowTagMenu(false);
                    }}
                    className="flex items-center gap-1.5 px-2 py-1 text-left rounded text-xs hover:bg-amber-50 dark:hover:bg-amber-950/40 text-amber-700 dark:text-amber-300 font-bold"
                  >
                    <Bookmark className="w-3 h-3" />
                    <span>[IMPORTANT]</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      applyFormat('badge', 'URGENT');
                      setShowTagMenu(false);
                    }}
                    className="flex items-center gap-1.5 px-2 py-1 text-left rounded text-xs hover:bg-rose-50 dark:hover:bg-rose-950/40 text-rose-700 dark:text-rose-300 font-bold"
                  >
                    <Bookmark className="w-3 h-3" />
                    <span>[URGENT]</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      applyFormat('badge', 'CLOSED CAL');
                      setShowTagMenu(false);
                    }}
                    className="flex items-center gap-1.5 px-2 py-1 text-left rounded text-xs hover:bg-emerald-50 dark:hover:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold"
                  >
                    <Check className="w-3 h-3" />
                    <span>[CLOSED CAL]</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      applyFormat('badge', 'TARGET 2026');
                      setShowTagMenu(false);
                    }}
                    className="flex items-center gap-1.5 px-2 py-1 text-left rounded text-xs hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-bold"
                  >
                    <Bookmark className="w-3 h-3" />
                    <span>[TARGET 2026]</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Quick Errand Templates */}
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-slate-500 font-medium hidden md:inline">Presets:</span>
            <button
              type="button"
              onClick={() => insertErrandPreset('operation')}
              className="px-2 py-1 rounded bg-slate-200/80 dark:bg-zinc-800 hover:bg-indigo-100 dark:hover:bg-indigo-950/60 text-[11px] font-semibold text-slate-700 dark:text-zinc-300"
              title="Insert site operation errand checklist"
            >
              + Ops Checklist
            </button>
            <button
              type="button"
              onClick={() => insertErrandPreset('siteHunting')}
              className="px-2 py-1 rounded bg-slate-200/80 dark:bg-zinc-800 hover:bg-indigo-100 dark:hover:bg-indigo-950/60 text-[11px] font-semibold text-slate-700 dark:text-zinc-300"
              title="Insert site hunting option list"
            >
              + Site Hunting
            </button>
            <button
              type="button"
              onClick={() => insertErrandPreset('docsNotary')}
              className="px-2 py-1 rounded bg-slate-200/80 dark:bg-zinc-800 hover:bg-indigo-100 dark:hover:bg-indigo-950/60 text-[11px] font-semibold text-slate-700 dark:text-zinc-300"
              title="Insert documentation and notary tasks"
            >
              + Docs & Notary
            </button>
          </div>
        </div>

        {/* Modal Main Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {activeTab === 'editor' ? (
            /* Split View: Text Editor on Left, Live Presentation Preview on Right */
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-full min-h-[360px]">
              {/* Left Column: Textarea with formatting shortcuts */}
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-zinc-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Raw Content & Errand Notes</span>
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Use **bold**, <u>underline</u>, ==highlight==, [ ] errands
                  </span>
                </div>
                <textarea
                  ref={textareaRef}
                  value={content}
                  onChange={e => setContent(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type notes, errand details, operations, sites or paste multi-line content here...&#10;&#10;Examples:&#10;**FOR SITE OPERATION**&#10;==MEAL, CARGO, LBC, NOTARY, PRINTING, LOAD==&#10;[ ] Securing documents&#10;[ ] Traveling from Sibugay to Zamboanga City"
                  className="flex-1 w-full min-h-[300px] p-3.5 rounded-xl border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-950 text-slate-900 dark:text-zinc-100 font-mono text-xs focus:ring-2 focus:ring-indigo-500 outline-none resize-none leading-relaxed shadow-inner"
                />
                <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 dark:text-zinc-400">
                  <div className="flex items-center gap-3">
                    <span>Lines: {content.split('\n').length}</span>
                    <span>Characters: {content.length}</span>
                    <span>Errand Checkpoints: {errandList.length}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setContent('')}
                    className="text-slate-400 hover:text-red-500 transition-colors"
                  >
                    Clear All
                  </button>
                </div>
              </div>

              {/* Right Column: Live Presentation & Executive Report Preview */}
              <div className="flex flex-col h-full bg-slate-50/70 dark:bg-zinc-800/40 p-4 rounded-xl border border-slate-200 dark:border-zinc-700/80">
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-zinc-300 mb-2 pb-2 border-b border-slate-200 dark:border-zinc-700">
                  <span className="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400">
                    <Eye className="w-3.5 h-3.5" />
                    <span>Presentation & Report Preview</span>
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300">
                    Live Formatted Output
                  </span>
                </div>

                <div className="flex-1 overflow-y-auto custom-scrollbar p-3 rounded-lg bg-white dark:bg-zinc-900 border border-slate-200/80 dark:border-zinc-700/60 shadow-xs">
                  {content.trim() ? (
                    renderFormattedContent(content, {
                      interactiveChecklist: true,
                      onToggleTask: (lineIdx, origLine, nextStatus) => {
                        toggleErrandInManager(lineIdx, !nextStatus);
                      }
                    })
                  ) : (
                    <div className="flex flex-col items-center justify-center h-48 text-slate-400 text-center">
                      <Sparkles className="w-6 h-6 mb-2 text-slate-300 dark:text-zinc-600" />
                      <p className="font-semibold text-xs">Nothing to preview yet</p>
                      <p className="text-[11px] text-slate-400 max-w-xs mt-1">
                        Select text on the left and click Bold, Underline, Highlight, or Errand Task to see rich live styling!
                      </p>
                    </div>
                  )}
                </div>

                <div className="mt-2.5 p-2 rounded-lg bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 text-[11px] text-indigo-900 dark:text-indigo-200 flex items-center justify-between">
                  <span>💡 This exact styling is preserved in the table and executive PDF reports.</span>
                </div>
              </div>
            </div>
          ) : (
            /* Dedicated Errand Manager View */
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800">
                <div>
                  <h4 className="font-bold text-xs text-indigo-950 dark:text-indigo-100">
                    Interactive Errand & Milestone Manager
                  </h4>
                  <p className="text-[11px] text-indigo-700 dark:text-indigo-300 mt-0.5">
                    Click checkboxes to mark errands finished or pending. Items sync directly to the cell content.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-white dark:bg-zinc-800 border border-indigo-200 dark:border-indigo-700 text-indigo-700 dark:text-indigo-300 shadow-2xs">
                    {errandList.filter(e => e.isChecked).length} / {errandList.length} Finished
                  </span>
                </div>
              </div>

              {/* Add New Errand Input */}
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  id="new-errand-input"
                  placeholder="Add a new errand task (e.g. 'Notary of contract', 'Follow up G1304 landowner')..."
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      const val = (e.target as HTMLInputElement).value;
                      if (val) {
                        addNewErrandToContent(val);
                        (e.target as HTMLInputElement).value = '';
                      }
                    }
                  }}
                  className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none focus:ring-2 focus:ring-indigo-500 shadow-2xs"
                />
                <button
                  type="button"
                  onClick={() => {
                    const input = document.getElementById('new-errand-input') as HTMLInputElement;
                    if (input && input.value) {
                      addNewErrandToContent(input.value);
                      input.value = '';
                    }
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Errand</span>
                </button>
              </div>

              {/* Errand List */}
              <div className="space-y-2 max-h-[380px] overflow-y-auto custom-scrollbar">
                {errandList.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 bg-slate-50 dark:bg-zinc-800/40 rounded-xl border border-dashed border-slate-300 dark:border-zinc-700">
                    <CheckSquare className="w-8 h-8 mx-auto mb-2 text-slate-300 dark:text-zinc-600" />
                    <p className="font-semibold text-xs text-slate-600 dark:text-zinc-300">
                      No checkbox errand tasks in this cell yet
                    </p>
                    <p className="text-[11px] text-slate-400 mt-1 max-w-sm mx-auto">
                      Add errands using the field above or switch to the Editor and click <strong>[ ] Errand Task</strong>.
                    </p>
                  </div>
                ) : (
                  errandList.map((errand, idx) => (
                    <div
                      key={idx}
                      className={`flex items-center justify-between gap-3 p-3 rounded-xl border transition-all ${
                        errand.isChecked
                          ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60 text-slate-500 dark:text-zinc-400'
                          : 'bg-white dark:bg-zinc-800 border-slate-200 dark:border-zinc-700 text-slate-800 dark:text-zinc-100 shadow-2xs'
                      }`}
                    >
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <button
                          type="button"
                          onClick={() => toggleErrandInManager(errand.lineIndex, errand.isChecked)}
                          className={`p-1 rounded transition-transform hover:scale-110 ${
                            errand.isChecked
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-indigo-600 dark:text-indigo-400'
                          }`}
                        >
                          {errand.isChecked ? (
                            <CheckSquare className="w-4 h-4" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                        <span
                          className={`text-xs font-medium truncate ${
                            errand.isChecked ? 'line-through decoration-emerald-500' : ''
                          }`}
                        >
                          {errand.text}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => deleteErrandLine(errand.lineIndex)}
                          className="p-1 rounded text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/40 transition-colors"
                          title="Delete Errand"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 flex flex-wrap items-center justify-between gap-3">
          <div className="text-[11px] text-slate-500 dark:text-zinc-400">
            Press <kbd className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-zinc-800 font-mono text-[10px]">Ctrl+B</kbd> for bold,{' '}
            <kbd className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-zinc-800 font-mono text-[10px]">Ctrl+U</kbd> for underline,{' '}
            <kbd className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-zinc-800 font-mono text-[10px]">Ctrl+H</kbd> for highlight.
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold border border-slate-300 dark:border-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-700 dark:text-zinc-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => {
                onSave(rowId, columnId, content);
                onClose();
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs transition-colors"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save & Apply Changes</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
