import React, { useState, useMemo, useRef } from 'react';
import {
  Shield,
  ShieldCheck,
  Download,
  Upload,
  Plus,
  X,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  DollarSign,
  Calendar,
  User,
  Paperclip,
  Trash2,
  Check,
  FileText,
  AlertCircle,
  ExternalLink,
  Camera,
  Image as ImageIcon,
  Eye,
  Maximize2,
  Sparkles,
  Layers,
  MapPin
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { LegalChecklistItem, Row, Column } from '../types/tracker';
import { formatCurrency } from '../utils/storage';
import {
  STANDARD_REQUIREMENT_PRESETS,
  createOfficialDocumentSvg,
  createSitePhotoSvg
} from '../utils/referencePictures';

interface LegalChecklistModalProps {
  isOpen: boolean;
  onClose: () => void;
  siteRow: Row;
  column?: Column;
  onUpdateSiteChecklist: (updatedItems: LegalChecklistItem[]) => void;
  onNotify?: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onPreviewMedia?: (media: { type: 'jpeg' | 'pdf'; url: string; title: string }) => void;
}

// Default standard requirements with authentic attached reference pictures & proof documents
export const DEFAULT_LEGAL_CHECKLIST_ITEMS: LegalChecklistItem[] = [
  {
    id: 'req-1',
    requirement: 'Barangay Resolution & Site Endorsement',
    category: 'Clearance',
    status: 'Completed',
    amount: 15000,
    assignedStaff: 'PIC: JHENG QUINTO',
    submissionDate: '2026-08-05',
    completionDate: '2026-08-12',
    sopRef: 'SOP-LGU-01',
    receiptDoc: 'Brgy-Res-Signed-OR#8491.pdf',
    receiptDocUrl: STANDARD_REQUIREMENT_PRESETS['req-1']?.previewUrl,
    attachedPictureUrl: STANDARD_REQUIREMENT_PRESETS['req-1']?.previewUrl,
    receiptDocType: 'jpeg',
    remarks: 'Barangay council session passed resolution with unanimous approval.'
  },
  {
    id: 'req-2',
    requirement: 'Lessor Notarized Lease Contract & CTC Title',
    category: 'Legal',
    status: 'Completed',
    amount: 35000,
    assignedStaff: 'Atty. R. Santos',
    submissionDate: '2026-08-10',
    completionDate: '2026-08-18',
    sopRef: 'SOP-LEG-02',
    receiptDoc: 'Notarized-LeaseContract-Book24.pdf',
    receiptDocUrl: STANDARD_REQUIREMENT_PRESETS['req-2']?.previewUrl,
    attachedPictureUrl: STANDARD_REQUIREMENT_PRESETS['req-2']?.previewUrl,
    receiptDocType: 'jpeg',
    remarks: 'Certified true copy of title verified with Registry of Deeds.'
  },
  {
    id: 'req-3',
    requirement: 'Zoning Locational Clearance Certificate',
    category: 'Permit',
    status: 'In Progress',
    amount: 22000,
    assignedStaff: 'PIC: JHENG QUINTO',
    submissionDate: '2026-08-25',
    completionDate: '',
    sopRef: 'SOP-ZON-03',
    receiptDoc: 'Zoning-Application-Receipt#1029.pdf',
    receiptDocUrl: STANDARD_REQUIREMENT_PRESETS['req-3']?.previewUrl,
    attachedPictureUrl: STANDARD_REQUIREMENT_PRESETS['req-3']?.previewUrl,
    receiptDocType: 'jpeg',
    remarks: 'LGU zoning board hearing scheduled for next Tuesday.'
  },
  {
    id: 'req-4',
    requirement: 'Building Permit (BP) Filing Fees & Endorsement',
    category: 'Permit',
    status: 'Submitted',
    amount: 45000,
    assignedStaff: 'Engr. Villanueva',
    submissionDate: '2026-09-02',
    completionDate: '',
    sopRef: 'SOP-BP-04',
    receiptDoc: 'OBO-Filing-AssessedOrder.pdf',
    receiptDocUrl: STANDARD_REQUIREMENT_PRESETS['req-4']?.previewUrl,
    attachedPictureUrl: STANDARD_REQUIREMENT_PRESETS['req-4']?.previewUrl,
    receiptDocType: 'jpeg',
    remarks: 'Awaiting City Building Official structural evaluation release.'
  },
  {
    id: 'req-5',
    requirement: 'CAAP Height Clearance Permit',
    category: 'Clearance',
    status: 'In Progress',
    amount: 18500,
    assignedStaff: 'Engr. Ramos',
    submissionDate: '2026-08-20',
    completionDate: '',
    sopRef: 'SOP-CAAP-05',
    receiptDoc: 'CAAP-FlightNav-OrderOfPayment.pdf',
    receiptDocUrl: STANDARD_REQUIREMENT_PRESETS['req-5']?.previewUrl,
    attachedPictureUrl: STANDARD_REQUIREMENT_PRESETS['req-5']?.previewUrl,
    receiptDocType: 'jpeg',
    remarks: 'Obstacle evaluation analysis underway at central office.'
  },
  {
    id: 'req-6',
    requirement: 'Social Acceptability & HOA Clearance',
    category: 'Social',
    status: 'Completed',
    amount: 10000,
    assignedStaff: 'PIC: JHENG QUINTO',
    submissionDate: '2026-08-08',
    completionDate: '2026-08-14',
    sopRef: 'SOP-SOC-01',
    receiptDoc: 'Community-HOA-NoObjection-Letter.pdf',
    receiptDocUrl: STANDARD_REQUIREMENT_PRESETS['req-6']?.previewUrl,
    attachedPictureUrl: STANDARD_REQUIREMENT_PRESETS['req-6']?.previewUrl,
    receiptDocType: 'jpeg',
    remarks: 'Signed no-objection certificates received from neighboring properties.'
  },
  {
    id: 'req-7',
    requirement: 'BFP Fire Safety Evaluation Clearance (FSEC)',
    category: 'Clearance',
    status: 'Pending',
    amount: 12500,
    assignedStaff: 'Engr. Ramos',
    submissionDate: '',
    completionDate: '',
    sopRef: 'SOP-BFP-02',
    receiptDoc: 'BFP-OrderOfPayment#4410.pdf',
    receiptDocUrl: STANDARD_REQUIREMENT_PRESETS['req-7']?.previewUrl,
    attachedPictureUrl: STANDARD_REQUIREMENT_PRESETS['req-7']?.previewUrl,
    receiptDocType: 'jpeg',
    remarks: 'Pending electrical & architectural plan stamp from BFP marshall.'
  },
  {
    id: 'req-8',
    requirement: 'BIR Documentary Stamp Tax & Tax Declaration',
    category: 'Legal',
    status: 'Completed',
    amount: 28000,
    assignedStaff: 'Atty. R. Santos',
    submissionDate: '2026-08-15',
    completionDate: '2026-08-22',
    sopRef: 'SOP-BIR-07',
    receiptDoc: 'BIR-Form2000-DST-PaymentProof.pdf',
    receiptDocUrl: STANDARD_REQUIREMENT_PRESETS['req-8']?.previewUrl,
    attachedPictureUrl: STANDARD_REQUIREMENT_PRESETS['req-8']?.previewUrl,
    receiptDocType: 'jpeg',
    remarks: 'Paid via authorized agent bank; electronic return filed.'
  }
];

export const LegalChecklistModal: React.FC<LegalChecklistModalProps> = ({
  isOpen,
  onClose,
  siteRow,
  column,
  onUpdateSiteChecklist,
  onNotify,
  onPreviewMedia
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const rowImageUploadRefs = useRef<Record<string, HTMLInputElement | null>>({});

  // View mode: Table vs Reference Pictures Gallery
  const [viewMode, setViewMode] = useState<'table' | 'pictures'>('table');

  // Extract site identity for header
  const siteId = String(siteRow.col_site_id || siteRow.id || 'NS-BIZ22-C30');
  const siteName = String(siteRow.col_site_name || 'Brgy.Kalanganan01_CotabatoCity_Maguindanao');
  const location = String(siteRow.col_location || 'Phil-Tower Consortium Inc.');
  const pic = String(siteRow.col_responsible || 'JHENG QUINTO');
  const siteStage = String(siteRow.col_status || siteRow.col_saq_status || 'Pre-Con Permitting');

  // Generate official Site Photo reference SVG
  const sitePhotoUrl = useMemo(() => {
    return createSitePhotoSvg(siteId, siteName, siteStage);
  }, [siteId, siteName, siteStage]);

  // Parse items from siteRow[column.id] and ensure reference pictures are linked
  const initialItems = useMemo<LegalChecklistItem[]>(() => {
    const colKey = column?.id || 'col_legal_checklist';
    const raw = siteRow[colKey];
    let parsed: any[] = [];

    if (Array.isArray(raw)) {
      parsed = raw;
    } else if (typeof raw === 'string' && raw.trim().startsWith('[')) {
      try {
        const decoded = JSON.parse(raw);
        if (Array.isArray(decoded) && decoded.length > 0) {
          parsed = decoded;
        }
      } catch {}
    }

    if (parsed.length === 0) {
      parsed = DEFAULT_LEGAL_CHECKLIST_ITEMS;
    }

    // Enrich items with standard preset pictures if missing
    return parsed.map((item, idx) => {
      const preset = STANDARD_REQUIREMENT_PRESETS[item.id] || STANDARD_REQUIREMENT_PRESETS[`req-${(idx % 8) + 1}`];
      const hasPic = Boolean(item.attachedPictureUrl || item.receiptDocUrl);
      if (!hasPic && preset) {
        return {
          ...item,
          attachedPictureUrl: preset.previewUrl,
          receiptDocUrl: preset.previewUrl,
          receiptDoc: item.receiptDoc || preset.docNumber + '.pdf',
          receiptDocType: 'jpeg'
        };
      }
      return item;
    });
  }, [siteRow, column]);

  const [items, setItems] = useState<LegalChecklistItem[]>(initialItems);
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'Legal' | 'Permit' | 'Social' | 'Clearance'>('ALL');
  const [isAddingItem, setIsAddingItem] = useState(false);

  // New item draft state
  const [newRequirement, setNewRequirement] = useState('');
  const [newCategory, setNewCategory] = useState<'Legal' | 'Permit' | 'Social' | 'Clearance'>('Legal');
  const [newStatus, setNewStatus] = useState<LegalChecklistItem['status']>('Pending');
  const [newAmount, setNewAmount] = useState<number>(0);
  const [newAssigned, setNewAssigned] = useState('PIC: JHENG QUINTO');
  const [newSubmission, setNewSubmission] = useState('');
  const [newCompletion, setNewCompletion] = useState('');
  const [newSop, setNewSop] = useState('SOP-LEG-01');
  const [newReceipt, setNewReceipt] = useState('');
  const [newAttachedPicUrl, setNewAttachedPicUrl] = useState('');
  const [newRemarks, setNewRemarks] = useState('');

  // KPI Calculations matching reference screenshot
  const totalRequirements = items.length;
  const completedItems = items.filter(i => i.status === 'Completed');
  const completedCount = completedItems.length;
  const completedPercent = totalRequirements > 0 ? Math.round((completedCount / totalRequirements) * 100) : 0;
  const inProgressCount = items.filter(i => i.status === 'In Progress' || i.status === 'Submitted').length;
  const withPicturesCount = items.filter(i => Boolean(i.attachedPictureUrl || i.receiptDocUrl || i.receiptDoc)).length;

  const totalLegalBudget = useMemo(() => {
    return items.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  }, [items]);

  const completedFeesDisbursed = useMemo(() => {
    return completedItems.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  }, [completedItems]);

  // Filtered requirements
  const filteredItems = useMemo(() => {
    if (activeCategory === 'ALL') return items;
    return items.filter(i => i.category === activeCategory);
  }, [items, activeCategory]);

  // Save changes handler
  const saveAndPersist = (updated: LegalChecklistItem[]) => {
    setItems(updated);
    onUpdateSiteChecklist(updated);
  };

  // Toggle item status
  const handleToggleStatus = (id: string, newStat: LegalChecklistItem['status']) => {
    const updated = items.map(item => {
      if (item.id === id) {
        return {
          ...item,
          status: newStat,
          completionDate: newStat === 'Completed' && !item.completionDate ? new Date().toISOString().slice(0, 10) : item.completionDate
        };
      }
      return item;
    });
    saveAndPersist(updated);
    onNotify?.(`Updated status to "${newStat}"`, 'success');
  };

  // Handle uploading picture/proof document for an existing requirement
  const handleUploadItemPicture = (itemId: string, file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      const isPdf = file.type.includes('pdf') || file.name.toLowerCase().endsWith('.pdf');

      const updated = items.map(item => {
        if (item.id === itemId) {
          return {
            ...item,
            receiptDoc: file.name,
            receiptDocUrl: dataUrl,
            attachedPictureUrl: isPdf ? undefined : dataUrl,
            receiptDocType: (isPdf ? 'pdf' : 'jpeg') as 'jpeg' | 'pdf'
          };
        }
        return item;
      });

      saveAndPersist(updated);
      onNotify?.(`Attached "${file.name}" to requirement reference!`, 'success');
    };
    reader.readAsDataURL(file);
  };

  // Handle opening preview media in Lightbox
  const handlePreviewPicture = (item: LegalChecklistItem) => {
    const previewUrl =
      item.attachedPictureUrl ||
      item.receiptDocUrl ||
      STANDARD_REQUIREMENT_PRESETS[item.id]?.previewUrl ||
      createOfficialDocumentSvg(
        item.requirement,
        'Site Acquisition, Regulatory Affairs & Building Permitting Dossier',
        item.category,
        item.sopRef || 'DOC-2026',
        `${siteId} — ${siteName}`,
        item.completionDate || item.submissionDate || '2026-09-01'
      );

    onPreviewMedia?.({
      type: item.receiptDocType === 'pdf' ? 'pdf' : 'jpeg',
      url: previewUrl,
      title: `${siteId}: ${item.requirement} (${item.category} Compliance)`
    });
  };

  // Delete item
  const handleDeleteItem = (id: string) => {
    const updated = items.filter(i => i.id !== id);
    saveAndPersist(updated);
    onNotify?.('Requirement removed from checklist', 'info');
  };

  // Add custom item
  const handleAddCustomRequirement = () => {
    if (!newRequirement.trim()) {
      onNotify?.('Please enter a requirement name', 'error');
      return;
    }

    const customDocSvg = createOfficialDocumentSvg(
      newRequirement.trim(),
      'Office of the Telecom Infrastructure Inspectorate',
      newCategory,
      newSop.trim() || 'SOP-CUSTOM-01',
      `${siteId} — ${siteName}`,
      newSubmission || new Date().toISOString().slice(0, 10)
    );

    const newItem: LegalChecklistItem = {
      id: 'req-' + Date.now(),
      requirement: newRequirement.trim(),
      category: newCategory,
      status: newStatus,
      amount: Number(newAmount) || 0,
      assignedStaff: newAssigned.trim() || 'PIC: JHENG QUINTO',
      submissionDate: newSubmission || '',
      completionDate: newCompletion || '',
      sopRef: newSop.trim() || 'SOP-REQ',
      receiptDoc: newReceipt.trim() || `${newRequirement.trim().replace(/\s+/g, '-')}-Proof.pdf`,
      receiptDocUrl: newAttachedPicUrl || customDocSvg,
      attachedPictureUrl: newAttachedPicUrl || customDocSvg,
      receiptDocType: 'jpeg',
      remarks: newRemarks.trim() || ''
    };

    const updated = [...items, newItem];
    saveAndPersist(updated);
    onNotify?.(`Added "${newItem.requirement}" to legal checklist!`, 'success');

    // Reset draft form
    setNewRequirement('');
    setNewAmount(0);
    setNewReceipt('');
    setNewAttachedPicUrl('');
    setNewRemarks('');
    setIsAddingItem(false);
  };

  // Export Excel Template
  const handleExportExcelTemplate = () => {
    const dataToExport = items.map(i => ({
      'REQUIREMENT': i.requirement,
      'CATEGORY': i.category,
      'STATUS': i.status,
      'AMOUNT (PHP)': i.amount,
      'ASSIGNED STAFF': i.assignedStaff || '',
      'SUBMISSION DATE': i.submissionDate || '',
      'COMPLETION DATE': i.completionDate || '',
      'SOP REF': i.sopRef || '',
      'RECEIPT / PROOF DOCUMENT': i.receiptDoc || '',
      'REMARKS': i.remarks || ''
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Legal Checklist');
    XLSX.writeFile(wb, `${siteId}_Legal_Fees_Compliance_Checklist.xlsx`);
    onNotify?.('Downloaded Excel checklist template', 'success');
  };

  // Import from Excel
  const handleImportExcel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsName = wb.SheetNames[0];
        const ws = wb.Sheets[wsName];
        const rows = XLSX.utils.sheet_to_json<any>(ws);

        if (rows.length === 0) {
          onNotify?.('Excel file contains no rows', 'error');
          return;
        }

        const imported: LegalChecklistItem[] = rows.map((r, idx) => {
          const reqName = String(r['REQUIREMENT'] || r['Requirement'] || `Requirement #${idx + 1}`);
          const cat = (['Legal', 'Permit', 'Social', 'Clearance'].includes(r['CATEGORY'] || r['Category']) ? r['CATEGORY'] || r['Category'] : 'Legal') as any;
          const stat = (['Completed', 'In Progress', 'Submitted', 'Pending', 'Waived'].includes(r['STATUS'] || r['Status']) ? r['STATUS'] || r['Status'] : 'In Progress') as any;
          const preview = createOfficialDocumentSvg(
            reqName,
            'Imported Regulatory Dossier',
            cat,
            `IMP-${idx + 1}`,
            `${siteId} — ${siteName}`,
            new Date().toISOString().slice(0, 10)
          );

          return {
            id: 'imported-' + Date.now() + '-' + idx,
            requirement: reqName,
            category: cat,
            status: stat,
            amount: parseFloat(String(r['AMOUNT (PHP)'] || r['AMOUNT'] || r['Amount'] || 0).replace(/[^0-9.-]+/g, '')) || 0,
            assignedStaff: String(r['ASSIGNED STAFF'] || r['Assigned Staff'] || pic || ''),
            submissionDate: String(r['SUBMISSION DATE'] || r['SUBMISSION'] || ''),
            completionDate: String(r['COMPLETION DATE'] || r['COMPLETION'] || ''),
            sopRef: String(r['SOP REF'] || r['SOP'] || 'SOP-LEG'),
            receiptDoc: String(r['RECEIPT / PROOF DOCUMENT'] || r['RECEIPT'] || ''),
            receiptDocUrl: preview,
            attachedPictureUrl: preview,
            receiptDocType: 'jpeg',
            remarks: String(r['REMARKS'] || r['Remarks'] || '')
          };
        });

        const merged = [...items, ...imported];
        saveAndPersist(merged);
        onNotify?.(`Successfully imported ${imported.length} legal requirements!`, 'success');
      } catch (err) {
        console.error('Import failed', err);
        onNotify?.('Failed to parse Excel file. Please use matching headers.', 'error');
      }
    };
    reader.readAsBinaryString(file);
    e.target.value = '';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150">
      <div className="w-full max-w-6xl rounded-2xl border border-slate-800 bg-[#090e17] text-white shadow-2xl flex flex-col max-h-[96vh] overflow-hidden">
        {/* Hidden Excel File Input */}
        <input
          type="file"
          ref={fileInputRef}
          accept=".xlsx, .xls, .csv"
          className="hidden"
          onChange={handleImportExcel}
        />

        {/* Modal Header */}
        <div className="p-4 sm:px-6 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4 bg-[#0d131f]">
          <div className="flex items-center gap-3">
            {/* Amber Shield Container */}
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              <Shield className="w-5 h-5 fill-amber-500/20" />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                {/* Site ID Badge */}
                <span className="px-2.5 py-0.5 rounded-md font-mono font-bold text-xs bg-cyan-950/90 text-cyan-400 border border-cyan-500/40 tracking-wider">
                  {siteId}
                </span>
                <h2 className="font-black text-base sm:text-lg text-white tracking-wide uppercase">
                  LEGAL FEES & COMPLIANCE CHECKLIST
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Per-Site Clickable Checklist
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 truncate max-w-2xl">
                {siteName} • {location} • PIC: <strong className="text-slate-200">{pic}</strong>
              </p>
            </div>
          </div>

          {/* Top Right Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* View Mode Toggle: Table vs Pictures Gallery */}
            <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5">
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold transition-all ${
                  viewMode === 'table' ? 'bg-sky-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Checklist Table</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('pictures')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold transition-all ${
                  viewMode === 'pictures' ? 'bg-amber-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
                title="View attached reference pictures and proof documents for this site"
              >
                <ImageIcon className="w-3.5 h-3.5 text-amber-300" />
                <span>Reference Pictures ({withPicturesCount})</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleExportExcelTemplate}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors"
              title="Download Excel Template"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Excel Template</span>
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-2xs"
              title="Import requirements from Excel (.xlsx)"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Import</span>
            </button>

            <button
              type="button"
              onClick={() => setIsAddingItem(!isAddingItem)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition-colors shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Add Requirement</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Site Reference Photo Banner (Per-Site Inspection Reference) */}
        <div className="px-4 sm:px-6 py-2.5 bg-gradient-to-r from-sky-950/40 via-indigo-950/30 to-[#090e17] border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            {/* Clickable site photo thumbnail */}
            <div
              onClick={() => {
                onPreviewMedia?.({
                  type: 'jpeg',
                  url: sitePhotoUrl,
                  title: `${siteId} - Telecom Site Field Inspection Reference Photo`
                });
              }}
              className="relative w-14 h-9 rounded-lg overflow-hidden border border-sky-500/40 cursor-pointer group shadow-sm shrink-0"
              title="Click to examine full site reference photo"
            >
              <img src={sitePhotoUrl} alt={siteName} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              <div className="absolute inset-0 bg-black/30 group-hover:bg-transparent flex items-center justify-center">
                <Camera className="w-3.5 h-3.5 text-white drop-shadow" />
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-white flex items-center gap-1">
                  <Camera className="w-3.5 h-3.5 text-sky-400" />
                  <span>Site Reference Photo:</span>
                </span>
                <span className="font-mono text-cyan-300 font-bold">{siteId}</span>
                <span className="text-slate-400">• Stage: <strong className="text-emerald-400">{siteStage}</strong></span>
              </div>
              <p className="text-[11px] text-slate-400">
                Official telecommunication antenna tower & ground coordinates photo reference. Click thumbnail to enlarge.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              onPreviewMedia?.({
                type: 'jpeg',
                url: sitePhotoUrl,
                title: `${siteId} - Telecom Site Field Inspection Reference Photo`
              });
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-sky-500/15 hover:bg-sky-500/25 text-sky-300 border border-sky-500/30 text-[11px] font-bold transition-colors"
          >
            <Eye className="w-3 h-3" />
            <span>View Full Site Photo</span>
          </button>
        </div>

        {/* 5 Summary KPI Cards in a Row */}
        <div className="p-4 sm:px-6 border-b border-slate-800/80 bg-[#090e17]">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
            {/* 1. Total Requirements */}
            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0d131f] space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 block">Total Requirements</span>
              <div className="text-2xl font-black text-white font-mono">
                {totalRequirements}
              </div>
            </div>

            {/* 2. Completed */}
            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0d131f] space-y-1">
              <span className="text-[11px] font-semibold text-emerald-400 block">Completed</span>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {completedCount} <span className="text-sm font-semibold text-emerald-500/80">({completedPercent}%)</span>
              </div>
            </div>

            {/* 3. In Progress / Submitted */}
            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0d131f] space-y-1">
              <span className="text-[11px] font-semibold text-amber-400 block">In Progress / Submitted</span>
              <div className="text-2xl font-black text-amber-400 font-mono">
                {inProgressCount}
              </div>
            </div>

            {/* 4. Total Legal Budget */}
            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0d131f] space-y-1">
              <span className="text-[11px] font-semibold text-slate-400 block">Total Legal Budget</span>
              <div className="text-2xl font-black text-white font-mono">
                {formatCurrency(totalLegalBudget, '₱')}
              </div>
            </div>

            {/* 5. Completed Fees Disbursed */}
            <div className="p-3.5 rounded-xl border border-slate-800 bg-[#0d131f] space-y-1">
              <span className="text-[11px] font-semibold text-cyan-400 block">Completed Fees Disbursed</span>
              <div className="text-2xl font-black text-cyan-400 font-mono">
                {formatCurrency(completedFeesDisbursed, '₱')}
              </div>
            </div>
          </div>
        </div>

        {/* Filter Category Tabs Row */}
        <div className="px-4 sm:px-6 py-3 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3 bg-[#0a0f19]">
          <div className="flex items-center gap-1.5 flex-wrap">
            {(['ALL', 'Legal', 'Permit', 'Social', 'Clearance'] as const).map(cat => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-1 rounded-md text-xs font-bold transition-all ${
                  activeCategory === cat
                    ? 'bg-sky-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-400 font-medium">
            <span className="flex items-center gap-1.5 text-cyan-400">
              <ImageIcon className="w-3.5 h-3.5" />
              <span>{withPicturesCount} reference picture{withPicturesCount !== 1 ? 's' : ''} attached</span>
            </span>
            <span>•</span>
            <span>Showing {filteredItems.length} requirement{filteredItems.length !== 1 ? 's' : ''}</span>
          </div>
        </div>

        {/* Inline Add Custom Requirement Form */}
        {isAddingItem && (
          <div className="p-4 bg-slate-900 border-b border-slate-800 space-y-3 animate-in slide-in-from-top-2 duration-150 text-xs">
            <div className="flex items-center justify-between font-bold text-white">
              <span className="flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-sky-400" />
                <span>Add Custom Legal & Compliance Requirement</span>
              </span>
              <button onClick={() => setIsAddingItem(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
              <div className="sm:col-span-2">
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Requirement Name</label>
                <input
                  type="text"
                  placeholder="e.g. Environmental Compliance Certificate (ECC)"
                  value={newRequirement}
                  onChange={e => setNewRequirement(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white outline-none focus:border-sky-500"
                  autoFocus
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Category</label>
                <select
                  value={newCategory}
                  onChange={e => setNewCategory(e.target.value as any)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white outline-none"
                >
                  <option value="Legal">Legal</option>
                  <option value="Permit">Permit</option>
                  <option value="Social">Social</option>
                  <option value="Clearance">Clearance</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Status</label>
                <select
                  value={newStatus}
                  onChange={e => setNewStatus(e.target.value as any)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white outline-none"
                >
                  <option value="Pending">Pending</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Submitted">Submitted</option>
                  <option value="Completed">Completed</option>
                  <option value="Waived">Waived</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Fee Amount (₱)</label>
                <input
                  type="number"
                  placeholder="0"
                  value={newAmount}
                  onChange={e => setNewAmount(parseFloat(e.target.value) || 0)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Assigned Staff</label>
                <input
                  type="text"
                  placeholder="e.g. PIC: JHENG QUINTO"
                  value={newAssigned}
                  onChange={e => setNewAssigned(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Submission Date</label>
                <input
                  type="date"
                  value={newSubmission}
                  onChange={e => setNewSubmission(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white outline-none"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">SOP Reference</label>
                <input
                  type="text"
                  placeholder="e.g. SOP-DENR-01"
                  value={newSop}
                  onChange={e => setNewSop(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Proof Document Name</label>
                <input
                  type="text"
                  placeholder="e.g. OfficialReceipt#7729.pdf"
                  value={newReceipt}
                  onChange={e => setNewReceipt(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Attach Reference Picture (Photo / PDF)</label>
                <input
                  type="file"
                  accept="image/*,application/pdf"
                  onChange={e => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = ev => {
                        setNewAttachedPicUrl(ev.target?.result as string);
                        setNewReceipt(file.name);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="w-full p-1.5 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs outline-none"
                />
              </div>

              <div className="sm:col-span-4">
                <label className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Engineer Remarks</label>
                <input
                  type="text"
                  placeholder="Notes regarding processing, LGU assessment, or validation..."
                  value={newRemarks}
                  onChange={e => setNewRemarks(e.target.value)}
                  className="w-full p-2 rounded-lg bg-slate-950 border border-slate-700 text-white outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsAddingItem(false)}
                className="px-3 py-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAddCustomRequirement}
                className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold"
              >
                Add Requirement
              </button>
            </div>
          </div>
        )}

        {/* View Mode 1: Reference Pictures & Proof Docs Gallery Grid */}
        {viewMode === 'pictures' ? (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#090e17] custom-scrollbar">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-cyan-400" />
                  <span>Attached Reference Pictures & Proof Documents Gallery</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Visual proof archive for site <strong className="text-cyan-400">{siteId}</strong>. Click any picture to enlarge in high resolution.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors"
              >
                Back to Table View
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredItems.map(item => {
                const picUrl =
                  item.attachedPictureUrl ||
                  item.receiptDocUrl ||
                  STANDARD_REQUIREMENT_PRESETS[item.id]?.previewUrl ||
                  createOfficialDocumentSvg(
                    item.requirement,
                    'Regulatory Clearance Reference',
                    item.category,
                    item.sopRef || 'SOP-2026',
                    `${siteId} — ${siteName}`,
                    item.completionDate || item.submissionDate || '2026-09-01'
                  );

                const isCompleted = item.status === 'Completed';

                return (
                  <div
                    key={item.id}
                    className="rounded-xl border border-slate-800 bg-[#0d131f] overflow-hidden flex flex-col group hover:border-slate-700 transition-all shadow-md"
                  >
                    {/* Picture Preview Canvas */}
                    <div
                      onClick={() => handlePreviewPicture(item)}
                      className="relative h-44 bg-slate-950 overflow-hidden cursor-pointer flex items-center justify-center p-2"
                      title="Click to examine full reference picture"
                    >
                      <img
                        src={picUrl}
                        alt={item.requirement}
                        className="w-full h-full object-contain group-hover:scale-103 transition-transform"
                      />
                      <div className="absolute inset-0 bg-black/30 group-hover:bg-transparent transition-colors flex items-center justify-center">
                        <span className="opacity-0 group-hover:opacity-100 transition-opacity px-2.5 py-1 rounded-md bg-black/70 text-white text-[11px] font-bold flex items-center gap-1.5 backdrop-blur-xs">
                          <Eye className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Click to Enlarge</span>
                        </span>
                      </div>

                      {/* Category Chip */}
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold bg-black/70 text-white backdrop-blur-xs border border-white/20">
                        {item.category}
                      </span>

                      {/* Status Tag */}
                      <span className={`absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-bold border backdrop-blur-xs ${
                        isCompleted
                          ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                          : 'bg-amber-950/80 text-amber-300 border-amber-500/50'
                      }`}>
                        {item.status}
                      </span>
                    </div>

                    {/* Metadata Card Footer */}
                    <div className="p-3 flex-1 flex flex-col justify-between space-y-2">
                      <div>
                        <h4 className="font-bold text-xs text-white line-clamp-2 leading-tight">
                          {item.requirement}
                        </h4>
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1.5">
                          <span className="font-mono font-bold text-emerald-400">
                            {formatCurrency(item.amount, '₱')}
                          </span>
                          <span className="text-[10px] font-mono text-slate-500">
                            {item.sopRef || 'SOP-LEG'}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px]">
                        <button
                          type="button"
                          onClick={() => handlePreviewPicture(item)}
                          className="flex items-center gap-1 text-sky-400 hover:text-sky-300 font-semibold"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Picture</span>
                        </button>

                        <label
                          className="flex items-center gap-1 text-slate-400 hover:text-white cursor-pointer"
                          title="Upload new picture / proof document"
                        >
                          <Camera className="w-3 h-3" />
                          <span>Replace</span>
                          <input
                            type="file"
                            accept="image/*,application/pdf"
                            className="hidden"
                            onChange={e => {
                              const file = e.target.files?.[0];
                              if (file) handleUploadItemPicture(item.id, file);
                            }}
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          /* View Mode 2: Standard Requirements & Compliance Table */
          <div className="flex-1 overflow-x-auto overflow-y-auto custom-scrollbar p-2 sm:p-4 bg-[#090e17]">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="sticky top-0 bg-[#0d131f] border-b border-slate-800 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 z-10">
                <tr>
                  <th className="p-3 whitespace-nowrap">REQUIREMENT</th>
                  <th className="p-3 whitespace-nowrap">CATEGORY</th>
                  <th className="p-3 whitespace-nowrap">STATUS</th>
                  <th className="p-3 whitespace-nowrap text-right">AMOUNT (₱)</th>
                  <th className="p-3 whitespace-nowrap">ASSIGNED STAFF</th>
                  <th className="p-3 whitespace-nowrap">SUBMISSION</th>
                  <th className="p-3 whitespace-nowrap">COMPLETION</th>
                  <th className="p-3 whitespace-nowrap">SOP REF</th>
                  <th className="p-3 whitespace-nowrap">ATTACHED PICTURE / PROOF DOCUMENT</th>
                  <th className="p-3 whitespace-nowrap">REMARKS</th>
                  <th className="p-3 whitespace-nowrap text-center">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-normal">
                {filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={11} className="p-8 text-center text-slate-500">
                      No requirements found under category "{activeCategory}". Click <strong>+ Add Requirement</strong> or <strong>Import</strong> to add items.
                    </td>
                  </tr>
                ) : (
                  filteredItems.map(item => {
                    const isCompleted = item.status === 'Completed';

                    const categoryColor = {
                      Legal: 'text-amber-400 bg-amber-950/40 border-amber-800/60',
                      Permit: 'text-purple-400 bg-purple-950/40 border-purple-800/60',
                      Social: 'text-emerald-400 bg-emerald-950/40 border-emerald-800/60',
                      Clearance: 'text-sky-400 bg-sky-950/40 border-sky-800/60'
                    }[item.category] || 'text-slate-400 bg-slate-900 border-slate-800';

                    const statusColor = {
                      Completed: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
                      'In Progress': 'bg-amber-500/20 text-amber-300 border-amber-500/40',
                      Submitted: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
                      Pending: 'bg-slate-800 text-slate-400 border-slate-700',
                      Waived: 'bg-zinc-800 text-zinc-400 border-zinc-700'
                    }[item.status] || 'bg-slate-800 text-slate-300 border-slate-700';

                    // Attached picture preview url
                    const picUrl =
                      item.attachedPictureUrl ||
                      item.receiptDocUrl ||
                      STANDARD_REQUIREMENT_PRESETS[item.id]?.previewUrl ||
                      createOfficialDocumentSvg(
                        item.requirement,
                        'Regulatory Affairs Certificate',
                        item.category,
                        item.sopRef || 'SOP-2026',
                        `${siteId} — ${siteName}`,
                        item.completionDate || item.submissionDate || '2026-09-01'
                      );

                    return (
                      <tr
                        key={item.id}
                        className={`hover:bg-slate-800/40 transition-colors ${
                          isCompleted ? 'bg-emerald-950/10' : ''
                        }`}
                      >
                        {/* 1. REQUIREMENT */}
                        <td className="p-3 font-semibold text-slate-100 min-w-[220px]">
                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => handleToggleStatus(item.id, isCompleted ? 'In Progress' : 'Completed')}
                              className="text-slate-400 hover:text-emerald-400 shrink-0"
                              title={isCompleted ? 'Mark as In Progress' : 'Mark as Completed'}
                            >
                              {isCompleted ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-500/20" />
                              ) : (
                                <div className="w-4 h-4 rounded-full border border-slate-600 hover:border-emerald-400" />
                              )}
                            </button>
                            <span className={isCompleted ? 'text-slate-200' : 'text-white'}>
                              {item.requirement}
                            </span>
                          </div>
                        </td>

                        {/* 2. CATEGORY */}
                        <td className="p-3 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${categoryColor}`}>
                            {item.category}
                          </span>
                        </td>

                        {/* 3. STATUS */}
                        <td className="p-3 whitespace-nowrap">
                          <select
                            value={item.status}
                            onChange={e => handleToggleStatus(item.id, e.target.value as any)}
                            className={`text-[10px] font-bold px-2 py-1 rounded border outline-none bg-slate-900 cursor-pointer ${statusColor}`}
                          >
                            <option value="Completed">Completed</option>
                            <option value="In Progress">In Progress</option>
                            <option value="Submitted">Submitted</option>
                            <option value="Pending">Pending</option>
                            <option value="Waived">Waived</option>
                          </select>
                        </td>

                        {/* 4. AMOUNT (₱) */}
                        <td className="p-3 font-mono font-bold text-right text-emerald-400 whitespace-nowrap">
                          {formatCurrency(item.amount, '₱')}
                        </td>

                        {/* 5. ASSIGNED STAFF */}
                        <td className="p-3 whitespace-nowrap text-slate-300">
                          <div className="flex items-center gap-1.5">
                            <User className="w-3 h-3 text-slate-500 shrink-0" />
                            <span>{item.assignedStaff || 'Unassigned'}</span>
                          </div>
                        </td>

                        {/* 6. SUBMISSION */}
                        <td className="p-3 whitespace-nowrap font-mono text-[11px] text-slate-400">
                          {item.submissionDate || '-'}
                        </td>

                        {/* 7. COMPLETION */}
                        <td className="p-3 whitespace-nowrap font-mono text-[11px] text-slate-300">
                          {item.completionDate || (isCompleted ? '2026-08-20' : '-')}
                        </td>

                        {/* 8. SOP REF */}
                        <td className="p-3 whitespace-nowrap font-mono text-[11px] text-indigo-300">
                          {item.sopRef || '-'}
                        </td>

                        {/* 9. ATTACHED PICTURE / PROOF DOCUMENT (Rich Clickable Thumbnail) */}
                        <td className="p-3 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            {/* Clickable Image / Document Thumbnail */}
                            <div
                              onClick={() => handlePreviewPicture(item)}
                              className="relative w-10 h-7 rounded border border-slate-700 bg-black/60 overflow-hidden cursor-pointer group shadow-2xs shrink-0"
                              title="Click to view full reference picture in high resolution"
                            >
                              <img
                                src={picUrl}
                                alt={item.requirement}
                                className="w-full h-full object-contain group-hover:scale-110 transition-transform"
                              />
                              <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent flex items-center justify-center">
                                <Eye className="w-3 h-3 text-white drop-shadow opacity-80 group-hover:opacity-100" />
                              </div>
                            </div>

                            {/* Clickable Title Badge */}
                            <button
                              type="button"
                              onClick={() => handlePreviewPicture(item)}
                              className="inline-flex items-center gap-1.5 px-2 py-1 rounded bg-slate-800/90 hover:bg-slate-700 text-sky-400 hover:text-sky-300 text-[11px] font-semibold border border-slate-700/80 transition-colors max-w-[150px] truncate"
                              title="Click to view reference picture"
                            >
                              <Camera className="w-3 h-3 shrink-0 text-cyan-400" />
                              <span className="truncate">{item.receiptDoc || `${item.requirement.slice(0, 14)}...`}</span>
                            </button>

                            {/* Upload / Replace Picture Button */}
                            <label
                              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white cursor-pointer transition-colors"
                              title="Upload or replace attached picture / proof document"
                            >
                              <Upload className="w-3 h-3" />
                              <input
                                type="file"
                                accept="image/*,application/pdf"
                                className="hidden"
                                onChange={e => {
                                  const file = e.target.files?.[0];
                                  if (file) handleUploadItemPicture(item.id, file);
                                }}
                              />
                            </label>
                          </div>
                        </td>

                        {/* 10. REMARKS */}
                        <td className="p-3 text-[11px] text-slate-400 max-w-xs truncate" title={item.remarks}>
                          {item.remarks || '-'}
                        </td>

                        {/* 11. ACTIONS */}
                        <td className="p-3 text-center whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => handleDeleteItem(item.id)}
                            className="p-1 rounded text-slate-500 hover:text-red-400 hover:bg-slate-800 transition-colors"
                            title="Delete requirement"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Modal Bottom Footer */}
        <div className="p-4 sm:px-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-[#0d131f]">
          {/* Left: Green indicator dot with real-time persistence label */}
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
            <span className="font-medium">
              Per-Site Legal Checklist Active: Attached reference pictures, milestone compliance, and amounts persist directly to site row.
            </span>
          </div>

          {/* Right: Close Checklist button */}
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold border border-slate-700 transition-colors shadow-xs"
          >
            Close Checklist
          </button>
        </div>
      </div>
    </div>
  );
};
