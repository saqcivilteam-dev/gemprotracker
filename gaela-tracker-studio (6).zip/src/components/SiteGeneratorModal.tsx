import React, { useState } from 'react';
import {
  Zap,
  Radio,
  X,
  CheckCircle2,
  TrendingUp,
  Layers,
  FileSpreadsheet,
  AlertCircle,
  Clock,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { AppState, Tracker } from '../types/tracker';
import { generateSiteBatch, createDedicatedSiteTracker } from '../utils/fastSiteGenerator';
import { saveStateToIndexedDB } from '../utils/indexedDBStorage';

interface SiteGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onTrackerGenerated: (updatedState: AppState, message: string) => void;
  onNotify: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const SiteGeneratorModal: React.FC<SiteGeneratorModalProps> = ({
  isOpen,
  onClose,
  state,
  onTrackerGenerated,
  onNotify
}) => {
  const [siteCount, setSiteCount] = useState<number>(5000);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [progress, setProgress] = useState<{ current: number; total: number; percent: number }>({
    current: 0,
    total: 0,
    percent: 0
  });
  const [generationTime, setGenerationTime] = useState<number | null>(null);
  const [targetMode, setTargetMode] = useState<'new' | 'replace' | 'append'>('new');

  const activeTracker = state.trackers.find(t => t.id === state.activeTrackerId) || state.trackers[0];

  const PRESETS = [
    { count: 1000, label: '1,000 Sites', speed: '~0.1s', tag: 'Fast Test' },
    { count: 5000, label: '5,000 Sites', speed: '~0.3s', tag: 'EM RPO Target' },
    { count: 10000, label: '10,000 Sites', speed: '~0.6s', tag: 'Regional Scale' },
    { count: 50000, label: '50,000 Sites', speed: '~1.5s', tag: 'High Volume' },
    { count: 100000, label: '100,000 Sites', speed: '~2.8s', tag: 'Max Capacity' }
  ];

  const handleStartGeneration = async () => {
    if (siteCount < 1 || siteCount > 100000) {
      onNotify('Please select a site count between 1 and 100,000.', 'error');
      return;
    }

    try {
      setIsGenerating(true);
      setProgress({ current: 0, total: siteCount, percent: 0 });
      const startTime = performance.now();

      // Chunked asynchronous generation
      const rows = await generateSiteBatch(siteCount, 1, p => {
        setProgress(p);
      });

      const elapsedMs = Math.round(performance.now() - startTime);
      setGenerationTime(elapsedMs);

      let updatedTrackers = [...state.trackers];
      let newActiveId = state.activeTrackerId;
      let successMsg = '';

      if (targetMode === 'new') {
        const newTracker = createDedicatedSiteTracker(rows);
        newTracker.name = `EM RPO Site Tracker (${rows.length.toLocaleString()} Sites)`;
        updatedTrackers.unshift(newTracker);
        newActiveId = newTracker.id;
        successMsg = `Created new Site Tracker with ${rows.length.toLocaleString()} sites in ${elapsedMs}ms!`;
      } else if (targetMode === 'replace') {
        updatedTrackers = updatedTrackers.map(t =>
          t.id === activeTracker.id
            ? { ...t, rows }
            : t
        );
        successMsg = `Replaced active tracker with ${rows.length.toLocaleString()} sites in ${elapsedMs}ms!`;
      } else {
        // Append
        updatedTrackers = updatedTrackers.map(t =>
          t.id === activeTracker.id
            ? { ...t, rows: [...t.rows, ...rows] }
            : t
        );
        const totalRows = (activeTracker.rows.length + rows.length).toLocaleString();
        successMsg = `Appended ${rows.length.toLocaleString()} sites (Total: ${totalRows}) in ${elapsedMs}ms!`;
      }

      const newState: AppState = {
        ...state,
        trackers: updatedTrackers,
        activeTrackerId: newActiveId
      };

      // Safely persist into IndexedDB for large datasets exceeding 5MB
      await saveStateToIndexedDB(newState);

      onTrackerGenerated(newState, successMsg);
      onNotify(successMsg, 'success');
      onClose();
    } catch (err: any) {
      console.error('Generation error:', err);
      onNotify(err.message || 'Error generating site records.', 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-xl bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-800 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between bg-gradient-to-r from-emerald-500/10 via-indigo-500/10 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-zinc-100 flex items-center gap-2">
                <span>Ultra-Fast Site Generator</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  Target: 100,000 Sites
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Non-blocking batch synthesis for large-scale telecom, acquisition, and milestone tracking.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isGenerating}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Preset Buttons */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-zinc-400">
              Select Capacity Preset
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {PRESETS.map(p => (
                <button
                  key={p.count}
                  type="button"
                  onClick={() => setSiteCount(p.count)}
                  disabled={isGenerating}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    siteCount === p.count
                      ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-950 dark:text-emerald-100 shadow-xs ring-1 ring-emerald-500'
                      : 'border-slate-200 dark:border-zinc-800 hover:border-slate-300 dark:hover:border-zinc-700 bg-white dark:bg-zinc-800/40 text-slate-700 dark:text-zinc-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-extrabold text-sm">{p.label}</span>
                    <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                      {p.speed}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">
                    {p.tag}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Count Slider */}
          <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50/70 dark:bg-zinc-800/30 space-y-2">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-zinc-300">
              <span>Custom Site Count:</span>
              <span className="font-mono text-sm font-black text-indigo-600 dark:text-indigo-400">
                {siteCount.toLocaleString()} Sites
              </span>
            </div>
            <input
              type="range"
              min={100}
              max={100000}
              step={500}
              value={siteCount}
              onChange={e => setSiteCount(parseInt(e.target.value, 10))}
              disabled={isGenerating}
              className="w-full h-1.5 bg-slate-200 dark:bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />
            <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>100</span>
              <span>25,000</span>
              <span>50,000</span>
              <span>75,000</span>
              <span>100,000</span>
            </div>
          </div>

          {/* Target Action Mode */}
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-zinc-400">
              Output Destination
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setTargetMode('new')}
                disabled={isGenerating}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  targetMode === 'new'
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-950 dark:text-indigo-100 shadow-2xs font-semibold'
                    : 'border-slate-200 dark:border-zinc-800 text-slate-600 dark:text-zinc-400 hover:bg-slate-50'
                }`}
              >
                <div className="font-bold">New Site Tracker</div>
                <div className="text-[10px] text-slate-400">Preconfigures 24 fields & KPIs</div>
              </button>
              <button
                type="button"
                onClick={() => setTargetMode('replace')}
                disabled={isGenerating}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  targetMode === 'replace'
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-950 dark:text-indigo-100 shadow-2xs font-semibold'
                    : 'border-slate-200 dark:border-zinc-800 text-slate-600 dark:text-zinc-400 hover:bg-slate-50'
                }`}
              >
                <div className="font-bold">Replace Rows</div>
                <div className="text-[10px] text-slate-400">In current active tracker</div>
              </button>
              <button
                type="button"
                onClick={() => setTargetMode('append')}
                disabled={isGenerating}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  targetMode === 'append'
                    ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-950 dark:text-indigo-100 shadow-2xs font-semibold'
                    : 'border-slate-200 dark:border-zinc-800 text-slate-600 dark:text-zinc-400 hover:bg-slate-50'
                }`}
              >
                <div className="font-bold">Append to Current</div>
                <div className="text-[10px] text-slate-400">Adds onto existing rows</div>
              </button>
            </div>
          </div>

          {/* Progress Indicator */}
          {isGenerating && (
            <div className="p-4 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-emerald-50/70 dark:bg-emerald-950/40 space-y-2 animate-in fade-in">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-800 dark:text-emerald-200">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  Generating {siteCount.toLocaleString()} Site Records...
                </span>
                <span className="font-mono">{progress.percent}%</span>
              </div>
              <div className="w-full bg-emerald-200 dark:bg-emerald-900 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-600 h-full transition-all duration-150 rounded-full"
                  style={{ width: `${progress.percent}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-emerald-700 dark:text-emerald-300 font-mono">
                <span>{progress.current.toLocaleString()} / {progress.total.toLocaleString()} sites</span>
                <span>Optimized non-blocking chunks</span>
              </div>
            </div>
          )}

          {/* Included Fields Preview */}
          <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-800/40 space-y-2 text-xs">
            <div className="font-bold text-slate-700 dark:text-zinc-300 flex items-center justify-between">
              <span>Automatic EM RPO Fields (24 Columns)</span>
              <span className="text-[10px] text-emerald-600 font-bold">57% Acquired KPI Target Pace</span>
            </div>
            <div className="flex flex-wrap gap-1 text-[10px] text-slate-600 dark:text-zinc-400">
              {[
                'Site ID', 'Site Name', 'Location', 'TowerCo', 'Acquisition Status', 'Acq Target Date',
                'Legal Status', 'Legal Rep', 'Legal Fee (₱)', 'Contract Status', 'Milestones',
                'Approved Budget (₱)', 'Actual Cost (₱)', 'Remaining Budget (₱)', 'Variance (₱)',
                'Responsible Person', 'Team', 'Priority', 'Risk Level', 'Next Action'
              ].map(f => (
                <span key={f} className="px-2 py-0.5 rounded bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700">
                  {f}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            disabled={isGenerating}
            className="px-4 py-2 text-xs font-semibold rounded-xl border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 hover:bg-slate-50 transition-colors disabled:opacity-50"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleStartGeneration}
            disabled={isGenerating}
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-md transition-all active:scale-95 disabled:opacity-50"
          >
            <Zap className="w-4 h-4 fill-current" />
            <span>{isGenerating ? 'Generating...' : `Generate ${siteCount.toLocaleString()} Sites Now`}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
