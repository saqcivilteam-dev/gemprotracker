import React, { useState, useMemo } from 'react';
import {
  Search,
  X,
  ExternalLink,
  ArrowRight,
  Filter,
  Calendar,
  Building2,
  DollarSign,
  FileCheck2,
  Tag,
  CheckSquare,
  Square,
  Calculator,
  PlusCircle,
  Copy,
  Check,
  TrendingUp,
  Maximize2,
  Eye,
  FileText,
  Image as ImageIcon,
  ChevronDown,
  ChevronUp,
  LayoutGrid,
  Table as TableIcon,
  Info,
  Layers,
  Sparkles,
  Download,
  Clock,
  ShieldCheck,
  AlertCircle,
  Printer,
  FileSpreadsheet
} from 'lucide-react';
import { Tracker, AppState, Column, ColumnType, Row } from '../types/tracker';
import { formatCurrency, formatPercent, normalizeExcelDate, exportSearchResultsToExcel } from '../utils/storage';
import { renderFormattedContent } from '../utils/textFormatter';

interface GlobalSearchModalProps {
  state: AppState;
  isDark: boolean;
  onClose: () => void;
  onSelectResult: (trackerId: string, rowId: string, searchTerm?: string) => void;
  onPreviewImage?: (url: string, title: string) => void;
  onPreviewPdf?: (url: string, title: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  state,
  isDark,
  onClose,
  onSelectResult,
  onPreviewImage,
  onPreviewPdf
}) => {
  const [query, setQuery] = useState('');
  const [checkedTrackerIds, setCheckedTrackerIds] = useState<string[]>(() =>
    state.trackers.map(t => t.id)
  );
  const [viewMode, setViewMode] = useState<'cards' | 'table' | 'dossier'>('cards');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedSummary, setCopiedSummary] = useState<boolean>(false);
  const [inspectedRow, setInspectedRow] = useState<any | null>(null);
  const [expandedRowIds, setExpandedRowIds] = useState<Record<string, boolean>>({});
  const [allExpanded, setAllExpanded] = useState<boolean>(true);

  // Helper to toggle single tracker
  const handleToggleTracker = (trackerId: string) => {
    setCheckedTrackerIds(prev =>
      prev.includes(trackerId) ? prev.filter(id => id !== trackerId) : [...prev, trackerId]
    );
  };

  const handleSelectAllTrackers = () => {
    setCheckedTrackerIds(state.trackers.map(t => t.id));
  };

  const handleClearAllTrackers = () => {
    setCheckedTrackerIds([]);
  };

  // Toggle expand/collapse of column details for a specific card
  const toggleRowExpanded = (rowUniqueKey: string) => {
    setExpandedRowIds(prev => ({
      ...prev,
      [rowUniqueKey]: !prev[rowUniqueKey]
    }));
  };

  // Toggle all cards expanded/collapsed
  const handleToggleExpandAll = () => {
    const next = !allExpanded;
    setAllExpanded(next);
    const newMap: Record<string, boolean> = {};
    searchResults.forEach(res => {
      newMap[res.uniqueKey] = next;
    });
    setExpandedRowIds(newMap);
  };

  // Helper to highlight matching keyword in text
  const highlightMatch = (text: any, q: string) => {
    if (!text && text !== 0) return <span className="text-slate-400 italic">None</span>;
    const str = String(text);
    const cleanQ = q.trim();
    if (!cleanQ) return str;

    const regex = new RegExp(`(${cleanQ.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
    const parts = str.split(regex);

    if (parts.length === 1) return str;

    return (
      <>
        {parts.map((part, i) =>
          regex.test(part) ? (
            <mark
              key={i}
              className="bg-amber-200 dark:bg-amber-900/80 text-amber-950 dark:text-amber-100 font-bold px-0.5 rounded shadow-2xs"
            >
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  };

  // Safe number parser
  const parseNum = (v: any): number => {
    if (v === undefined || v === null || v === '') return 0;
    if (typeof v === 'number') return isNaN(v) ? 0 : v;
    const cleaned = String(v).replace(/[^0-9.-]+/g, '');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
  };

  // Format value by column type
  const formatCellValue = (val: any, col: Column): string => {
    if (val === undefined || val === null || val === '') return '';
    if (col.type === 'amount') {
      const num = parseNum(val);
      return formatCurrency(num, col.currencySymbol || '₱');
    }
    if (col.type === 'percent') {
      const num = parseNum(val);
      return formatPercent(num);
    }
    if (col.type === 'date') {
      return normalizeExcelDate(val);
    }
    return String(val);
  };

  // Search across all checked trackers and rows to extract full row details
  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    const results: Array<{
      trackerId: string;
      trackerName: string;
      trackerIcon?: string;
      trackerColor?: string;
      rowId: string;
      uniqueKey: string;
      primaryTitle: string;
      personName: string;
      calNo: string;
      projectName: string;
      weekName: string;
      statusValue: string;
      statusColName: string;
      purposeValue: string;
      remarksValue: string;
      dataValue: string;
      requestAmount: number;
      approvedAmount: number;
      liquidatedAmount: number;
      openCalAmount: number;
      dateLiquidated: string;
      dates: Array<{ label: string; value: string; raw: any }>;
      amounts: Array<{ label: string; value: number; formatted: string }>;
      mediaAttachments: Array<{ type: 'jpeg' | 'pdf'; label: string; value: string }>;
      columns: Column[];
      allColumnsData: Array<{
        colId: string;
        colName: string;
        type: ColumnType;
        rawValue: any;
        formattedValue: string;
        isMatch: boolean;
      }>;
      rawRow: Row;
    }> = [];

    state.trackers.forEach(tracker => {
      if (!checkedTrackerIds.includes(tracker.id)) return;

      tracker.rows.forEach(row => {
        let isMatch = !q; // If no query, matches all rows
        const allColumnsData: Array<{
          colId: string;
          colName: string;
          type: ColumnType;
          rawValue: any;
          formattedValue: string;
          isMatch: boolean;
        }> = [];

        const dates: Array<{ label: string; value: string; raw: any }> = [];
        const amounts: Array<{ label: string; value: number; formatted: string }> = [];
        const mediaAttachments: Array<{ type: 'jpeg' | 'pdf'; label: string; value: string }> = [];

        let primaryTitle = '';
        let personName = '';
        let calNo = '';
        let projectName = '';
        let weekName = '';
        let siteName = '';
        let statusValue = '';
        let statusColName = '';
        let purposeValue = '';
        let remarksValue = '';
        let dataValue = '';
        let requestAmount = 0;
        let approvedAmount = 0;
        let liquidatedAmount = 0;
        let dateLiquidated = '';

        tracker.columns.forEach((col, cIdx) => {
          const rawValue = row[col.id];
          const formattedValue = formatCellValue(rawValue, col);
          const colNameLower = col.name.toLowerCase();
          const strValLower = String(rawValue || '').toLowerCase();
          const formattedValLower = formattedValue.toLowerCase();

          // Check keyword match across all values
          const cellMatches =
            Boolean(q) &&
            (strValLower.includes(q) ||
              formattedValLower.includes(q) ||
              colNameLower.includes(q));

          if (cellMatches) {
            isMatch = true;
          }

          allColumnsData.push({
            colId: col.id,
            colName: col.name,
            type: col.type,
            rawValue,
            formattedValue,
            isMatch: cellMatches
          });

          // Intelligent column semantics detection
          if (colNameLower === 'name' || colNameLower.includes('person') || colNameLower.includes('engineer') || colNameLower.includes('assignee')) {
            personName = String(rawValue || '');
          }

          if (colNameLower.includes('cal no') || colNameLower.includes('cal #') || colNameLower.includes('voucher') || colNameLower.includes('ref')) {
            calNo = String(rawValue || '');
          }

          if (colNameLower.includes('project') || colNameLower.includes('vendor')) {
            projectName = String(rawValue || '');
          }

          if (colNameLower === 'week' || colNameLower.includes('wk')) {
            weekName = String(rawValue || '');
          }

          if (colNameLower.includes('site') || colNameLower.includes('station') || colNameLower.includes('location')) {
            siteName = String(rawValue || '');
          }

          if (colNameLower.includes('data') || colNameLower.includes('errand') || colNameLower.includes('task')) {
            dataValue = String(rawValue || '');
          }

          // Detect Status / Remarks
          if (col.type === 'status' || colNameLower.includes('status')) {
            statusValue = String(rawValue || '');
            statusColName = col.name;
          }

          if (colNameLower.includes('purpose') || colNameLower.includes('scope')) {
            purposeValue = String(rawValue || '');
          }

          if (colNameLower.includes('remark') || colNameLower.includes('note') || colNameLower.includes('comment')) {
            remarksValue = String(rawValue || '');
            // Often remarks holds 'CLOSED CAL' or 'OPEN CAL'
            if (!statusValue && (remarksValue.includes('CAL') || remarksValue.includes('CLOSE') || remarksValue.includes('OPEN') || remarksValue.includes('SETTLED'))) {
              statusValue = remarksValue;
              statusColName = col.name;
            }
          }

          // Detect Dates
          if (
            (col.type === 'date' || colNameLower.includes('date') || colNameLower.includes('apply') || colNameLower.includes('target') || colNameLower.includes('settled') || colNameLower.includes('close')) &&
            rawValue
          ) {
            dates.push({
              label: col.name,
              value: formattedValue,
              raw: rawValue
            });

            if (colNameLower.includes('liquidat') || colNameLower.includes('settled')) {
              dateLiquidated = formattedValue;
            }
          }

          // Detect Amounts
          if (
            (col.type === 'amount' || colNameLower.includes('amount') || colNameLower.includes('fee') || colNameLower.includes('payment') || colNameLower.includes('cost')) &&
            rawValue !== undefined && rawValue !== null && rawValue !== ''
          ) {
            const num = parseNum(rawValue);
            amounts.push({
              label: col.name,
              value: num,
              formatted: formattedValue || formatCurrency(num, col.currencySymbol || '₱')
            });

            if (colNameLower.includes('req')) {
              requestAmount = num;
            } else if (colNameLower.includes('appr')) {
              approvedAmount = num;
            } else if (colNameLower.includes('liquidat') || colNameLower.includes('settled') || colNameLower.includes('paid')) {
              liquidatedAmount = num;
            }
          }

          // Detect Media Attachments (JPEG/PDF)
          if ((col.type === 'jpeg' || col.type === 'pdf') && rawValue) {
            mediaAttachments.push({
              type: col.type,
              label: col.name,
              value: String(rawValue)
            });
          }
        });

        if (isMatch) {
          // Construct best complete primary title
          if (calNo && personName) {
            primaryTitle = `${calNo} · ${personName}`;
          } else if (personName) {
            primaryTitle = personName;
          } else if (calNo) {
            primaryTitle = calNo;
          } else if (siteName) {
            primaryTitle = siteName;
          } else {
            primaryTitle = String(row[tracker.columns[0]?.id] || `Row #${row.id.slice(-6)}`);
          }

          // If no explicit request amount but there is an amount column
          if (requestAmount === 0 && amounts.length > 0) {
            requestAmount = amounts[0].value;
          }

          const baseAmount = approvedAmount > 0 ? approvedAmount : requestAmount;
          const openCalAmount = Math.max(0, baseAmount - liquidatedAmount);

          results.push({
            trackerId: tracker.id,
            trackerName: tracker.name,
            trackerIcon: tracker.icon,
            trackerColor: tracker.color,
            rowId: row.id,
            uniqueKey: `${tracker.id}-${row.id}`,
            primaryTitle,
            personName,
            calNo,
            projectName,
            weekName,
            statusValue: statusValue || remarksValue || 'Active',
            statusColName: statusColName || 'Status',
            purposeValue,
            remarksValue,
            dataValue,
            requestAmount,
            approvedAmount,
            liquidatedAmount,
            openCalAmount,
            dateLiquidated,
            dates,
            amounts,
            mediaAttachments,
            columns: tracker.columns,
            allColumnsData,
            rawRow: row
          });
        }
      });
    });

    return results;
  }, [query, state.trackers, checkedTrackerIds]);

  // Compute live search subtotals across all matched records
  const searchSubtotal = useMemo(() => {
    let totalRequested = 0;
    let totalApproved = 0;
    let totalLiquidated = 0;
    let totalOpenCal = 0;
    let totalMatches = searchResults.length;

    const trackerCounts: Record<string, { name: string; amount: number; count: number; color?: string }> = {};

    searchResults.forEach(res => {
      totalRequested += res.requestAmount || 0;
      totalApproved += res.approvedAmount || res.requestAmount || 0;
      totalLiquidated += res.liquidatedAmount || 0;
      totalOpenCal += res.openCalAmount || 0;

      if (!trackerCounts[res.trackerId]) {
        trackerCounts[res.trackerId] = {
          name: res.trackerName,
          color: res.trackerColor,
          amount: 0,
          count: 0
        };
      }
      trackerCounts[res.trackerId].count += 1;
      trackerCounts[res.trackerId].amount += res.requestAmount || (res.amounts[0]?.value || 0);
    });

    const overallAmount = totalApproved > 0 ? totalApproved : totalRequested;

    return {
      totalRequested,
      totalApproved: overallAmount,
      totalLiquidated,
      totalOpenCal,
      totalAmount: overallAmount,
      totalMatches,
      breakdown: Object.values(trackerCounts),
      settlementRate: overallAmount > 0 ? Math.round((totalLiquidated / overallAmount) * 100) : 0
    };
  }, [searchResults]);

  // Copy full single row details to clipboard
  const handleCopySingleRow = (res: typeof searchResults[0]) => {
    let text = `=========================================\n`;
    text += `SHEET: ${res.trackerName}\n`;
    text += `RECORD: ${res.primaryTitle}\n`;
    if (res.projectName) text += `PROJECT: ${res.projectName}\n`;
    if (res.weekName) text += `WEEK: ${res.weekName}\n`;
    if (res.statusValue) text += `STATUS: ${res.statusValue}\n`;
    text += `-----------------------------------------\n`;
    text += `ALL ROW DETAILS:\n`;
    res.allColumnsData.forEach(col => {
      text += `${col.colName}: ${col.formattedValue || '—'}\n`;
    });
    text += `=========================================`;

    navigator.clipboard.writeText(text);
    setCopiedId(res.uniqueKey);
    setTimeout(() => setCopiedId(null), 2500);
  };

  // Copy full complete data details report to clipboard
  const handleCopyCompleteDetails = () => {
    let text = `=================================================================================\n`;
    text += `GAELA TRACKER STUDIO - COMPLETE DATA DETAILS REPORT\n`;
    text += `Generated: ${new Date().toLocaleString()}\n`;
    text += `Filter / Search Query: "${query || 'ALL RECORDS'}"\n`;
    text += `Matching Records: ${searchSubtotal.totalMatches}\n`;
    text += `---------------------------------------------------------------------------------\n`;
    text += `FINANCIAL RECONCILIATION SUMMARY:\n`;
    text += `• Total Requested:  ${formatCurrency(searchSubtotal.totalRequested, '₱')}\n`;
    text += `• Total Approved:   ${formatCurrency(searchSubtotal.totalApproved, '₱')}\n`;
    text += `• Total Liquidated: ${formatCurrency(searchSubtotal.totalLiquidated, '₱')} (${searchSubtotal.settlementRate}% Settlement Rate)\n`;
    text += `• Remaining Open CAL / Balance: ${formatCurrency(searchSubtotal.totalOpenCal, '₱')}\n`;
    text += `=================================================================================\n\n`;

    searchResults.forEach((res, i) => {
      text += `[RECORD #${i + 1}] ${res.primaryTitle}\n`;
      text += `Sheet: ${res.trackerName} | Project: ${res.projectName || '—'} | Week: ${res.weekName || '—'}\n`;
      text += `Status: ${res.statusValue} | Requested: ₱${res.requestAmount.toLocaleString()} | Liquidated: ₱${res.liquidatedAmount.toLocaleString()} | Open CAL: ₱${res.openCalAmount.toLocaleString()}\n`;
      if (res.purposeValue) text += `Scope/Purpose: ${res.purposeValue}\n`;
      if (res.dataValue) text += `DATA / Errands:\n${res.dataValue}\n`;
      text += `Complete Attributes:\n`;
      res.allColumnsData.forEach(c => {
        text += `  • ${c.colName}: ${c.formattedValue || '—'}\n`;
      });
      text += `---------------------------------------------------------------------------------\n`;
    });

    navigator.clipboard.writeText(text);
    setCopiedSummary(true);
    setTimeout(() => setCopiedSummary(false), 3000);
  };

  // Export Complete Search Data to genuine Excel (.xlsx) file
  const handleExportExcel = () => {
    exportSearchResultsToExcel(searchResults, query);
  };

  // Print Complete Report
  const handlePrintDossier = () => {
    window.print();
  };

  // Status badge styling helper
  const getStatusBadgeClass = (status: string) => {
    const s = status.toLowerCase();
    if (s.includes('settled') || s.includes('completed') || s.includes('approved') || s.includes('close')) {
      return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border-emerald-300 dark:border-emerald-800';
    }
    if (s.includes('payment requested') || s.includes('in progress') || s.includes('evaluat') || s.includes('open')) {
      return 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border-amber-300 dark:border-amber-800';
    }
    if (s.includes('delayed') || s.includes('reject') || s.includes('issue')) {
      return 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300 border-rose-300 dark:border-rose-800';
    }
    return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/80 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800';
  };

  // Quick preset queries for user ease
  const presets = ['All Records', 'OPEN CAL', 'CLOSED CAL', 'PHILTOWER', 'EDGEPOINT', 'GLOBE', 'WEEK 03', 'SETTLED'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-2 sm:p-4 animate-in fade-in duration-150">
      <div
        className={`w-full max-w-6xl h-[94vh] rounded-2xl flex flex-col shadow-2xl border overflow-hidden ${
          isDark
            ? 'bg-zinc-900 border-zinc-700 text-zinc-100'
            : 'bg-white border-slate-200 text-slate-800'
        }`}
      >
        {/* Header */}
        <div className="p-3.5 sm:p-4 border-b border-slate-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3 bg-slate-50/90 dark:bg-zinc-800/90 backdrop-blur-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 text-white flex items-center justify-center shadow-xs">
              <Search className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-900 dark:text-zinc-100">
                  Search All Data & Complete Row Details
                </h2>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-950/80 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  {searchResults.length} Records Found
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Generate and inspect complete details across all connected trackers, projects, and personnel records.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Primary Action: Generate Complete Data Details */}
            <button
              type="button"
              onClick={() => setViewMode(viewMode === 'dossier' ? 'cards' : 'dossier')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-xs ${
                viewMode === 'dossier'
                  ? 'bg-indigo-600 text-white shadow-indigo-500/25 ring-2 ring-indigo-400'
                  : 'bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white'
              }`}
              title="Generate complete data details dossier with full columns, financial KPIs & print report"
            >
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>{viewMode === 'dossier' ? 'View Search Cards' : 'Generate Complete Details'}</span>
            </button>

            {/* View Mode Switcher */}
            <div className="flex items-center bg-slate-200 dark:bg-zinc-800 p-0.5 rounded-lg border border-slate-300 dark:border-zinc-700">
              <button
                type="button"
                onClick={() => setViewMode('cards')}
                className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                  viewMode === 'cards'
                    ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
                }`}
                title="View full row cards with all details"
              >
                <LayoutGrid className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Cards</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                  viewMode === 'table'
                    ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
                }`}
                title="View in spreadsheet data table format"
              >
                <TableIcon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Table</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('dossier')}
                className={`flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-md transition-all ${
                  viewMode === 'dossier'
                    ? 'bg-white dark:bg-zinc-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                    : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
                }`}
                title="Generate complete audit report dossier"
              >
                <FileText className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Report</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-zinc-800 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Search Input & Checked Trackers Toolbar */}
        <div className="p-3 sm:p-4 border-b border-slate-200 dark:border-zinc-800 space-y-2.5 bg-white dark:bg-zinc-900">
          <div className="relative">
            <Search className="w-4 h-4 text-indigo-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              autoFocus
              placeholder="Search all data: CAL number, personnel name, project, week, amount, scope, errands, remarks..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-sm rounded-xl border border-indigo-300 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800/80 focus:bg-white dark:focus:bg-zinc-800 focus:border-indigo-500 outline-none text-slate-900 dark:text-zinc-100 font-medium shadow-2xs"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Tracker Selection Checkboxes */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-600 dark:text-zinc-400">
              <span className="flex items-center gap-1.5">
                <Calculator className="w-3.5 h-3.5 text-indigo-600" />
                <span>Search in Trackers ({checkedTrackerIds.length} of {state.trackers.length}):</span>
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSelectAllTrackers}
                  className="text-indigo-600 dark:text-indigo-400 hover:underline font-semibold"
                >
                  Check All
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={handleClearAllTrackers}
                  className="text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 font-semibold"
                >
                  Clear All
                </button>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {state.trackers.map(t => {
                const isChecked = checkedTrackerIds.includes(t.id);
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => handleToggleTracker(t.id)}
                    className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-semibold transition-all ${
                      isChecked
                        ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-300 dark:border-indigo-700 text-indigo-800 dark:text-indigo-200 shadow-2xs'
                        : 'bg-slate-100 dark:bg-zinc-800/50 border-slate-200 dark:border-zinc-700 text-slate-400 dark:text-zinc-500 hover:border-slate-300'
                    }`}
                  >
                    {isChecked ? (
                      <CheckSquare className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    ) : (
                      <Square className="w-3.5 h-3.5 text-slate-400 dark:text-zinc-600" />
                    )}
                    <span>{t.name}</span>
                    <span className="text-[10px] text-slate-400 font-normal">({t.rows.length})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Preset Tags & Actions */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5 border-t border-slate-100 dark:border-zinc-800">
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              <span className="text-slate-400 dark:text-zinc-500 text-[11px] font-semibold flex items-center gap-1">
                <Tag className="w-3 h-3" /> Quick presets:
              </span>
              {presets.map(tag => (
                <button
                  key={tag}
                  onClick={() => {
                    if (tag === 'All Records') {
                      setQuery('');
                    } else {
                      setQuery(tag);
                    }
                  }}
                  className={`px-2 py-0.5 rounded-full text-[11px] font-medium border transition-colors ${
                    (tag === 'All Records' && !query) || query.toLowerCase() === tag.toLowerCase()
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-slate-100 dark:bg-zinc-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 text-slate-600 dark:text-zinc-300 border-slate-200 dark:border-zinc-700'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>

            {/* Quick Export & Print Actions */}
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={handleExportExcel}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 text-emerald-800 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-800 shadow-2xs transition-colors"
                title="Download genuine Microsoft Excel (.xlsx) file with all columns of all matching records"
              >
                <Download className="w-3 h-3 text-emerald-600" />
                <span>Export Excel (.xlsx)</span>
              </button>

              <button
                type="button"
                onClick={handlePrintDossier}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 text-slate-700 dark:text-zinc-200 border border-slate-300 dark:border-zinc-700 shadow-2xs transition-colors"
                title="Print complete data details report or save as PDF"
              >
                <Printer className="w-3 h-3 text-slate-500" />
                <span>Print PDF</span>
              </button>
            </div>
          </div>
        </div>

        {/* Live Search Subtotal Banner */}
        {searchResults.length > 0 && (
          <div className="px-4 py-2.5 bg-indigo-50/80 dark:bg-indigo-950/40 border-b border-indigo-100 dark:border-indigo-900/60 flex flex-wrap items-center justify-between gap-3 animate-in fade-in">
            <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
              <div className="flex items-center gap-1.5">
                <Calculator className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span className="text-xs font-bold text-slate-700 dark:text-zinc-300">
                  {query ? `Search Total ("${query}"):` : 'Consolidated Total:'}
                </span>
                <span className="text-base font-black text-indigo-700 dark:text-indigo-300">
                  {formatCurrency(searchSubtotal.totalAmount, '₱')}
                </span>
              </div>

              <div className="text-xs text-slate-600 dark:text-zinc-400 flex flex-wrap items-center gap-3 font-medium">
                <span>
                  Requested: <strong className="text-slate-800 dark:text-zinc-200">{formatCurrency(searchSubtotal.totalRequested, '₱')}</strong>
                </span>
                <span>
                  Liquidated: <strong className="text-emerald-600 dark:text-emerald-400">{formatCurrency(searchSubtotal.totalLiquidated, '₱')}</strong>
                </span>
                <span>
                  Open CAL / Bal: <strong className="text-rose-600 dark:text-rose-400">{formatCurrency(searchSubtotal.totalOpenCal, '₱')}</strong>
                </span>
                <span>
                  Settled: <strong className="text-indigo-600 dark:text-indigo-400">{searchSubtotal.settlementRate}%</strong>
                </span>
                <span>
                  Records: <strong className="text-slate-800 dark:text-zinc-200">{searchSubtotal.totalMatches}</strong>
                </span>
              </div>
            </div>

            {/* Subtotal Action Buttons */}
            <div className="flex items-center gap-2">
              {viewMode === 'cards' && (
                <button
                  type="button"
                  onClick={handleToggleExpandAll}
                  className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border border-indigo-300 dark:border-indigo-700 bg-white dark:bg-zinc-800 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 shadow-2xs transition-colors"
                  title="Expand or collapse full column breakdowns on all cards"
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>{allExpanded ? 'Collapse Columns' : 'Expand All Columns'}</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleCopyCompleteDetails}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 hover:bg-slate-50 shadow-2xs transition-colors"
                title="Copy complete data details report"
              >
                {copiedSummary ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedSummary ? 'Copied Details!' : 'Copy Complete Report'}</span>
              </button>
            </div>
          </div>
        )}

        {/* Results Area */}
        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-slate-50/50 dark:bg-zinc-950/30">
          {searchResults.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-zinc-800 flex items-center justify-center mx-auto text-slate-400">
                <Search className="w-6 h-6" />
              </div>
              <p className="text-base font-bold text-slate-700 dark:text-zinc-200">
                {query ? `No matching records found for "${query}"` : 'No trackers selected'}
              </p>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Check at least one tracker above, or search for personnel names, CAL numbers, projects, dates, or remarks.
              </p>
            </div>
          ) : viewMode === 'dossier' ? (
            /* COMPLETE DATA DETAILS DOSSIER VIEW (EXECUTIVE REPORT) */
            <div className="space-y-4 max-w-4xl mx-auto print:max-w-none print:p-0">
              {/* Report Header Card */}
              <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-sm print:border-none print:shadow-none">
                <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-200 dark:border-zinc-800">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                      Official Audit & Operations Dossier
                    </span>
                    <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-zinc-100 tracking-tight mt-0.5">
                      Complete Data Details Report
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-zinc-400 mt-1">
                      Consolidated search breakdown containing complete attributes, financial disbursements, and errand checklists.
                    </p>
                  </div>

                  <div className="text-right text-xs space-y-1">
                    <div className="font-mono text-slate-500">Date: {new Date().toLocaleDateString()}</div>
                    <div className="text-slate-400">Query Filter: <span className="font-bold text-slate-700 dark:text-zinc-200">{query || 'All Records'}</span></div>
                    <div className="text-slate-400">Matching Rows: <span className="font-bold text-indigo-600 dark:text-indigo-400">{searchResults.length}</span></div>
                  </div>
                </div>

                {/* KPI Cards Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/60 border border-slate-100 dark:border-zinc-800">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Total Requested</span>
                    <span className="text-base sm:text-lg font-black text-slate-900 dark:text-zinc-100 mt-0.5 block">
                      {formatCurrency(searchSubtotal.totalRequested, '₱')}
                    </span>
                    <span className="text-[10px] text-slate-400">All matched requests</span>
                  </div>

                  <div className="p-3 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 block">Approved Cap</span>
                    <span className="text-base sm:text-lg font-black text-indigo-700 dark:text-indigo-300 mt-0.5 block">
                      {formatCurrency(searchSubtotal.totalApproved, '₱')}
                    </span>
                    <span className="text-[10px] text-indigo-500">Approved allocations</span>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/60">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 block">Total Liquidated</span>
                    <span className="text-base sm:text-lg font-black text-emerald-700 dark:text-emerald-300 mt-0.5 block">
                      {formatCurrency(searchSubtotal.totalLiquidated, '₱')}
                    </span>
                    <span className="text-[10px] text-emerald-600 font-semibold">{searchSubtotal.settlementRate}% completed</span>
                  </div>

                  <div className="p-3 rounded-xl bg-rose-50/60 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-900/60">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400 block">Open CAL Balance</span>
                    <span className="text-base sm:text-lg font-black text-rose-700 dark:text-rose-300 mt-0.5 block">
                      {formatCurrency(searchSubtotal.totalOpenCal, '₱')}
                    </span>
                    <span className="text-[10px] text-rose-500 font-semibold">Remaining liquidation</span>
                  </div>
                </div>
              </div>

              {/* Individual Complete Row Slips */}
              <div className="space-y-4">
                {searchResults.map((res, i) => (
                  <div
                    key={res.uniqueKey}
                    className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-xs print:break-inside-avoid print:border-slate-300"
                  >
                    {/* Record Header */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-zinc-800">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2 py-0.5 rounded font-mono font-bold text-xs bg-indigo-600 text-white">
                          #{i + 1}
                        </span>
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                          {res.trackerName}
                        </span>
                        {res.calNo && (
                          <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 border border-slate-200 dark:border-zinc-700">
                            {res.calNo}
                          </span>
                        )}
                        {res.projectName && (
                          <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                            {res.projectName}
                          </span>
                        )}
                        {res.weekName && (
                          <span className="text-xs font-bold px-2 py-0.5 rounded bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-300 border border-slate-200 dark:border-zinc-700">
                            {res.weekName}
                          </span>
                        )}
                        <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadgeClass(res.statusValue)}`}>
                          {res.statusValue}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          onSelectResult(res.trackerId, res.rowId, query);
                          onClose();
                        }}
                        className="print:hidden text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold flex items-center gap-1"
                      >
                        <span>Open in Sheet</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Personnel & Title */}
                    <div className="py-2.5">
                      <h3 className="text-base font-extrabold text-slate-900 dark:text-zinc-100">
                        {res.personName ? `${res.personName}` : res.primaryTitle}
                      </h3>
                      {res.purposeValue && (
                        <p className="text-xs text-slate-600 dark:text-zinc-300 mt-0.5 font-medium">
                          Purpose: <span className="font-semibold text-slate-800 dark:text-zinc-200">{res.purposeValue}</span>
                        </p>
                      )}
                    </div>

                    {/* Financial Summary Line */}
                    <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/50 border border-slate-100 dark:border-zinc-800 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">Requested:</span>
                        <span className="font-bold text-slate-800 dark:text-zinc-200">₱{res.requestAmount.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">Approved:</span>
                        <span className="font-bold text-indigo-600 dark:text-indigo-400">₱{res.approvedAmount.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">Liquidated:</span>
                        <span className="font-bold text-emerald-600 dark:text-emerald-400">₱{res.liquidatedAmount.toLocaleString()}</span>
                        {res.dateLiquidated && (
                          <span className="text-[10px] text-slate-400 block">({res.dateLiquidated})</span>
                        )}
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block font-bold">Open CAL:</span>
                        <span className={`font-black ${res.openCalAmount > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
                          ₱{res.openCalAmount.toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {/* Rich DATA & Errand Breakdown (Preserves Highlights, Bold & Underline) */}
                    {res.dataValue && (
                      <div className="mt-3 p-3.5 rounded-xl bg-indigo-50/40 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300 block mb-1.5 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-indigo-500" />
                          <span>Operational Tasks, Scope & Traveling Route:</span>
                        </span>
                        <div className="text-xs text-slate-800 dark:text-zinc-200 leading-relaxed">
                          {renderFormattedContent(res.dataValue, { isCompact: true })}
                        </div>
                      </div>
                    )}

                    {/* Complete All Columns Grid */}
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-zinc-800">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                        Complete Column Details ({res.allColumnsData.length} Attributes):
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-xs">
                        {res.allColumnsData.map(col => (
                          <div key={col.colId} className="p-2 rounded-lg bg-slate-50/80 dark:bg-zinc-800/40 border border-slate-100 dark:border-zinc-800">
                            <span className="text-[10px] text-slate-400 block font-bold uppercase truncate">{col.colName}</span>
                            <span className="font-semibold text-slate-800 dark:text-zinc-200 block truncate mt-0.5">
                              {col.formattedValue || <span className="text-slate-300 dark:text-zinc-600 font-normal italic">—</span>}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Formal Audit Sign-Off Section */}
              <div className="p-5 rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 text-xs">
                <span className="font-bold text-slate-700 dark:text-zinc-300 uppercase tracking-wider block mb-4">
                  Official Verification & Signatures
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-2">
                  <div className="border-t border-slate-300 dark:border-zinc-700 pt-2 space-y-1">
                    <span className="text-[11px] text-slate-400 block">Prepared By:</span>
                    <span className="font-bold text-slate-800 dark:text-zinc-200 block">Operations Specialist</span>
                    <span className="text-[10px] text-slate-400 block">Date: ____________________</span>
                  </div>
                  <div className="border-t border-slate-300 dark:border-zinc-700 pt-2 space-y-1">
                    <span className="text-[11px] text-slate-400 block">Audited & Verified By:</span>
                    <span className="font-bold text-slate-800 dark:text-zinc-200 block">Finance / Quality Auditor</span>
                    <span className="text-[10px] text-slate-400 block">Date: ____________________</span>
                  </div>
                  <div className="border-t border-slate-300 dark:border-zinc-700 pt-2 space-y-1">
                    <span className="text-[11px] text-slate-400 block">Approved for Liquidation:</span>
                    <span className="font-bold text-slate-800 dark:text-zinc-200 block">Project Manager / Director</span>
                    <span className="text-[10px] text-slate-400 block">Date: ____________________</span>
                  </div>
                </div>
              </div>
            </div>
          ) : viewMode === 'table' ? (
            /* SPREADSHEET TABLE VIEW (ALL DETAILS IN DATA GRID) */
            <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden bg-white dark:bg-zinc-900 shadow-sm">
              <div className="overflow-x-auto custom-scrollbar max-h-[62vh]">
                <table className="w-full text-xs text-left border-collapse whitespace-nowrap">
                  <thead className="bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300 font-bold sticky top-0 z-10 border-b border-slate-200 dark:border-zinc-700">
                    <tr>
                      <th className="p-3">Source Sheet</th>
                      <th className="p-3">CAL / Ref #</th>
                      <th className="p-3">Personnel Name</th>
                      <th className="p-3">Project</th>
                      <th className="p-3">Week</th>
                      <th className="p-3">Status</th>
                      <th className="p-3">Requested</th>
                      <th className="p-3">Liquidated</th>
                      <th className="p-3">Open CAL</th>
                      <th className="p-3">Scope / DATA Details</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-zinc-800">
                    {searchResults.map((res, idx) => (
                      <tr
                        key={res.uniqueKey}
                        className="hover:bg-indigo-50/40 dark:hover:bg-indigo-950/20 transition-colors group"
                      >
                        {/* Tracker */}
                        <td className="p-3">
                          <span className="inline-flex items-center gap-1 font-bold text-[11px] px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                            <Building2 className="w-3 h-3" />
                            {res.trackerName}
                          </span>
                        </td>

                        {/* CAL No */}
                        <td className="p-3 font-mono font-bold text-slate-800 dark:text-zinc-200">
                          {res.calNo ? highlightMatch(res.calNo, query) : <span className="text-slate-400">—</span>}
                        </td>

                        {/* Personnel Name */}
                        <td className="p-3 font-bold text-slate-900 dark:text-zinc-100">
                          {highlightMatch(res.personName || res.primaryTitle, query)}
                        </td>

                        {/* Project */}
                        <td className="p-3">
                          {res.projectName ? (
                            <span className="px-2 py-0.5 rounded font-semibold text-[10px] bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                              {highlightMatch(res.projectName, query)}
                            </span>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </td>

                        {/* Week */}
                        <td className="p-3 font-semibold text-slate-600 dark:text-zinc-300">
                          {res.weekName || '—'}
                        </td>

                        {/* Status */}
                        <td className="p-3">
                          <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border ${getStatusBadgeClass(res.statusValue)}`}>
                            {highlightMatch(res.statusValue, query)}
                          </span>
                        </td>

                        {/* Requested */}
                        <td className="p-3 font-bold text-slate-800 dark:text-zinc-200">
                          ₱{res.requestAmount.toLocaleString()}
                        </td>

                        {/* Liquidated */}
                        <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400">
                          ₱{res.liquidatedAmount.toLocaleString()}
                        </td>

                        {/* Open CAL */}
                        <td className="p-3 font-black text-rose-600 dark:text-rose-400">
                          {res.openCalAmount > 0 ? `₱${res.openCalAmount.toLocaleString()}` : <span className="text-emerald-500 font-bold">Settled</span>}
                        </td>

                        {/* DATA Details / Scope */}
                        <td className="p-3 max-w-sm whitespace-normal">
                          <div className="line-clamp-2 text-xs">
                            {res.dataValue ? renderFormattedContent(res.dataValue, { isCompact: true }) : res.purposeValue || '—'}
                          </div>
                        </td>

                        {/* Actions */}
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setInspectedRow(res)}
                              className="px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 dark:bg-zinc-800 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 font-semibold text-[11px] flex items-center gap-1"
                              title="Inspect complete column details"
                            >
                              <Eye className="w-3 h-3 text-indigo-500" />
                              <span>Details</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                onSelectResult(res.trackerId, res.rowId, query);
                                onClose();
                              }}
                              className="px-2 py-1 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-[11px] flex items-center gap-1"
                              title="Open this record in its original sheet"
                            >
                              <span>Open</span>
                              <ArrowRight className="w-3 h-3" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* DETAILED CARDS VIEW (SHOWS ALL COLUMNS ON EVERY ROW) */
            <div className="space-y-3.5">
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-zinc-400 px-1">
                <span>
                  Showing complete details for <strong className="text-slate-800 dark:text-zinc-200">{searchResults.length}</strong> matching record{searchResults.length === 1 ? '' : 's'}:
                </span>
                <span className="text-[11px]">All column attributes, amounts, dates, and scope included</span>
              </div>

              {searchResults.map((res, idx) => {
                const isExpanded = expandedRowIds[res.uniqueKey] !== false; // default expanded

                return (
                  <div
                    key={res.uniqueKey}
                    className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 hover:border-indigo-400 dark:hover:border-indigo-600 hover:shadow-md transition-all group"
                  >
                    {/* Card Top Header */}
                    <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-slate-100 dark:border-zinc-800">
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200/80 dark:border-indigo-800 flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5" />
                            {res.trackerName}
                          </span>

                          {res.calNo && (
                            <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-md bg-slate-100 dark:bg-zinc-800 text-slate-800 dark:text-zinc-200 border border-slate-200 dark:border-zinc-700">
                              {highlightMatch(res.calNo, query)}
                            </span>
                          )}

                          {res.projectName && (
                            <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800">
                              {highlightMatch(res.projectName, query)}
                            </span>
                          )}

                          {res.weekName && (
                            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-300 border border-slate-200 dark:border-zinc-700">
                              {highlightMatch(res.weekName, query)}
                            </span>
                          )}

                          <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadgeClass(res.statusValue)}`}>
                            {highlightMatch(res.statusValue, query)}
                          </span>
                        </div>

                        {/* Primary Title */}
                        <h3 className="text-base font-extrabold text-slate-900 dark:text-zinc-100 tracking-tight flex items-center gap-2">
                          <span>{highlightMatch(res.primaryTitle, query)}</span>
                        </h3>
                      </div>

                      {/* Top Action Buttons */}
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleCopySingleRow(res)}
                          className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-700 text-xs font-semibold text-slate-700 dark:text-zinc-200 transition-colors flex items-center gap-1"
                          title="Copy all row data to clipboard"
                        >
                          {copiedId === res.uniqueKey ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          <span className="hidden sm:inline">{copiedId === res.uniqueKey ? 'Copied' : 'Copy'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setInspectedRow(res)}
                          className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 hover:bg-slate-100 dark:hover:bg-zinc-700 text-xs font-semibold text-slate-700 dark:text-zinc-200 transition-colors flex items-center gap-1"
                          title="Inspect raw details"
                        >
                          <Eye className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="hidden sm:inline">Inspect</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            onSelectResult(res.trackerId, res.rowId, query);
                            onClose();
                          }}
                          className="px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1 group-hover:translate-x-0.5"
                          title="Jump directly to this row inside the tracker"
                        >
                          <span>Open in Tracker</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Financial Highlights Bar */}
                    <div className="my-3 p-2.5 rounded-lg bg-slate-50 dark:bg-zinc-800/60 border border-slate-100 dark:border-zinc-800/80 flex flex-wrap items-center justify-between gap-2.5 text-xs">
                      <div className="flex flex-wrap items-center gap-4">
                        <div className="flex items-center gap-1">
                          <span className="text-[11px] text-slate-400 font-medium">Requested:</span>
                          <span className="font-extrabold text-slate-800 dark:text-zinc-200">
                            ₱{res.requestAmount.toLocaleString()}
                          </span>
                        </div>
                        {res.approvedAmount > 0 && (
                          <div className="flex items-center gap-1">
                            <span className="text-[11px] text-slate-400 font-medium">Approved:</span>
                            <span className="font-extrabold text-indigo-600 dark:text-indigo-400">
                              ₱{res.approvedAmount.toLocaleString()}
                            </span>
                          </div>
                        )}
                        <div className="flex items-center gap-1">
                          <span className="text-[11px] text-slate-400 font-medium">Liquidated:</span>
                          <span className="font-extrabold text-emerald-600 dark:text-emerald-400">
                            ₱{res.liquidatedAmount.toLocaleString()}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-[11px] text-slate-400 font-medium">Open CAL:</span>
                          <span className={`font-black ${res.openCalAmount > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600'}`}>
                            ₱{res.openCalAmount.toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {/* Dates */}
                      <div className="flex flex-wrap items-center gap-2">
                        {res.dates.map((dt, dIdx) => (
                          <div
                            key={dIdx}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-200/80 dark:border-amber-900/40 text-[11px]"
                          >
                            <Calendar className="w-3 h-3 text-amber-600" />
                            <span className="font-medium text-slate-500 dark:text-zinc-400">{dt.label}:</span>
                            <span className="font-semibold">{highlightMatch(dt.value, query)}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Scope & Formatted DATA Errands (Preserving Highlights & Checkboxes) */}
                    {(res.purposeValue || res.dataValue) && (
                      <div className="my-2.5 space-y-2 text-xs">
                        {res.purposeValue && (
                          <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-zinc-800/40 border border-slate-200/60 dark:border-zinc-800">
                            <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-300 uppercase tracking-wider block mb-0.5">
                              Scope / Purpose
                            </span>
                            <p className="text-slate-800 dark:text-zinc-200 font-medium">
                              {highlightMatch(res.purposeValue, query)}
                            </p>
                          </div>
                        )}

                        {res.dataValue && (
                          <div className="p-3 rounded-lg bg-indigo-50/50 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50">
                            <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-300 uppercase tracking-wider block mb-1 flex items-center gap-1">
                              <Sparkles className="w-3 h-3 text-indigo-500" />
                              <span>DATA & Operational Errands (Formatted Highlights & Tasks):</span>
                            </span>
                            <div className="text-slate-800 dark:text-zinc-200">
                              {renderFormattedContent(res.dataValue, { isCompact: true })}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Media Attachments Strip */}
                    {res.mediaAttachments.length > 0 && (
                      <div className="flex flex-wrap items-center gap-2 my-2.5 pt-1">
                        <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                          <FileText className="w-3 h-3 text-indigo-500" />
                          <span>Attachments:</span>
                        </span>
                        {res.mediaAttachments.map((media, mIdx) => (
                          <div key={mIdx} className="flex items-center gap-1">
                            {media.type === 'jpeg' ? (
                              <button
                                type="button"
                                onClick={() => onPreviewImage?.(media.value, `${res.primaryTitle} - ${media.label}`)}
                                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold bg-cyan-50 dark:bg-cyan-950/60 text-cyan-800 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800 hover:bg-cyan-100 transition-colors"
                              >
                                <ImageIcon className="w-3.5 h-3.5 text-cyan-600" />
                                <span>{media.label}: {media.value}</span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => onPreviewPdf?.(media.value, `${res.primaryTitle} - ${media.label}`)}
                                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-semibold bg-purple-50 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300 border border-purple-200 dark:border-purple-800 hover:bg-purple-100 transition-colors"
                              >
                                <FileCheck2 className="w-3.5 h-3.5 text-purple-600" />
                                <span>{media.label}: {media.value}</span>
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Complete Column Breakdown Grid (Shows EVERY COLUMN on this row!) */}
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-zinc-800">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-zinc-500 flex items-center gap-1.5">
                          <Layers className="w-3 h-3 text-indigo-500" />
                          <span>All Row Attributes ({res.allColumnsData.length} Columns):</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => toggleRowExpanded(res.uniqueKey)}
                          className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                        >
                          <span>{isExpanded ? 'Hide Columns' : 'Show All Columns'}</span>
                          {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                        </button>
                      </div>

                      {isExpanded && (
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-xs animate-in fade-in">
                          {res.allColumnsData.map(col => {
                            const hasValue = col.formattedValue !== '';

                            return (
                              <div
                                key={col.colId}
                                className={`p-2 rounded-lg border transition-colors ${
                                  col.isMatch
                                    ? 'bg-amber-50/80 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800/80'
                                    : 'bg-slate-50/60 dark:bg-zinc-800/40 border-slate-100 dark:border-zinc-800'
                                }`}
                              >
                                <span className="text-[10px] font-bold text-slate-400 dark:text-zinc-500 uppercase block truncate">
                                  {col.colName}
                                </span>
                                <div className="mt-0.5 font-semibold text-slate-800 dark:text-zinc-200 truncate">
                                  {hasValue ? (
                                    col.type === 'amount' ? (
                                      <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">
                                        {col.formattedValue}
                                      </span>
                                    ) : col.type === 'percent' ? (
                                      <span className="text-indigo-600 dark:text-indigo-400 font-bold">
                                        {col.formattedValue}
                                      </span>
                                    ) : (
                                      highlightMatch(col.formattedValue, query)
                                    )
                                  ) : (
                                    <span className="text-slate-300 dark:text-zinc-600 italic font-normal text-[11px]">
                                      —
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-zinc-400 bg-slate-50 dark:bg-zinc-800/40">
          <div className="flex items-center gap-2">
            <kbd className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-zinc-700 text-[10px] font-mono">ESC</kbd>
            <span>to close search</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleExportExcel}
              className="text-emerald-600 dark:text-emerald-400 hover:underline font-semibold flex items-center gap-1"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export All Search Results (.xlsx)</span>
            </button>
            <span className="text-slate-300 dark:text-zinc-700">•</span>
            <div className="font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Complete Data Details Across All Connected Sheets</span>
            </div>
          </div>
        </div>

        {/* Raw Detail Inspector Modal */}
        {inspectedRow && (
          <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/60 p-4">
            <div
              className={`w-full max-w-2xl max-h-[85vh] rounded-2xl flex flex-col shadow-2xl border overflow-hidden ${
                isDark ? 'bg-zinc-900 border-zinc-700 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
              }`}
            >
              <div className="p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-extrabold flex items-center gap-2">
                    <span>Complete Row Attributes & Details</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold">
                      {inspectedRow.trackerName}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5 font-mono">
                    ID: {inspectedRow.rowId}
                  </p>
                </div>
                <button
                  onClick={() => setInspectedRow(null)}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-400"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 custom-scrollbar space-y-2.5">
                {inspectedRow.allColumnsData.map((col: any) => (
                  <div
                    key={col.colId}
                    className="p-3 rounded-lg border border-slate-200 dark:border-zinc-800 bg-slate-50/60 dark:bg-zinc-800/40 flex items-start justify-between gap-4"
                  >
                    <div className="space-y-0.5 min-w-0 flex-1">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        {col.colName} ({col.type})
                      </span>
                      <div className="text-sm font-semibold text-slate-900 dark:text-zinc-100 break-words">
                        {col.colName.toLowerCase().includes('data') && col.rawValue ? (
                          renderFormattedContent(col.rawValue, { isCompact: true })
                        ) : (
                          col.formattedValue || <span className="text-slate-400 italic font-normal">Empty</span>
                        )}
                      </div>
                    </div>

                    {col.formattedValue && (
                      <button
                        type="button"
                        onClick={() => {
                          navigator.clipboard.writeText(col.formattedValue);
                          setCopiedId(col.colId);
                          setTimeout(() => setCopiedId(null), 2000);
                        }}
                        className="p-1 text-slate-400 hover:text-indigo-600 shrink-0"
                        title="Copy value"
                      >
                        {copiedId === col.colId ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    )}
                  </div>
                ))}
              </div>

              <div className="p-3 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => handleCopySingleRow(inspectedRow)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-zinc-800 flex items-center gap-1.5"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Entire Row</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    onSelectResult(inspectedRow.trackerId, inspectedRow.rowId, query);
                    setInspectedRow(null);
                    onClose();
                  }}
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-xs flex items-center gap-1.5"
                >
                  <span>Jump to Row in Sheet</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
