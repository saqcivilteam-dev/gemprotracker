import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  Send,
  Clock,
  CheckCircle2,
  XCircle,
  Eye,
  PlusCircle,
  Edit3,
  Trash2,
  Download,
  AlertCircle,
  Columns,
  RotateCcw,
  Sparkles
} from 'lucide-react';
import { AppState, User, Tracker, AccessRequest } from '../types/tracker';

interface AccessRequestModalProps {
  state: AppState;
  currentUser: User;
  isDark: boolean;
  onClose: () => void;
  onSubmitRequest: (payload: {
    trackerId: string;
    requestedPermissions: {
      view: boolean;
      add: boolean;
      edit: boolean;
      delete: boolean;
      export: boolean;
    };
    requestedFields: string[];
    reason: string;
  }) => Promise<{ success: boolean; message?: string }>;
}

export const AccessRequestModal: React.FC<AccessRequestModalProps> = ({
  state,
  currentUser,
  isDark,
  onClose,
  onSubmitRequest
}) => {
  const [selectedTrackerId, setSelectedTrackerId] = useState<string>(
    state.activeTrackerId || state.trackers[0]?.id || ''
  );

  const [permView, setPermView] = useState<boolean>(true);
  const [permAdd, setPermAdd] = useState<boolean>(false);
  const [permEdit, setPermEdit] = useState<boolean>(true);
  const [permDelete, setPermDelete] = useState<boolean>(false);
  const [permExport, setPermExport] = useState<boolean>(false);

  const [selectedFields, setSelectedFields] = useState<string[]>([]);
  const [reason, setReason] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const targetTracker = state.trackers.find(t => t.id === selectedTrackerId) || state.trackers[0];

  // Initialize selected fields with visible columns when tracker changes
  const handleTrackerChange = (trackerId: string) => {
    setSelectedTrackerId(trackerId);
    setSelectedFields([]);
  };

  const handleToggleField = (colId: string) => {
    setSelectedFields(prev =>
      prev.includes(colId) ? prev.filter(id => id !== colId) : [...prev, colId]
    );
  };

  const handleSelectAllFields = () => {
    if (!targetTracker) return;
    if (selectedFields.length === targetTracker.columns.length) {
      setSelectedFields([]);
    } else {
      setSelectedFields(targetTracker.columns.map(c => c.id));
    }
  };

  const myRequests = useMemo(() => {
    return (state.accessRequests || []).filter(r => r.userId === currentUser.id);
  }, [state.accessRequests, currentUser.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTrackerId) {
      setStatusMessage({ type: 'error', text: 'Please select a tracker.' });
      return;
    }
    if (!reason.trim()) {
      setStatusMessage({ type: 'error', text: 'Please provide a business reason for your request.' });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    const res = await onSubmitRequest({
      trackerId: selectedTrackerId,
      requestedPermissions: {
        view: permView,
        add: permAdd,
        edit: permEdit,
        delete: permDelete,
        export: permExport
      },
      requestedFields: permEdit ? selectedFields : [],
      reason: reason.trim()
    });

    setIsSubmitting(false);

    if (res.success) {
      setStatusMessage({
        type: 'success',
        text: 'Access request submitted successfully! An Administrator will review and approve your permissions.'
      });
      setReason('');
      setSelectedFields([]);
    } else {
      setStatusMessage({
        type: 'error',
        text: res.message || 'Failed to submit access request. Please try again.'
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div
        className={`w-full max-w-2xl rounded-2xl border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden my-auto ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base">Request Tracker Access</h3>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 dark:bg-zinc-800 text-slate-700 dark:text-zinc-300">
                  {currentUser.role}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Submit a permission request to the Administrator for specific trackers and columns.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-zinc-800 cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Status Message */}
          {statusMessage && (
            <div
              className={`p-3 rounded-xl border flex items-start gap-2.5 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                  : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <div className="flex-1 font-medium">{statusMessage.text}</div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* 1. Target Tracker */}
            <div>
              <label className="block font-semibold mb-1.5 text-slate-700 dark:text-zinc-300">
                1. Select Tracker to Access <span className="text-red-500">*</span>
              </label>
              <select
                value={selectedTrackerId}
                onChange={e => handleTrackerChange(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs font-medium outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {state.trackers.map(t => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.columns.length} columns, {t.rows.length} records)
                  </option>
                ))}
              </select>
            </div>

            {/* 2. Requested Permissions */}
            <div>
              <label className="block font-semibold mb-1.5 text-slate-700 dark:text-zinc-300">
                2. Requested Actions
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-800/60 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permView}
                    onChange={e => setPermView(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="flex items-center gap-1.5">
                    <Eye className="w-3.5 h-3.5 text-blue-500" />
                    <span className="font-semibold">View</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-800/60 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permAdd}
                    onChange={e => setPermAdd(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="flex items-center gap-1.5">
                    <PlusCircle className="w-3.5 h-3.5 text-emerald-500" />
                    <span className="font-semibold">Add</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-800/60 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permEdit}
                    onChange={e => setPermEdit(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="flex items-center gap-1.5">
                    <Edit3 className="w-3.5 h-3.5 text-amber-500" />
                    <span className="font-semibold">Edit</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-800/60 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permDelete}
                    onChange={e => setPermDelete(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="flex items-center gap-1.5">
                    <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                    <span className="font-semibold">Delete</span>
                  </div>
                </label>

                <label className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-800/60 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permExport}
                    onChange={e => setPermExport(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <div className="flex items-center gap-1.5">
                    <Download className="w-3.5 h-3.5 text-purple-500" />
                    <span className="font-semibold">Export</span>
                  </div>
                </label>
              </div>
            </div>

            {/* 3. Field-Level Editing Selection */}
            {permEdit && targetTracker && (
              <div className="space-y-2 p-3.5 rounded-xl border border-amber-200/80 dark:border-amber-900/40 bg-amber-50/30 dark:bg-amber-950/20">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-zinc-200">
                    <Columns className="w-3.5 h-3.5 text-amber-600" />
                    <span>3. Choose Fields You Want To Edit</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleSelectAllFields}
                    className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                  >
                    {selectedFields.length === targetTracker.columns.length ? 'Deselect All' : 'Select All Columns'}
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-zinc-400">
                  Select which specific columns you need permission to edit. Unselected columns will remain View Only or No Access.
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 pt-1">
                  {targetTracker.columns.map(col => {
                    const isChecked = selectedFields.includes(col.id);
                    return (
                      <label
                        key={col.id}
                        className={`flex items-center gap-2 p-2 rounded-lg border text-xs cursor-pointer transition-all ${
                          isChecked
                            ? 'bg-amber-100/70 dark:bg-amber-900/40 border-amber-300 dark:border-amber-700 text-slate-900 dark:text-zinc-100 font-semibold'
                            : 'bg-white dark:bg-zinc-800 border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-400'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleField(col.id)}
                          className="rounded text-amber-600 focus:ring-amber-500"
                        />
                        <span className="truncate">{col.name}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 4. Reason */}
            <div>
              <label className="block font-semibold mb-1 text-slate-700 dark:text-zinc-300">
                4. Business Justification / Reason <span className="text-red-500">*</span>
              </label>
              <textarea
                value={reason}
                onChange={e => setReason(e.target.value)}
                rows={3}
                placeholder="e.g., Need to update daily site milestone progress and remarks for QA audit."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-xs cursor-pointer disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Submitting Request...' : 'Submit Access Request'}</span>
              </button>
            </div>
          </form>

          {/* Past Requests Section */}
          <div className="pt-4 border-t border-slate-200 dark:border-zinc-800 space-y-3">
            <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-zinc-200">
              <Clock className="w-4 h-4 text-slate-500" />
              <span>Your Access Requests History ({myRequests.length})</span>
            </div>

            {myRequests.length === 0 ? (
              <div className="p-4 rounded-xl border border-dashed border-slate-200 dark:border-zinc-800 text-center text-slate-400">
                You have not submitted any access requests yet.
              </div>
            ) : (
              <div className="space-y-2">
                {myRequests.map(req => (
                  <div
                    key={req.id}
                    className="p-3 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50/50 dark:bg-zinc-800/40 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-zinc-100">
                          {req.trackerName}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                            req.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : req.status === 'rejected'
                              ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                              : req.status === 'revoked'
                              ? 'bg-zinc-200 text-zinc-700 dark:bg-zinc-700 dark:text-zinc-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse'
                          }`}
                        >
                          {req.status}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-zinc-400 mt-1">
                        Reason: &ldquo;{req.reason}&rdquo;
                      </div>
                      {req.adminNote && (
                        <div className="text-[11px] text-indigo-600 dark:text-indigo-400 font-semibold mt-0.5">
                          Admin Note: {req.adminNote}
                        </div>
                      )}
                    </div>

                    <div className="text-[10px] text-slate-400 shrink-0 sm:text-right">
                      <div>Submitted: {new Date(req.createdAt).toLocaleDateString()}</div>
                      {req.reviewedBy && <div>Reviewed by: {req.reviewedBy}</div>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between bg-slate-50/50 dark:bg-zinc-800/40">
          <span className="text-[11px] text-slate-500 dark:text-zinc-400">
            Permissions are enforced in database and logs.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-200 hover:bg-slate-300 dark:bg-zinc-700 dark:hover:bg-zinc-600 text-slate-800 dark:text-zinc-200 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
