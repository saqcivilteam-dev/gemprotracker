import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Search,
  Filter,
  ArrowUpDown,
  Plus,
  Trash2,
  Copy,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Eye,
  SlidersHorizontal,
  FileSpreadsheet,
  Download,
  Upload,
  AlignLeft,
  Calendar,
  ExternalLink,
  Image as ImageIcon,
  FileText,
  CheckCircle2,
  Clock,
  AlertCircle,
  MoreVertical,
  Layers,
  ArrowDownUp,
  Maximize2,
  Minimize2,
  ArrowUp,
  ArrowDown,
  X,
  ClipboardPaste,
  Sparkles,
  Calculator,
  CheckSquare,
  Square,
  DollarSign,
  Check,
  HelpCircle,
  RefreshCw,
  Lock,
  Unlock,
  Undo2,
  Redo2,
  Shield,
  ShieldCheck,
  AlertTriangle,
  Presentation,
  EyeOff,
  ShieldAlert,
  KeyRound
} from 'lucide-react';
import { Tracker, Row, Column, User, TrackerPermission, FieldAccessLevel } from '../types/tracker';
import { getEffectiveTrackerPermission, getFieldAccess } from '../utils/permissionUtils';
import { formatCurrency, formatPercent, exportToExcel, normalizeExcelDate, parseExcelData } from '../utils/storage';
import { renderFormattedContent } from '../utils/textFormatter';
import { DEFAULT_LEGAL_CHECKLIST_ITEMS } from './LegalChecklistModal';
import { generateDefaultDayByDayLog, calculateDayByDaySla, STATUS_BADGE_STYLES } from '../utils/dayByDayUtils';
import { RichTextEditorModal } from './RichTextEditorModal';
import { formatDateYMD } from '../utils/saqSlaEngine';

// Safe number parser
const parseNum = (v: any): number => {
  if (v === undefined || v === null || v === '') return 0;
  if (typeof v === 'number') return isNaN(v) ? 0 : v;
  const cleaned = String(v).replace(/[^0-9.-]+/g, '');
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? 0 : parsed;
};

interface TrackerTableProps {
  tracker: Tracker;
  currentUser: User | null;
  isDark: boolean;
  highlightedRowId?: string | null;
  initialSearchTerm?: string;
  canUndo?: boolean;
  canRedo?: boolean;
  onUndo?: () => void;
  onRedo?: () => void;
  isDataProtected?: boolean;
  onToggleDataProtection?: () => void;
  onSearchChange?: (term: string) => void;
  onUpdateTracker: (updated: Tracker) => void;
  onOpenExcelPaste: () => void;
  onOpenColumnManager: () => void;
  onPreviewImage: (url: string, title: string) => void;
  onPreviewPdf: (url: string, title: string) => void;
  onExportCSV: () => void;
  onOpenReport?: () => void;
  onOpenPresentation?: () => void;
  trackerPermissions?: TrackerPermission[];
  onRequestAccess?: () => void;
  onLogActivity?: (action: string, params: {
    trackerId?: string;
    trackerName?: string;
    changedField?: string;
    columnId?: string;
    rowId?: string;
    oldValue?: any;
    newValue?: any;
    details?: string;
  }) => void;
  onOpenLegalChecklist?: (row: Row, column?: Column) => void;
  onOpenDayByDay?: (row: Row, column?: Column) => void;
  onNotify?: (message: string, type?: 'success' | 'info' | 'error', action?: { label: string; onClick: () => void }) => void;
}

export const TrackerTable: React.FC<TrackerTableProps> = ({
  tracker,
  currentUser,
  isDark,
  highlightedRowId,
  initialSearchTerm,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  isDataProtected,
  onToggleDataProtection,
  onSearchChange,
  onUpdateTracker,
  onOpenExcelPaste,
  onOpenColumnManager,
  onPreviewImage,
  onPreviewPdf,
  onExportCSV,
  onOpenReport,
  onOpenPresentation,
  trackerPermissions,
  onRequestAccess,
  onLogActivity,
  onOpenLegalChecklist,
  onOpenDayByDay,
  onNotify
}) => {
  // Table control states
  const [searchTerm, setSearchTerm] = useState(initialSearchTerm || '');
  const [sortCol, setSortCol] = useState<string | null>(null);

  // Sync search term if initialSearchTerm changes
  React.useEffect(() => {
    if (initialSearchTerm !== undefined) {
      setSearchTerm(initialSearchTerm);
    }
  }, [initialSearchTerm]);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [pageSize, setPageSize] = useState<number>(30); // 20, 30, 40, 50, 75, 100, 500
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [textWrap, setTextWrap] = useState<boolean>(true);
  const [selectedRowIds, setSelectedRowIds] = useState<string[]>([]);
  const [groupByCol, setGroupByCol] = useState<string | null>(null);
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const [flexibleWidth, setFlexibleWidth] = useState<boolean>(true);

  // Collapsible Row Details Mode
  const [expandedRowIds, setExpandedRowIds] = useState<Record<string, boolean>>({});
  const handleToggleRowExpand = (rowId: string) => {
    setExpandedRowIds(prev => ({ ...prev, [rowId]: !prev[rowId] }));
  };
  const handleExpandAllRows = () => {
    const next: Record<string, boolean> = {};
    tracker.rows.forEach(r => { next[r.id] = true; });
    setExpandedRowIds(next);
  };
  const handleCollapseAllRows = () => {
    setExpandedRowIds({});
  };

  // Ribbon Toolbar Collapsible & Row Density modes for tables with many data
  const [isRibbonCollapsed, setIsRibbonCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gaela_ribbon_collapsed') === 'true';
    } catch {
      return false;
    }
  });
  const [rowDensity, setRowDensity] = useState<'normal' | 'compact'>(() => {
    try {
      return (localStorage.getItem('gaela_table_density') as 'normal' | 'compact') || 'normal';
    } catch {
      return 'normal';
    }
  });

  const handleToggleRibbon = () => {
    setIsRibbonCollapsed(prev => {
      const next = !prev;
      try {
        localStorage.setItem('gaela_ribbon_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  const handleToggleDensity = () => {
    setRowDensity(prev => {
      const next = prev === 'normal' ? 'compact' : 'normal';
      try {
        localStorage.setItem('gaela_table_density', next);
      } catch {}
      return next;
    });
  };

  // Open CAL (Cash Advance Liquidation) & Row-Level Sum states
  const [showRowCalcColumn, setShowRowCalcColumn] = useState<boolean>(true);
  const [openCalFilter, setOpenCalFilter] = useState<'all' | 'open' | 'settled'>('all');
  const [showOpenCalModal, setShowOpenCalModal] = useState<boolean>(false);
  const [copiedOpenCal, setCopiedOpenCal] = useState<boolean>(false);

  // Check if tracker has any amount columns
  const hasAmountCols = useMemo(() => {
    return tracker.columns.some(c => c.type === 'amount');
  }, [tracker.columns]);

  // Fast Clipboard Paste & Active Cell Selection (Row highlighting removed per user request)
  const [activeCell, setActiveCell] = useState<{ rowId: string; colId: string } | null>(null);
  const [pasteNotice, setPasteNotice] = useState<string | null>(null);
  const tableContainerRef = useRef<HTMLDivElement>(null);

  // Organized Toolbar Dropdown Menus
  const [showImportMenu, setShowImportMenu] = useState<boolean>(false);
  const [showExportMenu, setShowExportMenu] = useState<boolean>(false);
  const [showViewMenu, setShowViewMenu] = useState<boolean>(false);

  const importMenuRef = useRef<HTMLDivElement>(null);
  const exportMenuRef = useRef<HTMLDivElement>(null);
  const viewMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (importMenuRef.current && !importMenuRef.current.contains(e.target as Node)) {
        setShowImportMenu(false);
      }
      if (exportMenuRef.current && !exportMenuRef.current.contains(e.target as Node)) {
        setShowExportMenu(false);
      }
      if (viewMenuRef.current && !viewMenuRef.current.contains(e.target as Node)) {
        setShowViewMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Column drag resizing state
  const [resizingColId, setResizingColId] = useState<string | null>(null);
  const resizeStartXRef = useRef<number>(0);
  const resizeStartWidthRef = useRef<number>(0);

  // Inline cell editing state
  const [editingCell, setEditingCell] = useState<{ rowId: string; colId: string } | null>(null);
  const [editValue, setEditValue] = useState<any>('');

  // Data Protection mode state (protects against accidental deletes and typo/cell modifications)
  const [localProtected, setLocalProtected] = useState<boolean>(true);
  const isProtectedEffective = isDataProtected !== undefined ? isDataProtected : localProtected;

  // Effective Tracker & Field Permissions
  const effectivePermission = useMemo(() => {
    return getEffectiveTrackerPermission(currentUser, tracker.id, trackerPermissions || []);
  }, [currentUser, tracker.id, trackerPermissions]);

  const canViewTracker = effectivePermission.canView;
  const canAdd = effectivePermission.canAdd;
  const canEdit = effectivePermission.canEdit;
  const canDelete = effectivePermission.canDelete;
  const canExport = effectivePermission.canExport;
  const canModifyData = canEdit && !isProtectedEffective;

  // Helper to resolve field access for any column
  const getColAccess = React.useCallback(
    (colId: string): FieldAccessLevel => {
      return getFieldAccess(colId, currentUser, effectivePermission, tracker.columns);
    },
    [currentUser, effectivePermission, tracker.columns]
  );

  // Rich Errand & Highlight Formatter Modal Editor State
  const [richEditorCell, setRichEditorCell] = useState<{
    rowId: string;
    rowNumber: number;
    rowTitle?: string;
    columnId: string;
    columnName: string;
    initialValue: string;
  } | null>(null);

  const handleOpenRichEditor = (row: Row, col: Column, rowNum: number) => {
    if (!canEdit) {
      onNotify?.('🔒 Edit permission is not granted on this tracker.', 'error');
      return;
    }
    const access = getColAccess(col.id);
    if (access !== 'edit') {
      onNotify?.(`🔒 Field "${col.name}" is ${access === 'no_access' ? 'restricted' : 'view-only'}. Cannot edit.`, 'info');
      return;
    }
    const titleCol = tracker.columns.find(c => {
      const n = c.name.toLowerCase();
      return n.includes('station') || n.includes('item') || n.includes('cal') || n.includes('name');
    });
    const rowTitle = titleCol ? String(row[titleCol.id] || '') : `Row #${rowNum}`;
    setRichEditorCell({
      rowId: row.id,
      rowNumber: rowNum,
      rowTitle,
      columnId: col.id,
      columnName: col.name,
      initialValue: String(row[col.id] || '')
    });
  };

  const handleSaveRichText = (rowId: string, colId: string, updatedVal: string) => {
    const row = tracker.rows.find(r => r.id === rowId);
    const oldVal = row ? row[colId] : undefined;
    const col = tracker.columns.find(c => c.id === colId);

    onUpdateTracker({
      ...tracker,
      rows: tracker.rows.map(r => (r.id === rowId ? { ...r, [colId]: updatedVal } : r))
    });
    if (onNotify) onNotify('Cell content and errands updated successfully!', 'success');

    if (oldVal !== updatedVal && onLogActivity) {
      onLogActivity('EDIT_CELL', {
        trackerId: tracker.id,
        trackerName: tracker.name,
        columnId: colId,
        changedField: col?.name || colId,
        rowId,
        oldValue: oldVal,
        newValue: updatedVal,
        details: `Updated text / errands in ${col?.name || colId}.`
      });
    }
  };

  const handleToggleCellErrand = React.useCallback(
    (rowId: string, colId: string, lineIndex: number, originalLine: string, nextStatus: boolean) => {
      if (!canModifyData) {
        if (onNotify) onNotify('🔒 Table is protected. Unlock "Edit Mode" in toolbar to check off errands.', 'info');
        return;
      }
      const access = getColAccess(colId);
      if (access !== 'edit') {
        if (onNotify) onNotify('🔒 Field restricted: Modifying errands is only permitted on editable fields.', 'info');
        return;
      }
      const row = tracker.rows.find(r => r.id === rowId);
      if (!row) return;
      const val = String(row[colId] || '');
      const lines = val.split('\n');
      if (lines[lineIndex] !== undefined) {
        if (nextStatus) {
          lines[lineIndex] = lines[lineIndex].replace(/^(\s*)\[\s*\]/, '$1[x]');
        } else {
          lines[lineIndex] = lines[lineIndex].replace(/^(\s*)\[[xX]\]/, '$1[ ]');
        }
        const updatedVal = lines.join('\n');
        onUpdateTracker({
          ...tracker,
          rows: tracker.rows.map(r => (r.id === rowId ? { ...r, [colId]: updatedVal } : r))
        });
      }
    },
    [canModifyData, tracker, onUpdateTracker, onNotify]
  );

  // Bulk delete confirmation state
  const [showBulkConfirm, setShowBulkConfirm] = useState<boolean>(false);

  // Single row delete confirmation modal state (Accidental delete protection)
  const [rowToDelete, setRowToDelete] = useState<{ id: string; rowNum: number; title: string } | null>(null);

  // Toggle Table Live Totals Summary Footer
  const [showSummaryFooter, setShowSummaryFooter] = useState<boolean>(true);

  // Visible columns
  const visibleColumns = useMemo(() => {
    return tracker.columns.filter(c => c.visible);
  }, [tracker.columns]);

  // Local column width overrides during interactive drag to avoid heavy parent re-renders
  const [colWidthOverrides, setColWidthOverrides] = useState<Record<string, number>>({});

  // Handle Column Resize via Mouse Drag - commits once on mouseUp for max performance
  const handleResizeStart = (e: React.MouseEvent, colId: string, currentWidth: number = 180) => {
    e.preventDefault();
    e.stopPropagation();
    setResizingColId(colId);
    resizeStartXRef.current = e.clientX;
    resizeStartWidthRef.current = currentWidth;

    let finalWidth = currentWidth;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const delta = moveEvent.clientX - resizeStartXRef.current;
      finalWidth = Math.max(90, resizeStartWidthRef.current + delta);
      setColWidthOverrides(prev => ({ ...prev, [colId]: finalWidth }));
    };

    const handleMouseUp = () => {
      setResizingColId(null);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
      // Single commit to parent state
      onUpdateTracker({
        ...tracker,
        columns: tracker.columns.map(c => (c.id === colId ? { ...c, width: finalWidth } : c))
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  };

  // High-performance column classification memoized once per column set
  const classifiedCols = useMemo(() => {
    const allAmountCols = tracker.columns.filter(c => c.type === 'amount');
    const reqCols = allAmountCols.filter(c => {
      const n = (c.name + ' ' + c.id).toLowerCase();
      return (
        n.includes('req') ||
        n.includes('advance') ||
        n.includes('cal') ||
        n.includes('invoice') ||
        n.includes('budget') ||
        n.includes('contract') ||
        n.includes('cost') ||
        n.includes('value')
      );
    });

    const settledCols = allAmountCols.filter(c => {
      const n = (c.name + ' ' + c.id).toLowerCase();
      return (
        n.includes('settled') ||
        n.includes('paid') ||
        n.includes('liquidat') ||
        n.includes('clear') ||
        n.includes('disburs')
      );
    });

    const pctCol = tracker.columns.find(c => c.type === 'percent');
    const statusCol = tracker.columns.find(c => c.type === 'status');

    return { allAmountCols, reqCols, settledCols, pctCol, statusCol };
  }, [tracker.columns]);

  // Precomputed Row Metrics Map: O(1) instant metric lookup for every row
  const rowMetricsMap = useMemo(() => {
    const map = new Map<string, {
      rowSum: number;
      requestAmount: number;
      settledAmount: number;
      remainingOpenCal: number;
      isOpenCal: boolean;
    }>();

    const { allAmountCols, reqCols, settledCols, pctCol, statusCol } = classifiedCols;

    tracker.rows.forEach(row => {
      let rowSum = 0;
      for (let i = 0; i < allAmountCols.length; i++) {
        rowSum += parseNum(row[allAmountCols[i].id]);
      }

      let requestAmount = 0;
      let settledAmount = 0;

      if (reqCols.length > 0) {
        for (let i = 0; i < reqCols.length; i++) {
          requestAmount += parseNum(row[reqCols[i].id]);
        }
      } else if (allAmountCols.length > 0) {
        requestAmount = parseNum(row[allAmountCols[0].id]);
      }

      if (settledCols.length > 0) {
        for (let i = 0; i < settledCols.length; i++) {
          settledAmount += parseNum(row[settledCols[i].id]);
        }
      } else if (pctCol && row[pctCol.id] !== undefined) {
        const pct = Math.min(100, Math.max(0, parseNum(row[pctCol.id])));
        settledAmount = requestAmount * (pct / 100);
      } else if (statusCol) {
        const s = String(row[statusCol.id] || '').toLowerCase();
        if (['completed', 'settled', 'approved', 'done', 'closed'].includes(s)) {
          settledAmount = requestAmount;
        }
      }

      if (row['col-open-cal'] !== undefined && row['col-open-cal'] !== '') {
        const explicitOpen = parseNum(row['col-open-cal']);
        map.set(row.id, {
          rowSum: row['col-row-sum'] !== undefined ? parseNum(row['col-row-sum']) : rowSum,
          requestAmount,
          settledAmount,
          remainingOpenCal: explicitOpen,
          isOpenCal: explicitOpen > 0
        });
        return;
      }

      const remainingOpenCal = Math.max(0, requestAmount - settledAmount);
      map.set(row.id, {
        rowSum,
        requestAmount,
        settledAmount,
        remainingOpenCal,
        isOpenCal: remainingOpenCal > 0
      });
    });

    return map;
  }, [tracker.rows, classifiedCols]);

  const defaultMetric = useMemo(() => ({
    rowSum: 0,
    requestAmount: 0,
    settledAmount: 0,
    remainingOpenCal: 0,
    isOpenCal: false
  }), []);

  // Compute Row-level Total Sum and Remaining Open CAL metrics (O(1) instant)
  const getRowCalcMetrics = (row: Row) => {
    return rowMetricsMap.get(row.id) || defaultMetric;
  };

  // Debounced search sync to parent App to prevent laggy full-tree re-renders on keystroke
  const searchDebounceTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleSearchChangeInternal = (val: string) => {
    setSearchTerm(val);
    setCurrentPage(1);
    if (onSearchChange) {
      if (searchDebounceTimerRef.current) clearTimeout(searchDebounceTimerRef.current);
      searchDebounceTimerRef.current = setTimeout(() => {
        onSearchChange(val);
      }, 200);
    }
  };

  // Filtered & Sorted Rows
  const processedRows = useMemo(() => {
    let result = [...tracker.rows];

    // Search filter across all visible columns
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase().trim();
      result = result.filter(row => {
        return visibleColumns.some(col => {
          const val = row[col.id];
          return val !== undefined && val !== null && String(val).toLowerCase().includes(q);
        });
      });
    }

    // Status filter
    if (statusFilter !== 'all') {
      result = result.filter(row => {
        const statusVal = String(row['col-status'] || row['b-status'] || row['e-status'] || '');
        return statusVal.toLowerCase() === statusFilter.toLowerCase();
      });
    }

    // Open CAL Filter
    if (openCalFilter === 'open') {
      result = result.filter(row => getRowCalcMetrics(row).isOpenCal);
    } else if (openCalFilter === 'settled') {
      result = result.filter(row => {
        const m = getRowCalcMetrics(row);
        return !m.isOpenCal && m.requestAmount > 0;
      });
    }

    // Sorting
    if (sortCol) {
      if (sortCol === '__row_open_cal') {
        result.sort((a, b) => {
          const valA = getRowCalcMetrics(a).remainingOpenCal;
          const valB = getRowCalcMetrics(b).remainingOpenCal;
          return sortDir === 'asc' ? valA - valB : valB - valA;
        });
      } else if (sortCol === '__row_sum') {
        result.sort((a, b) => {
          const valA = getRowCalcMetrics(a).rowSum;
          const valB = getRowCalcMetrics(b).rowSum;
          return sortDir === 'asc' ? valA - valB : valB - valA;
        });
      } else {
        result.sort((a, b) => {
          const valA = a[sortCol];
          const valB = b[sortCol];

          if (valA === undefined || valA === null) return 1;
          if (valB === undefined || valB === null) return -1;

          if (typeof valA === 'number' && typeof valB === 'number') {
            return sortDir === 'asc' ? valA - valB : valB - valA;
          }

          const strA = String(valA).toLowerCase();
          const strB = String(valB).toLowerCase();
          if (strA < strB) return sortDir === 'asc' ? -1 : 1;
          if (strA > strB) return sortDir === 'asc' ? 1 : -1;
          return 0;
        });
      }
    }

    return result;
  }, [tracker.rows, searchTerm, statusFilter, openCalFilter, sortCol, sortDir, visibleColumns]);

  // Overall Open CAL calculations across currently active processed rows
  const overallOpenCalMetrics = useMemo(() => {
    let totalOpenCal = 0;
    let totalRowSum = 0;
    let totalSettled = 0;
    let totalRequested = 0;
    let openCount = 0;
    let settledCount = 0;

    processedRows.forEach(row => {
      const m = getRowCalcMetrics(row);
      totalOpenCal += m.remainingOpenCal;
      totalRowSum += m.rowSum;
      totalSettled += m.settledAmount;
      totalRequested += m.requestAmount;
      if (m.isOpenCal) {
        openCount++;
      } else if (m.requestAmount > 0) {
        settledCount++;
      }
    });

    return {
      totalOpenCal,
      totalRowSum,
      totalSettled,
      totalRequested,
      openCount,
      settledCount,
      settlementRate: totalRequested > 0 ? Math.round((totalSettled / totalRequested) * 100) : 0
    };
  }, [processedRows, tracker.columns]);

  // Compute live column subtotals across all currently filtered/matched rows
  const columnSubtotals = useMemo(() => {
    const subtotals: Record<string, { sum: number; count: number; completedCount: number }> = {};

    visibleColumns.forEach(col => {
      subtotals[col.id] = { sum: 0, count: 0, completedCount: 0 };
    });

    processedRows.forEach(row => {
      visibleColumns.forEach(col => {
        const val = row[col.id];
        if (col.type === 'amount' || col.type === 'percent') {
          if (val !== undefined && val !== null && val !== '') {
            const num = typeof val === 'number' ? val : parseFloat(String(val).replace(/[^0-9.-]+/g, ''));
            if (!isNaN(num)) {
              subtotals[col.id].sum += num;
              subtotals[col.id].count += 1;
            }
          }
        } else if (col.type === 'status') {
          const s = String(val || '').toLowerCase();
          if (s === 'completed' || s === 'done' || s === 'approved' || s === 'settled') {
            subtotals[col.id].completedCount += 1;
          }
        }
      });
    });

    return subtotals;
  }, [processedRows, visibleColumns]);

  // Grouping logic (same in Excel)
  const groupedData = useMemo(() => {
    if (!groupByCol) return null;

    const groups: Record<string, Row[]> = {};
    processedRows.forEach(row => {
      const key = String(row[groupByCol] || 'Uncategorized');
      if (!groups[key]) groups[key] = [];
      groups[key].push(row);
    });
    return groups;
  }, [processedRows, groupByCol]);

  // Group metrics (amount totals per group for collapsible header display)
  const groupMetrics = useMemo(() => {
    if (!groupByCol || !groupedData) return null;
    const amountCols = visibleColumns.filter(c => c.type === 'amount');
    const metrics: Record<string, { count: number; subtotals: Record<string, number> }> = {};

    Object.entries(groupedData).forEach(([key, rows]) => {
      const subtotals: Record<string, number> = {};
      amountCols.forEach(col => {
        subtotals[col.id] = rows.reduce((sum, r) => sum + parseNum(r[col.id]), 0);
      });
      metrics[key] = {
        count: rows.length,
        subtotals
      };
    });

    return metrics;
  }, [groupByCol, groupedData, visibleColumns]);

  const handleToggleGroupCollapse = (groupKey: string) => {
    setCollapsedGroups(prev => ({
      ...prev,
      [groupKey]: !prev[groupKey]
    }));
  };

  const handleExpandAllGroups = () => {
    setCollapsedGroups({});
  };

  const handleCollapseAllGroups = () => {
    if (!groupedData) return;
    const allCollapsed: Record<string, boolean> = {};
    Object.keys(groupedData).forEach(k => {
      allCollapsed[k] = true;
    });
    setCollapsedGroups(allCollapsed);
  };

  // Pagination
  const totalPages = Math.ceil(processedRows.length / pageSize) || 1;
  const paginatedRows = useMemo(() => {
    if (groupByCol) return processedRows; // When grouped, show full group set
    const start = (currentPage - 1) * pageSize;
    return processedRows.slice(start, start + pageSize);
  }, [processedRows, currentPage, pageSize, groupByCol]);

  // Inline edit handlers
  // Inline edit handlers
  const handleStartEdit = (rowId: string, colId: string, currentVal: any) => {
    if (!canEdit) {
      onNotify?.('🔒 Edit permission is not granted on this tracker.', 'error');
      return;
    }
    const access = getColAccess(colId);
    if (access !== 'edit') {
      const colName = tracker.columns.find(c => c.id === colId)?.name || colId;
      if (access === 'no_access') {
        onNotify?.(`🔒 Access Denied: Field "${colName}" is set to No Access by Administrator.`, 'error');
      } else {
        onNotify?.(`🔒 Field Restricted: "${colName}" is set to View Only by Administrator.`, 'info');
      }
      return;
    }
    setActiveCell({ rowId, colId });
    setEditingCell({ rowId, colId });
    setEditValue(currentVal ?? '');
  };

  const handleSaveEdit = () => {
    if (!editingCell) return;
    const { rowId, colId } = editingCell;
    const col = tracker.columns.find(c => c.id === colId);
    const row = tracker.rows.find(r => r.id === rowId);
    const oldVal = row ? row[colId] : undefined;

    let parsedVal: any = editValue;
    if (col?.type === 'amount') {
      parsedVal = parseFloat(String(editValue).replace(/[^0-9.-]+/g, '')) || 0;
    } else if (col?.type === 'percent') {
      parsedVal = parseFloat(String(editValue).replace(/[^0-9.-]+/g, '')) || 0;
    } else if (col?.type === 'date') {
      parsedVal = normalizeExcelDate(editValue);
    }

    const updatedRows = tracker.rows.map(r => {
      if (r.id === rowId) {
        return { ...r, [colId]: parsedVal };
      }
      return r;
    });

    onUpdateTracker({ ...tracker, rows: updatedRows });
    setEditingCell(null);

    if (oldVal !== parsedVal && onLogActivity) {
      onLogActivity('EDIT_CELL', {
        trackerId: tracker.id,
        trackerName: tracker.name,
        columnId: colId,
        changedField: col?.name || colId,
        rowId,
        oldValue: oldVal,
        newValue: parsedVal,
        details: `Updated ${col?.name || colId} from "${oldVal ?? ''}" to "${parsedVal}".`
      });
    }
  };

  const handleKeyDownEdit = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSaveEdit();
    if (e.key === 'Escape') setEditingCell(null);
  };

  // Direct Clipboard Data Paste into Targeted Cell or Range
  const handleCellPaste = (startRowId: string, startColId: string, clipboardText: string) => {
    if (!canEdit || !clipboardText) return;

    // Parse TSV/CSV/multiline text
    const grid = parseExcelData(clipboardText);
    if (grid.length === 0 || grid[0].length === 0) return;

    // If single value and in editing mode, standard behavior applies
    const isSingleCell = grid.length === 1 && grid[0].length === 1;

    const startRowIdx = tracker.rows.findIndex(r => r.id === startRowId);
    const startColIdx = visibleColumns.findIndex(c => c.id === startColId);

    if (startRowIdx === -1 || startColIdx === -1) return;

    const updatedRows = [...tracker.rows];
    let cellsChangedCount = 0;
    let restrictedSkipped = 0;

    for (let rOffset = 0; rOffset < grid.length; rOffset++) {
      const rowIdx = startRowIdx + rOffset;
      if (rowIdx >= updatedRows.length) {
        if (!canAdd) break; // Cannot add rows if no Add permission
        const extraRow = createBlankRow();
        updatedRows.push(extraRow);
      }

      const currentRow = { ...updatedRows[rowIdx] };
      const rowData = grid[rOffset];

      for (let cOffset = 0; cOffset < rowData.length; cOffset++) {
        const colIdx = startColIdx + cOffset;
        if (colIdx >= visibleColumns.length) continue;

        const targetCol = visibleColumns[colIdx];
        const access = getColAccess(targetCol.id);
        if (access !== 'edit') {
          restrictedSkipped++;
          continue; // Field-level security: cannot paste into unauthorized fields!
        }

        const rawCellText = rowData[cOffset].trim();

        let parsedVal: any = rawCellText;
        if (targetCol.type === 'amount') {
          parsedVal = parseFloat(rawCellText.replace(/[^0-9.-]+/g, '')) || 0;
        } else if (targetCol.type === 'percent') {
          parsedVal = parseFloat(rawCellText.replace(/[^0-9.-]+/g, '')) || 0;
        } else if (targetCol.type === 'date') {
          parsedVal = normalizeExcelDate(rawCellText);
        } else if (targetCol.type === 'status') {
          parsedVal = rawCellText;
        }

        currentRow[targetCol.id] = parsedVal;
        cellsChangedCount++;
      }

      updatedRows[rowIdx] = currentRow;
    }

    onUpdateTracker({ ...tracker, rows: updatedRows });

    let msg = isSingleCell
      ? `Pasted data into cell!`
      : `Pasted ${grid.length} row(s) × ${grid[0].length} column(s) (${cellsChangedCount} cells)!`;

    if (restrictedSkipped > 0) {
      msg += ` (${restrictedSkipped} restricted fields skipped due to View-Only permissions)`;
    }

    setPasteNotice(msg);
    if (onNotify) onNotify(msg, restrictedSkipped > 0 ? 'info' : 'success');
    setTimeout(() => setPasteNotice(null), 4000);
  };

  // Keyboard navigation & clipboard event listener for table container
  useEffect(() => {
    const handleGlobalPaste = (e: ClipboardEvent) => {
      // If user is currently typing in an input or textarea, let normal paste happen unless it contains tabs or newlines
      const activeElement = document.activeElement;
      const isInput = activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA');

      const clipboardData = e.clipboardData?.getData('text/plain');
      if (!clipboardData) return;

      const hasTabOrNewline = clipboardData.includes('\t') || clipboardData.includes('\n');

      // If active cell is highlighted (or editing cell and text has multiple cells)
      const targetCell = activeCell || editingCell;
      if (targetCell) {
        if (!isInput || hasTabOrNewline) {
          e.preventDefault();
          if (editingCell) setEditingCell(null);
          handleCellPaste(targetCell.rowId, targetCell.colId, clipboardData);
        }
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!activeCell || editingCell) return;
      const activeElement = document.activeElement;
      if (activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA')) {
        return;
      }

      const currentRowIdx = paginatedRows.findIndex(r => r.id === activeCell.rowId);
      const currentColIdx = visibleColumns.findIndex(c => c.id === activeCell.colId);

      if (currentRowIdx === -1 || currentColIdx === -1) return;

      if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (currentRowIdx > 0) {
          setActiveCell({ rowId: paginatedRows[currentRowIdx - 1].id, colId: activeCell.colId });
        }
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (currentRowIdx < paginatedRows.length - 1) {
          setActiveCell({ rowId: paginatedRows[currentRowIdx + 1].id, colId: activeCell.colId });
        }
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        if (currentColIdx > 0) {
          setActiveCell({ rowId: activeCell.rowId, colId: visibleColumns[currentColIdx - 1].id });
        }
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        if (currentColIdx < visibleColumns.length - 1) {
          setActiveCell({ rowId: activeCell.rowId, colId: visibleColumns[currentColIdx + 1].id });
        }
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const row = tracker.rows.find(r => r.id === activeCell.rowId);
        if (row) {
          handleStartEdit(activeCell.rowId, activeCell.colId, row[activeCell.colId]);
        }
      }
    };

    window.addEventListener('paste', handleGlobalPaste);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('paste', handleGlobalPaste);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [activeCell, editingCell, tracker.rows, visibleColumns, paginatedRows, canEdit]);

  // Fast paste from clipboard button handler
  const handleFastPasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text) {
        if (onNotify) onNotify('Clipboard is empty. Copy cells from Excel first!', 'error');
        return;
      }

      // If active cell selected, paste into it. If not, paste into first cell of first row
      const targetRowId = activeCell?.rowId || paginatedRows[0]?.id || tracker.rows[0]?.id;
      const targetColId = activeCell?.colId || visibleColumns[0]?.id;

      if (!targetRowId || !targetColId) {
        if (onNotify) onNotify('No row/column available to paste into.', 'error');
        return;
      }

      handleCellPaste(targetRowId, targetColId, text);
    } catch (err) {
      // Clipboard read permission might require user interaction, fallback to Excel paste modal
      onOpenExcelPaste();
    }
  };

  // Row Manipulation Handlers
  const createBlankRow = () => {
    const newRowId = 'row-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
    const newRow: Row = { id: newRowId };

    tracker.columns.forEach(col => {
      if (col.type === 'amount') newRow[col.id] = 0;
      else if (col.type === 'percent') newRow[col.id] = 0;
      else if (col.type === 'status') newRow[col.id] = col.options?.[0] || 'In Progress';
      else if (col.type === 'date') newRow[col.id] = new Date().toISOString().slice(0, 10);
      else if (col.type === 'legal-checklist') newRow[col.id] = JSON.stringify(DEFAULT_LEGAL_CHECKLIST_ITEMS);
      else if (col.type === 'day-by-day') newRow[col.id] = generateDefaultDayByDayLog(newRowId, 'New Site Candidate');
      else newRow[col.id] = '';
    });
    return newRow;
  };

  const handleAddRow = () => {
    if (!canAdd) {
      if (onNotify) onNotify('🔒 Permission Denied: You do not have permission to ADD rows to this tracker.', 'error');
      return;
    }
    const newRow = createBlankRow();

    onUpdateTracker({
      ...tracker,
      rows: [newRow, ...tracker.rows]
    });

    if (onLogActivity) {
      onLogActivity('ADD_ROW', {
        trackerId: tracker.id,
        trackerName: tracker.name,
        rowId: newRow.id,
        changedField: 'Rows',
        newValue: 'New Row Record',
        details: `Added new row to ${tracker.name}.`
      });
    }

    // Auto focus edit on the first visible text column
    const firstCol = visibleColumns[0]?.id;
    if (firstCol && getColAccess(firstCol) === 'edit') {
      setEditingCell({ rowId: newRow.id, colId: firstCol });
      setEditValue('');
    }
  };

  // Insert row in between rows (Above or Below target row)
  const handleInsertRow = (targetRowId: string, position: 'above' | 'below') => {
    if (!canAdd) {
      if (onNotify) onNotify('🔒 Permission Denied: You do not have permission to ADD rows to this tracker.', 'error');
      return;
    }
    const newRow = createBlankRow();
    const targetIdx = tracker.rows.findIndex(r => r.id === targetRowId);

    if (targetIdx === -1) {
      onUpdateTracker({
        ...tracker,
        rows: [newRow, ...tracker.rows]
      });
      return;
    }

    const insertIdx = position === 'above' ? targetIdx : targetIdx + 1;
    const updatedRows = [...tracker.rows];
    updatedRows.splice(insertIdx, 0, newRow);

    onUpdateTracker({
      ...tracker,
      rows: updatedRows
    });

    if (onLogActivity) {
      onLogActivity('ADD_ROW', {
        trackerId: tracker.id,
        trackerName: tracker.name,
        rowId: newRow.id,
        changedField: 'Rows',
        newValue: `Inserted Row (${position})`,
        details: `Inserted new row ${position} row #${targetRowId}.`
      });
    }

    // Auto-focus new row
    const firstCol = visibleColumns[0]?.id;
    if (firstCol && getColAccess(firstCol) === 'edit') {
      setEditingCell({ rowId: newRow.id, colId: firstCol });
      setEditValue('');
    }
  };

  // Working Delete Row Handler with protection and undo support
  const handleDeleteRow = (rowId: string) => {
    if (!canDelete) {
      if (onNotify) onNotify('🔒 Permission Denied: You do not have permission to DELETE rows from this tracker.', 'error');
      return;
    }
    if (!canModifyData) {
      onNotify?.('🔒 Data is protected from deletion. Unlock Edit Mode in toolbar to delete rows.', 'info');
      return;
    }
    onUpdateTracker({
      ...tracker,
      rows: tracker.rows.filter(r => r.id !== rowId)
    });
    setSelectedRowIds(prev => prev.filter(id => id !== rowId));
    onNotify?.('Row deleted.', 'info', onUndo ? { label: '↺ Undo', onClick: onUndo } : undefined);

    if (onLogActivity) {
      onLogActivity('DELETE_ROW', {
        trackerId: tracker.id,
        trackerName: tracker.name,
        rowId,
        changedField: 'Rows',
        oldValue: `Row ID: ${rowId}`,
        newValue: 'Deleted',
        details: `Deleted row #${rowId} in ${tracker.name}.`
      });
    }
  };

  // Working Bulk Delete Handler (NO window.confirm to avoid iframe blocking!)
  const handleExecuteBulkDelete = () => {
    if (!canDelete) {
      if (onNotify) onNotify('🔒 Permission Denied: You do not have permission to DELETE rows from this tracker.', 'error');
      return;
    }
    if (!canModifyData || selectedRowIds.length === 0) return;
    onUpdateTracker({
      ...tracker,
      rows: tracker.rows.filter(r => !selectedRowIds.includes(r.id))
    });

    if (onLogActivity) {
      onLogActivity('DELETE_ROW', {
        trackerId: tracker.id,
        trackerName: tracker.name,
        changedField: 'Rows (Bulk)',
        oldValue: `${selectedRowIds.length} rows`,
        newValue: 'Deleted',
        details: `Bulk deleted ${selectedRowIds.length} rows in ${tracker.name}.`
      });
    }

    setSelectedRowIds([]);
    setShowBulkConfirm(false);
    onNotify?.(`Deleted ${selectedRowIds.length} rows.`, 'info', onUndo ? { label: '↺ Undo', onClick: onUndo } : undefined);
  };


  // Generate & Add Permanent 'ROW TOTAL SUM' and 'REMAINING OPEN CAL' Columns for all rows
  const handleGenerateRowSumAndOpenCalColumns = () => {
    if (!canEdit) return;

    const rowSumColExists = tracker.columns.some(c => c.id === 'col-row-sum');
    const openCalColExists = tracker.columns.some(c => c.id === 'col-open-cal');

    let updatedColumns = [...tracker.columns];

    if (!rowSumColExists) {
      updatedColumns.push({
        id: 'col-row-sum',
        name: 'ROW TOTAL SUM (₱)',
        type: 'amount',
        width: 175,
        visible: true,
        color: 'blue',
        currencySymbol: '₱'
      });
    }

    if (!openCalColExists) {
      updatedColumns.push({
        id: 'col-open-cal',
        name: 'REMAINING OPEN CAL (₱)',
        type: 'amount',
        width: 195,
        visible: true,
        color: 'rose',
        currencySymbol: '₱'
      });
    }

    // Populate all rows with their computed Row Total Sum and Remaining Open CAL
    const updatedRows = tracker.rows.map(row => {
      const metrics = getRowCalcMetrics(row);
      return {
        ...row,
        'col-row-sum': metrics.rowSum,
        'col-open-cal': metrics.remainingOpenCal
      };
    });

    onUpdateTracker({
      ...tracker,
      columns: updatedColumns,
      rows: updatedRows
    });

    onNotify?.(
      `Generated 'ROW TOTAL SUM' and 'REMAINING OPEN CAL' columns for all ${tracker.rows.length} rows! Total Open CAL: ₱${overallOpenCalMetrics.totalOpenCal.toLocaleString()} (${overallOpenCalMetrics.openCount} open items)`,
      'success'
    );
    setShowOpenCalModal(false);
  };


  // Export CSV specifically for open CAL rows
  const handleExportOpenCalCSV = () => {
    const rowsToExport = processedRows.filter(r => getRowCalcMetrics(r).isOpenCal);
    if (rowsToExport.length === 0) {
      onNotify?.('No open CAL rows to export! All items are fully settled.', 'info');
      return;
    }

    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'Row #,Site / Item Description,Total Row Sum (PHP),Requested (PHP),Settled (PHP),Remaining Open CAL (PHP),Status\n';

    rowsToExport.forEach((r, idx) => {
      const m = getRowCalcMetrics(r);
      const textCol = tracker.columns.find(c => c.type === 'text');
      const label = textCol ? String(r[textCol.id] || '').replace(/,/g, ' ').replace(/"/g, '""') : `Row ${idx + 1}`;
      csvContent += `"${idx + 1}","${label}","${m.rowSum}","${m.requestAmount}","${m.settledAmount}","${m.remainingOpenCal}","Open CAL"\n`;
    });

    csvContent += `\n"TOTAL","","${overallOpenCalMetrics.totalRowSum}","${overallOpenCalMetrics.totalRequested}","${overallOpenCalMetrics.totalSettled}","${overallOpenCalMetrics.totalOpenCal}","${overallOpenCalMetrics.openCount} Open Items"\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${tracker.name.replace(/\s+/g, '_')}_Remaining_Open_CAL_Report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onNotify?.(`Exported Open CAL report with ${rowsToExport.length} open items!`, 'success');
  };

  // Copy structured Open CAL report to clipboard
  const handleCopyOpenCalSummary = () => {
    const openRows = processedRows.filter(r => getRowCalcMetrics(r).isOpenCal);
    let summary = `=========================================\n`;
    summary += `${tracker.name.toUpperCase()} - REMAINING OPEN CAL REPORT\n`;
    summary += `Generated: ${new Date().toLocaleString()}\n`;
    summary += `-----------------------------------------\n`;
    summary += `REMAINING TOTAL OPEN CAL: ₱${overallOpenCalMetrics.totalOpenCal.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    summary += `Total Advance / Requested: ₱${overallOpenCalMetrics.totalRequested.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    summary += `Total Settled / Cleared:  ₱${overallOpenCalMetrics.totalSettled.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    summary += `Total Row Sum:            ₱${overallOpenCalMetrics.totalRowSum.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}\n`;
    summary += `Open Items Count:         ${overallOpenCalMetrics.openCount} items pending liquidation\n`;
    summary += `Settled Items Count:      ${overallOpenCalMetrics.settledCount} items fully settled\n`;
    summary += `-----------------------------------------\n`;
    summary += `OPEN CAL BREAKDOWN BY ROW:\n`;
    openRows.forEach((r, i) => {
      const m = getRowCalcMetrics(r);
      const textCol = tracker.columns.find(c => c.type === 'text');
      const label = textCol ? String(r[textCol.id] || `Row #${i + 1}`) : `Row #${i + 1}`;
      summary += `${i + 1}. ${label}\n   • Requested: ₱${m.requestAmount.toLocaleString()} | Settled: ₱${m.settledAmount.toLocaleString()} | OPEN CAL: ₱${m.remainingOpenCal.toLocaleString()}\n`;
    });
    summary += `=========================================\n`;

    navigator.clipboard.writeText(summary);
    setCopiedOpenCal(true);
    setTimeout(() => setCopiedOpenCal(false), 3000);
    onNotify?.('Copied Open CAL summary to clipboard!', 'success');
  };

  const handleDuplicateRow = (row: Row) => {
    if (!canEdit) return;
    const clonedRow: Row = {
      ...JSON.parse(JSON.stringify(row)),
      id: 'row-' + Date.now()
    };
    onUpdateTracker({
      ...tracker,
      rows: [...tracker.rows, clonedRow]
    });
  };

  // Select all rows
  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedRowIds(paginatedRows.map(r => r.id));
    } else {
      setSelectedRowIds([]);
    }
  };

  const handleSelectRow = (rowId: string) => {
    setSelectedRowIds(prev =>
      prev.includes(rowId) ? prev.filter(id => id !== rowId) : [...prev, rowId]
    );
  };

  // Toggle Column Visibility / Collapse
  const handleToggleColVisibility = (colId: string) => {
    onUpdateTracker({
      ...tracker,
      columns: tracker.columns.map(c =>
        c.id === colId ? { ...c, visible: !c.visible } : c
      )
    });
  };

  // File Upload Handlers (for JPEG & PDF in rows)
  const handleFileUploadForRow = (rowId: string, colId: string, file: File, type: 'jpeg' | 'pdf') => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const updatedRows = tracker.rows.map(r => {
        if (r.id === rowId) {
          return { ...r, [colId]: type === 'jpeg' ? result : file.name };
        }
        return r;
      });
      onUpdateTracker({ ...tracker, rows: updatedRows });
    };
    reader.readAsDataURL(file);
  };

  // Column header color classes
  const getHeaderColorClass = (color?: Column['color']) => {
    switch (color) {
      case 'blue': return 'border-b-2 border-b-blue-500 text-blue-900 dark:text-blue-200';
      case 'indigo': return 'border-b-2 border-b-indigo-500 text-indigo-900 dark:text-indigo-200';
      case 'emerald': return 'border-b-2 border-b-emerald-500 text-emerald-900 dark:text-emerald-200';
      case 'amber': return 'border-b-2 border-b-amber-500 text-amber-900 dark:text-amber-200';
      case 'rose': return 'border-b-2 border-b-rose-500 text-rose-900 dark:text-rose-200';
      case 'cyan': return 'border-b-2 border-b-cyan-500 text-cyan-900 dark:text-cyan-200';
      case 'purple': return 'border-b-2 border-b-purple-500 text-purple-900 dark:text-purple-200';
      default: return 'border-b-2 border-b-slate-400 text-slate-900 dark:text-zinc-200';
    }
  };

  // Reusable row renderer for standard pagination and collapsible group views
  const renderRow = (row: Row, rIdx: number, rowNum: number) => {
    const isSelected = selectedRowIds.includes(row.id);
    const isHighlighted = highlightedRowId === row.id;
    const isRowExpanded = Boolean(expandedRowIds[row.id]);
    const isCompact = rowDensity === 'compact';
    const cellPad = isCompact ? 'py-1 px-2.5 text-[11px]' : 'p-2.5 text-xs';
    const actionPad = isCompact ? 'py-1 px-2' : 'p-2.5';

    return (
      <React.Fragment key={row.id}>
        <tr
          className={`transition-colors group ${
            isHighlighted
              ? 'bg-amber-100/90 dark:bg-amber-950/60 ring-2 ring-amber-400 dark:ring-amber-500'
              : isSelected
              ? 'bg-indigo-50/60 dark:bg-indigo-950/30'
              : 'hover:bg-slate-50/80 dark:hover:bg-zinc-800/50'
          }`}
        >
          {/* Checkbox */}
          <td className={`${cellPad} text-center border-r border-slate-100 dark:border-zinc-800`}>
            <input
              type="checkbox"
              checked={isSelected}
              onChange={() => handleSelectRow(row.id)}
              className="rounded text-indigo-600 focus:ring-0 cursor-pointer"
            />
          </td>

          {/* Row Index Number & Expand/Collapse Details Toggle */}
          <td
            onClick={() => setActiveCell({ rowId: row.id, colId: visibleColumns[0]?.id || '' })}
            className={`${cellPad} text-center font-mono text-[11px] border-r border-slate-100 dark:border-zinc-800 cursor-pointer text-slate-400 whitespace-nowrap`}
          >
            <div className="flex items-center justify-center gap-1">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleToggleRowExpand(row.id);
                }}
                className="p-0.5 rounded text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors cursor-pointer"
                title={isRowExpanded ? 'Collapse row details' : 'Expand full row details'}
              >
                {isRowExpanded ? (
                  <ChevronDown className="w-3.5 h-3.5 text-indigo-500" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5" />
                )}
              </button>
              <span>{rowNum}</span>
            </div>
          </td>

        {/* Dynamic Cells */}
        {visibleColumns.map(col => {
          const cellVal = row[col.id];
          const isEditing =
            editingCell?.rowId === row.id && editingCell?.colId === col.id;
          const isActive =
            activeCell?.rowId === row.id && activeCell?.colId === col.id;

          const colAccess = getColAccess(col.id);
          const isNoAccess = colAccess === 'no_access';

          return (
            <td
              key={col.id}
              onClick={() => setActiveCell({ rowId: row.id, colId: col.id })}
              onDoubleClick={() => {
                if (colAccess !== 'edit') {
                  const colName = col.name || col.id;
                  if (colAccess === 'no_access') {
                    onNotify?.(`🔒 Access Denied: Field "${colName}" is set to No Access by Administrator.`, 'error');
                  } else {
                    onNotify?.(`🔒 Field Restricted: "${colName}" is set to View Only by Administrator.`, 'info');
                  }
                  return;
                }
                if (isProtectedEffective) {
                  onNotify?.('🔒 Data is protected from accidental edits. Click "Unlock to Edit" in the toolbar to modify cells.', 'info');
                  return;
                }
                handleStartEdit(row.id, col.id, cellVal);
              }}
              onPaste={e => {
                if (colAccess !== 'edit') {
                  e.preventDefault();
                  onNotify?.(`🔒 Cannot paste into "${col.name || col.id}": Field is restricted to View Only.`, 'error');
                  return;
                }
                if (isProtectedEffective) {
                  e.preventDefault();
                  onNotify?.('🔒 Table is in Protected Mode. Unlock "Edit Mode" in toolbar to paste data.', 'info');
                  return;
                }
                const pasted = e.clipboardData.getData('text');
                if (pasted && (!editingCell || pasted.includes('\t') || pasted.includes('\n'))) {
                  e.preventDefault();
                  e.stopPropagation();
                  handleCellPaste(row.id, col.id, pasted);
                }
              }}
              className={`${cellPad} border-r border-slate-100 dark:border-zinc-800 align-top transition-colors relative ${
                textWrap ? 'whitespace-normal' : 'whitespace-nowrap truncate'
              } ${
                isActive
                  ? 'ring-2 ring-indigo-500 dark:ring-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/40 z-10'
                  : ''
              } ${isNoAccess ? 'bg-slate-50/60 dark:bg-zinc-950/30' : ''}`}
            >
              {isNoAccess ? (
                <div
                  className="flex items-center gap-1.5 py-1 text-slate-400 dark:text-zinc-500 italic select-none text-[11px] font-mono cursor-not-allowed"
                  title="Field restricted: You do not have permission to view or edit this column."
                >
                  <Lock className="w-3 h-3 text-slate-400 dark:text-zinc-500 shrink-0" />
                  <span>Hidden (No Access)</span>
                </div>
              ) : isEditing ? (
                <div className="flex items-center gap-1 w-full">
                  <input
                    autoFocus
                    type={
                      col.type === 'amount' || col.type === 'percent'
                        ? 'number'
                        : col.type === 'date'
                        ? 'date'
                        : 'text'
                    }
                    value={editValue}
                    onChange={e => setEditValue(e.target.value)}
                    onBlur={handleSaveEdit}
                    onKeyDown={handleKeyDownEdit}
                    className="flex-1 w-full text-xs px-2 py-1 rounded border border-indigo-500 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none shadow-xs"
                  />
                  {col.type === 'text' && (
                    <button
                      type="button"
                      onMouseDown={e => {
                        e.preventDefault();
                        e.stopPropagation();
                        handleSaveEdit();
                        handleOpenRichEditor(row, col, rowNum);
                      }}
                      className="p-1 rounded bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900 text-indigo-600 dark:text-indigo-400 shrink-0 border border-indigo-200 dark:border-indigo-800"
                      title="Open Rich Errand & Highlight Formatter"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ) : (
                // Formatted Renderers based on Column Type
                <div
                  onDoubleClick={() => {
                    if (colAccess !== 'edit') {
                      const colName = col.name || col.id;
                      onNotify?.(`🔒 Field Restricted: "${colName}" is set to View Only by Administrator.`, 'info');
                      return;
                    }
                    if (isProtectedEffective) {
                      onNotify?.('🔒 Data is protected from accidental edits. Click "Unlock to Edit" in the toolbar to modify cells.', 'info');
                      return;
                    }
                    handleStartEdit(row.id, col.id, cellVal);
                  }}
                  className="cursor-pointer min-h-[22px] flex items-center select-text"
                  title={colAccess !== 'edit' ? `Field "${col.name}" is View-Only` : isProtectedEffective ? 'Double-click to edit (Currently Protected)' : 'Double-click to edit'}
                >
                  {col.type === 'amount' ? (
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(
                        typeof cellVal === 'number'
                          ? cellVal
                          : parseFloat(String(cellVal || 0).replace(/[^0-9.-]+/g, '')) || 0,
                        '₱'
                      )}
                    </span>
                  ) : col.type === 'percent' ? (
                    <div className="w-full space-y-1">
                      <div className="flex items-center justify-between text-[11px] font-semibold">
                        <span>{formatPercent(Number(cellVal) || 0)}</span>
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-slate-100 dark:bg-zinc-800 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${
                            Number(cellVal) >= 100
                              ? 'bg-emerald-500'
                              : Number(cellVal) >= 50
                              ? 'bg-indigo-500'
                              : 'bg-amber-500'
                          }`}
                          style={{ width: `${Math.min(100, Math.max(0, Number(cellVal) || 0))}%` }}
                        />
                      </div>
                    </div>
                  ) : col.type === 'status' ? (
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold inline-block ${
                        String(cellVal).toLowerCase() === 'completed'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800'
                          : String(cellVal).toLowerCase() === 'in progress'
                          ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/80 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800'
                          : String(cellVal).toLowerCase() === 'review'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300 border border-amber-300 dark:border-amber-800'
                          : 'bg-slate-100 text-slate-800 dark:bg-zinc-800 dark:text-zinc-300 border border-slate-200 dark:border-zinc-700'
                      }`}
                    >
                      {String(cellVal || 'In Progress')}
                    </span>
                  ) : col.type === 'date' ? (
                    <div className="flex items-center gap-1.5 text-slate-700 dark:text-zinc-300 font-mono text-[11px]">
                      <Calendar className="w-3.5 h-3.5 text-slate-400" />
                      <span>{cellVal ? normalizeExcelDate(cellVal) : '-'}</span>
                    </div>
                  ) : col.type === 'jpeg' ? (
                    cellVal ? (
                      <div
                        onClick={e => {
                          e.stopPropagation();
                          onPreviewImage(cellVal, `${col.name} - Row #${rowNum}`);
                        }}
                        className="flex items-center gap-1.5 p-1 rounded-md bg-slate-100 dark:bg-zinc-800 hover:ring-1 hover:ring-indigo-500 cursor-zoom-in"
                      >
                        <img
                          src={cellVal}
                          alt="Preview"
                          className="w-7 h-7 rounded object-cover"
                        />
                        <span className="text-[11px] font-medium text-slate-600 dark:text-zinc-300 truncate max-w-[90px]">
                          View JPEG
                        </span>
                      </div>
                    ) : (
                      <label
                        onClick={e => e.stopPropagation()}
                        className="flex items-center gap-1 px-2 py-1 rounded border border-dashed border-slate-300 dark:border-zinc-700 hover:border-indigo-500 text-[10px] text-slate-400 cursor-pointer"
                      >
                        <ImageIcon className="w-3 h-3" />
                        <span>Upload JPEG</span>
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          className="hidden"
                          onChange={e => {
                            const file = e.target.files?.[0];
                            if (file) handleFileUploadForRow(row.id, col.id, file, 'jpeg');
                          }}
                        />
                      </label>
                    )
                  ) : col.type === 'pdf' ? (
                    cellVal ? (
                      <div
                        onClick={e => {
                          e.stopPropagation();
                          onPreviewPdf(cellVal, `${col.name} - Row #${rowNum}`);
                        }}
                        className="flex items-center gap-1.5 px-2 py-1 rounded bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-[11px] font-medium cursor-pointer"
                      >
                        <FileText className="w-3.5 h-3.5 text-purple-500" />
                        <span className="truncate max-w-[120px]">{String(cellVal)}</span>
                      </div>
                    ) : (
                      <label
                        onClick={e => e.stopPropagation()}
                        className="flex items-center gap-1 px-2 py-1 rounded border border-dashed border-slate-300 dark:border-zinc-700 hover:border-purple-500 text-[10px] text-slate-400 cursor-pointer"
                      >
                        <FileText className="w-3 h-3" />
                        <span>Attach PDF</span>
                        <input
                          type="file"
                          accept="application/pdf"
                          className="hidden"
                          onChange={e => {
                            const file = e.target.files?.[0];
                            if (file) handleFileUploadForRow(row.id, col.id, file, 'pdf');
                          }}
                        />
                      </label>
                    )
                  ) : col.type === 'legal-checklist' ? (
                    (() => {
                      let parsedList: any[] = [];
                      if (Array.isArray(cellVal)) {
                        parsedList = cellVal;
                      } else if (typeof cellVal === 'string' && cellVal.trim().startsWith('[')) {
                        try {
                          parsedList = JSON.parse(cellVal);
                        } catch {}
                      }
                      if (parsedList.length === 0) {
                        parsedList = DEFAULT_LEGAL_CHECKLIST_ITEMS;
                      }
                      const doneCount = parsedList.filter((item: any) => item.status === 'Completed').length;
                      const totalCount = parsedList.length;
                      const totalAmount = parsedList.reduce((acc: number, curr: any) => acc + (Number(curr.amount) || 0), 0);
                      const isComplete = doneCount === totalCount && totalCount > 0;
                      const picsCount = parsedList.filter((item: any) => Boolean(item.attachedPictureUrl || item.receiptDocUrl || item.receiptDoc)).length;
                      const siteIdText = String(row.col_site_id || row.id || 'Site');

                      return (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenLegalChecklist?.(row, col);
                          }}
                          className={`w-full text-left p-1.5 rounded-lg border transition-all flex items-center justify-between gap-1.5 shadow-2xs group/checklist hover:scale-[1.01] cursor-pointer ${
                            isComplete
                              ? 'border-emerald-500/40 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300'
                              : 'border-amber-500/50 bg-amber-50/70 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-200'
                          }`}
                          title={`Per-Site Clickable Checklist: Click to open ${siteIdText} legal milestones & view attached reference pictures`}
                        >
                          <div className="flex items-center gap-1.5 truncate">
                            <Shield className={`w-3.5 h-3.5 shrink-0 ${isComplete ? 'text-emerald-500 fill-emerald-500/20' : 'text-amber-500 fill-amber-500/20'}`} />
                            <div className="flex flex-col truncate leading-tight">
                              <span className="font-bold text-[11px] truncate flex items-center gap-1">
                                <span>Checklist</span>
                                <span className={`text-[10px] px-1 rounded font-mono ${isComplete ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300' : 'bg-amber-500/20 text-amber-800 dark:text-amber-200'}`}>
                                  {doneCount}/{totalCount}
                                </span>
                              </span>
                              {picsCount > 0 && (
                                <span className="text-[9px] text-cyan-700 dark:text-cyan-400 font-semibold flex items-center gap-0.5 truncate">
                                  <span>📷</span>
                                  <span>{picsCount} Pics Attached</span>
                                </span>
                              )}
                            </div>
                          </div>
                          <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-black/5 dark:bg-black/30 shrink-0">
                            {formatCurrency(totalAmount, '₱')}
                          </span>
                        </button>
                      );
                    })()
                  ) : col.type === 'day-by-day' ? (
                    (() => {
                      let parsedLogs: any[] = [];
                      if (Array.isArray(cellVal)) {
                        parsedLogs = cellVal;
                      } else if (typeof cellVal === 'string' && cellVal.trim().startsWith('[')) {
                        try {
                          parsedLogs = JSON.parse(cellVal);
                        } catch {}
                      }
                      if (parsedLogs.length === 0) {
                        parsedLogs = generateDefaultDayByDayLog(row.col_site_id || row.id, row.col_site_name || 'Site');
                      }

                      const sla = calculateDayByDaySla(row, parsedLogs, formatDateYMD(new Date()));
                      const siteIdText = String(row.col_site_id || row.id || 'Site');
                      const latestUpdateNotes = sla.latestLog?.progressNotes || 'Daily progress logged';
                      const badge = STATUS_BADGE_STYLES[sla.currentStatus] || STATUS_BADGE_STYLES['Site Hunting'];

                      return (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenDayByDay?.(row, col);
                          }}
                          className={`w-full text-left p-1.5 rounded-lg border transition-all flex items-center justify-between gap-1.5 shadow-2xs group/daybyday hover:scale-[1.01] cursor-pointer ${
                            sla.slaHealth === 'completed'
                              ? 'border-emerald-500/40 bg-emerald-50/70 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300'
                              : sla.slaHealth === 'overdue'
                              ? 'border-red-500/60 bg-red-50/70 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-900/50 text-red-900 dark:text-red-200'
                              : sla.slaHealth === 'stalled' || sla.slaHealth === 'approaching_warning'
                              ? 'border-amber-500/50 bg-amber-50/70 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-200'
                              : 'border-blue-500/40 bg-blue-50/70 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-blue-900 dark:text-blue-200'
                          }`}
                          title={`Click to record Day-by-Day updates & monitor SAQ SLA for ${siteIdText} (Official SLA Start: ${sla.officialSlaStartDate})`}
                        >
                          <div className="flex items-center gap-1.5 truncate">
                            <Calendar className="w-3.5 h-3.5 shrink-0 text-blue-500" />
                            <div className="flex flex-col truncate leading-tight">
                              <div className="flex items-center gap-1.5 truncate">
                                <span className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold border ${badge.bg} ${badge.text} ${badge.border}`}>
                                  {sla.currentStatus}
                                </span>
                                <span className="font-bold text-[11px] truncate">
                                  {sla.badgeLabel}
                                </span>
                              </div>
                              <span className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-[150px]">
                                {sla.lastUpdateDate}: {latestUpdateNotes}
                              </span>
                            </div>
                          </div>

                          <div className="flex flex-col items-end shrink-0 leading-none">
                            <span className="text-[9px] font-mono font-bold px-1 py-0.5 rounded bg-black/5 dark:bg-black/30">
                              📋 {sla.totalLogsCount} logs
                            </span>
                            <span className="text-[8px] text-blue-600 dark:text-blue-400 font-mono mt-0.5">
                              Start: {sla.officialSlaStartDate}
                            </span>
                          </div>
                        </button>
                      );
                    })()
                  ) : (
                    <div className="relative group/cell w-full">
                      <div className="select-text pr-5 min-h-[22px]">
                        {renderFormattedContent(cellVal, {
                          isCompact,
                          interactiveChecklist: canModifyData,
                          onToggleTask: (lineIdx, origLine, nextStatus) =>
                            handleToggleCellErrand(row.id, col.id, lineIdx, origLine, nextStatus)
                        })}
                      </div>
                      {canEdit && (
                        <button
                          type="button"
                          onClick={e => {
                            e.stopPropagation();
                            handleOpenRichEditor(row, col, rowNum);
                          }}
                          className="absolute right-0 top-0 opacity-0 group-hover/cell:opacity-100 p-1 rounded bg-white dark:bg-zinc-800 border border-slate-300 dark:border-zinc-700 text-indigo-600 dark:text-indigo-400 shadow-xs hover:bg-indigo-50 dark:hover:bg-zinc-700 transition-all z-10"
                          title="Manage & Format: bold, underline, highlight & errands"
                        >
                          <Sparkles className="w-3 h-3 text-indigo-500" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </td>
          );
        })}

        {/* Working Row Actions - Fully Visible & Interactive */}
        <td className={`${actionPad} text-right border-l border-slate-100 dark:border-zinc-800`}>
          <div className="flex items-center justify-end gap-1">
            {canEdit && (
              <>
                <button
                  onClick={() => handleInsertRow(row.id, 'above')}
                  title="Insert row above (in between)"
                  className="p-1 rounded text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 flex items-center"
                >
                  <ArrowUp className="w-3 h-3 text-indigo-500" />
                </button>

                <button
                  onClick={() => handleInsertRow(row.id, 'below')}
                  title="Insert row below (in between)"
                  className="p-1 rounded text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 flex items-center"
                >
                  <ArrowDown className="w-3 h-3 text-indigo-500" />
                </button>

                <button
                  onClick={() => handleDuplicateRow(row)}
                  title="Duplicate Row"
                  className="p-1 rounded text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    const textCol = tracker.columns.find(c =>
                      (c.name + ' ' + c.id).toLowerCase().includes('data') ||
                      (c.name + ' ' + c.id).toLowerCase().includes('errand') ||
                      (c.name + ' ' + c.id).toLowerCase().includes('remark') ||
                      (c.name + ' ' + c.id).toLowerCase().includes('note') ||
                      c.type === 'text'
                    ) || visibleColumns[0];
                    if (textCol) {
                      handleOpenRichEditor(row, textCol, rowNum);
                    }
                  }}
                  title="Manage Errands, Highlights, Bold & Underline for this record"
                  className="p-1 rounded text-indigo-500 hover:text-indigo-700 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    if (isProtectedEffective) {
                      onNotify?.('🔒 Data is protected from accidental deletion. Unlock Edit Mode in toolbar to delete rows.', 'info');
                      return;
                    }
                    setRowToDelete({
                      id: row.id,
                      rowNum,
                      title: String(row[visibleColumns[0]?.id] || 'Selected Row')
                    });
                  }}
                  title={isProtectedEffective ? 'Data is protected. Unlock to delete.' : 'Delete Row'}
                  className={`p-1 rounded transition-colors shadow-2xs ${
                    isProtectedEffective
                      ? 'text-slate-300 dark:text-zinc-600 cursor-not-allowed'
                      : 'text-rose-500 hover:text-white hover:bg-rose-600 dark:hover:bg-rose-600'
                  }`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </td>
      </tr>

      {/* Collapsible Row Details Drawer */}
      {isRowExpanded && (
        <tr className="bg-slate-50/80 dark:bg-zinc-900/80 border-b border-indigo-100 dark:border-indigo-950/60 transition-colors">
          <td colSpan={visibleColumns.length + 3} className="p-3 sm:px-6">
            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#0c1017] shadow-sm space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-slate-100 dark:border-zinc-800">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-xs text-slate-900 dark:text-white uppercase tracking-wider">
                    Row #{rowNum} Details Overview
                  </span>
                  <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                    {String(row.col_site_id || row.id)}
                  </span>
                  {row.col_site_name && (
                    <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      {String(row.col_site_name)}
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5">
                  {onOpenDayByDay && (
                    <button
                      type="button"
                      onClick={() => onOpenDayByDay(row, visibleColumns.find(c => c.type === 'day-by-day') || visibleColumns[0])}
                      className="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Day-by-Day Tracker</span>
                    </button>
                  )}
                  {onOpenLegalChecklist && (
                    <button
                      type="button"
                      onClick={() => onOpenLegalChecklist(row, visibleColumns.find(c => c.id === 'col_legal_checklist') || visibleColumns[0])}
                      className="px-2.5 py-1 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <Shield className="w-3.5 h-3.5" />
                      <span>Legal Checklist</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => handleToggleRowExpand(row.id)}
                    className="p-1 rounded text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                    title="Collapse row details"
                  >
                    <ChevronUp className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Grid of All Columns */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 text-xs">
                {tracker.columns.map(col => {
                  const val = row[col.id];
                  let displayVal = String(val ?? '-');
                  if (col.type === 'amount') {
                    displayVal = formatCurrency(parseNum(val), '₱');
                  } else if (col.type === 'day-by-day' && Array.isArray(val)) {
                    displayVal = `${val.length} logs (${val[val.length - 1]?.status || 'Active'})`;
                  } else if (col.id === 'col_legal_checklist' && Array.isArray(val)) {
                    displayVal = `${val.filter((i: any) => i.status === 'Completed').length}/${val.length} completed`;
                  }

                  return (
                    <div key={col.id} className="p-2 rounded-lg bg-slate-50 dark:bg-zinc-900 border border-slate-200/80 dark:border-zinc-800/80 flex flex-col justify-between">
                      <span className="text-[10px] uppercase font-bold text-slate-400 truncate mb-0.5">
                        {col.name}
                      </span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 truncate" title={displayVal}>
                        {displayVal || '-'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </td>
        </tr>
      )}
    </React.Fragment>
  );
};

  // If user does not have permission to view this tracker, show secure access restricted state
  if (!canViewTracker) {
    return (
      <div className="rounded-2xl border border-amber-200 dark:border-amber-900/60 bg-white/95 dark:bg-zinc-900/95 p-8 sm:p-12 text-center max-w-xl mx-auto my-12 shadow-md backdrop-blur-md">
        <div className="w-16 h-16 rounded-2xl bg-amber-100 dark:bg-amber-950/80 flex items-center justify-center mx-auto text-amber-600 dark:text-amber-400 mb-4 shadow-xs border border-amber-200 dark:border-amber-800">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <div className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800 mb-2">
          Security Access Control
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-zinc-100 tracking-tight">
          Tracker Access Restricted
        </h2>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-zinc-400 mt-2.5 max-w-md mx-auto leading-relaxed">
          {currentUser?.role === 'staff'
            ? `Your account (${currentUser.username} · Staff) does not currently have approved access to "${tracker.name}". Staff members can only view and manage trackers approved by an Administrator.`
            : `Your account (${currentUser?.username || 'Guest'} · Guest) requires Administrator approval to view "${tracker.name}".`}
        </p>

        <div className="mt-6 flex flex-col sm:flex-row items-center justify-center gap-3">
          {onRequestAccess && (
            <button
              onClick={onRequestAccess}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md hover:shadow-indigo-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              <span>Request Access to this Tracker</span>
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Excel-like Control Ribbon / Toolbar with Collapsible Mode */}
      {isRibbonCollapsed ? (
        /* Compact Collapsed Toolbar (Maximizes Screen for Many Data Rows) */
        <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white/95 dark:bg-zinc-900/95 shadow-2xs backdrop-blur-md">
          {/* Left: Essential Quick Actions */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Data Protection Toggle */}
            <button
              onClick={onToggleDataProtection || (() => setLocalProtected(prev => !prev))}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold border shadow-2xs transition-all ${
                isProtectedEffective
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100'
                  : 'bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-200 border-amber-300 dark:border-amber-800 hover:bg-amber-100'
              }`}
              title={
                isProtectedEffective
                  ? 'Data Protection Mode is ON: Protects against accidental deletes and edits. Click to unlock.'
                  : 'Edit Mode Active: Changes are permitted. Click to lock and protect data.'
              }
            >
              {isProtectedEffective ? (
                <>
                  <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>🔒 Protected</span>
                </>
              ) : (
                <>
                  <Unlock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>✏️ Edit Mode</span>
                </>
              )}
            </button>

            {/* Undo & Redo (Compact) */}
            {onUndo && (
              <button
                onClick={onUndo}
                disabled={!canUndo}
                className="p-1 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 disabled:opacity-40 shadow-2xs"
                title="Undo last action (Ctrl+Z)"
              >
                <Undo2 className="w-3.5 h-3.5 text-indigo-500" />
              </button>
            )}
            {onRedo && (
              <button
                onClick={onRedo}
                disabled={!canRedo}
                className="p-1 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 disabled:opacity-40 shadow-2xs"
                title="Redo action (Ctrl+Y)"
              >
                <Redo2 className="w-3.5 h-3.5 text-indigo-500" />
              </button>
            )}

            {/* Add Row Button */}
            {canEdit && (
              <button
                onClick={() => {
                  if (isProtectedEffective) {
                    onNotify?.('🔒 Data is protected. Click "Unlock to Edit" in the toolbar to add rows.', 'info');
                    return;
                  }
                  handleAddRow();
                }}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Row</span>
              </button>
            )}

            {/* Grouping Indicator & Controls if Grouped */}
            {groupByCol ? (
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-xs text-indigo-800 dark:text-indigo-200 font-semibold">
                <span>Grouped by: {tracker.columns.find(c => c.id === groupByCol)?.name}</span>
                <button
                  type="button"
                  onClick={handleExpandAllGroups}
                  className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-white dark:bg-zinc-800 border border-indigo-300 dark:border-indigo-700 hover:bg-indigo-50"
                  title="Expand all groups"
                >
                  Expand All
                </button>
                <button
                  type="button"
                  onClick={handleCollapseAllGroups}
                  className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-white dark:bg-zinc-800 border border-indigo-300 dark:border-indigo-700 hover:bg-indigo-50"
                  title="Collapse all groups"
                >
                  Collapse All
                </button>
              </div>
            ) : (
              <span className="text-[11px] font-semibold text-slate-500 dark:text-zinc-400">
                {processedRows.length} rows
              </span>
            )}
          </div>

          {/* Right: Quick Search + Density + Expand Toolbar */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search records..."
                value={searchTerm}
                onChange={e => handleSearchChangeInternal(e.target.value)}
                className="text-xs pl-8 pr-6 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none w-36 sm:w-48 shadow-2xs"
              />
              {searchTerm && (
                <button
                  onClick={() => handleSearchChangeInternal('')}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            <button
              onClick={handleToggleDensity}
              className={`px-2 py-1 rounded-lg text-xs font-semibold border transition-colors shadow-2xs ${
                rowDensity === 'compact'
                  ? 'bg-indigo-50 dark:bg-indigo-950/50 border-indigo-300 text-indigo-700 dark:text-indigo-300'
                  : 'bg-white dark:bg-zinc-800 border-slate-300 text-slate-600 dark:text-zinc-300'
              }`}
              title={rowDensity === 'compact' ? 'Compact density active (fits more rows)' : 'Normal density active'}
            >
              {rowDensity === 'compact' ? 'Compact' : 'Normal'}
            </button>

            {/* Expand Ribbon Button */}
            <button
              type="button"
              onClick={handleToggleRibbon}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold bg-indigo-50 dark:bg-indigo-950/70 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 shadow-2xs transition-colors"
              title="Expand full toolbar ribbon to view all tools, filters & export options"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Expand Toolbar</span>
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        /* Full Expanded Control Ribbon - Clean, Professionally Organized 2-Tier Architecture */
        <div className="p-3 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white/95 dark:bg-zinc-900/95 shadow-xs backdrop-blur-md space-y-2.5">
          {/* Row 1: Primary Action & Tool Ribbon */}
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            {/* Left Zone: Editing, Row Operations, and Column Tools */}
            <div className="flex flex-wrap items-center gap-2">
              {/* Primary CTA: Add Row */}
              {canEdit && (
                <button
                  onClick={() => {
                    if (isProtectedEffective) {
                      onNotify?.('🔒 Data is protected. Click "Unlock to Edit" in the toolbar to add rows.', 'info');
                      return;
                    }
                    handleAddRow();
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Row</span>
                </button>
              )}

              {/* Data Protection Mode Switch */}
              <button
                onClick={onToggleDataProtection || (() => setLocalProtected(prev => !prev))}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                  isProtectedEffective
                    ? 'bg-slate-100 dark:bg-zinc-800/80 text-slate-700 dark:text-zinc-300 border-slate-300 dark:border-zinc-700 hover:bg-slate-200'
                    : 'bg-amber-50 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 border-amber-300 dark:border-amber-700 hover:bg-amber-100'
                }`}
                title={
                  isProtectedEffective
                    ? 'Data Protection Mode Active: Prevents accidental cell overwrites and row deletes. Click to Unlock.'
                    : 'Edit Mode Active: Changes permitted. Click to Lock and protect data.'
                }
              >
                {isProtectedEffective ? (
                  <>
                    <Lock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>Protected</span>
                  </>
                ) : (
                  <>
                    <Unlock className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                    <span>Edit Mode</span>
                  </>
                )}
              </button>

              {/* Undo and Redo History Segmented Group */}
              {(onUndo || onRedo) && (
                <div className="flex items-center rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 overflow-hidden shadow-2xs">
                  {onUndo && (
                    <button
                      onClick={onUndo}
                      disabled={!canUndo}
                      className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-zinc-200 hover:bg-slate-50 dark:hover:bg-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed border-r border-slate-200 dark:border-zinc-700 transition-colors"
                      title="Undo last action (Ctrl+Z)"
                    >
                      <Undo2 className="w-3.5 h-3.5 text-slate-500 dark:text-zinc-400" />
                      <span className="hidden sm:inline">Undo</span>
                    </button>
                  )}
                  {onRedo && (
                    <button
                      onClick={onRedo}
                      disabled={!canRedo}
                      className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:text-zinc-200 hover:bg-slate-50 dark:hover:bg-zinc-700 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                      title="Redo action (Ctrl+Y)"
                    >
                      <Redo2 className="w-3.5 h-3.5 text-slate-500 dark:text-zinc-400" />
                      <span className="hidden sm:inline">Redo</span>
                    </button>
                  )}
                </div>
              )}

              {/* Import & Paste Dropdown Menu */}
              {canEdit && (
                <div className="relative" ref={importMenuRef}>
                  <button
                    onClick={() => {
                      setShowImportMenu(!showImportMenu);
                      setShowExportMenu(false);
                      setShowViewMenu(false);
                    }}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 shadow-2xs transition-colors"
                    title="Import data from Excel, CSV, or paste clipboard content"
                  >
                    <Upload className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>Import & Paste</span>
                    <ChevronDown className="w-3 h-3 text-slate-400" />
                  </button>

                  {showImportMenu && (
                    <div className="absolute left-0 mt-1.5 w-60 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-xl py-1 z-50 text-xs animate-in fade-in">
                      <button
                        onClick={() => {
                          setShowImportMenu(false);
                          onOpenExcelPaste();
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-zinc-800 flex items-center gap-2.5 text-slate-700 dark:text-zinc-200"
                      >
                        <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                        <div>
                          <div className="font-semibold">Import Excel / Wizard</div>
                          <div className="text-[10px] text-slate-400">Upload .xlsx file or paste tabular data</div>
                        </div>
                      </button>

                      <button
                        onClick={() => {
                          setShowImportMenu(false);
                          handleFastPasteFromClipboard();
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-zinc-800 flex items-center gap-2.5 text-slate-700 dark:text-zinc-200 border-t border-slate-100 dark:border-zinc-800"
                      >
                        <ClipboardPaste className="w-4 h-4 text-indigo-500" />
                        <div>
                          <div className="font-semibold">Paste to Selected Cell</div>
                          <div className="text-[10px] text-slate-400">Direct clipboard insertion (Ctrl+V)</div>
                        </div>
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Columns Customizer */}
              <button
                onClick={onOpenColumnManager}
                className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 shadow-2xs transition-colors"
                title="Add, hide, reorder and customize columns"
              >
                <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-500" />
                <span>Columns</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-100 dark:bg-zinc-700 text-slate-600 dark:text-zinc-300 font-bold">
                  {visibleColumns.length}
                </span>
              </button>

              {/* Row Sum & Open CAL Liquidation Generator */}
              {hasAmountCols && (
                <button
                  onClick={() => setShowOpenCalModal(true)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-rose-50/70 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 shadow-2xs transition-colors"
                  title="Generate row total sum & remaining open CAL (Cash Advance Liquidation) for all rows"
                >
                  <Calculator className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                  <span>Row Sum & Open CAL</span>
                  {overallOpenCalMetrics.openCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-600 text-white">
                      {overallOpenCalMetrics.openCount}
                    </span>
                  )}
                </button>
              )}
            </div>

            {/* Right Zone: Reporting, View Settings, and Minimizer */}
            <div className="flex items-center gap-2">
              {/* Reports & Export Consolidated Menu */}
              <div className="relative" ref={exportMenuRef}>
                <button
                  onClick={() => {
                    setShowExportMenu(!showExportMenu);
                    setShowImportMenu(false);
                    setShowViewMenu(false);
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 shadow-2xs transition-colors"
                  title="Generate reports, slide decks, or export spreadsheets"
                >
                  <Download className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Reports & Export</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {showExportMenu && (
                  <div className="absolute right-0 mt-1.5 w-56 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-xl py-1 z-50 text-xs animate-in fade-in">
                    {onOpenReport && (
                      <button
                        onClick={() => {
                          setShowExportMenu(false);
                          onOpenReport();
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-zinc-800 flex items-center gap-2 text-slate-700 dark:text-zinc-200"
                      >
                        <FileText className="w-4 h-4 text-indigo-500" />
                        <div>
                          <div className="font-semibold">Executive Audit Report</div>
                          <div className="text-[10px] text-slate-400">Printable PDF report format</div>
                        </div>
                      </button>
                    )}

                    {onOpenPresentation && (
                      <button
                        onClick={() => {
                          setShowExportMenu(false);
                          onOpenPresentation();
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-zinc-800 flex items-center gap-2 text-slate-700 dark:text-zinc-200 border-t border-slate-100 dark:border-zinc-800"
                      >
                        <Presentation className="w-4 h-4 text-purple-500" />
                        <div>
                          <div className="font-semibold">Presentation Deck Mode</div>
                          <div className="text-[10px] text-slate-400">Live slide decks with KPI charts</div>
                        </div>
                      </button>
                    )}

                    {canExport && (
                      <button
                        onClick={() => {
                          setShowExportMenu(false);
                          exportToExcel(tracker);
                          onLogActivity?.('EXPORT_DATA', {
                            trackerId: tracker.id,
                            trackerName: tracker.name,
                            details: 'Exported tracker data to Excel (.xlsx)'
                          });
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-zinc-800 flex items-center gap-2 text-slate-700 dark:text-zinc-200 border-t border-slate-100 dark:border-zinc-800"
                      >
                        <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                        <div>
                          <div className="font-semibold">Export Excel (.xlsx)</div>
                          <div className="text-[10px] text-slate-400">Native formatted workbook</div>
                        </div>
                      </button>
                    )}

                    {onExportCSV && (
                      <button
                        onClick={() => {
                          setShowExportMenu(false);
                          onExportCSV();
                        }}
                        className="w-full px-3 py-2 text-left hover:bg-slate-50 dark:hover:bg-zinc-800 flex items-center gap-2 text-slate-700 dark:text-zinc-200 border-t border-slate-100 dark:border-zinc-800"
                      >
                        <Download className="w-4 h-4 text-blue-500" />
                        <div>
                          <div className="font-semibold">Export CSV Spreadsheet</div>
                          <div className="text-[10px] text-slate-400">Universal comma-delimited data</div>
                        </div>
                      </button>
                    )}
                  </div>
                )}
              </div>

              {/* View Settings Consolidated Popover */}
              <div className="relative" ref={viewMenuRef}>
                <button
                  onClick={() => {
                    setShowViewMenu(!showViewMenu);
                    setShowImportMenu(false);
                    setShowExportMenu(false);
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-200 shadow-2xs transition-colors"
                  title="Configure table display: density, text wrap, flexible width, and calculation columns"
                >
                  <Eye className="w-3.5 h-3.5 text-slate-500 dark:text-zinc-400" />
                  <span>View</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {showViewMenu && (
                  <div className="absolute right-0 mt-1.5 w-64 rounded-xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-xl p-2 z-50 text-xs space-y-2 animate-in fade-in">
                    <div className="font-bold text-[11px] text-slate-400 uppercase tracking-wider px-1">
                      Display Preferences
                    </div>

                    {/* Row Density */}
                    <div className="flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 transition-colors">
                      <span className="font-medium text-slate-700 dark:text-zinc-200">Compact Density</span>
                      <button
                        onClick={handleToggleDensity}
                        className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                          rowDensity === 'compact' ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-zinc-700'
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transition-transform ${
                            rowDensity === 'compact' ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    {/* Flexible Column Width */}
                    <div className="flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 transition-colors">
                      <span className="font-medium text-slate-700 dark:text-zinc-200">100% Flexible Width</span>
                      <button
                        onClick={() => setFlexibleWidth(!flexibleWidth)}
                        className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                          flexibleWidth ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-zinc-700'
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transition-transform ${
                            flexibleWidth ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    {/* Text Wrap */}
                    <div className="flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 transition-colors">
                      <span className="font-medium text-slate-700 dark:text-zinc-200">Text Wrap in Cells</span>
                      <button
                        onClick={() => setTextWrap(!textWrap)}
                        className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                          textWrap ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-zinc-700'
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transition-transform ${
                            textWrap ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>

                    {/* Row Calculation Column */}
                    {hasAmountCols && (
                      <div className="flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 transition-colors">
                        <span className="font-medium text-slate-700 dark:text-zinc-200">Row Sum Column</span>
                        <button
                          onClick={() => setShowRowCalcColumn(!showRowCalcColumn)}
                          className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                            showRowCalcColumn ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-zinc-700'
                          }`}
                        >
                          <div
                            className={`w-4 h-4 rounded-full bg-white transition-transform ${
                              showRowCalcColumn ? 'translate-x-4' : 'translate-x-0'
                            }`}
                          />
                        </button>
                      </div>
                    )}

                    {/* Column Totals Footer */}
                    <div className="flex items-center justify-between p-1.5 rounded-lg hover:bg-slate-50 dark:hover:bg-zinc-800 transition-colors">
                      <span className="font-medium text-slate-700 dark:text-zinc-200">Totals Summary Footer</span>
                      <button
                        onClick={() => setShowSummaryFooter(!showSummaryFooter)}
                        className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                          showSummaryFooter ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-zinc-700'
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white transition-transform ${
                            showSummaryFooter ? 'translate-x-4' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Minimize/Collapse Ribbon Toggle */}
              <button
                type="button"
                onClick={handleToggleRibbon}
                className="p-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-500 hover:text-slate-700 dark:hover:text-zinc-200 transition-colors"
                title="Collapse toolbar ribbon"
              >
                <ChevronUp className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Row 2: Search, Filters, Grouping & Record Status */}
          <div className="pt-2 border-t border-slate-100 dark:border-zinc-800/80 flex flex-wrap items-center justify-between gap-2.5">
            {/* Left Filter Strip */}
            <div className="flex flex-wrap items-center gap-2">
              {/* Search input with clean clear button */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search items, notes, stations..."
                  value={searchTerm}
                  onChange={e => handleSearchChangeInternal(e.target.value)}
                  className="text-xs pl-8 pr-7 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-slate-50/50 dark:bg-zinc-800/60 text-slate-900 dark:text-zinc-100 outline-none w-48 sm:w-60 focus:border-indigo-500 focus:bg-white dark:focus:bg-zinc-800 transition-all shadow-2xs"
                />
                {searchTerm && (
                  <button
                    onClick={() => handleSearchChangeInternal('')}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Status Filter */}
              <div className="flex items-center gap-1.5 text-xs">
                <select
                  value={statusFilter}
                  onChange={e => {
                    setStatusFilter(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 outline-none shadow-2xs font-medium"
                >
                  <option value="all">All Statuses</option>
                  <option value="completed">Completed</option>
                  <option value="in progress">In Progress</option>
                  <option value="review">Review</option>
                  <option value="pending approval">Pending Approval</option>
                  <option value="on hold">On Hold</option>
                </select>
              </div>

              {/* Group By Selector */}
              <div className="flex items-center gap-1.5 text-xs">
                <span className="text-slate-400 dark:text-zinc-500 hidden sm:inline text-[11px]">Group:</span>
                <select
                  value={groupByCol || ''}
                  onChange={e => {
                    setGroupByCol(e.target.value || null);
                    setCollapsedGroups({});
                  }}
                  className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 outline-none shadow-2xs font-medium"
                >
                  <option value="">None (Standard Grid)</option>
                  {visibleColumns
                    .filter(c => c.type === 'text' || c.type === 'status')
                    .map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                </select>

                {groupByCol && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={handleExpandAllGroups}
                      className="px-2 py-1 rounded text-[11px] font-semibold bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 shadow-2xs transition-colors"
                      title="Expand all grouped sections"
                    >
                      Expand All
                    </button>
                    <button
                      type="button"
                      onClick={handleCollapseAllGroups}
                      className="px-2 py-1 rounded text-[11px] font-semibold bg-slate-100 dark:bg-zinc-800 hover:bg-slate-200 text-slate-700 dark:text-zinc-300 border border-slate-300 dark:border-zinc-700 shadow-2xs transition-colors"
                      title="Collapse all grouped sections"
                    >
                      Collapse All
                    </button>
                  </div>
                )}

                {/* Expand / Collapse All Row Details Button */}
                <button
                  type="button"
                  onClick={() => {
                    if (Object.keys(expandedRowIds).length > 0) {
                      handleCollapseAllRows();
                    } else {
                      handleExpandAllRows();
                    }
                  }}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 border border-slate-200 dark:border-zinc-700 hover:bg-slate-50 dark:hover:bg-zinc-700 shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
                  title={Object.keys(expandedRowIds).length > 0 ? 'Collapse all row cards' : 'Expand all row cards to view full details'}
                >
                  {Object.keys(expandedRowIds).length > 0 ? (
                    <>
                      <ChevronUp className="w-3.5 h-3.5 text-indigo-500" />
                      <span>Collapse Rows</span>
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-3.5 h-3.5" />
                      <span>Expand Rows</span>
                    </>
                  )}
                </button>
              </div>

              {/* Bulk Delete Bar with Inline Confirmation */}
              {selectedRowIds.length > 0 && canEdit && (
                <div className="flex items-center gap-1.5 p-1 px-2.5 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-xs">
                  <span className="font-bold text-red-700 dark:text-red-300">
                    {selectedRowIds.length} selected
                  </span>
                  {showBulkConfirm ? (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={handleExecuteBulkDelete}
                        className="px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white font-bold text-xs"
                      >
                        Confirm Delete
                      </button>
                      <button
                        onClick={() => setShowBulkConfirm(false)}
                        className="px-1.5 py-1 rounded bg-slate-200 dark:bg-zinc-700 text-slate-700 dark:text-zinc-200 text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setShowBulkConfirm(true)}
                      className="flex items-center gap-1 px-2 py-1 rounded bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shadow-2xs"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Selected</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Right Status Segmented Filter */}
            {hasAmountCols && (
              <div className="flex items-center bg-slate-100 dark:bg-zinc-800/80 p-0.5 rounded-lg border border-slate-200 dark:border-zinc-700 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setOpenCalFilter('all');
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
                    openCalFilter === 'all'
                      ? 'bg-white dark:bg-zinc-900 text-slate-900 dark:text-white shadow-2xs'
                      : 'text-slate-600 dark:text-zinc-400 hover:text-slate-900'
                  }`}
                >
                  All Rows ({tracker.rows.length})
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setOpenCalFilter('open');
                    setCurrentPage(1);
                  }}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
                    openCalFilter === 'open'
                      ? 'bg-rose-600 text-white shadow-2xs font-bold'
                      : 'text-rose-600 dark:text-rose-400 hover:text-rose-700'
                  }`}
                  title="Filter to show only rows with remaining open CAL"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
                  <span>Open CAL ({overallOpenCalMetrics.openCount})</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setOpenCalFilter('settled');
                    setCurrentPage(1);
                  }}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all ${
                    openCalFilter === 'settled'
                      ? 'bg-emerald-600 text-white shadow-2xs font-bold'
                      : 'text-emerald-600 dark:text-emerald-400 hover:text-emerald-700'
                  }`}
                  title="Filter to show settled rows"
                >
                  Settled ({overallOpenCalMetrics.settledCount})
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Hidden / Collapsed Columns Restorer Bar */}
      {tracker.columns.some(c => !c.visible) && (
        <div className="flex flex-wrap items-center gap-1.5 p-2 rounded-lg bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/40 text-xs">
          <span className="text-amber-800 dark:text-amber-300 font-semibold flex items-center gap-1">
            <Eye className="w-3.5 h-3.5" />
            Hidden / Collapsed Columns:
          </span>
          {tracker.columns
            .filter(c => !c.visible)
            .map(col => (
              <button
                key={col.id}
                onClick={() => handleToggleColVisibility(col.id)}
                className="px-2 py-0.5 rounded-full bg-white dark:bg-zinc-800 border border-amber-300 dark:border-amber-800 text-slate-700 dark:text-zinc-200 hover:bg-amber-100 flex items-center gap-1 text-[11px] font-medium shadow-2xs"
                title="Click to restore column"
              >
                <span>+ {col.name}</span>
              </button>
            ))}
        </div>
      )}

      {/* Floating / Toast Paste Feedback Notice */}
      {pasteNotice && (
        <div className="flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs font-semibold shadow-md animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <ClipboardPaste className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{pasteNotice}</span>
          </div>
          <button
            onClick={() => setPasteNotice(null)}
            className="p-1 rounded-md text-emerald-700 hover:text-emerald-950 dark:text-emerald-300 dark:hover:text-white"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Grid View */}
      <div
        ref={tableContainerRef}
        className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden shadow-xs bg-white dark:bg-zinc-900 focus:outline-none"
        tabIndex={0}
      >
        <div className="overflow-x-auto custom-scrollbar">
          <table className={`border-collapse text-xs ${flexibleWidth ? 'w-full' : 'w-max min-w-full'}`}>
            {/* Table Header */}
            <thead className="bg-slate-50 dark:bg-zinc-800/90 sticky top-0 z-10 select-none">
              <tr>
                {/* Checkbox column */}
                <th className="p-2.5 text-center w-10 border-b border-r border-slate-200 dark:border-zinc-800">
                  <input
                    type="checkbox"
                    checked={
                      paginatedRows.length > 0 &&
                      paginatedRows.every(r => selectedRowIds.includes(r.id))
                    }
                    onChange={handleSelectAll}
                    className="rounded text-indigo-600 focus:ring-0 cursor-pointer"
                  />
                </th>

                {/* Index # column & Expand/Collapse All Rows toggle */}
                <th className="p-2 text-center w-14 text-slate-400 font-mono border-b border-r border-slate-200 dark:border-zinc-800 whitespace-nowrap">
                  <div className="flex items-center justify-center gap-0.5">
                    <button
                      type="button"
                      onClick={() => {
                        if (Object.keys(expandedRowIds).length > 0) {
                          handleCollapseAllRows();
                        } else {
                          handleExpandAllRows();
                        }
                      }}
                      className="p-0.5 rounded text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 cursor-pointer transition-colors"
                      title={Object.keys(expandedRowIds).length > 0 ? 'Collapse all row details' : 'Expand all row details'}
                    >
                      {Object.keys(expandedRowIds).length > 0 ? (
                        <ChevronDown className="w-3.5 h-3.5 text-indigo-500" />
                      ) : (
                        <ChevronRight className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <span>#</span>
                  </div>
                </th>

                {/* Custom Columns */}
                {visibleColumns.map(col => {
                  const isSorted = sortCol === col.id;
                  const colWidth = colWidthOverrides[col.id] || col.width || 180;
                  const colAccess = getColAccess(col.id);

                  return (
                    <th
                      key={col.id}
                      style={{
                        width: flexibleWidth ? undefined : `${colWidth}px`,
                        minWidth: `${Math.min(colWidth, 160)}px`
                      }}
                      className={`p-2.5 text-left border-b border-r border-slate-200 dark:border-zinc-800 font-bold relative group transition-colors ${
                        getHeaderColorClass(col.color)
                      } ${flexibleWidth ? 'flex-1' : ''}`}
                    >
                      <div className="flex items-center justify-between gap-1">
                        {/* Column Name & Sort Trigger */}
                        <div
                          onClick={() => {
                            if (sortCol === col.id) {
                              setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
                            } else {
                              setSortCol(col.id);
                              setSortDir('asc');
                            }
                          }}
                          className="flex items-center gap-1.5 cursor-pointer truncate flex-1"
                          title="Click to sort column"
                        >
                          <span className="truncate">{col.name}</span>
                          {colAccess === 'view' && currentUser?.role !== 'admin' && (
                            <span className="text-[9px] px-1 py-0.2 rounded bg-slate-100 dark:bg-zinc-800 text-slate-500 dark:text-zinc-400 border border-slate-200 dark:border-zinc-700 font-semibold shrink-0" title="View-Only Field">
                              View
                            </span>
                          )}
                          {colAccess === 'no_access' && currentUser?.role !== 'admin' && (
                            <span className="text-[9px] px-1 py-0.2 rounded bg-red-100 dark:bg-red-950/80 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900 font-bold shrink-0 flex items-center gap-0.5" title="No Access Field">
                              <Lock className="w-2.5 h-2.5" /> Restricted
                            </span>
                          )}
                          {isSorted && (
                            <ArrowUpDown className="w-3 h-3 text-indigo-600 dark:text-indigo-400 shrink-0" />
                          )}
                        </div>

                        {/* Column Header Controls */}
                        <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                          {/* Collapse / Hide Column Button */}
                          <button
                            onClick={() => handleToggleColVisibility(col.id)}
                            className="p-1 rounded text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200"
                            title="Hide / Collapse Column"
                          >
                            ◀
                          </button>
                        </div>
                      </div>

                      {/* Interactive Drag Handle to Resize Column Width */}
                      <div
                        onMouseDown={e => handleResizeStart(e, col.id, colWidth)}
                        className={`absolute right-0 top-0 bottom-0 w-2 cursor-col-resize hover:bg-indigo-500/60 z-20 transition-colors ${
                          resizingColId === col.id ? 'bg-indigo-600' : ''
                        }`}
                        title="Drag border to resize column"
                      />
                    </th>
                  );
                })}

                {/* Row Actions Header */}
                <th className="p-2.5 text-right w-32 border-b border-slate-200 dark:border-zinc-800 font-bold text-slate-500">
                  Actions
                </th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-100 dark:divide-zinc-800">
              {paginatedRows.length === 0 ? (
                <tr>
                  <td
                    colSpan={visibleColumns.length + 3}
                    className="p-12 text-center text-slate-400"
                  >
                    <div className="max-w-xs mx-auto space-y-2">
                      <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-zinc-800 flex items-center justify-center mx-auto text-slate-400">
                        <Search className="w-5 h-5" />
                      </div>
                      <p className="font-semibold text-xs text-slate-600 dark:text-zinc-300">
                        No rows found matching your criteria.
                      </p>
                      {canEdit && (
                        <button
                          onClick={handleAddRow}
                          className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold"
                        >
                          Add New Row
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : groupByCol && groupedData ? (
                Object.entries(groupedData).map(([groupKey, groupRows]) => {
                  const isGroupCollapsed = Boolean(collapsedGroups[groupKey]);
                  const groupCol = tracker.columns.find(c => c.id === groupByCol);
                  const metrics = groupMetrics?.[groupKey];

                  return (
                    <React.Fragment key={groupKey}>
                      {/* Collapsible Group Header Row */}
                      <tr
                        onClick={() => handleToggleGroupCollapse(groupKey)}
                        className="bg-indigo-50/80 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/60 cursor-pointer border-t-2 border-b border-indigo-200 dark:border-indigo-800 transition-colors select-none group/header"
                      >
                        <td colSpan={visibleColumns.length + 3} className="py-2 px-3">
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div className="flex items-center gap-2">
                              <span className="p-1 rounded-md bg-white dark:bg-zinc-800 text-indigo-600 dark:text-indigo-400 shadow-2xs group-hover/header:scale-110 transition-transform">
                                {isGroupCollapsed ? (
                                  <ChevronRight className="w-3.5 h-3.5" />
                                ) : (
                                  <ChevronDown className="w-3.5 h-3.5" />
                                )}
                              </span>
                              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-zinc-400">
                                {groupCol?.name || "Group"}:
                              </span>
                              <span className="text-xs font-black text-slate-900 dark:text-zinc-100">
                                {groupKey}
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-indigo-100 dark:bg-indigo-900/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                                {groupRows.length} {groupRows.length === 1 ? "record" : "records"}
                              </span>
                              {isGroupCollapsed && (
                                <span className="text-[11px] text-slate-400 dark:text-zinc-500 italic hidden sm:inline">
                                  (Click to expand records)
                                </span>
                              )}
                            </div>

                            {/* Group Subtotals in Header */}
                            {metrics && (
                              <div className="flex flex-wrap items-center gap-2 text-xs">
                                {Object.entries(metrics.subtotals).map(([colId, subtotalVal]) => {
                                  const c = tracker.columns.find(col => col.id === colId);
                                  if (!c || subtotalVal === 0) return null;
                                  return (
                                    <span
                                      key={colId}
                                      className="flex items-center gap-1 text-[11px] bg-white/90 dark:bg-zinc-800/90 px-2 py-0.5 rounded-md border border-indigo-200/70 dark:border-indigo-800/70 shadow-2xs"
                                    >
                                      <span className="text-slate-500 dark:text-zinc-400">{c.name}:</span>
                                      <strong className="text-emerald-700 dark:text-emerald-400 font-bold">
                                        {formatCurrency(subtotalVal, c.currencySymbol || "₱")}
                                      </strong>
                                    </span>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>

                      {/* Group Records (only shown if not collapsed) */}
                      {!isGroupCollapsed &&
                        groupRows.map((row, rIdx) => renderRow(row, rIdx, rIdx + 1))}
                    </React.Fragment>
                  );
                })
              ) : (
                paginatedRows.map((row, rIdx) =>
                  renderRow(row, rIdx, (currentPage - 1) * pageSize + rIdx + 1)
                )
              )}
            </tbody>

            {/* Live Column Totals Summary Footer */}
            {showSummaryFooter && (
              <tfoot className="sticky bottom-0 z-10 bg-slate-100 dark:bg-zinc-800/95 backdrop-blur-sm border-t-2 border-indigo-500/40 text-xs font-semibold shadow-md">
                <tr className="divide-x divide-slate-200 dark:divide-zinc-700">
                  <td className="p-2.5 text-center text-slate-400">∑</td>
                  <td className="p-2.5 font-mono text-[11px] text-slate-700 dark:text-zinc-300 font-bold uppercase tracking-wider text-center">
                    Column Totals
                  </td>
                  {visibleColumns.map(col => {
                    const data = columnSubtotals[col.id];
                    if (!data) return <td key={col.id} className="p-2.5"></td>;

                    if (col.type === 'amount') {
                      return (
                        <td key={col.id} className="p-2.5 text-right font-extrabold text-slate-900 dark:text-white bg-indigo-50/40 dark:bg-indigo-950/20">
                          <div className="flex flex-col items-end">
                            <span className="text-indigo-600 dark:text-indigo-400 font-mono">
                              {formatCurrency(data.sum, col.currencySymbol || '₱')}
                            </span>
                            <span className="text-[10px] text-slate-400 font-normal">
                              Total ({data.count} items)
                            </span>
                          </div>
                        </td>
                      );
                    }

                    if (col.type === 'percent') {
                      const avg = data.count > 0 ? data.sum / data.count : 0;
                      return (
                        <td key={col.id} className="p-2.5 text-center font-bold text-amber-600 dark:text-amber-400">
                          <div className="flex flex-col items-center">
                            <span>{formatPercent(avg)}</span>
                            <span className="text-[10px] text-slate-400 font-normal">Average</span>
                          </div>
                        </td>
                      );
                    }

                    if (col.type === 'status') {
                      return (
                        <td key={col.id} className="p-2.5 text-center text-emerald-600 dark:text-emerald-400 font-bold">
                          <div className="flex flex-col items-center">
                            <span>{data.completedCount} Done</span>
                            <span className="text-[10px] text-slate-400 font-normal">
                              {processedRows.length > 0 ? `${Math.round((data.completedCount / processedRows.length) * 100)}% settled` : ''}
                            </span>
                          </div>
                        </td>
                      );
                    }

                    if (col.type === 'day-by-day') {
                      let overdueCount = 0;
                      let totalDailyLogs = 0;
                      processedRows.forEach(r => {
                        let parsed: any[] = [];
                        const val = r[col.id];
                        if (Array.isArray(val)) parsed = val;
                        else if (typeof val === 'string' && val.trim().startsWith('[')) {
                          try { parsed = JSON.parse(val); } catch {}
                        }
                        if (parsed.length === 0) parsed = generateDefaultDayByDayLog(r.col_site_id || r.id, r.col_site_name || 'Site');
                        const calc = calculateDayByDaySla(r, parsed, formatDateYMD(new Date()));
                        if (calc.isOverdue) overdueCount++;
                        totalDailyLogs += calc.totalLogsCount;
                      });
                      return (
                        <td key={col.id} className="p-2.5 text-center text-blue-600 dark:text-blue-400 font-bold">
                          <div className="flex flex-col items-center leading-tight">
                            <span className="text-[11px]">📅 {totalDailyLogs} Total Logs</span>
                            <span className="text-[10px] text-slate-500 font-normal">
                              {overdueCount > 0 ? `🚨 ${overdueCount} Overdue Sites` : '🟢 All Sites On Track'}
                            </span>
                          </div>
                        </td>
                      );
                    }

                    if (col.type === 'legal-checklist') {
                      let totalComplianceSum = 0;
                      let totalRequirementsDone = 0;
                      let totalRequirementsCount = 0;
                      processedRows.forEach(r => {
                        let parsed: any[] = [];
                        const val = r[col.id];
                        if (Array.isArray(val)) parsed = val;
                        else if (typeof val === 'string' && val.trim().startsWith('[')) {
                          try { parsed = JSON.parse(val); } catch {}
                        }
                        if (parsed.length === 0) parsed = DEFAULT_LEGAL_CHECKLIST_ITEMS;
                        totalRequirementsDone += parsed.filter((i: any) => i.status === 'Completed').length;
                        totalRequirementsCount += parsed.length;
                        totalComplianceSum += parsed.reduce((sum: number, i: any) => sum + (Number(i.amount) || 0), 0);
                      });
                      const pct = totalRequirementsCount > 0 ? Math.round((totalRequirementsDone / totalRequirementsCount) * 100) : 0;
                      return (
                        <td key={col.id} className="p-2.5 text-center text-amber-600 dark:text-amber-400 font-bold">
                          <div className="flex flex-col items-center leading-tight">
                            <span className="text-[11px]">🛡️ {totalRequirementsDone}/{totalRequirementsCount} ({pct}%)</span>
                            <span className="text-[10px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">{formatCurrency(totalComplianceSum, '₱')}</span>
                          </div>
                        </td>
                      );
                    }

                    return (
                      <td key={col.id} className="p-2.5 text-slate-400 text-center text-[10px]">
                        {processedRows.length} rows
                      </td>
                    );
                  })}
                  <td className="p-2.5 text-center text-slate-400">
                    {processedRows.length} total
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>

        {/* Excel-like Footer with Pagination & Row Count Options */}
        <div className="p-3 border-t border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-800/60 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Row View Count Selector (20, 30, 40, 50, 75, 100, 500) */}
          <div className="flex items-center gap-2">
            <span className="text-slate-500 dark:text-zinc-400 font-medium">Rows per page:</span>
            <select
              value={pageSize}
              onChange={e => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="text-xs px-2 py-1 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-zinc-200 font-semibold outline-none"
            >
              <option value={20}>20 rows</option>
              <option value={30}>30 rows</option>
              <option value={40}>40 rows</option>
              <option value={50}>50 rows</option>
              <option value={75}>75 rows</option>
              <option value={100}>100 rows</option>
              <option value={500}>500 rows</option>
            </select>

            <span className="text-slate-400">
              Showing{' '}
              <strong className="text-slate-700 dark:text-zinc-300">
                {processedRows.length === 0 ? 0 : (currentPage - 1) * pageSize + 1}
              </strong>{' '}
              to{' '}
              <strong className="text-slate-700 dark:text-zinc-300">
                {Math.min(currentPage * pageSize, processedRows.length)}
              </strong>{' '}
              of <strong className="text-slate-700 dark:text-zinc-300">{processedRows.length}</strong> rows
            </span>
          </div>

          {/* Page Navigation */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-2.5 py-1 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-100 disabled:opacity-40 text-xs font-semibold"
            >
              Previous
            </button>
            <span className="px-2 font-mono text-xs text-slate-600 dark:text-zinc-300">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="px-2.5 py-1 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-100 disabled:opacity-40 text-xs font-semibold"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Rich Errand & Highlight Formatter Modal */}
      {richEditorCell && (
        <RichTextEditorModal
          isOpen={Boolean(richEditorCell)}
          rowId={richEditorCell.rowId}
          rowNumber={richEditorCell.rowNumber}
          rowTitle={richEditorCell.rowTitle}
          columnId={richEditorCell.columnId}
          columnName={richEditorCell.columnName}
          initialValue={richEditorCell.initialValue}
          isDark={isDark}
          onClose={() => setRichEditorCell(null)}
          onSave={handleSaveRichText}
        />
      )}

      {/* Single Row Deletion Confirmation Modal (Accidental Delete Protection) */}
      {rowToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 shadow-2xl p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-rose-100 dark:bg-rose-950/60 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-rose-600 dark:text-rose-400" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-zinc-100">
                  Delete Record #{rowToDelete.rowNum}?
                </h3>
                <p className="text-xs text-slate-500 dark:text-zinc-400">
                  Protecting your project records from accidental removal
                </p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-zinc-800/60 border border-slate-200 dark:border-zinc-700 text-xs space-y-1.5">
              <div className="text-slate-500">Record to delete:</div>
              <div className="font-bold text-slate-800 dark:text-zinc-200 truncate">
                {rowToDelete.title}
              </div>
              <div className="text-[11px] text-emerald-600 dark:text-emerald-400 pt-1">
                💡 Tip: If deleted by mistake, you can immediately restore it with <kbd className="px-1.5 py-0.5 rounded bg-slate-200 dark:bg-zinc-700 font-mono text-[10px]">Ctrl+Z</kbd> or the Undo button.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setRowToDelete(null)}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold border border-slate-300 dark:border-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-800 text-slate-700 dark:text-zinc-200 transition-colors"
              >
                Cancel (Keep Row)
              </button>
              <button
                type="button"
                onClick={() => {
                  const id = rowToDelete.id;
                  setRowToDelete(null);
                  handleDeleteRow(id);
                }}
                className="px-4 py-1.5 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-xs transition-colors"
              >
                Delete Row
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
