import React from 'react';
import { Palette, Check } from 'lucide-react';
import { AppTheme } from '../types/tracker';
import { themes } from '../utils/theme';

interface ThemeModalProps {
  currentTheme: AppTheme;
  isDark: boolean;
  onClose: () => void;
  onSelectTheme: (theme: AppTheme) => void;
}

export const ThemeModal: React.FC<ThemeModalProps> = ({
  currentTheme,
  isDark,
  onClose,
  onSelectTheme
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-md rounded-2xl border shadow-xl flex flex-col overflow-hidden ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Palette className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="font-bold text-sm">Theme & Visual Palette</h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Choose a professional color theme for your workspace
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-slate-600">
            ✕
          </button>
        </div>

        <div className="p-4 space-y-2">
          {Object.values(themes).map(t => {
            const isSelected = currentTheme === t.id;
            return (
              <button
                key={t.id}
                onClick={() => {
                  onSelectTheme(t.id);
                  onClose();
                }}
                className={`w-full p-3 rounded-xl border flex items-center justify-between transition-all ${
                  isSelected
                    ? 'border-indigo-600 bg-indigo-50/50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 font-bold shadow-xs'
                    : 'border-slate-200 dark:border-zinc-800 hover:bg-slate-50 dark:hover:bg-zinc-800 text-slate-700 dark:text-zinc-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-4 h-4 rounded-full border ${
                      t.id === 'slate'
                        ? 'bg-slate-600 border-slate-800'
                        : t.id === 'navy'
                        ? 'bg-sky-600 border-sky-800'
                        : t.id === 'emerald'
                        ? 'bg-emerald-600 border-emerald-800'
                        : t.id === 'dark'
                        ? 'bg-zinc-900 border-zinc-500'
                        : t.id === 'amber'
                        ? 'bg-amber-600 border-amber-800'
                        : 'bg-purple-600 border-purple-800'
                    }`}
                  />
                  <span className="text-xs">{t.name}</span>
                </div>
                {isSelected && <Check className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
