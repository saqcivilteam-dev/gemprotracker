import React from 'react';
import {
  Users,
  CheckCircle,
  XCircle,
  Shield,
  UserCheck,
  Clock,
  Trash2,
  Mail,
  Building
} from 'lucide-react';
import { User } from '../types/tracker';

interface GuestApprovalModalProps {
  users: User[];
  isDark: boolean;
  onClose: () => void;
  onManageGuest: (userId: string, action: 'approve' | 'reject' | 'delete' | 'change-permission', permission?: 'editor' | 'viewer') => void;
}

export const GuestApprovalModal: React.FC<GuestApprovalModalProps> = ({
  users,
  isDark,
  onClose,
  onManageGuest
}) => {
  const pendingGuests = users.filter(u => u.status === 'pending');
  const approvedGuests = users.filter(u => u.role === 'guest' && u.status === 'approved');
  const rejectedGuests = users.filter(u => u.status === 'rejected');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-2xl rounded-2xl border shadow-xl flex flex-col max-h-[90vh] overflow-hidden ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm">Guest Registrations & Approvals</h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Logged in as <span className="font-semibold text-indigo-600 dark:text-indigo-400">Administrator</span>
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-slate-600">
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto space-y-5 flex-1">
          {/* Pending Approval Section */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                <Clock className="w-4 h-4" />
                <span>Pending Approvals ({pendingGuests.length})</span>
              </div>
              <span className="text-[11px] text-slate-400">
                New guests require your approval before accessing trackers
              </span>
            </div>

            {pendingGuests.length === 0 ? (
              <div className="p-4 rounded-xl border border-dashed border-slate-200 dark:border-zinc-800 text-center text-xs text-slate-400">
                No pending guest requests right now. All registered team members have been reviewed!
              </div>
            ) : (
              <div className="space-y-2">
                {pendingGuests.map(guest => (
                  <div
                    key={guest.id}
                    className="p-3.5 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/40 dark:bg-amber-950/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900 dark:text-zinc-100">
                          {guest.username}
                        </span>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-200">
                          Awaiting Approval
                        </span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-zinc-400 flex flex-wrap items-center gap-3 mt-1">
                        <span className="flex items-center gap-1">
                          <Mail className="w-3 h-3 text-slate-400" />
                          {guest.email}
                        </span>
                        {guest.department && (
                          <span className="flex items-center gap-1">
                            <Building className="w-3 h-3 text-slate-400" />
                            {guest.department}
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400">
                          Requested: {new Date(guest.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => onManageGuest(guest.id, 'approve', 'editor')}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs flex items-center gap-1"
                        title="Approve with full editing & Excel paste rights"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Approve Editor</span>
                      </button>

                      <button
                        onClick={() => onManageGuest(guest.id, 'approve', 'viewer')}
                        className="px-2.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-xs flex items-center gap-1"
                        title="Approve with read-only viewer rights"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>Approve Viewer</span>
                      </button>

                      <button
                        onClick={() => onManageGuest(guest.id, 'reject')}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40"
                        title="Decline request"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Approved Active Guests Section */}
          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-zinc-800">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-zinc-400 flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-emerald-500" />
              <span>Approved Guest Accounts ({approvedGuests.length})</span>
            </div>

            <div className="space-y-1.5">
              {approvedGuests.map(guest => (
                <div
                  key={guest.id}
                  className="p-2.5 rounded-lg border border-slate-200 dark:border-zinc-800 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="font-semibold text-slate-800 dark:text-zinc-200 flex items-center gap-2">
                      <span>{guest.username}</span>
                      <span className="text-[10px] text-slate-400">({guest.email})</span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Dept: {guest.department || 'General'}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Role toggle */}
                    <select
                      value={guest.permission || 'editor'}
                      onChange={e => onManageGuest(guest.id, 'change-permission', e.target.value as any)}
                      className="text-xs px-2 py-1 rounded border border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800 outline-none"
                    >
                      <option value="editor">Editor (Can edit rows/cols)</option>
                      <option value="viewer">Viewer (Read-only)</option>
                    </select>

                    <button
                      onClick={() => onManageGuest(guest.id, 'delete')}
                      title="Revoke and delete guest account"
                      className="p-1 text-slate-400 hover:text-red-600 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-end bg-slate-50/50 dark:bg-zinc-800/40">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
