import React, { useState, useMemo } from 'react';
import {
  Sliders,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  MoveUp,
  MoveDown,
  Palette,
  FileText,
  DollarSign,
  Percent,
  Calendar,
  Image as ImageIcon,
  Check,
  AlertCircle,
  ShieldAlert,
  ChevronDown,
  Sparkles,
  Layers,
  Settings2
} from 'lucide-react';
import { Tracker, Column, ColumnType, SaqProcessStatus } from '../types/tracker';
import { SAQ_PROCESS_STATUS_OPTIONS } from '../utils/dayByDayUtils';

interface ColumnManagerModalProps {
  tracker: Tracker;
  isDark: boolean;
  onClose: () => void;
  onUpdateColumns: (updatedCols: Column[]) => void;
}

export const ColumnManagerModal: React.FC<ColumnManagerModalProps> = ({
  tracker,
  isDark,
  onClose,
  onUpdateColumns
}) => {
  const [columns, setColumns] = useState<Column[]>(JSON.parse(JSON.stringify(tracker.columns)));
  const [deleteConfirmIdx, setDeleteConfirmIdx] = useState<number | null>(null);
  const [expandedOptionsIdx, setExpandedOptionsIdx] = useState<number | null>(null);

  // Map original column types to detect and protect against unintended type changes
  const originalTypes = useMemo(() => {
    const map: Record<string, ColumnType> = {};
    tracker.columns.forEach(c => {
      map[c.id] = c.type;
    });
    return map;
  }, [tracker.columns]);

  const changedTypeColumns = useMemo(() => {
    return columns.filter(c => originalTypes[c.id] && originalTypes[c.id] !== c.type);
  }, [columns, originalTypes]);

  // Add new column form state
  const [newColName, setNewColName] = useState('');
  const [newColType, setNewColType] = useState<ColumnType>('text');
  const [newColColor, setNewColColor] = useState<Column['color']>('slate');
  const [newColCurrency, setNewColCurrency] = useState('₱');
  const [newColOptionsText, setNewColOptionsText] = useState('Site Hunting, Pro Docs, Pre-Con, Post-Con, FAC, Billing');

  const handleAddColumn = () => {
    if (!newColName.trim()) return;

    let parsedOptions: string[] | undefined = undefined;
    if (newColType === 'status') {
      parsedOptions = newColOptionsText
        .split(',')
        .map(s => s.trim())
        .filter(Boolean);
      if (parsedOptions.length === 0) {
        parsedOptions = [...SAQ_PROCESS_STATUS_OPTIONS];
      }
    }

    const newCol: Column = {
      id: 'col-' + Date.now(),
      name: newColName.trim(),
      type: newColType,
      width:
        newColType === 'day-by-day'
          ? 250
          : newColType === 'legal-checklist'
          ? 230
          : newColType === 'jpeg' || newColType === 'pdf'
          ? 160
          : 180,
      visible: true,
      color: newColColor,
      currencySymbol: newColType === 'amount' ? newColCurrency : undefined,
      options: parsedOptions
    };

    setColumns([...columns, newCol]);
    setNewColName('');
  };

  const handleApplyPreset = (
    name: string,
    type: ColumnType,
    color: Column['color'],
    options?: string[]
  ) => {
    setNewColName(name);
    setNewColType(type);
    setNewColColor(color);
    if (options) {
      setNewColOptionsText(options.join(', '));
    }
  };

  const handleMove = (index: number, direction: 'up' | 'down') => {
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= columns.length) return;
    const cloned = [...columns];
    const temp = cloned[index];
    cloned[index] = cloned[targetIdx];
    cloned[targetIdx] = temp;
    setColumns(cloned);
  };

  const handleToggleVisible = (index: number) => {
    const cloned = [...columns];
    cloned[index].visible = !cloned[index].visible;
    setColumns(cloned);
  };

  const handleDeleteColumn = (index: number) => {
    if (columns.length <= 1) {
      return;
    }
    setColumns(columns.filter((_, idx) => idx !== index));
    setDeleteConfirmIdx(null);
    if (expandedOptionsIdx === index) {
      setExpandedOptionsIdx(null);
    }
  };

  const handleSave = () => {
    onUpdateColumns(columns);
    onClose();
  };

  const getTypeIcon = (type: ColumnType) => {
    switch (type) {
      case 'amount':
        return <span className="font-bold text-emerald-600 text-xs">₱</span>;
      case 'percent':
        return <Percent className="w-3.5 h-3.5 text-amber-500" />;
      case 'date':
        return <Calendar className="w-3.5 h-3.5 text-rose-500" />;
      case 'status':
        return <Layers className="w-3.5 h-3.5 text-indigo-500" />;
      case 'jpeg':
        return <ImageIcon className="w-3.5 h-3.5 text-cyan-500" />;
      case 'pdf':
        return <FileText className="w-3.5 h-3.5 text-purple-500" />;
      case 'legal-checklist':
        return <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />;
      case 'day-by-day':
        return <Calendar className="w-3.5 h-3.5 text-blue-500" />;
      default:
        return <FileText className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs">
      <div
        className={`w-full max-w-4xl rounded-2xl border shadow-2xl flex flex-col max-h-[92vh] overflow-hidden ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className="p-4 sm:px-6 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between bg-slate-50/70 dark:bg-zinc-900/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-600 dark:text-indigo-400 shrink-0">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-zinc-100 flex items-center gap-2">
                <span>Customize Columns &amp; Appearance</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  Interactive Studio
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Add, edit, reorder, and delete columns. Configure Text, Date, Status dropdown bar (Site Hunting → Billing), Amount (₱), Legal Checked List, and Clickable Day-by-Day Updates.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1 custom-scrollbar">
          {/* Quick Presets Bar */}
          <div className="p-3.5 rounded-xl border border-indigo-200/70 dark:border-indigo-900/40 bg-indigo-50/50 dark:bg-indigo-950/20 space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <span className="text-[11px] font-bold text-indigo-900 dark:text-indigo-200 flex items-center gap-1.5 uppercase tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                <span>Quick Add Presets (One-Click Setup):</span>
              </span>
              <span className="text-[10px] text-indigo-700 dark:text-indigo-300 font-medium">
                Click any preset to prefill the Add Column form
              </span>
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              {/* Preset 1: Day-by-Day Update */}
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Day-by-Day Progress & SLA Updates',
                    'day-by-day',
                    'blue'
                  )
                }
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-500/15 hover:bg-blue-500/25 text-blue-700 dark:text-blue-300 border border-blue-500/40 text-xs font-bold transition-all shadow-2xs hover:scale-101"
                title="Clickable per-site Day-by-Day update log that drives the central SAQ SLA Engine"
              >
                <Calendar className="w-3.5 h-3.5 text-blue-500" />
                <span>+ Day-by-Day Update</span>
              </button>

              {/* Preset 2: Status Dropdown Bar */}
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'SAQ Workflow Status',
                    'status',
                    'purple',
                    [...SAQ_PROCESS_STATUS_OPTIONS]
                  )
                }
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 text-purple-700 dark:text-purple-300 border border-purple-500/40 text-xs font-bold transition-all shadow-2xs hover:scale-101"
                title="Dropdown status bar: Site Hunting, Pro Docs, Pre-Con, Post-Con, FAC, Billing"
              >
                <Layers className="w-3.5 h-3.5 text-purple-500" />
                <span>+ Status (Site Hunting → Billing)</span>
              </button>

              {/* Preset 3: Date of Site Survey */}
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Date of Site Survey',
                    'date',
                    'blue'
                  )
                }
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-700 dark:text-rose-300 border border-rose-500/40 text-xs font-bold transition-all shadow-2xs hover:scale-101"
                title="Date column for actual date when site survey / hunting begins (official SLA start date)"
              >
                <Calendar className="w-3.5 h-3.5 text-rose-500" />
                <span>+ Date (Site Survey / Hunting Start)</span>
              </button>

              {/* Preset 4: Details / Remarks */}
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Details & Remarks',
                    'text',
                    'slate'
                  )
                }
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-500/15 hover:bg-slate-500/25 text-slate-700 dark:text-slate-300 border border-slate-500/40 text-xs font-bold transition-all shadow-2xs hover:scale-101"
                title="Text column for site remarks, obstacles, or stakeholder feedback"
              >
                <FileText className="w-3.5 h-3.5 text-slate-500" />
                <span>+ Details / Remarks</span>
              </button>

              {/* Preset 5: Capex Amount */}
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Capex Budget (₱)',
                    'amount',
                    'emerald'
                  )
                }
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-all shadow-2xs hover:scale-101"
                title="Currency amount column for capex allocation or disbursement fees"
              >
                <span className="font-bold text-emerald-600 text-xs">₱</span>
                <span>+ Capex Amount (₱)</span>
              </button>

              {/* Preset 6: Legal Checked List */}
              <button
                type="button"
                onClick={() =>
                  handleApplyPreset(
                    'Legal Fees & Compliance Checklist',
                    'legal-checklist',
                    'amber'
                  )
                }
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 text-amber-700 dark:text-amber-300 border border-amber-500/40 text-xs font-bold transition-all shadow-2xs hover:scale-101"
                title="Per-site clickable checklist with attached reference pictures and proof documents"
              >
                <ShieldAlert className="w-3.5 h-3.5 text-amber-500" />
                <span>+ Legal Checked List</span>
              </button>
            </div>
          </div>

          {/* Add Column Box */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-extrabold text-slate-800 dark:text-zinc-100 flex items-center gap-1.5 uppercase tracking-wide">
                <Plus className="w-4 h-4 text-indigo-500" />
                <span>Add Column</span>
              </div>
              <span className="text-[11px] text-slate-500">
                Columns can be reordered, edited, or deleted anytime
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
              <div className="sm:col-span-5">
                <input
                  type="text"
                  placeholder="Column Name (e.g. Day-by-Day Updates, Site Survey Date)"
                  value={newColName}
                  onChange={e => setNewColName(e.target.value)}
                  className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none focus:border-indigo-500"
                />
              </div>

              <div className="sm:col-span-4">
                <select
                  value={newColType}
                  onChange={e => {
                    const selected = e.target.value as ColumnType;
                    setNewColType(selected);
                    if (selected === 'day-by-day' && !newColName.trim()) {
                      setNewColName('Day-by-Day Progress & SLA Updates');
                      setNewColColor('blue');
                    } else if (selected === 'legal-checklist' && !newColName.trim()) {
                      setNewColName('Legal Fees & Compliance Checklist');
                      setNewColColor('amber');
                    } else if (selected === 'status' && !newColName.trim()) {
                      setNewColName('SAQ Workflow Status');
                      setNewColColor('purple');
                    } else if (selected === 'date' && !newColName.trim()) {
                      setNewColName('Date of Site Survey');
                      setNewColColor('blue');
                    }
                  }}
                  className="w-full text-xs font-semibold px-2.5 py-2 rounded-lg border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none focus:border-indigo-500"
                >
                  <option value="text">Text (General Info / Details / Remarks)</option>
                  <option value="date">Date (Site Survey / Milestone Date)</option>
                  <option value="status">Status (Drop Down Status Bar: Site Hunting → Billing)</option>
                  <option value="day-by-day">Day-by-Day Update (📅 Clickable Progress Log &amp; SAQ SLA)</option>
                  <option value="amount">Amount (₱ Capex / Budget / Cost)</option>
                  <option value="percent">Percent (0 - 100% Milestone Progress)</option>
                  <option value="legal-checklist">Legal Checked List (🛡️ Per-Site Clickable Checklist)</option>
                  <option value="jpeg">JPEG (Attached Photo / Image)</option>
                  <option value="pdf">PDF (Attached Document)</option>
                </select>
              </div>

              <div className="sm:col-span-3 flex gap-1.5">
                <select
                  value={newColColor}
                  onChange={e => setNewColColor(e.target.value as any)}
                  className="w-full text-xs px-2.5 py-2 rounded-lg border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none"
                >
                  <option value="blue">Blue</option>
                  <option value="indigo">Indigo</option>
                  <option value="purple">Purple</option>
                  <option value="emerald">Emerald</option>
                  <option value="amber">Amber</option>
                  <option value="rose">Rose</option>
                  <option value="cyan">Cyan</option>
                  <option value="slate">Slate</option>
                </select>

                <button
                  type="button"
                  onClick={handleAddColumn}
                  disabled={!newColName.trim()}
                  className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shrink-0 disabled:opacity-40 shadow-xs flex items-center gap-1"
                  title="Add column to tracker"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add</span>
                </button>
              </div>
            </div>

            {/* Status Options Editor if Status is chosen */}
            {newColType === 'status' && (
              <div className="p-3 rounded-lg bg-purple-500/10 border border-purple-500/30 text-xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-purple-800 dark:text-purple-300">
                    Dropdown Status Bar Choices (comma-separated):
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setNewColOptionsText('Site Hunting, Pro Docs, Pre-Con, Post-Con, FAC, Billing')
                    }
                    className="text-[10px] font-bold text-purple-600 dark:text-purple-400 underline hover:opacity-80"
                  >
                    Reset to Standard SAQ 6-Stages
                  </button>
                </div>
                <input
                  type="text"
                  value={newColOptionsText}
                  onChange={e => setNewColOptionsText(e.target.value)}
                  placeholder="Site Hunting, Pro Docs, Pre-Con, Post-Con, FAC, Billing"
                  className="w-full text-xs p-2 rounded border border-purple-300 dark:border-purple-700 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none"
                />
              </div>
            )}

            {/* Currency Choice if Amount is chosen */}
            {newColType === 'amount' && (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500 font-medium">Currency Symbol:</span>
                <select
                  value={newColCurrency}
                  onChange={e => setNewColCurrency(e.target.value)}
                  className="text-xs p-1.5 rounded border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900"
                >
                  <option value="₱">₱ (Philippine Peso)</option>
                  <option value="$">$ (US Dollar)</option>
                  <option value="€">€ (Euro)</option>
                  <option value="£">£ (British Pound)</option>
                </select>
              </div>
            )}

            {/* Explanatory callout for Day-by-Day Update */}
            {newColType === 'day-by-day' && (
              <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-800 dark:text-blue-200 text-xs flex items-start gap-2.5 animate-in fade-in duration-150">
                <Calendar className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="font-bold">
                    Per-Site Clickable Day-by-Day Update &amp; SAQ SLA Center:
                  </div>
                  <div className="text-[11px] leading-relaxed text-blue-700 dark:text-blue-300">
                    Records daily ongoing progress, date of site survey (encoded automatically or in real-time), status drop down bar (<strong>Site Hunting, Pro Docs, Pre-Con, Post-Con, FAC, Billing</strong>), day-by-day progress/updates, details/remarks, and SLA tracking rules. Official SLA begins strictly when <strong>Site Hunting</strong> starts, driving the centralized SAQ SLA &amp; Early Warning Center without redundant triggers elsewhere.
                  </div>
                </div>
              </div>
            )}

            {/* Explanatory callout for Legal Checked List */}
            {newColType === 'legal-checklist' && (
              <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-800 dark:text-amber-200 text-xs flex items-start gap-2.5 animate-in fade-in duration-150">
                <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="font-bold">Per-Site Clickable Legal Checked List:</div>
                  <div className="text-[11px] leading-relaxed text-amber-700 dark:text-amber-300">
                    Creates an interactive button on each site row. When clicked, it opens the site's complete Legal &amp; Permitting Checklist with milestones, fee disbursement tracking, and <strong>attached reference pictures &amp; proof documents</strong> (with full lightbox viewer &amp; uploads).
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Accidental Type Change Alert */}
          {changedTypeColumns.length > 0 && (
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-300 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5 shadow-2xs">
              <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="font-bold">Column Data Type Modified:</div>
                <div className="text-[11px] leading-relaxed">
                  You are changing the type of{' '}
                  <strong>
                    {changedTypeColumns
                      .map(c => `"${c.name}" (${originalTypes[c.id]} → ${c.type})`)
                      .join(', ')}
                  </strong>
                  . Existing row data in this column will be adapted to the new format upon saving.
                </div>
              </div>
            </div>
          )}

          {/* Existing Columns List */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="text-xs font-bold text-slate-700 dark:text-zinc-300 uppercase tracking-wide flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-indigo-500" />
                <span>Existing Columns ({columns.length})</span>
              </div>
              <div className="text-[11px] text-slate-500 dark:text-zinc-400">
                Edit column names, types, order, or delete as wanted
              </div>
            </div>

            <div className="space-y-1.5">
              {columns.map((col, idx) => (
                <div
                  key={col.id}
                  className={`p-2.5 rounded-xl border transition-all ${
                    col.visible
                      ? isDark
                        ? 'bg-zinc-800/90 border-zinc-700'
                        : 'bg-white border-slate-200 shadow-2xs'
                      : 'bg-slate-100 dark:bg-zinc-800/40 border-dashed border-slate-300 dark:border-zinc-700 opacity-70'
                  }`}
                >
                  <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                    {/* Visibility Toggle */}
                    <button
                      onClick={() => handleToggleVisible(idx)}
                      title={col.visible ? 'Hide / Collapse Column' : 'Show Column'}
                      className="p-1 rounded text-slate-400 hover:text-indigo-600 shrink-0"
                    >
                      {col.visible ? (
                        <Eye className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <EyeOff className="w-4 h-4 text-slate-400" />
                      )}
                    </button>

                    {/* Column Name Input - Directly Editable */}
                    <input
                      type="text"
                      value={col.name}
                      onChange={e => {
                        const cloned = [...columns];
                        cloned[idx].name = e.target.value;
                        setColumns(cloned);
                      }}
                      className="flex-1 min-w-[130px] text-xs font-bold px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none focus:border-indigo-500 shadow-2xs"
                      title="Edit column header name"
                    />

                    {/* Type Selector - Directly Editable */}
                    <div className="flex items-center gap-1 shrink-0">
                      {getTypeIcon(col.type)}
                      <select
                        value={col.type}
                        onChange={e => {
                          const cloned = [...columns];
                          const selectedType = e.target.value as ColumnType;
                          cloned[idx].type = selectedType;
                          if (selectedType === 'status' && !cloned[idx].options) {
                            cloned[idx].options = [...SAQ_PROCESS_STATUS_OPTIONS];
                          }
                          setColumns(cloned);
                        }}
                        className="text-xs font-medium px-2 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none"
                        title="Change column type"
                      >
                        <option value="text">Text</option>
                        <option value="date">Date</option>
                        <option value="status">Status Dropdown</option>
                        <option value="day-by-day">Day-by-Day Update (📅 Per-Site)</option>
                        <option value="amount">Amount (₱)</option>
                        <option value="percent">Percent (%)</option>
                        <option value="legal-checklist">Legal Checked List (🛡️ Per-Site)</option>
                        <option value="jpeg">JPEG Image</option>
                        <option value="pdf">PDF Document</option>
                      </select>
                    </div>

                    {/* Header Color - Directly Editable */}
                    <select
                      value={col.color || 'slate'}
                      onChange={e => {
                        const cloned = [...columns];
                        cloned[idx].color = e.target.value as any;
                        setColumns(cloned);
                      }}
                      className="text-xs px-2 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none shrink-0"
                      title="Column accent color"
                    >
                      <option value="slate">Slate</option>
                      <option value="blue">Blue</option>
                      <option value="indigo">Indigo</option>
                      <option value="purple">Purple</option>
                      <option value="emerald">Emerald</option>
                      <option value="amber">Amber</option>
                      <option value="rose">Rose</option>
                      <option value="cyan">Cyan</option>
                    </select>

                    {/* Options Drawer Toggle for Status columns */}
                    {col.type === 'status' && (
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedOptionsIdx(expandedOptionsIdx === idx ? null : idx)
                        }
                        className="px-2 py-1 rounded bg-purple-500/15 text-purple-700 dark:text-purple-300 border border-purple-500/30 text-[10px] font-bold flex items-center gap-1 shrink-0"
                        title="Configure status dropdown options"
                      >
                        <Settings2 className="w-3 h-3" />
                        <span>Options ({(col.options || []).length})</span>
                      </button>
                    )}

                    {/* Currency Symbol for Amount columns */}
                    {col.type === 'amount' && (
                      <input
                        type="text"
                        value={col.currencySymbol || '₱'}
                        onChange={e => {
                          const cloned = [...columns];
                          cloned[idx].currencySymbol = e.target.value;
                          setColumns(cloned);
                        }}
                        className="w-8 text-center text-xs font-bold p-1 rounded border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 shrink-0"
                        title="Currency symbol"
                      />
                    )}

                    {/* Order buttons */}
                    <div className="flex items-center gap-0.5 shrink-0">
                      <button
                        onClick={() => handleMove(idx, 'up')}
                        disabled={idx === 0}
                        className="p-1 rounded text-slate-400 hover:text-slate-600 disabled:opacity-20"
                        title="Move column up"
                      >
                        <MoveUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleMove(idx, 'down')}
                        disabled={idx === columns.length - 1}
                        className="p-1 rounded text-slate-400 hover:text-slate-600 disabled:opacity-20"
                        title="Move column down"
                      >
                        <MoveDown className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Delete button with immediate inline confirm */}
                    {deleteConfirmIdx === idx ? (
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          onClick={() => handleDeleteColumn(idx)}
                          className="px-2 py-1 rounded bg-red-600 hover:bg-red-700 text-white text-[11px] font-bold"
                          title="Confirm deletion"
                        >
                          Confirm
                        </button>
                        <button
                          onClick={() => setDeleteConfirmIdx(null)}
                          className="px-1.5 py-1 rounded bg-slate-200 dark:bg-zinc-700 text-slate-700 dark:text-zinc-200 text-[11px]"
                        >
                          ✕
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setDeleteConfirmIdx(idx)}
                        disabled={columns.length <= 1}
                        className="p-1 rounded text-slate-400 hover:text-red-600 disabled:opacity-20 shrink-0"
                        title="Delete column"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  {/* Status Options Drawer */}
                  {col.type === 'status' && expandedOptionsIdx === idx && (
                    <div className="mt-2.5 p-2.5 rounded-lg bg-purple-500/10 border border-purple-500/25 text-xs space-y-1.5 animate-in fade-in duration-100">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-purple-900 dark:text-purple-200 text-[11px]">
                          Edit Status Dropdown Choices (comma-separated):
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            const cloned = [...columns];
                            cloned[idx].options = [...SAQ_PROCESS_STATUS_OPTIONS];
                            setColumns(cloned);
                          }}
                          className="text-[10px] font-bold text-purple-700 dark:text-purple-300 underline"
                        >
                          Apply SAQ Preset: Site Hunting → Billing
                        </button>
                      </div>
                      <input
                        type="text"
                        value={(col.options || []).join(', ')}
                        onChange={e => {
                          const cloned = [...columns];
                          cloned[idx].options = e.target.value
                            .split(',')
                            .map(s => s.trim())
                            .filter(Boolean);
                          setColumns(cloned);
                        }}
                        className="w-full text-xs p-1.5 rounded border border-purple-300 dark:border-purple-700 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:px-6 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-between gap-3 bg-slate-50/70 dark:bg-zinc-900/80">
          <div className="text-[11px] text-slate-500 dark:text-zinc-400 hidden sm:block">
            Tip: Day-by-Day Update columns allow users to record daily ongoing progress per site and power the Early Warning Center.
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg text-slate-600 dark:text-zinc-300 hover:bg-slate-200 dark:hover:bg-zinc-700 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs transition-colors"
            >
              <Check className="w-4 h-4" />
              <span>Apply Changes</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
