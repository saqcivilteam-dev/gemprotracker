import React, { useState, useMemo } from 'react';
import {
  Bell,
  AlertTriangle,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Search,
  Filter,
  Download,
  Printer,
  ChevronRight,
  ChevronDown,
  Layers,
  ArrowRight,
  X,
  FileText,
  Building2,
  User,
  ShieldAlert,
  RotateCcw,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { AppState, Tracker, Row } from '../types/tracker';
import {
  evaluateAllSitesSaq,
  evaluateSiteSaq,
  SiteSaqReport,
  SAQ_STAGES,
  formatDateYMD
} from '../utils/saqSlaEngine';

interface SaqWarningReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onOpenDayByDay?: (siteRow: Row) => void;
  onUpdateSiteMovement?: (siteId: string, movementNote?: string) => void;
  onNotify: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const SaqWarningReportModal: React.FC<SaqWarningReportModalProps> = ({
  isOpen,
  onClose,
  state,
  onOpenDayByDay,
  onUpdateSiteMovement,
  onNotify
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'critical' | 'week_warning' | 'stalled' | 'timeline'>('all');
  const [selectedSiteId, setSelectedSiteId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedTrackerId, setSelectedTrackerId] = useState<string>(state.activeTrackerId);
  const [movementNote, setMovementNote] = useState<string>('');

  const currentTracker = state.trackers.find(t => t.id === selectedTrackerId) || state.trackers[0];

  // Evaluate SLA health across all rows in the active tracker strictly based on Day-by-Day data
  const evaluation = useMemo(() => {
    return evaluateAllSitesSaq(currentTracker.rows, formatDateYMD(new Date()));
  }, [currentTracker.rows]);

  // Selected site detailed report
  const selectedSiteReport = useMemo(() => {
    if (!selectedSiteId) {
      return evaluation.reports[0] || null;
    }
    return evaluation.reports.find(r => r.siteId === selectedSiteId) || evaluation.reports[0] || null;
  }, [evaluation.reports, selectedSiteId]);

  // Filtered reports based on active tab and search
  const filteredReports = useMemo(() => {
    return evaluation.reports.filter(report => {
      // Tab filter
      if (activeTab === 'critical' && report.overallStatus !== 'overdue') return false;
      if (activeTab === 'week_warning' && !report.warnings.some(w => w.severity === 'warning')) return false;
      if (activeTab === 'stalled' && !report.isStalled) return false;

      // Text search
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const match =
          report.siteId.toLowerCase().includes(q) ||
          report.siteName.toLowerCase().includes(q) ||
          (report.location && report.location.toLowerCase().includes(q)) ||
          (report.siteOwner && report.siteOwner.toLowerCase().includes(q)) ||
          report.currentStageName.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [evaluation.reports, activeTab, searchTerm]);

  // Quick Action: Record daily movement to un-stall a site
  const handleLogMovement = (siteId: string) => {
    if (onUpdateSiteMovement) {
      onUpdateSiteMovement(siteId, movementNote.trim() || 'Daily site progress check logged');
    }
    onNotify(`Daily movement recorded for site ${siteId}. Activity timestamp refreshed!`, 'success');
    setMovementNote('');
  };

  // Export Day-by-Day Report to CSV
  const handleExportCSV = () => {
    const headers = [
      'Site ID',
      'Site Name',
      'Region',
      'TowerCo/Owner',
      'Site Hunting Date',
      'Days Elapsed',
      'Last Movement Date',
      'Days Inactive',
      'Stalled (>14d)?',
      'Current SAQ Stage',
      'Overall SLA Status',
      'Property Docs Target (21d)',
      'Pre-Con Permit Target (44d)',
      'Post-Con Permit Target (21d)',
      'FAC Submission Target (7d)',
      'Active Warning Messages'
    ];

    const rows = evaluation.reports.map(r => [
      `"${r.siteId}"`,
      `"${r.siteName.replace(/"/g, '""')}"`,
      `"${(r.location || '').replace(/"/g, '""')}"`,
      `"${(r.siteOwner || '').replace(/"/g, '""')}"`,
      `"${r.huntingDate}"`,
      r.daysSinceHunting,
      `"${r.lastMovementDate}"`,
      r.daysSinceLastMovement,
      r.isStalled ? 'YES (STALLED)' : 'NO',
      `"${r.currentStageName}"`,
      `"${r.overallStatus.toUpperCase()}"`,
      `"${r.milestones[0]?.targetDate || ''}"`,
      `"${r.milestones[1]?.targetDate || ''}"`,
      `"${r.milestones[2]?.targetDate || ''}"`,
      `"${r.milestones[3]?.targetDate || ''}"`,
      `"${r.warnings.map(w => w.message).join('; ').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SAQ_Process_Daily_SLA_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onNotify('Exported Day-by-Day SAQ Report to CSV!', 'success');
  };

  // Print Report Handler
  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-6xl bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-800 flex flex-col max-h-[92vh] overflow-hidden printable-area">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between bg-slate-50/70 dark:bg-zinc-900/70 no-print">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 flex items-center justify-center shadow-2xs">
              <Bell className="w-5 h-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-zinc-100">
                  SAQ Process SLA Warning Center & Day-by-Day Report
                </h3>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
                  {evaluation.totalWarnings} Active Alerts
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Timeline SLAs: 21d Property Documents • 44d Pre-Con Permit • 21d Post-Con Permit • 7d FAC Submission • 1-Week Warnings • 14d Stalled Alerts
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 text-xs font-semibold text-slate-700 dark:text-zinc-200 flex items-center gap-1.5 shadow-2xs"
              title="Download CSV Report"
            >
              <Download className="w-3.5 h-3.5 text-blue-600" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 hover:bg-slate-50 text-xs font-semibold text-slate-700 dark:text-zinc-200 flex items-center gap-1.5 shadow-2xs"
              title="Print Daily Movement Report"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>Print</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* SLA KPI Cards Banner */}
        <div className="p-4 border-b border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
          <div
            onClick={() => setActiveTab('critical')}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              activeTab === 'critical'
                ? 'bg-red-50 dark:bg-red-950/60 border-red-400 text-red-900 dark:text-red-200 shadow-2xs font-semibold'
                : 'border-slate-200 dark:border-zinc-800 hover:bg-red-50/40 text-slate-700 dark:text-zinc-300'
            }`}
          >
            <div className="text-[10px] uppercase font-bold text-red-600 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>Overdue Milestones</span>
            </div>
            <div className="text-xl font-black text-red-600 mt-1">
              {evaluation.overdueSites.length}
            </div>
            <div className="text-[10px] text-slate-500">Exceeded SLA Target</div>
          </div>

          <div
            onClick={() => setActiveTab('week_warning')}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              activeTab === 'week_warning'
                ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-400 text-amber-900 dark:text-amber-200 shadow-2xs font-semibold'
                : 'border-slate-200 dark:border-zinc-800 hover:bg-amber-50/40 text-slate-700 dark:text-zinc-300'
            }`}
          >
            <div className="text-[10px] uppercase font-bold text-amber-600 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              <span>Due in &lt; 7 Days</span>
            </div>
            <div className="text-xl font-black text-amber-600 mt-1">
              {evaluation.approachingWeekSites.length}
            </div>
            <div className="text-[10px] text-slate-500">1-Week Early Warnings</div>
          </div>

          <div
            onClick={() => setActiveTab('stalled')}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              activeTab === 'stalled'
                ? 'bg-purple-50 dark:bg-purple-950/60 border-purple-400 text-purple-900 dark:text-purple-200 shadow-2xs font-semibold'
                : 'border-slate-200 dark:border-zinc-800 hover:bg-purple-50/40 text-slate-700 dark:text-zinc-300'
            }`}
          >
            <div className="text-[10px] uppercase font-bold text-purple-600 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>No Movement &gt;14d</span>
            </div>
            <div className="text-xl font-black text-purple-600 mt-1">
              {evaluation.stalledSites.length}
            </div>
            <div className="text-[10px] text-slate-500">2-Week Stagnant Sites</div>
          </div>

          <div
            onClick={() => setActiveTab('all')}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              activeTab === 'all'
                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-400 text-indigo-900 dark:text-indigo-200 shadow-2xs font-semibold'
                : 'border-slate-200 dark:border-zinc-800 hover:bg-indigo-50/40 text-slate-700 dark:text-zinc-300'
            }`}
          >
            <div className="text-[10px] uppercase font-bold text-indigo-600 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5" />
              <span>Total Sites Evaluated</span>
            </div>
            <div className="text-xl font-black text-indigo-600 mt-1">
              {evaluation.totalSites}
            </div>
            <div className="text-[10px] text-slate-500">{currentTracker.name}</div>
          </div>

          <div
            onClick={() => setActiveTab('timeline')}
            className={`p-3 rounded-xl border cursor-pointer transition-all ${
              activeTab === 'timeline'
                ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-400 text-emerald-900 dark:text-emerald-200 shadow-2xs font-semibold'
                : 'border-slate-200 dark:border-zinc-800 hover:bg-emerald-50/40 text-slate-700 dark:text-zinc-300'
            }`}
          >
            <div className="text-[10px] uppercase font-bold text-emerald-600 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>On-Track / Completed</span>
            </div>
            <div className="text-xl font-black text-emerald-600 mt-1">
              {evaluation.onTrackSites.length + evaluation.completedSites.length}
            </div>
            <div className="text-[10px] text-slate-500">Within Target SLA</div>
          </div>
        </div>

        {/* Tracker Source & Search Toolbar */}
        <div className="p-3 border-b border-slate-200 dark:border-zinc-800 bg-slate-50/60 dark:bg-zinc-900/60 flex flex-wrap items-center justify-between gap-3 no-print">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600 dark:text-zinc-400">Data Source:</span>
            <select
              value={selectedTrackerId}
              onChange={e => {
                setSelectedTrackerId(e.target.value);
                setSelectedSiteId(null);
              }}
              className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-zinc-200 font-medium outline-none"
            >
              {state.trackers.map(t => (
                <option key={t.id} value={t.id}>
                  {t.name} ({t.rows.length} sites)
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search site, owner, region, stage..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="w-full text-xs pl-8 pr-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-zinc-200 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Content Body: Split View with Sites List & Day-by-Day Report Detail */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          {/* Left Panel: Site Records & Alert Badges */}
          <div className="lg:col-span-5 border-r border-slate-200 dark:border-zinc-800 overflow-y-auto max-h-[58vh] divide-y divide-slate-100 dark:divide-zinc-800">
            {filteredReports.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 space-y-2">
                <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 opacity-60" />
                <p>No site warnings matching this filter criteria.</p>
              </div>
            ) : (
              filteredReports.map(report => {
                const isSelected = selectedSiteReport?.siteId === report.siteId;
                const hasCritical = report.warnings.some(w => w.severity === 'critical');
                const hasWeekWarning = report.warnings.some(w => w.severity === 'warning');

                return (
                  <div
                    key={report.siteId}
                    onClick={() => setSelectedSiteId(report.siteId)}
                    className={`p-3 cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-indigo-50 dark:bg-indigo-950/40 border-l-4 border-indigo-600'
                        : 'hover:bg-slate-50 dark:hover:bg-zinc-800/40'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-900 dark:text-zinc-100">
                            {report.siteId}
                          </span>
                          {hasCritical && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-red-100 text-red-800 border border-red-300">
                              OVERDUE
                            </span>
                          )}
                          {hasWeekWarning && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-amber-100 text-amber-800 border border-amber-300">
                              &lt; 7 DAYS
                            </span>
                          )}
                          {report.isStalled && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-purple-100 text-purple-800 border border-purple-300">
                              STALLED ({report.daysSinceLastMovement}d)
                            </span>
                          )}
                        </div>
                        <div className="text-xs font-semibold text-slate-700 dark:text-zinc-300 truncate mt-0.5">
                          {report.siteName}
                        </div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                          <span>{report.location || 'Region'}</span>
                          <span>•</span>
                          <span>{report.currentStageName}</span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-[11px] font-bold text-slate-600 dark:text-zinc-300">
                          Day {report.daysSinceHunting}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Last update: {report.daysSinceLastMovement}d ago
                        </div>
                      </div>
                    </div>

                    {/* Warning teaser */}
                    {report.warnings.length > 0 && (
                      <div className="mt-2 text-[11px] text-slate-600 dark:text-zinc-400 bg-white dark:bg-zinc-800/60 p-2 rounded-lg border border-slate-200 dark:border-zinc-700 flex items-start gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{report.warnings[0].message}</span>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Right Panel: Day-by-Day Timeline Report for Selected Site */}
          <div className="lg:col-span-7 p-5 overflow-y-auto max-h-[58vh] bg-white dark:bg-zinc-900 space-y-5">
            {selectedSiteReport ? (
              <>
                {/* Site Header Card */}
                <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-800/40 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5">
                        <Building2 className="w-4 h-4" />
                        <span>SITE PROFILE • {selectedSiteReport.siteId}</span>
                      </div>
                      <h4 className="text-base font-bold text-slate-900 dark:text-zinc-100">
                        {selectedSiteReport.siteName}
                      </h4>
                      <p className="text-xs text-slate-500">
                        {selectedSiteReport.location} • TowerCo: {selectedSiteReport.siteOwner} • Assigned: {selectedSiteReport.assignedTeam}
                      </p>
                    </div>

                    <div className="text-right">
                      <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                        Current Day In SAQ
                      </div>
                      <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400">
                        Day {selectedSiteReport.daysSinceHunting}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Hunting Started: {selectedSiteReport.huntingDate}
                      </div>
                    </div>
                  </div>

                  {/* Log Daily Movement Action */}
                  <div className="pt-2 border-t border-slate-200 dark:border-zinc-700/60 flex items-center gap-2 no-print">
                    <input
                      type="text"
                      placeholder="Add movement note (e.g. Pre-Con permit submitted to LGU)..."
                      value={movementNote}
                      onChange={e => setMovementNote(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleLogMovement(selectedSiteReport.siteId)}
                      className="flex-1 text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-zinc-200 outline-none"
                    />
                    <button
                      onClick={() => handleLogMovement(selectedSiteReport.siteId)}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 shrink-0"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Log Movement</span>
                    </button>
                    {onOpenDayByDay && (
                      <button
                        type="button"
                        onClick={() => {
                          const targetRow = currentTracker.rows.find(
                            r => r.col_site_id === selectedSiteReport.siteId || r.id === selectedSiteReport.siteId
                          );
                          if (targetRow) {
                            onClose();
                            onOpenDayByDay(targetRow);
                          }
                        }}
                        className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shrink-0 shadow-2xs"
                        title="Open per-site clickable Day-by-Day progress & SLA tracker"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>Day-by-Day Tracker</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* SAQ 4-Stage Process SLA Cards */}
                <div className="space-y-2">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-zinc-400 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Process Targets & SLA Status</span>
                  </h5>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                    {selectedSiteReport.milestones.map((m, idx) => {
                      const isDone = m.status === 'completed';
                      const isOver = m.isOverdue;
                      const isApproaching = m.isApproachingWeek;

                      return (
                        <div
                          key={m.stageId}
                          className={`p-3 rounded-xl border space-y-1.5 ${
                            isDone
                              ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                              : isOver
                              ? 'bg-red-50/60 dark:bg-red-950/30 border-red-300 dark:border-red-800'
                              : isApproaching
                              ? 'bg-amber-50/60 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800'
                              : 'bg-white dark:bg-zinc-800/40 border-slate-200 dark:border-zinc-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-800 dark:text-zinc-200">
                              {idx + 1}. {m.stageName}
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white dark:bg-zinc-800 border">
                              SLA: {m.slaDays} Days
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-[11px] text-slate-500">
                            <span>Target Date:</span>
                            <span className="font-semibold text-slate-700 dark:text-zinc-300">{m.targetDate}</span>
                          </div>

                          <div className="flex items-center justify-between text-[11px]">
                            <span>Status:</span>
                            {isDone ? (
                              <span className="font-bold text-emerald-600 flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3" /> Completed
                              </span>
                            ) : isOver ? (
                              <span className="font-bold text-red-600 flex items-center gap-1">
                                <AlertCircle className="w-3 h-3" /> Overdue by {Math.abs(m.daysRemaining)}d
                              </span>
                            ) : isApproaching ? (
                              <span className="font-bold text-amber-600 flex items-center gap-1">
                                <Clock className="w-3 h-3" /> Due in {m.daysRemaining}d (Warning)
                              </span>
                            ) : (
                              <span className="text-slate-600 dark:text-zinc-400">
                                In Progress ({m.daysRemaining}d left)
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Day-by-Day Timeline Audit Trail */}
                <div className="space-y-2">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-zinc-400 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-blue-500" />
                    <span>Day-by-Day Movement Timeline</span>
                  </h5>

                  <div className="border border-slate-200 dark:border-zinc-800 rounded-xl overflow-hidden divide-y divide-slate-100 dark:divide-zinc-800 text-xs">
                    {selectedSiteReport.dayByDayTimeline.map(step => (
                      <div
                        key={step.dayNumber}
                        className={`p-2.5 flex items-center justify-between gap-3 ${
                          step.isToday
                            ? 'bg-indigo-50/80 dark:bg-indigo-950/50 font-bold'
                            : step.isMilestone
                            ? 'bg-slate-50/80 dark:bg-zinc-800/50'
                            : ''
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span
                            className={`w-14 text-center px-1.5 py-0.5 rounded text-[10px] font-mono font-bold shrink-0 ${
                              step.isToday
                                ? 'bg-indigo-600 text-white'
                                : step.isMilestone
                                ? 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                                : 'bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-400'
                            }`}
                          >
                            Day {step.dayNumber}
                          </span>
                          <span className="text-slate-800 dark:text-zinc-200 truncate">
                            {step.event}
                          </span>
                        </div>

                        <div className="text-[11px] text-slate-400 shrink-0 font-mono">
                          {step.date}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="p-8 text-center text-xs text-slate-400">
                Select a site from the left panel to review its day-by-day report.
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 flex items-center justify-between text-xs text-slate-500 no-print">
          <span>
            Real-time SAQ calculations: Automatically monitors every site against 21d/44d/21d/7d SLAs and 14-day movement thresholds.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 hover:bg-slate-50 font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
