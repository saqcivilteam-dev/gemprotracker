import React, { useState, useEffect } from 'react';
import {
  Cloud,
  Check,
  Download,
  Upload,
  RefreshCw,
  Trash2,
  ExternalLink,
  X,
  FileJson,
  FileSpreadsheet,
  AlertTriangle,
  Lock,
  Search,
  CheckCircle2,
  HardDrive
} from 'lucide-react';
import { AppState, Tracker } from '../types/tracker';
import {
  signInToGoogleDrive,
  signOutGoogleDrive,
  getDriveAccessToken,
  getCurrentGoogleUser,
  listDriveFiles,
  uploadFileToDrive,
  downloadDriveFile,
  deleteDriveFile,
  GoogleDriveFile
} from '../utils/googleDrive';

interface GoogleDriveModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onRestoreState: (restoredState: AppState) => void;
  onNotify: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const GoogleDriveModal: React.FC<GoogleDriveModalProps> = ({
  isOpen,
  onClose,
  state,
  onRestoreState,
  onNotify
}) => {
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [googleUser, setGoogleUser] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [driveFiles, setDriveFiles] = useState<GoogleDriveFile[]>([]);
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [uploadFormat, setUploadFormat] = useState<'json' | 'csv'>('json');
  const [uploadTarget, setUploadTarget] = useState<'current' | 'all'>('current');
  const [confirmDeleteFile, setConfirmDeleteFile] = useState<GoogleDriveFile | null>(null);
  const [confirmRestoreFile, setConfirmRestoreFile] = useState<GoogleDriveFile | null>(null);
  const [lastUploadedFile, setLastUploadedFile] = useState<GoogleDriveFile | null>(null);

  const activeTracker = state.trackers.find(t => t.id === state.activeTrackerId) || state.trackers[0];

  // Check initial connection
  useEffect(() => {
    if (isOpen) {
      const token = getDriveAccessToken();
      const user = getCurrentGoogleUser();
      if (token && user) {
        setIsConnected(true);
        setGoogleUser(user);
        loadFiles();
      } else {
        setIsConnected(false);
        setGoogleUser(null);
      }
    }
  }, [isOpen]);

  const loadFiles = async () => {
    try {
      setLoading(true);
      const files = await listDriveFiles(searchFilter);
      setDriveFiles(files);
    } catch (err: any) {
      console.warn('Could not load Google Drive files:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSignIn = async () => {
    try {
      setLoading(true);
      const { user } = await signInToGoogleDrive();
      setIsConnected(true);
      setGoogleUser(user);
      onNotify(`Connected to Google Drive as ${user.displayName || user.email}!`, 'success');
      await loadFiles();
    } catch (err: any) {
      onNotify(err.message || 'Google Drive sign in failed.', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOutGoogleDrive();
      setIsConnected(false);
      setGoogleUser(null);
      setDriveFiles([]);
      setLastUploadedFile(null);
      onNotify('Disconnected from Google Drive.', 'info');
    } catch (err: any) {
      onNotify(err.message || 'Error signing out of Google Drive', 'error');
    }
  };

  const handleUpload = async () => {
    if (!isConnected) {
      onNotify('Please sign in to Google Drive first.', 'error');
      return;
    }

    try {
      setLoading(true);
      const timestamp = new Date().toISOString().slice(0, 10);

      let fileName = '';
      let content = '';
      let mimeType = 'application/json';

      if (uploadTarget === 'all') {
        fileName = `Gaela_Workspace_Backup_${timestamp}.json`;
        content = JSON.stringify(state, null, 2);
        mimeType = 'application/json';
      } else {
        const cleanName = (activeTracker?.name || 'Tracker').replace(/[^a-zA-Z0-9_-]/g, '_');
        if (uploadFormat === 'json') {
          fileName = `${cleanName}_${timestamp}.json`;
          content = JSON.stringify(activeTracker, null, 2);
          mimeType = 'application/json';
        } else {
          fileName = `${cleanName}_${timestamp}.csv`;
          const visibleCols = activeTracker.columns.filter(c => c.visible);
          const headers = visibleCols.map(c => `"${c.name.replace(/"/g, '""')}"`).join(',');
          const rows = activeTracker.rows.map(r =>
            visibleCols.map(c => `"${String(r[c.id] ?? '').replace(/"/g, '""')}"`).join(',')
          );
          content = [headers, ...rows].join('\n');
          mimeType = 'text/csv';
        }
      }

      const uploaded = await uploadFileToDrive(fileName, content, mimeType);
      setLastUploadedFile(uploaded);
      onNotify(`Successfully uploaded "${fileName}" to your Google Drive!`, 'success');
      await loadFiles();
    } catch (err: any) {
      onNotify(err.message || 'Upload to Google Drive failed.', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Safe file restore execution after explicit confirmation
  const handleExecuteRestore = async () => {
    if (!confirmRestoreFile) return;
    try {
      setLoading(true);
      const text = await downloadDriveFile(confirmRestoreFile.id);
      const parsed = JSON.parse(text);

      if (parsed.trackers && Array.isArray(parsed.trackers)) {
        // Complete workspace backup
        onRestoreState(parsed);
        onNotify(`Full workspace restored from Google Drive: "${confirmRestoreFile.name}"!`, 'success');
      } else if (parsed.columns && Array.isArray(parsed.columns) && parsed.rows && Array.isArray(parsed.rows)) {
        // Single tracker backup
        const newTrackers = [...state.trackers];
        const existingIdx = newTrackers.findIndex(t => t.id === parsed.id);
        if (existingIdx !== -1) {
          newTrackers[existingIdx] = parsed;
        } else {
          newTrackers.push(parsed);
        }
        onRestoreState({
          ...state,
          trackers: newTrackers,
          activeTrackerId: parsed.id
        });
        onNotify(`Tracker "${parsed.name}" restored and opened from Google Drive!`, 'success');
      } else {
        throw new Error('Unrecognized tracker data structure in selected file.');
      }
      setConfirmRestoreFile(null);
    } catch (err: any) {
      onNotify(err.message || 'Failed to restore file from Google Drive.', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Safe file deletion execution after explicit confirmation
  const handleExecuteDelete = async () => {
    if (!confirmDeleteFile) return;
    try {
      setLoading(true);
      await deleteDriveFile(confirmDeleteFile.id);
      onNotify(`File "${confirmDeleteFile.name}" deleted from Google Drive.`, 'info');
      setConfirmDeleteFile(null);
      await loadFiles();
    } catch (err: any) {
      onNotify(err.message || 'Failed to delete file from Google Drive.', 'error');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-white dark:bg-zinc-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-zinc-800 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between bg-slate-50/50 dark:bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 flex items-center justify-center shadow-2xs">
              <HardDrive className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-zinc-100 flex items-center gap-2">
                <span>Google Drive Integration</span>
                {isConnected && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                    Connected
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Save, backup, and restore large-scale site trackers directly with your Google Drive.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Connection Status Card */}
          {!isConnected ? (
            <div className="p-6 rounded-2xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-800/40 text-center space-y-4">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-white dark:bg-zinc-800 shadow-md flex items-center justify-center border border-slate-200 dark:border-zinc-700">
                <svg className="w-7 h-7" viewBox="0 0 48 48">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                </svg>
              </div>
              <div className="max-w-md mx-auto space-y-1">
                <h4 className="text-sm font-bold text-slate-800 dark:text-zinc-200">
                  Connect Your Google Account
                </h4>
                <p className="text-xs text-slate-500 dark:text-zinc-400">
                  Link Google Drive to store automatic backups, export site management datasets (up to 100,000 sites), and synchronize documents across your civil and SAQ teams.
                </p>
              </div>

              {/* Official Google Sign-In Button */}
              <button
                type="button"
                onClick={handleSignIn}
                disabled={loading}
                className="gsi-material-button"
              >
                <div className="gsi-material-button-state"></div>
                <div className="gsi-material-button-content-wrapper">
                  <div className="gsi-material-button-icon">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                      <path fill="none" d="M0 0h48v48H0z"></path>
                    </svg>
                  </div>
                  <span className="gsi-material-button-contents">
                    {loading ? 'Connecting to Google...' : 'Sign in with Google'}
                  </span>
                  <span style={{ display: 'none' }}>Sign in with Google</span>
                </div>
              </button>
            </div>
          ) : (
            <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/50 dark:bg-blue-950/20 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                {googleUser?.photoURL ? (
                  <img
                    src={googleUser.photoURL}
                    alt={googleUser.displayName || 'Google User'}
                    className="w-10 h-10 rounded-full border-2 border-white dark:border-zinc-800 shadow-2xs"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-blue-600 text-white font-bold flex items-center justify-center text-sm shadow-2xs">
                    {(googleUser?.displayName || googleUser?.email || 'G')[0].toUpperCase()}
                  </div>
                )}
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-zinc-100 flex items-center gap-1.5">
                    <span>{googleUser?.displayName || 'Google Account Connected'}</span>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-zinc-400">
                    {googleUser?.email}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={loadFiles}
                  disabled={loading}
                  className="p-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-600 dark:text-zinc-300 hover:bg-slate-50 text-xs flex items-center gap-1"
                  title="Refresh Drive files list"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  <span className="hidden sm:inline">Refresh</span>
                </button>
                <button
                  type="button"
                  onClick={handleSignOut}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-600 dark:text-zinc-300 hover:bg-red-50 hover:text-red-600 hover:border-red-200 text-xs font-medium transition-colors"
                >
                  Disconnect
                </button>
              </div>
            </div>
          )}

          {/* Upload / Backup Section */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-zinc-300 flex items-center gap-1.5">
              <Upload className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Save & Upload to Google Drive</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-slate-500 dark:text-zinc-400 block mb-1">
                  Scope
                </label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setUploadTarget('current')}
                    className={`flex-1 py-1.5 px-2.5 rounded-lg border text-xs font-medium text-left transition-all ${
                      uploadTarget === 'current'
                        ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-400 text-indigo-700 dark:text-indigo-300 shadow-2xs font-semibold'
                        : 'border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-400 hover:bg-slate-50'
                    }`}
                  >
                    Active Tracker ({activeTracker?.rows.length || 0} rows)
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadTarget('all')}
                    className={`flex-1 py-1.5 px-2.5 rounded-lg border text-xs font-medium text-left transition-all ${
                      uploadTarget === 'all'
                        ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-400 text-indigo-700 dark:text-indigo-300 shadow-2xs font-semibold'
                        : 'border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-400 hover:bg-slate-50'
                    }`}
                  >
                    All Trackers (Full Workspace)
                  </button>
                </div>
              </div>

              {uploadTarget === 'current' && (
                <div>
                  <label className="text-[11px] font-semibold text-slate-500 dark:text-zinc-400 block mb-1">
                    Format
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setUploadFormat('json')}
                      className={`flex-1 py-1.5 px-2.5 rounded-lg border text-xs font-medium flex items-center justify-center gap-1.5 transition-all ${
                        uploadFormat === 'json'
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-400 text-emerald-700 dark:text-emerald-300 shadow-2xs font-semibold'
                          : 'border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-400 hover:bg-slate-50'
                      }`}
                    >
                      <FileJson className="w-3.5 h-3.5" />
                      <span>JSON Backup</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setUploadFormat('csv')}
                      className={`flex-1 py-1.5 px-2.5 rounded-lg border text-xs font-medium flex items-center justify-center gap-1.5 transition-all ${
                        uploadFormat === 'csv'
                          ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-400 text-emerald-700 dark:text-emerald-300 shadow-2xs font-semibold'
                          : 'border-slate-200 dark:border-zinc-700 text-slate-600 dark:text-zinc-400 hover:bg-slate-50'
                      }`}
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      <span>CSV Spreadsheet</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-2 flex items-center justify-between gap-3">
              <div className="text-[11px] text-slate-500 dark:text-zinc-400">
                {uploadTarget === 'current'
                  ? `Saves "${activeTracker?.name}" to your Google Drive.`
                  : 'Saves complete multi-tracker studio workspace with all permissions and user logs.'}
              </div>
              <button
                type="button"
                onClick={handleUpload}
                disabled={!isConnected || loading}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-sm transition-all active:scale-95 disabled:opacity-50"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{loading ? 'Uploading...' : 'Save to Google Drive'}</span>
              </button>
            </div>

            {/* Notification badge when uploaded */}
            {lastUploadedFile && (
              <div className="mt-3 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200 text-xs flex items-center justify-between gap-2 animate-in fade-in">
                <div className="flex items-center gap-2 truncate">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="font-semibold truncate">Uploaded: {lastUploadedFile.name}</span>
                </div>
                {lastUploadedFile.webViewLink && (
                  <a
                    href={lastUploadedFile.webViewLink}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline shrink-0"
                  >
                    <span>Open in Drive</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            )}
          </div>

          {/* Files on Google Drive List & Restore */}
          {isConnected && (
            <div className="p-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-zinc-300 flex items-center gap-1.5">
                  <HardDrive className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Files on Google Drive ({driveFiles.length})</span>
                </h4>

                <div className="relative w-48">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Search drive files..."
                    value={searchFilter}
                    onChange={e => setSearchFilter(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && loadFiles()}
                    className="w-full text-xs pl-7 pr-2 py-1 rounded-md border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-800 dark:text-zinc-200 outline-none"
                  />
                </div>
              </div>

              {driveFiles.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 dark:border-zinc-800 rounded-xl">
                  {loading ? 'Fetching files from Google Drive...' : 'No files found in Google Drive matching filter. Click "Save to Google Drive" above to create your first cloud backup.'}
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-zinc-800 max-h-56 overflow-y-auto rounded-xl border border-slate-200 dark:border-zinc-800">
                  {driveFiles.map(file => {
                    const isJson = file.name.endsWith('.json') || file.mimeType.includes('json');
                    const isCsv = file.name.endsWith('.csv') || file.mimeType.includes('csv');

                    return (
                      <div
                        key={file.id}
                        className="p-2.5 flex items-center justify-between gap-2 hover:bg-slate-50 dark:hover:bg-zinc-800/60 transition-colors"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          {isJson ? (
                            <FileJson className="w-4 h-4 text-emerald-600 shrink-0" />
                          ) : isCsv ? (
                            <FileSpreadsheet className="w-4 h-4 text-blue-600 shrink-0" />
                          ) : (
                            <HardDrive className="w-4 h-4 text-slate-400 shrink-0" />
                          )}
                          <div className="min-w-0">
                            <div className="text-xs font-semibold text-slate-800 dark:text-zinc-200 truncate">
                              {file.name}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {file.modifiedTime ? new Date(file.modifiedTime).toLocaleDateString() : 'Drive File'}
                              {file.size ? ` • ${Math.round(parseInt(file.size, 10) / 1024)} KB` : ''}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          {isJson && (
                            <button
                              type="button"
                              onClick={() => setConfirmRestoreFile(file)}
                              className="px-2.5 py-1 text-[11px] font-bold rounded-md bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 transition-colors"
                              title="Restore and import tracker data from this Google Drive file"
                            >
                              Restore
                            </button>
                          )}
                          {file.webViewLink && (
                            <a
                              href={file.webViewLink}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-700 rounded"
                              title="Open on Google Drive"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteFile(file)}
                            className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded"
                            title="Delete file from Google Drive"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3.5 border-t border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-900 flex items-center justify-between text-xs text-slate-500">
          <span>Security: Access tokens are held exclusively in memory and never stored in cookies.</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 hover:bg-slate-50 font-medium transition-colors"
          >
            Close
          </button>
        </div>

        {/* Mandatory User Confirmation Dialog for Destructive Operations: File Restore */}
        {confirmRestoreFile && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-2xl p-5 shadow-2xl border border-amber-300 dark:border-amber-800 space-y-4">
              <div className="flex items-center gap-3 text-amber-600 dark:text-amber-400">
                <AlertTriangle className="w-6 h-6 shrink-0" />
                <h4 className="text-sm font-bold text-slate-900 dark:text-zinc-100">
                  Confirm Restore from Google Drive
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-zinc-300 leading-relaxed">
                Are you sure you want to restore data from <strong>"{confirmRestoreFile.name}"</strong>? This will load the stored site records and configuration into your current workspace. Any unsaved in-memory edits will be replaced with this version.
              </p>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmRestoreFile(null)}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 dark:border-zinc-700 text-slate-600 dark:text-zinc-300 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExecuteRestore}
                  disabled={loading}
                  className="px-4 py-1.5 text-xs font-bold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
                >
                  {loading ? 'Restoring...' : 'Confirm Restore'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Mandatory User Confirmation Dialog for Destructive Operations: File Deletion */}
        {confirmDeleteFile && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <div className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-2xl p-5 shadow-2xl border border-red-300 dark:border-red-800 space-y-4">
              <div className="flex items-center gap-3 text-red-600">
                <AlertTriangle className="w-6 h-6 shrink-0" />
                <h4 className="text-sm font-bold text-slate-900 dark:text-zinc-100">
                  Permanently Delete from Google Drive?
                </h4>
              </div>
              <p className="text-xs text-slate-600 dark:text-zinc-300 leading-relaxed">
                Are you sure you want to permanently delete <strong>"{confirmDeleteFile.name}"</strong> from your Google Drive? This action cannot be undone.
              </p>
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setConfirmDeleteFile(null)}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 dark:border-zinc-700 text-slate-600 dark:text-zinc-300 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExecuteDelete}
                  disabled={loading}
                  className="px-4 py-1.5 text-xs font-bold rounded-lg bg-red-600 hover:bg-red-500 text-white shadow-xs"
                >
                  {loading ? 'Deleting...' : 'Delete File'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
