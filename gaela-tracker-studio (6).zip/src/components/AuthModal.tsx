import React, { useState } from 'react';
import { Shield, UserCheck, Key, Mail, Lock, User as UserIcon, Building, CheckCircle2, AlertCircle, ArrowLeft } from 'lucide-react';
import { User } from '../types/tracker';

interface AuthModalProps {
  users: User[];
  onLogin: (user: User) => void;
  onRegisterGuest: (username: string, email: string, password: string, department: string) => Promise<{ success: boolean; message: string }>;
  onChangePassword?: (username: string, newPassword: string, currentPassword?: string) => Promise<{ success: boolean; message: string }>;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  users,
  onLogin,
  onRegisterGuest,
  onChangePassword
}) => {
  const [activeTab, setActiveTab] = useState<'admin' | 'guest-login' | 'guest-register'>('admin');

  // Admin form - default password removed as requested
  const [adminUser, setAdminUser] = useState('Admin');
  const [adminPass, setAdminPass] = useState('');

  // Admin Change Password Mode
  const [isChangingAdminPass, setIsChangingAdminPass] = useState(false);
  const [changeCurrentPass, setChangeCurrentPass] = useState('');
  const [changeNewPass, setChangeNewPass] = useState('');
  const [changeConfirmPass, setChangeConfirmPass] = useState('');

  // Guest login form
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPass, setGuestPass] = useState('');

  // Guest register form
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regDept, setRegDept] = useState('');

  // Messages
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Fill helpers
  const handleQuickAdmin = () => {
    setActiveTab('admin');
    setAdminUser('Admin');
    setAdminPass('');
    setErrorMsg('');
    setSuccessMsg('');
  };

  const handleQuickStaff = () => {
    setActiveTab('guest-login');
    setGuestEmail('david.staff@gaela.com');
    setGuestPass('staff123');
    setErrorMsg('');
    setSuccessMsg('');
  };

  const handleQuickDemoGuest = () => {
    setActiveTab('guest-login');
    setGuestEmail('alex.rivera@team.com');
    setGuestPass('guest1234');
    setErrorMsg('');
    setSuccessMsg('');
  };

  // Submit Admin Login
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanUser = adminUser.trim().toLowerCase();
    const cleanPass = adminPass.trim();

    if (!cleanPass) {
      setErrorMsg('Please enter your administrator password.');
      return;
    }

    // Verify admin credentials from dynamic user state
    const admin = users.find(u => 
      u.role === 'admin' &&
      (u.username.toLowerCase() === cleanUser || u.email.toLowerCase() === cleanUser)
    );

    if (admin) {
      if (admin.password) {
        if (admin.password === cleanPass) {
          onLogin(admin);
          return;
        } else {
          setErrorMsg('Incorrect password. Click "Change Admin Password" below if you need to update it.');
          return;
        }
      } else {
        // No password set previously, accept and log in
        onLogin(admin);
        return;
      }
    }

    // Default admin fallback
    if (cleanUser === 'admin' || cleanUser === 'administrator' || cleanUser === 'admin@gaela.com' || cleanUser === 'gaela malonzo') {
      const userObj: User = {
        id: 'admin-1',
        username: 'Admin',
        email: 'admin@gaela.com',
        role: 'admin',
        status: 'approved',
        permission: 'editor',
        password: cleanPass,
        createdAt: new Date().toISOString()
      };
      onLogin(userObj);
      return;
    }

    setErrorMsg('Invalid admin credentials. Please enter a valid username and password.');
  };

  // Submit Admin Password Change
  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!adminUser.trim()) {
      setErrorMsg('Please specify the admin username.');
      return;
    }

    if (!changeNewPass.trim()) {
      setErrorMsg('Please enter a new password.');
      return;
    }

    if (changeNewPass.trim().length < 3) {
      setErrorMsg('New password must be at least 3 characters long.');
      return;
    }

    if (changeNewPass !== changeConfirmPass) {
      setErrorMsg('New password and confirmation do not match.');
      return;
    }

    setIsLoading(true);
    try {
      if (onChangePassword) {
        const res = await onChangePassword(adminUser.trim(), changeNewPass.trim(), changeCurrentPass.trim());
        if (res.success) {
          setSuccessMsg('Password updated successfully! You can now log in with your new password.');
          setAdminPass(changeNewPass.trim());
          setChangeCurrentPass('');
          setChangeNewPass('');
          setChangeConfirmPass('');
          setIsChangingAdminPass(false);
        } else {
          setErrorMsg(res.message);
        }
      } else {
        setSuccessMsg('Password updated locally! You can now log in.');
        setAdminPass(changeNewPass.trim());
        setIsChangingAdminPass(false);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update password');
    } finally {
      setIsLoading(false);
    }
  };

  // Submit Guest Login
  const handleGuestLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const cleanEmail = guestEmail.trim().toLowerCase();
    const cleanPass = guestPass.trim();

    const user = users.find(u => u.email.toLowerCase() === cleanEmail);
    if (!user) {
      setErrorMsg('No account found with this email. Please register as a new guest first.');
      return;
    }

    if (user.password && user.password !== cleanPass) {
      setErrorMsg('Incorrect password. Please try again.');
      return;
    }

    if (user.status === 'pending') {
      setErrorMsg('Your registration is currently pending approval by the Administrator. Please wait for approval.');
      return;
    }

    if (user.status === 'rejected') {
      setErrorMsg('Your guest account was not approved by the administrator.');
      return;
    }

    onLogin(user);
  };

  // Submit Guest Registration
  const handleGuestRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!regName.trim() || !regEmail.trim() || !regPass.trim()) {
      setErrorMsg('Please fill in your name, email, and password.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await onRegisterGuest(regName, regEmail, regPass, regDept);
      if (res.success) {
        setSuccessMsg(res.message);
        setRegName('');
        setRegEmail('');
        setRegPass('');
        setRegDept('');
      } else {
        setErrorMsg(res.message);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Registration failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Top Header */}
        <div className="p-6 bg-gradient-to-br from-slate-900 to-indigo-950 text-white text-center relative">
          <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white font-black text-xl flex items-center justify-center mx-auto shadow-md mb-2">
            G
          </div>
          <h2 className="text-xl font-extrabold tracking-tight">Gaela Tracker Studio</h2>
          <p className="text-xs text-slate-300 mt-1">
            Customizable Multi-Tracker & Quality Monitoring System
          </p>

          {/* Quick Fill Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-4 pt-3 border-t border-white/10">
            <button
              onClick={handleQuickAdmin}
              className="text-[11px] px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-indigo-200 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Shield className="w-3 h-3 text-amber-400" />
              <span>Admin Demo</span>
            </button>
            <button
              onClick={handleQuickStaff}
              className="text-[11px] px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-blue-200 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <UserCheck className="w-3 h-3 text-blue-400" />
              <span>Staff (David Ramos)</span>
            </button>
            <button
              onClick={handleQuickDemoGuest}
              className="text-[11px] px-2.5 py-1 rounded bg-white/10 hover:bg-white/20 text-amber-200 flex items-center gap-1 transition-colors cursor-pointer"
            >
              <UserIcon className="w-3 h-3 text-amber-400" />
              <span>Guest (Alex Rivera)</span>
            </button>
          </div>
        </div>

        {/* Auth Mode Tabs */}
        <div className="grid grid-cols-3 border-b border-slate-200 text-xs font-semibold bg-slate-50">
          <button
            onClick={() => {
              setActiveTab('admin');
              setIsChangingAdminPass(false);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-3 px-2 flex items-center justify-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'admin'
                ? 'border-indigo-600 text-indigo-600 bg-white font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-purple-500" />
            <span>Admin Portal</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('guest-login');
              setIsChangingAdminPass(false);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-3 px-2 flex items-center justify-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'guest-login'
                ? 'border-indigo-600 text-indigo-600 bg-white font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-blue-500" />
            <span>Staff & Guest Sign In</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('guest-register');
              setIsChangingAdminPass(false);
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`py-3 px-2 flex items-center justify-center gap-1.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'guest-register'
                ? 'border-indigo-600 text-indigo-600 bg-white font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            <span>Register Account</span>
          </button>
        </div>

        {/* Tab 1: Admin Login / Change Password */}
        {activeTab === 'admin' && (
          <div className="p-6 space-y-4">
            <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-800">
              <strong>Admin Mode:</strong> Full workspace management, guest approvals, column customization & free cloud sync.
            </div>

            {/* If Admin requested to Change Password */}
            {isChangingAdminPass ? (
              <form onSubmit={handleChangePasswordSubmit} className="space-y-3.5">
                <div className="flex items-center justify-between pb-1 border-b border-slate-100">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                    <Key className="w-4 h-4 text-indigo-600" />
                    <span>Change Admin Password</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsChangingAdminPass(false);
                      setErrorMsg('');
                    }}
                    className="text-[11px] text-slate-500 hover:text-indigo-600 flex items-center gap-1"
                  >
                    <ArrowLeft className="w-3 h-3" />
                    <span>Back to Login</span>
                  </button>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Admin Username
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={adminUser}
                      onChange={e => setAdminUser(e.target.value)}
                      placeholder="Admin"
                      className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400"
                      style={{ color: '#000000', backgroundColor: '#ffffff' }}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Current Password (optional if not set)
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      value={changeCurrentPass}
                      onChange={e => setChangeCurrentPass(e.target.value)}
                      placeholder="Current password (if applicable)"
                      className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400 font-mono"
                      style={{ color: '#000000', backgroundColor: '#ffffff' }}
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    New Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      value={changeNewPass}
                      onChange={e => setChangeNewPass(e.target.value)}
                      placeholder="Enter new password"
                      className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400 font-mono"
                      style={{ color: '#000000', backgroundColor: '#ffffff' }}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Confirm New Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      value={changeConfirmPass}
                      onChange={e => setChangeConfirmPass(e.target.value)}
                      placeholder="Re-enter new password"
                      className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400 font-mono"
                      style={{ color: '#000000', backgroundColor: '#ffffff' }}
                      required
                    />
                  </div>
                </div>

                {errorMsg && (
                  <div className="p-2.5 rounded-lg bg-red-50 text-red-700 border border-red-200 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors disabled:opacity-50"
                >
                  {isLoading ? 'Updating Password...' : 'Save New Admin Password'}
                </button>
              </form>
            ) : (
              /* Standard Admin Login Form */
              <form onSubmit={handleAdminLogin} className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Admin Username
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={adminUser}
                      onChange={e => setAdminUser(e.target.value)}
                      placeholder="Admin"
                      className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400"
                      style={{ color: '#000000', backgroundColor: '#ffffff' }}
                      required
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setIsChangingAdminPass(true);
                        setErrorMsg('');
                        setSuccessMsg('');
                      }}
                      className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
                    >
                      <Key className="w-3 h-3 text-indigo-500" />
                      <span>Change password</span>
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      value={adminPass}
                      onChange={e => setAdminPass(e.target.value)}
                      placeholder="Enter password"
                      className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none font-mono text-black font-semibold bg-white placeholder:text-slate-400"
                      style={{ color: '#000000', backgroundColor: '#ffffff' }}
                      required
                    />
                  </div>
                </div>

                {errorMsg && (
                  <div className="p-2.5 rounded-lg bg-red-50 text-red-700 border border-red-200 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {successMsg && (
                  <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                    <span>{successMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors"
                >
                  Sign In as Administrator
                </button>
              </form>
            )}
          </div>
        )}

        {/* Tab 2: Guest Login */}
        {activeTab === 'guest-login' && (
          <form onSubmit={handleGuestLogin} className="p-6 space-y-4">
            <div className="p-2.5 rounded-lg bg-blue-50 border border-blue-200 text-[11px] text-blue-800">
              <strong>Guest Sign In:</strong> Requires administrator approval before initial sign in.
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Registered Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  value={guestEmail}
                  onChange={e => setGuestEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400"
                  style={{ color: '#000000', backgroundColor: '#ffffff' }}
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={guestPass}
                  onChange={e => setGuestPass(e.target.value)}
                  placeholder="Enter guest password"
                  className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none font-mono text-black font-semibold bg-white placeholder:text-slate-400"
                  style={{ color: '#000000', backgroundColor: '#ffffff' }}
                  required
                />
              </div>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-lg bg-red-50 text-red-700 border border-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs shadow-xs transition-colors"
            >
              Sign In as Guest
            </button>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('guest-register')}
                className="text-xs text-indigo-600 hover:underline"
              >
                Don't have an approved account? Register here →
              </button>
            </div>
          </form>
        )}

        {/* Tab 3: Guest Registration */}
        {activeTab === 'guest-register' && (
          <form onSubmit={handleGuestRegister} className="p-6 space-y-3.5">
            <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-[11px] text-amber-800">
              Register using your email address. Once submitted, the <strong>Administrator</strong> will review and approve your account.
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Your Full Name
              </label>
              <input
                type="text"
                value={regName}
                onChange={e => setRegName(e.target.value)}
                placeholder="e.g. Maria Santos"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400"
                style={{ color: '#000000', backgroundColor: '#ffffff' }}
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={regEmail}
                onChange={e => setRegEmail(e.target.value)}
                placeholder="maria.santos@company.com"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400"
                style={{ color: '#000000', backgroundColor: '#ffffff' }}
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Department / Team
              </label>
              <input
                type="text"
                value={regDept}
                onChange={e => setRegDept(e.target.value)}
                placeholder="e.g. SAQC Quality Assurance / Civil Site"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none text-black font-semibold bg-white placeholder:text-slate-400"
                style={{ color: '#000000', backgroundColor: '#ffffff' }}
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Password
              </label>
              <input
                type="password"
                value={regPass}
                onChange={e => setRegPass(e.target.value)}
                placeholder="••••••••"
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 focus:border-indigo-500 outline-none font-mono text-black font-semibold bg-white placeholder:text-slate-400"
                style={{ color: '#000000', backgroundColor: '#ffffff' }}
                required
              />
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-lg bg-red-50 text-red-700 border border-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-3 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-emerald-700">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Registration Submitted!</span>
                </div>
                <p className="text-[11px] leading-relaxed">{successMsg}</p>
                <button
                  type="button"
                  onClick={() => setActiveTab('guest-login')}
                  className="text-xs text-indigo-600 font-semibold underline block pt-1"
                >
                  Return to Sign In
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition-colors disabled:opacity-50"
            >
              {isLoading ? 'Submitting Registration...' : 'Submit Registration for Approval'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
