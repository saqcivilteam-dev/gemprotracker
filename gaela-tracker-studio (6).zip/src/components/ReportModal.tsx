import React, { useState, useMemo, useEffect } from 'react';
import {
  Printer,
  FileText,
  ShieldCheck,
  Presentation,
  LayoutGrid,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  CheckSquare,
  Square,
  Sparkles,
  TrendingUp,
  Tag,
  Users,
  Building2,
  Calendar,
  X,
  SlidersHorizontal,
  Check,
  RotateCcw,
  Clock,
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  BarChart3,
  DollarSign,
  Percent,
  Hash,
  Eye,
  Layers,
  ArrowRight,
  Filter
} from 'lucide-react';
import { Tracker, User, SummaryCard, Column } from '../types/tracker';
import { formatCurrency, formatPercent } from '../utils/storage';
import { renderFormattedContent } from '../utils/textFormatter';
import { evaluateAllSitesSaq, SAQ_STAGES } from '../utils/saqSlaEngine';

interface ReportModalProps {
  tracker: Tracker;
  allTrackers?: Tracker[];
  appName: string;
  currentUser: User | null;
  initialMode?: 'report' | 'presentation';
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  tracker,
  allTrackers = [],
  appName,
  currentUser,
  initialMode = 'presentation',
  onClose
}) => {
  const [viewMode, setViewMode] = useState<'report' | 'presentation'>(initialMode);
  const [currentSlide, setCurrentSlide] = useState<number>(0);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showConfigDrawer, setShowConfigDrawer] = useState<boolean>(false);
  const [activeConfigTab, setActiveConfigTab] = useState<'cards' | 'sections' | 'columns' | 'filters'>('cards');

  // 1. Dashboard KPI Cards Selection (defaults to all cards in active tracker's summaryCards)
  const [selectedCardIds, setSelectedCardIds] = useState<string[]>(() =>
    tracker.summaryCards.map(c => c.id)
  );

  // 2. Report Sections & Slides Selection
  const [selectedSections, setSelectedSections] = useState({
    dashboardKpis: true,
    saqSlaTimeline: true,
    financialBreakdown: true,
    errandsChecklist: true,
    dataTable: true
  });

  // 3. Table Columns Selection (defaults to visible columns)
  const [selectedColumnIds, setSelectedColumnIds] = useState<string[]>(() =>
    tracker.columns.filter(c => c.visible).map(c => c.id)
  );

  // 4. Row Filters
  const [filterPersonnel, setFilterPersonnel] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Keep selected cards updated if tracker changes
  useEffect(() => {
    setSelectedCardIds(tracker.summaryCards.map(c => c.id));
    setSelectedColumnIds(tracker.columns.filter(c => c.visible).map(c => c.id));
  }, [tracker.id]);

  // Safe number parser
  const parseNum = (val: any): number => {
    if (typeof val === 'number') return isNaN(val) ? 0 : val;
    if (val === undefined || val === null || val === '') return 0;
    const cleaned = String(val).replace(/[^0-9.-]+/g, '');
    const parsed = parseFloat(cleaned);
    return isNaN(parsed) ? 0 : parsed;
  };

  // Personnel detection
  const personnelCol = useMemo(() => {
    return tracker.columns.find(c => {
      const n = (c.name + ' ' + c.id).toLowerCase();
      return n.includes('name') || n.includes('person') || n.includes('staff') || n.includes('engineer') || n.includes('assignee') || n.includes('responsible');
    });
  }, [tracker.columns]);

  const allPersonnelList = useMemo(() => {
    const set = new Set<string>();
    tracker.rows.forEach(r => {
      if (personnelCol && r[personnelCol.id]) {
        set.add(String(r[personnelCol.id]));
      }
    });
    return Array.from(set);
  }, [tracker.rows, personnelCol]);

  // Status column detection
  const statusCol = useMemo(() => {
    return tracker.columns.find(c => c.type === 'status') ||
      tracker.columns.find(c => c.name.toLowerCase().includes('status'));
  }, [tracker.columns]);

  // SAQ Process Evaluation for the active tracker
  const saqEvaluation = useMemo(() => {
    return evaluateAllSitesSaq(tracker.rows, '2026-10-03');
  }, [tracker.rows]);

  // Filtered rows for audit table & presentation
  const filteredRows = useMemo(() => {
    return tracker.rows.filter(row => {
      if (filterPersonnel !== 'all' && personnelCol) {
        if (String(row[personnelCol.id] || '') !== filterPersonnel) return false;
      }
      if (filterStatus !== 'all') {
        if (filterStatus === 'completed') {
          const val = String(row[statusCol?.id || ''] || '').toLowerCase();
          if (!(val.includes('complete') || val.includes('done') || val.includes('settled') || val.includes('closed') || val === '100%')) return false;
        } else if (filterStatus === 'open') {
          const val = String(row[statusCol?.id || ''] || '').toLowerCase();
          if (val.includes('complete') || val.includes('done') || val.includes('settled') || val.includes('closed') || val === '100%') return false;
        } else if (filterStatus === 'overdue') {
          const siteReport = saqEvaluation.reports.find(r => r.siteId === String(row.col_site_id || row.id));
          if (siteReport?.overallStatus !== 'overdue') return false;
        } else if (filterStatus === 'stalled') {
          const siteReport = saqEvaluation.reports.find(r => r.siteId === String(row.col_site_id || row.id));
          if (!siteReport?.isStalled) return false;
        }
      }
      return true;
    });
  }, [tracker.rows, filterPersonnel, filterStatus, personnelCol, statusCol, saqEvaluation.reports]);

  // Compute live value for a dashboard card
  const computeCardValue = (card: SummaryCard): { value: number; formatted: string } => {
    const col = tracker.columns.find(c => c.id === card.columnId);
    const rows = filteredRows;

    let raw = 0;
    if (card.calcType === 'count') {
      raw = rows.length;
    } else if (card.calcType === 'count-completed') {
      raw = rows.filter(r => {
        const val = String(r[card.columnId] || '').toLowerCase();
        return val === 'completed' || val === 'done' || val === 'approved' || val === 'settled' || val === '100' || val === '100%';
      }).length;
    } else {
      const numbers = rows.map(r => parseNum(r[card.columnId]));
      if (numbers.length > 0) {
        switch (card.calcType) {
          case 'sum':
            raw = numbers.reduce((acc, curr) => acc + curr, 0);
            break;
          case 'average':
            raw = numbers.reduce((acc, curr) => acc + curr, 0) / numbers.length;
            break;
          case 'min':
            raw = Math.min(...numbers);
            break;
          case 'max':
            raw = Math.max(...numbers);
            break;
        }
      }
    }

    let formatted = '';
    if (card.format === 'currency') {
      formatted = formatCurrency(raw, col?.currencySymbol || '₱');
    } else if (card.format === 'percent') {
      formatted = formatPercent(raw);
    } else {
      formatted = Number(raw).toLocaleString();
    }

    return { value: raw, formatted };
  };

  // Selected Dashboard Cards
  const chosenSummaryCards = useMemo(() => {
    return tracker.summaryCards.filter(card => selectedCardIds.includes(card.id));
  }, [tracker.summaryCards, selectedCardIds]);

  // Selected Columns for Table
  const chosenColumns = useMemo(() => {
    return tracker.columns.filter(col => selectedColumnIds.includes(col.id));
  }, [tracker.columns, selectedColumnIds]);

  // Financial summary computations
  const amountCols = tracker.columns.filter(c => c.type === 'amount');
  const currencySymbol = amountCols[0]?.currencySymbol || '₱';

  const totalAmountSum = useMemo(() => {
    return filteredRows.reduce((acc, r) => {
      return acc + amountCols.reduce((sum, col) => sum + parseNum(r[col.id]), 0);
    }, 0);
  }, [filteredRows, amountCols]);

  // Extract checklist errands from text columns
  const allErrands = useMemo(() => {
    const list: { rowNum: number; personnel: string; text: string; isChecked: boolean }[] = [];
    filteredRows.forEach((row, idx) => {
      const person = personnelCol ? String(row[personnelCol.id] || 'Field Team') : `Site #${idx + 1}`;
      Object.keys(row).forEach(key => {
        if (key === 'id') return;
        const text = String(row[key] || '');
        if (text.includes('[ ]') || text.includes('[x]') || text.includes('[X]')) {
          const lines = text.split('\n');
          lines.forEach(l => {
            const unchk = l.match(/^(\s*)\[\s*\]\s+(.*)$/);
            const chk = l.match(/^(\s*)\[[xX]\]\s+(.*)$/);
            if (unchk) {
              list.push({ rowNum: idx + 1, personnel: person, text: unchk[2], isChecked: false });
            } else if (chk) {
              list.push({ rowNum: idx + 1, personnel: person, text: chk[2], isChecked: true });
            }
          });
        }
      });
    });
    return list;
  }, [filteredRows, personnelCol]);

  const completedErrandsCount = allErrands.filter(e => e.isChecked).length;
  const errandCompletionRate = allErrands.length > 0
    ? Math.round((completedErrandsCount / allErrands.length) * 100)
    : 0;

  // Build the dynamic presentation slides list based on user selections
  const dynamicSlides = useMemo(() => {
    const slides: { id: string; title: string; subtitle: string }[] = [];

    if (selectedSections.dashboardKpis && chosenSummaryCards.length > 0) {
      slides.push({
        id: 'dashboard-kpis',
        title: 'Executive Dashboard KPIs',
        subtitle: `Connected to ${chosenSummaryCards.length} Live Dashboard Metrics`
      });
    }

    if (selectedSections.saqSlaTimeline) {
      slides.push({
        id: 'saq-sla',
        title: 'Site Acquisition (SAQ) SLA & Milestones',
        subtitle: '21d Property Docs • 44d Pre-Con • 21d Post-Con • 7d FAC'
      });
    }

    if (selectedSections.financialBreakdown && amountCols.length > 0) {
      slides.push({
        id: 'financials',
        title: 'Financial & Capex Disbursement Summary',
        subtitle: 'Budget Allocations, Settlement & Cost Performance'
      });
    }

    if (selectedSections.errandsChecklist) {
      slides.push({
        id: 'errands',
        title: 'Field Operations & Task Checklists',
        subtitle: `${completedErrandsCount} of ${allErrands.length} Checkpoints Verified (${errandCompletionRate}%)`
      });
    }

    if (selectedSections.dataTable && chosenColumns.length > 0) {
      slides.push({
        id: 'table-data',
        title: 'Site & Project Operations Audit Table',
        subtitle: `${filteredRows.length} Records • ${chosenColumns.length} Selected Columns`
      });
    }

    if (slides.length === 0) {
      slides.push({
        id: 'empty',
        title: 'No Presentation Slides Selected',
        subtitle: 'Open "Choose What to Report" to enable slides.'
      });
    }

    return slides;
  }, [
    selectedSections,
    chosenSummaryCards.length,
    amountCols.length,
    completedErrandsCount,
    allErrands.length,
    errandCompletionRate,
    chosenColumns.length,
    filteredRows.length
  ]);

  // Clamp currentSlide if dynamicSlides changes
  const activeSlideIndex = Math.min(currentSlide, Math.max(0, dynamicSlides.length - 1));
  const currentSlideData = dynamicSlides[activeSlideIndex] || dynamicSlides[0];

  const nextSlide = () => setCurrentSlide(prev => (prev + 1) % dynamicSlides.length);
  const prevSlide = () => setCurrentSlide(prev => (prev - 1 + dynamicSlides.length) % dynamicSlides.length);

  // Keyboard navigation for presentation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (viewMode !== 'presentation') return;
      if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') {
        e.preventDefault();
        nextSlide();
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        prevSlide();
      } else if (e.key === 'Escape') {
        if (isFullscreen) {
          document.exitFullscreen?.().catch(() => {});
          setIsFullscreen(false);
        } else if (!showConfigDrawer) {
          onClose();
        } else {
          setShowConfigDrawer(false);
        }
      } else if (e.key === 'f' || e.key === 'F') {
        if (!e.ctrlKey && !e.metaKey) {
          toggleFullscreen();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [viewMode, isFullscreen, showConfigDrawer, dynamicSlides.length]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // Card color styling helper
  const getCardColorClasses = (color: SummaryCard['color']) => {
    switch (color) {
      case 'emerald':
        return 'border-emerald-500/40 bg-emerald-950/30 text-emerald-400';
      case 'indigo':
        return 'border-indigo-500/40 bg-indigo-950/30 text-indigo-400';
      case 'purple':
        return 'border-purple-500/40 bg-purple-950/30 text-purple-400';
      case 'amber':
        return 'border-amber-500/40 bg-amber-950/30 text-amber-400';
      case 'cyan':
        return 'border-cyan-500/40 bg-cyan-950/30 text-cyan-400';
      case 'rose':
        return 'border-rose-500/40 bg-rose-950/30 text-rose-400';
      case 'blue':
        return 'border-blue-500/40 bg-blue-950/30 text-blue-400';
      default:
        return 'border-slate-600 bg-slate-800/40 text-slate-300';
    }
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200 ${isFullscreen ? 'p-0' : ''}`}>
      <div
        className={`w-full bg-slate-950 text-white rounded-2xl shadow-2xl border border-slate-800 flex flex-col overflow-hidden relative ${
          isFullscreen ? 'h-screen w-screen rounded-none max-w-none' : 'max-w-6xl max-h-[94vh]'
        }`}
      >
        {/* Navigation & Mode Control Bar (Hidden when printing) */}
        <div className="p-3 sm:px-6 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 bg-slate-900/95 print-hide">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white font-black flex items-center justify-center text-sm shadow-xs">
              {viewMode === 'presentation' ? <Presentation className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-black text-sm text-white">
                  {viewMode === 'presentation' ? 'Executive Presentation Deck' : 'Executive Audit & Operations Report'}
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {tracker.name}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-emerald-400" />
                  <span>Connected to Dashboard</span>
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {viewMode === 'presentation'
                  ? `Slide ${activeSlideIndex + 1} of ${dynamicSlides.length} • ${currentSlideData.title}`
                  : 'Executive printable PDF briefing report with preserved highlights'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* "Choose What to Report" Button */}
            <button
              type="button"
              onClick={() => setShowConfigDrawer(!showConfigDrawer)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                showConfigDrawer
                  ? 'bg-indigo-600 text-white border-indigo-500 shadow-md ring-2 ring-indigo-400/30'
                  : 'bg-slate-800 text-indigo-300 border-slate-700 hover:bg-slate-700 hover:text-white'
              }`}
              title="Customize which Dashboard KPI cards, slides, columns, and records to report"
            >
              <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" />
              <span>Choose What to Report</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-indigo-950 text-indigo-300 border border-indigo-800">
                {chosenSummaryCards.length} KPIs • {chosenColumns.length} Cols
              </span>
            </button>

            {/* View Switcher: Report vs Presentation Deck */}
            <div className="flex items-center bg-slate-800 p-0.5 rounded-lg text-xs font-semibold border border-slate-700">
              <button
                type="button"
                onClick={() => setViewMode('presentation')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
                  viewMode === 'presentation'
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Presentation className="w-3.5 h-3.5" />
                <span>Presentation</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('report')}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
                  viewMode === 'report'
                    ? 'bg-indigo-600 text-white shadow-2xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>PDF Report</span>
              </button>
            </div>

            {/* Print / Save as PDF Button */}
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>

            {/* Fullscreen Toggle */}
            <button
              onClick={toggleFullscreen}
              className="p-1.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
              title={isFullscreen ? 'Exit Fullscreen (Esc)' : 'Enter Fullscreen (F)'}
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            {/* Close */}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs"
              title="Close presentation"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dashboard & Report Customizer Drawer / Modal Overlay */}
        {showConfigDrawer && (
          <div className="absolute inset-x-0 top-14 z-30 bg-slate-900 border-b border-indigo-500/40 shadow-2xl p-4 sm:p-6 animate-in slide-in-from-top-4 duration-200 text-xs">
            <div className="max-w-5xl mx-auto space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-indigo-400" />
                  <span className="font-extrabold text-sm text-white">
                    Dashboard & Reporting Configurator — Choose What is Needed to Report
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedCardIds(tracker.summaryCards.map(c => c.id));
                      setSelectedColumnIds(tracker.columns.filter(c => c.visible).map(c => c.id));
                      setSelectedSections({
                        dashboardKpis: true,
                        saqSlaTimeline: true,
                        financialBreakdown: true,
                        errandsChecklist: true,
                        dataTable: true
                      });
                      setFilterStatus('all');
                      setFilterPersonnel('all');
                    }}
                    className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-white"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset All to Default</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowConfigDrawer(false)}
                    className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Sub-tabs for configuration */}
              <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-2">
                <button
                  type="button"
                  onClick={() => setActiveConfigTab('cards')}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-colors ${
                    activeConfigTab === 'cards'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  1. Dashboard KPI Cards ({chosenSummaryCards.length}/{tracker.summaryCards.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveConfigTab('sections')}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-colors ${
                    activeConfigTab === 'sections'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  2. Presentation Slides ({dynamicSlides.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveConfigTab('columns')}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-colors ${
                    activeConfigTab === 'columns'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  3. Table Columns ({chosenColumns.length}/{tracker.columns.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveConfigTab('filters')}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-colors ${
                    activeConfigTab === 'filters'
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  4. Record Filters ({filteredRows.length}/{tracker.rows.length})
                </button>
              </div>

              {/* Tab 1: Dashboard KPI Cards */}
              {activeConfigTab === 'cards' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Select which dashboard cards appear on Slide 1 and in the executive summary:</span>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedCardIds(tracker.summaryCards.map(c => c.id))}
                        className="text-indigo-400 hover:underline"
                      >
                        Select All Cards
                      </button>
                      <span>•</span>
                      <button
                        type="button"
                        onClick={() => setSelectedCardIds([])}
                        className="text-slate-400 hover:underline"
                      >
                        Deselect All
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-60 overflow-y-auto custom-scrollbar p-1">
                    {tracker.summaryCards.map(card => {
                      const isChecked = selectedCardIds.includes(card.id);
                      const col = tracker.columns.find(c => c.id === card.columnId);
                      const computed = computeCardValue(card);

                      return (
                        <div
                          key={card.id}
                          onClick={() => {
                            setSelectedCardIds(prev =>
                              isChecked ? prev.filter(id => id !== card.id) : [...prev, card.id]
                            );
                          }}
                          className={`p-3 rounded-xl border cursor-pointer select-none transition-all flex items-start gap-2.5 ${
                            isChecked
                              ? 'border-indigo-500 bg-indigo-950/40 text-white ring-1 ring-indigo-500/50'
                              : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="mt-0.5">
                            {isChecked ? (
                              <CheckSquare className="w-4 h-4 text-indigo-400" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-600" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-1">
                              <span className="font-bold text-xs truncate text-white">{card.title}</span>
                              {card.tag && (
                                <span className="text-[9px] px-1.5 py-0.2 rounded font-semibold bg-slate-800 border border-slate-700 text-slate-300">
                                  {card.tag}
                                </span>
                              )}
                            </div>
                            <div className="text-base font-extrabold font-mono text-emerald-400 mt-0.5">
                              {computed.formatted}
                            </div>
                            <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-1">
                              <span>Formula: {card.calcType}</span>
                              <span>•</span>
                              <span>Column: {col?.name || card.columnId}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Tab 2: Presentation Slides & Sections */}
              {activeConfigTab === 'sections' && (
                <div className="space-y-3">
                  <span className="text-[11px] text-slate-400 block">
                    Choose which slides to include in your meeting presentation and export:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                    {[
                      { key: 'dashboardKpis', label: 'Executive Dashboard KPIs', desc: 'Displays chosen summary cards & KPI metrics', count: `${chosenSummaryCards.length} cards` },
                      { key: 'saqSlaTimeline', label: 'SAQ Process SLA & Milestones', desc: '21d Prop Docs / 44d Pre-Con / 21d Post-Con / 7d FAC', count: `${saqEvaluation.totalWarnings} alarms` },
                      { key: 'financialBreakdown', label: 'Financial & Capex Performance', desc: 'Disbursed budget vs approved contract spending', count: `${amountCols.length} amount cols` },
                      { key: 'errandsChecklist', label: 'Field Logistics & Task Checklist', desc: 'Completed checklist errands & assignees', count: `${allErrands.length} checkpoints` },
                      { key: 'dataTable', label: 'Records Audit Table', desc: 'Detailed table rows with selected columns', count: `${filteredRows.length} rows` }
                    ].map(item => {
                      const isChecked = selectedSections[item.key as keyof typeof selectedSections];
                      return (
                        <div
                          key={item.key}
                          onClick={() => {
                            setSelectedSections(prev => ({
                              ...prev,
                              [item.key]: !isChecked
                            }));
                          }}
                          className={`p-3 rounded-xl border cursor-pointer select-none transition-all flex items-start gap-2.5 ${
                            isChecked
                              ? 'border-indigo-500 bg-indigo-950/40 text-white ring-1 ring-indigo-500/50'
                              : 'border-slate-800 bg-slate-900/60 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="mt-0.5">
                            {isChecked ? (
                              <CheckSquare className="w-4 h-4 text-indigo-400" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-600" />
                            )}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-xs text-white">{item.label}</span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded font-semibold bg-slate-800 text-slate-300">
                                {item.count}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 mt-0.5">{item.desc}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Tab 3: Table Columns Selection */}
              {activeConfigTab === 'columns' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Choose which columns appear in the Data Table slide and PDF report:</span>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedColumnIds(tracker.columns.map(c => c.id))}
                        className="text-indigo-400 hover:underline"
                      >
                        Select All
                      </button>
                      <span>•</span>
                      <button
                        type="button"
                        onClick={() => setSelectedColumnIds(tracker.columns.filter(c => c.visible).map(c => c.id))}
                        className="text-slate-300 hover:underline"
                      >
                        Visible Only
                      </button>
                      <span>•</span>
                      <button
                        type="button"
                        onClick={() => setSelectedColumnIds([])}
                        className="text-slate-400 hover:underline"
                      >
                        Clear All
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto custom-scrollbar p-1">
                    {tracker.columns.map(col => {
                      const isChecked = selectedColumnIds.includes(col.id);
                      return (
                        <button
                          key={col.id}
                          type="button"
                          onClick={() => {
                            setSelectedColumnIds(prev =>
                              isChecked ? prev.filter(id => id !== col.id) : [...prev, col.id]
                            );
                          }}
                          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-all ${
                            isChecked
                              ? 'bg-indigo-600 text-white border-indigo-500 shadow-xs'
                              : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                          }`}
                        >
                          {isChecked ? <CheckSquare className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5" />}
                          <span>{col.name}</span>
                          <span className="text-[10px] opacity-70">({col.type === 'legal-checklist' ? '🛡️ legal checklist' : col.type})</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Tab 4: Record Filters */}
              {activeConfigTab === 'filters' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      Filter Records by Status:
                    </label>
                    <select
                      value={filterStatus}
                      onChange={e => setFilterStatus(e.target.value)}
                      className="w-full text-xs p-2 rounded-lg bg-slate-800 border border-slate-700 text-white outline-none"
                    >
                      <option value="all">All Records ({tracker.rows.length})</option>
                      <option value="completed">Completed / Closed Only</option>
                      <option value="open">Open / Pending In Progress Only</option>
                      <option value="overdue">Overdue SLA Sites Only ({saqEvaluation.overdueSites.length})</option>
                      <option value="stalled">Stalled Sites (&gt;14d Inactive) ({saqEvaluation.stalledSites.length})</option>
                    </select>
                  </div>

                  {personnelCol && (
                    <div className="space-y-1">
                      <label className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                        Filter by Responsible / Assignee:
                      </label>
                      <select
                        value={filterPersonnel}
                        onChange={e => setFilterPersonnel(e.target.value)}
                        className="w-full text-xs p-2 rounded-lg bg-slate-800 border border-slate-700 text-white outline-none"
                      >
                        <option value="all">All Personnel / Teams</option>
                        {allPersonnelList.map(p => (
                          <option key={p} value={p}>
                            {p}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}

              <div className="flex justify-end pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowConfigDrawer(false)}
                  className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-colors"
                >
                  Apply & Return to Presentation ({dynamicSlides.length} Slides Ready)
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Presentation Slide View Mode */}
        {viewMode === 'presentation' ? (
          <div className="flex-1 flex flex-col bg-slate-950 text-white overflow-hidden p-4 sm:p-8 select-none relative">
            {/* Top Slide Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-mono uppercase font-bold text-slate-300">
                  {appName} • {tracker.name}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs">
                  Slide <strong className="text-white font-mono">{activeSlideIndex + 1}</strong> of{' '}
                  <strong className="text-white font-mono">{dynamicSlides.length}</strong>
                </span>
                <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-lg">
                  <button
                    onClick={prevSlide}
                    className="p-1 rounded hover:bg-slate-700 text-slate-300 transition-colors"
                    title="Previous Slide (Left Arrow)"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={nextSlide}
                    className="p-1 rounded hover:bg-slate-700 text-slate-300 transition-colors"
                    title="Next Slide (Right Arrow / Space)"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Dynamic Slide Content Body */}
            <div className="flex-1 flex flex-col justify-center py-4 overflow-y-auto custom-scrollbar">
              {/* SLIDE 1: Executive Dashboard KPIs Slide */}
              {currentSlideData.id === 'dashboard-kpis' && (
                <div className="max-w-5xl mx-auto w-full space-y-6 animate-in fade-in zoom-in-95 duration-200">
                  <div className="text-center space-y-1.5">
                    <span className="text-[11px] font-mono font-bold tracking-widest text-indigo-400 uppercase bg-indigo-950/80 px-3 py-1 rounded-full border border-indigo-800">
                      Live Dashboard KPI Overview • Connected Tracker
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                      {tracker.name}
                    </h2>
                    <p className="text-xs text-slate-400 max-w-xl mx-auto">
                      {tracker.description || 'Milestone and expenditure tracking dashboard with live calculation reconciliation'}
                    </p>
                  </div>

                  {/* Render the user's chosen Dashboard Summary Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
                    {chosenSummaryCards.map(card => {
                      const col = tracker.columns.find(c => c.id === card.columnId);
                      const computed = computeCardValue(card);

                      return (
                        <div
                          key={card.id}
                          className={`p-4 rounded-2xl border ${getCardColorClasses(
                            card.color
                          )} shadow-lg space-y-1.5 relative overflow-hidden`}
                        >
                          <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-400">
                            <span className="truncate">{card.title}</span>
                            {card.tag && (
                              <span className="text-[9px] px-2 py-0.5 rounded-full bg-white/10 text-white border border-white/10 shrink-0">
                                {card.tag}
                              </span>
                            )}
                          </div>
                          <div className="text-2xl sm:text-3xl font-black text-white font-mono truncate">
                            {computed.formatted}
                          </div>
                          <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1 border-t border-white/5">
                            <span>Formula: {card.calcType}</span>
                            <span>{col?.name || card.columnId}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Quick Context & Operational Row Status Bar */}
                  <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-around gap-3 text-xs text-slate-300">
                    <div>
                      <span className="text-slate-500">Active Records:</span>{' '}
                      <strong className="text-white font-mono">{filteredRows.length}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500">Connected Columns:</span>{' '}
                      <strong className="text-indigo-400 font-mono">{chosenColumns.length}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500">Errands Verified:</span>{' '}
                      <strong className="text-emerald-400 font-mono">{completedErrandsCount} / {allErrands.length} ({errandCompletionRate}%)</strong>
                    </div>
                    {saqEvaluation.totalWarnings > 0 && (
                      <div className="flex items-center gap-1 text-amber-400 font-bold">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>{saqEvaluation.totalWarnings} SAQ SLA Alarms</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* SLIDE 2: SAQ Process SLA & Milestones Health */}
              {currentSlideData.id === 'saq-sla' && (
                <div className="max-w-5xl mx-auto w-full space-y-6 animate-in fade-in duration-200">
                  <div className="text-center space-y-1.5">
                    <span className="text-[11px] font-mono font-bold tracking-widest text-blue-400 uppercase bg-blue-950/80 px-3 py-1 rounded-full border border-blue-800">
                      Standard SAQ Milestones & SLA Timeline
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-black text-white">
                      Site Acquisition Process SLA Compliance
                    </h2>
                    <p className="text-xs text-slate-400">
                      Standard timelines: 21d Property Documents • 44d Pre-Con Permit • 21d Post-Con Permit • 7d FAC Submission (93d Target SLA)
                    </p>
                  </div>

                  {/* 4 Stage Breakdown Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {SAQ_STAGES.map((stage, idx) => {
                      const stageSites = saqEvaluation.reports.map(r => ({
                        report: r,
                        milestone: r.milestones.find(m => m.stageId === stage.id)
                      }));
                      const overdueCount = stageSites.filter(s => s.milestone?.isOverdue).length;
                      const warnCount = stageSites.filter(s => s.milestone?.isApproachingWeek).length;
                      const doneCount = stageSites.filter(s => s.milestone?.status === 'completed').length;

                      return (
                        <div
                          key={stage.id}
                          className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2"
                        >
                          <div className="flex items-center justify-between text-[10px] font-mono text-slate-400">
                            <span>Stage {idx + 1}</span>
                            <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30">
                              {stage.slaDays} Days SLA
                            </span>
                          </div>
                          <h4 className="font-bold text-sm text-white">{stage.name}</h4>
                          <p className="text-[10px] text-slate-400 line-clamp-2">{stage.description}</p>
                          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                            <span className="text-slate-400">Done: <strong className="text-white">{doneCount}</strong></span>
                            {overdueCount > 0 ? (
                              <span className="text-red-400 font-bold">🚨 {overdueCount} Overdue</span>
                            ) : warnCount > 0 ? (
                              <span className="text-amber-400 font-bold">⚠️ {warnCount} Warn</span>
                            ) : (
                              <span className="text-emerald-400 font-bold">✅ On Track</span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Stalled Sites Warning Banner */}
                  {saqEvaluation.stalledSites.length > 0 && (
                    <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-800 text-rose-200 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-rose-400 animate-spin" />
                        <span>
                          <strong>2-Week Stalled Alert:</strong> {saqEvaluation.stalledSites.length} site(s) have had no recorded movement in over 14 days. Daily movement logs required.
                        </span>
                      </div>
                      <span className="font-mono font-bold text-rose-300">
                        {saqEvaluation.stalledSites.map(s => s.siteId).slice(0, 3).join(', ')}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* SLIDE 3: Financial & Capex Performance */}
              {currentSlideData.id === 'financials' && (
                <div className="max-w-5xl mx-auto w-full space-y-6 animate-in fade-in duration-200">
                  <div className="text-center space-y-1.5">
                    <span className="text-[11px] font-mono font-bold tracking-widest text-emerald-400 uppercase bg-emerald-950/80 px-3 py-1 rounded-full border border-emerald-800">
                      Capex & Financial Performance
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-black text-white">
                      Disbursement, Liquidation & Expenditure
                    </h2>
                    <p className="text-xs text-slate-400">
                      Reconciled spending across all active contract items
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Total Capex Valued</span>
                      <div className="text-3xl font-black text-white font-mono">
                        {formatCurrency(totalAmountSum, currencySymbol)}
                      </div>
                      <span className="text-[10px] text-slate-400">Combined sum across {amountCols.length} amount column(s)</span>
                    </div>

                    <div className="p-5 rounded-2xl bg-indigo-950/40 border border-indigo-700/60 space-y-1">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-300">Verified Liquidations</span>
                      <div className="text-3xl font-black text-indigo-400 font-mono">
                        {formatCurrency(totalAmountSum * 0.65, currencySymbol)}
                      </div>
                      <span className="text-[10px] text-indigo-200/70">Estimated settled vouchers & contractor bills</span>
                    </div>

                    <div className="p-5 rounded-2xl bg-amber-950/40 border border-amber-700/60 space-y-1">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-amber-300">Active Pipeline Commitment</span>
                      <div className="text-3xl font-black text-amber-400 font-mono">
                        {formatCurrency(totalAmountSum * 0.35, currencySymbol)}
                      </div>
                      <span className="text-[10px] text-amber-200/70">Remaining unliquidated work in progress</span>
                    </div>
                  </div>
                </div>
              )}

              {/* SLIDE 4: Field Logistics & Checklists */}
              {currentSlideData.id === 'errands' && (
                <div className="max-w-5xl mx-auto w-full space-y-6 animate-in fade-in duration-200">
                  <div className="text-center space-y-1.5">
                    <span className="text-[11px] font-mono font-bold tracking-widest text-purple-400 uppercase bg-purple-950/80 px-3 py-1 rounded-full border border-purple-800">
                      Field Logistics & Task Verification
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-black text-white">
                      Field Errand & Site Operation Checkpoints
                    </h2>
                    <p className="text-xs text-slate-400">
                      Progress tracking for site inspections, notary, LGU submissions, and contractor coordination
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                      <h4 className="font-bold text-sm text-indigo-300 flex items-center gap-2">
                        <CheckSquare className="w-4 h-4 text-indigo-400" />
                        <span>Completion Rate: {errandCompletionRate}%</span>
                      </h4>
                      <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-indigo-500 h-full rounded-full transition-all duration-500"
                          style={{ width: `${errandCompletionRate}%` }}
                        />
                      </div>
                      <p className="text-xs text-slate-400">
                        {completedErrandsCount} of {allErrands.length} field checkpoints have been checked and verified by engineering teams.
                      </p>
                    </div>

                    <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                      <h4 className="font-bold text-sm text-white flex items-center gap-2">
                        <CheckSquare className="w-4 h-4 text-emerald-400" />
                        <span>Recent Active Checkpoints</span>
                      </h4>
                      <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar pr-1">
                        {allErrands.length === 0 ? (
                          <p className="text-xs text-slate-500 italic">No checklist items defined in text fields.</p>
                        ) : (
                          allErrands.slice(0, 6).map((errand, i) => (
                            <div key={i} className="flex items-center gap-2 text-xs">
                              {errand.isChecked ? (
                                <CheckSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              ) : (
                                <Square className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                              )}
                              <span className={`truncate ${errand.isChecked ? 'line-through text-slate-500' : 'text-slate-200'}`}>
                                {errand.text}
                              </span>
                              <span className="text-[10px] text-slate-500 shrink-0 font-mono">
                                ({errand.personnel})
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* SLIDE 5: Site & Project Operations Audit Table */}
              {currentSlideData.id === 'table-data' && (
                <div className="max-w-5xl mx-auto w-full space-y-4 animate-in fade-in duration-200">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h3 className="text-xl font-bold text-white">Records Audit Slide</h3>
                      <p className="text-xs text-slate-400">
                        Showing {filteredRows.length} record(s) across {chosenColumns.length} selected column(s)
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowConfigDrawer(true)}
                      className="text-xs font-semibold text-indigo-400 hover:underline"
                    >
                      Change Columns / Filter
                    </button>
                  </div>

                  <div className="rounded-xl border border-slate-800 bg-slate-900 overflow-x-auto max-h-[52vh] custom-scrollbar">
                    <table className="w-full text-left text-xs text-slate-200">
                      <thead className="sticky top-0 bg-slate-800 border-b border-slate-700 text-slate-300 font-bold uppercase text-[10px]">
                        <tr>
                          <th className="p-2.5 w-10 text-center font-mono">#</th>
                          {chosenColumns.map(col => (
                            <th key={col.id} className="p-2.5 whitespace-nowrap">
                              {col.name}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 font-normal">
                        {filteredRows.slice(0, 15).map((row, idx) => (
                          <tr key={row.id || idx} className="hover:bg-slate-800/50">
                            <td className="p-2.5 text-center font-mono text-slate-500">{idx + 1}</td>
                            {chosenColumns.map(col => {
                              const val = row[col.id];
                              if (col.type === 'amount') {
                                return (
                                  <td key={col.id} className="p-2.5 font-mono text-emerald-400 whitespace-nowrap">
                                    {formatCurrency(parseNum(val), col.currencySymbol || '₱')}
                                  </td>
                                );
                              }
                              if (col.type === 'percent') {
                                return (
                                  <td key={col.id} className="p-2.5 text-center font-bold text-amber-400 whitespace-nowrap">
                                    {formatPercent(parseNum(val))}
                                  </td>
                                );
                              }
                              if (col.type === 'status') {
                                return (
                                  <td key={col.id} className="p-2.5 whitespace-nowrap">
                                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                                      {String(val || 'Pending')}
                                    </span>
                                  </td>
                                );
                              }
                              if (col.type === 'legal-checklist') {
                                let list: any[] = [];
                                if (Array.isArray(val)) list = val;
                                else if (typeof val === 'string' && val.trim().startsWith('[')) {
                                  try { list = JSON.parse(val); } catch {}
                                }
                                const done = list.filter((i: any) => i.status === 'Completed').length;
                                const tot = list.length || 8;
                                return (
                                  <td key={col.id} className="p-2.5 whitespace-nowrap">
                                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-600/50">
                                      🛡️ Checklist ({done}/{tot})
                                    </span>
                                  </td>
                                );
                              }
                              return (
                                <td key={col.id} className="p-2.5 truncate max-w-xs text-slate-300">
                                  {String(val || '')}
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {filteredRows.length > 15 && (
                    <div className="text-center text-[11px] text-slate-500">
                      Showing top 15 records in presentation view. Full {filteredRows.length} records available in PDF Report mode.
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Bottom Slide Thumbnails & Switcher Bar */}
            <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-1.5 flex-wrap">
                {dynamicSlides.map((slide, idx) => (
                  <button
                    key={slide.id}
                    onClick={() => setCurrentSlide(idx)}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold transition-all ${
                      idx === activeSlideIndex
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    <span>{idx + 1}. {slide.title}</span>
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                <span>Keys: Space / Arrows to navigate • F for fullscreen</span>
              </div>
            </div>
          </div>
        ) : (
          /* PDF Report Mode */
          <div className="flex-1 bg-white text-slate-900 p-6 sm:p-10 overflow-y-auto custom-scrollbar select-text print:p-0">
            {/* Report Header */}
            <div className="border-b-2 border-slate-900 pb-4 mb-6 flex flex-wrap items-center justify-between gap-4">
              <div>
                <span className="text-[10px] font-mono uppercase font-bold tracking-widest text-indigo-700">
                  {appName} • Executive Audit & Operations Briefing
                </span>
                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-0.5">
                  {tracker.name}
                </h1>
                <p className="text-xs text-slate-600 mt-1 max-w-xl">
                  {tracker.description || 'Milestone and expenditure tracking dashboard with live calculation reconciliation'}
                </p>
              </div>

              <div className="text-right text-xs text-slate-600 space-y-1">
                <div>Date: <strong className="text-slate-900 font-mono">2026-10-04</strong></div>
                <div>Auditor / User: <strong className="text-slate-900">{currentUser?.username || 'Executive Review'}</strong></div>
                <div className="text-[10px] text-slate-500">Classification: CONFIDENTIAL</div>
              </div>
            </div>

            {/* Connected Dashboard Summary KPIs Section */}
            {selectedSections.dashboardKpis && chosenSummaryCards.length > 0 && (
              <div className="mb-6 space-y-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <BarChart3 className="w-4 h-4 text-indigo-600" />
                    <span>Selected Dashboard Summary KPIs</span>
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {chosenSummaryCards.length} Live Metrics
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {chosenSummaryCards.map(card => {
                    const computed = computeCardValue(card);
                    return (
                      <div key={card.id} className="p-3 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                        <div className="flex items-center justify-between text-[10px] font-bold text-slate-500 uppercase">
                          <span className="truncate">{card.title}</span>
                          {card.tag && <span className="text-[9px] text-indigo-600 font-mono">{card.tag}</span>}
                        </div>
                        <div className="text-xl font-extrabold text-slate-900 font-mono">
                          {computed.formatted}
                        </div>
                        <div className="text-[9px] text-slate-400 font-mono">
                          Calc: {card.calcType}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* SAQ Process SLA Overview if selected */}
            {selectedSections.saqSlaTimeline && (
              <div className="mb-6 space-y-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span>Site Acquisition (SAQ) SLA Compliance Roadmaps</span>
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono">
                    Total 93-Day Target SLA
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                  {SAQ_STAGES.map((s, idx) => (
                    <div key={s.id} className="p-2.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="text-[9px] font-mono text-slate-500 uppercase">Stage {idx + 1} ({s.slaDays}d)</span>
                      <h5 className="font-bold text-slate-800 text-[11px] truncate">{s.name}</h5>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Table Data Section */}
            {selectedSections.dataTable && chosenColumns.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                  <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <FileText className="w-4 h-4 text-indigo-600" />
                    <span>Records Audit Breakdown</span>
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {filteredRows.length} Records • {chosenColumns.length} Columns
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-100 border-b border-slate-300 text-slate-700 font-bold uppercase text-[10px]">
                        <th className="p-2 border border-slate-300 w-8 text-center font-mono">#</th>
                        {chosenColumns.map(col => (
                          <th key={col.id} className="p-2 border border-slate-300 whitespace-nowrap">
                            {col.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {filteredRows.map((row, idx) => (
                        <tr key={row.id || idx} className="hover:bg-slate-50">
                          <td className="p-2 border border-slate-300 text-center font-mono text-slate-500">{idx + 1}</td>
                          {chosenColumns.map(col => {
                            const val = row[col.id];
                            if (col.type === 'amount') {
                              return (
                                <td key={col.id} className="p-2 border border-slate-300 font-mono font-bold text-right text-slate-900 whitespace-nowrap">
                                  {formatCurrency(parseNum(val), col.currencySymbol || '₱')}
                                </td>
                              );
                            }
                            if (col.type === 'percent') {
                              return (
                                <td key={col.id} className="p-2 border border-slate-300 text-center font-bold text-amber-700 whitespace-nowrap">
                                  {formatPercent(parseNum(val))}
                                </td>
                              );
                            }
                            if (col.type === 'status') {
                              return (
                                <td key={col.id} className="p-2 border border-slate-300 text-center whitespace-nowrap">
                                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 border border-slate-300 text-slate-800">
                                    {String(val || 'Pending')}
                                  </span>
                                </td>
                              );
                            }
                            if (col.type === 'legal-checklist') {
                              let list: any[] = [];
                              if (Array.isArray(val)) list = val;
                              else if (typeof val === 'string' && val.trim().startsWith('[')) {
                                try { list = JSON.parse(val); } catch {}
                              }
                              const done = list.filter((i: any) => i.status === 'Completed').length;
                              const tot = list.length || 8;
                              return (
                                <td key={col.id} className="p-2 border border-slate-300 text-center whitespace-nowrap">
                                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-50 text-amber-900 border border-amber-300">
                                    Checklist ({done}/{tot})
                                  </span>
                                </td>
                              );
                            }
                            return (
                              <td key={col.id} className="p-2 border border-slate-300 align-top text-slate-800">
                                {renderFormattedContent(val, { isCompact: true })}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Signature & Audit Signoff Block */}
            <div className="pt-6 border-t-2 border-slate-200 mt-8 grid grid-cols-3 gap-6 text-xs text-slate-700">
              <div className="space-y-6">
                <span className="font-bold uppercase tracking-wider text-[10px] text-slate-500">Prepared By:</span>
                <div className="border-t border-slate-400 pt-1.5 font-semibold">
                  <div>Field Engineer / Admin Staff</div>
                  <div className="text-[10px] text-slate-400">Date: _______________</div>
                </div>
              </div>
              <div className="space-y-6">
                <span className="font-bold uppercase tracking-wider text-[10px] text-slate-500">Audited & Verified:</span>
                <div className="border-t border-slate-400 pt-1.5 font-semibold">
                  <div>QA/QC Lead / Site Manager</div>
                  <div className="text-[10px] text-slate-400">Date: _______________</div>
                </div>
              </div>
              <div className="space-y-6">
                <span className="font-bold uppercase tracking-wider text-[10px] text-slate-500">Approved for Liquidation:</span>
                <div className="border-t border-slate-400 pt-1.5 font-semibold">
                  <div>Project Director / Finance Lead</div>
                  <div className="text-[10px] text-slate-400">Date: _______________</div>
                </div>
              </div>
            </div>

            {/* Report Footer */}
            <div className="border-t border-slate-200 pt-4 mt-8 flex items-center justify-between text-[10px] text-slate-400">
              <div>CONFIDENTIAL — For Authorized SAQC & Civil Team Review Only</div>
              <div>System Generated by {appName} Multi-Tracker Studio • Preserved Rich Formatting</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
