import React, { useState, useMemo } from 'react';
import {
  AlertTriangle,
  Clock,
  Calendar,
  CheckCircle2,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  FolderKanban,
  ArrowRight,
  FileText,
  RotateCcw,
  Sparkles,
  ShieldAlert,
  Folder,
  Check
} from 'lucide-react';
import { Tracker, AppState, TrackerFolder, Row } from '../types/tracker';
import {
  evaluateAllSitesSaq,
  SAQ_STAGES,
  formatDateYMD
} from '../utils/saqSlaEngine';

interface SaqProcessWarningBannerProps {
  currentTracker: Tracker;
  state: AppState;
  onOpenWarningModal: () => void;
  onOpenDayByDay?: (siteRow: Row) => void;
  onFilterTable?: (term: string) => void;
  onUpdateSiteMovement?: (siteId: string, note?: string) => void;
  onMoveTrackerToFolder?: (trackerId: string, folderId: string | null) => void;
  onNotify?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const SaqProcessWarningBanner: React.FC<SaqProcessWarningBannerProps> = ({
  currentTracker,
  state,
  onOpenWarningModal,
  onOpenDayByDay,
  onFilterTable,
  onUpdateSiteMovement,
  onMoveTrackerToFolder,
  onNotify
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gaela_saq_banner_expanded') !== 'false';
    } catch {
      return true;
    }
  });

  const [showFolderMenu, setShowFolderMenu] = useState<boolean>(false);
  const [quickSiteId, setQuickSiteId] = useState<string>('');
  const [quickMovementNote, setQuickMovementNote] = useState<string>('');
  const [isLoggingMovement, setIsLoggingMovement] = useState<boolean>(false);

  const toggleExpand = () => {
    setIsExpanded(prev => {
      const next = !prev;
      try {
        localStorage.setItem('gaela_saq_banner_expanded', String(next));
      } catch {}
      return next;
    });
  };

  // Evaluate SLA health for current tracker strictly based on Day-by-Day data
  const evaluation = useMemo(() => {
    return evaluateAllSitesSaq(currentTracker.rows, formatDateYMD(new Date()));
  }, [currentTracker.rows]);

  const {
    totalSites,
    overdueSites,
    approachingWeekSites,
    stalledSites,
    onTrackSites,
    completedSites,
    totalWarnings
  } = evaluation;

  // Current Tracker's Folder
  const currentFolder = state.folders?.find(f => f.id === currentTracker.folderId);

  // Handle Quick Movement Logging
  const handleQuickLogMovement = () => {
    if (!quickSiteId) {
      onNotify?.('Please select or specify a site ID to log movement.', 'info');
      return;
    }
    onUpdateSiteMovement?.(quickSiteId, quickMovementNote.trim() || 'Daily site activity logged via SLA Banner');
    onNotify?.(`Daily movement logged for ${quickSiteId}! Inactivity timer refreshed.`, 'success');
    setQuickSiteId('');
    setQuickMovementNote('');
    setIsLoggingMovement(false);
  };

  return (
    <div className="mb-4 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 shadow-sm overflow-hidden transition-all">
      {/* Banner Top Header */}
      <div className="p-3 sm:p-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-400 shrink-0">
            <ShieldAlert className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-extrabold text-sm sm:text-base tracking-tight text-white flex items-center gap-1.5">
                <span>Site Acquisition (SAQ) SLA & Early Warning Center</span>
              </span>
              
              {/* Folder Breadcrumb & Quick Move */}
              <div className="relative inline-block">
                <button
                  type="button"
                  onClick={() => setShowFolderMenu(!showFolderMenu)}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-white/10 hover:bg-white/20 text-indigo-200 border border-white/15 transition-colors"
                  title="Click to organize or change folder"
                >
                  <Folder className="w-3 h-3 text-indigo-300" />
                  <span>{currentFolder ? currentFolder.name : 'Unfiled Folder'}</span>
                  <ChevronDown className="w-3 h-3 text-white/60" />
                </button>

                {showFolderMenu && (
                  <div
                    onClick={e => e.stopPropagation()}
                    className="absolute left-0 mt-1 w-56 rounded-lg bg-slate-900 text-white border border-slate-700 shadow-2xl p-1.5 z-50 text-xs space-y-1"
                  >
                    <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
                      <span>Organize in Folder:</span>
                      <button onClick={() => setShowFolderMenu(false)} className="text-slate-400 hover:text-white">✕</button>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onMoveTrackerToFolder?.(currentTracker.id, null);
                        setShowFolderMenu(false);
                      }}
                      className={`w-full text-left px-2 py-1.5 rounded flex items-center justify-between ${
                        !currentTracker.folderId ? 'bg-indigo-600 text-white' : 'hover:bg-white/10 text-slate-300'
                      }`}
                    >
                      <span>📂 Unfiled (No Folder)</span>
                      {!currentTracker.folderId && <Check className="w-3.5 h-3.5" />}
                    </button>
                    {(state.folders || []).map(f => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => {
                          onMoveTrackerToFolder?.(currentTracker.id, f.id);
                          setShowFolderMenu(false);
                        }}
                        className={`w-full text-left px-2 py-1.5 rounded flex items-center justify-between ${
                          currentTracker.folderId === f.id ? 'bg-indigo-600 text-white' : 'hover:bg-white/10 text-slate-300'
                        }`}
                      >
                        <span className="truncate">📁 {f.name}</span>
                        {currentTracker.folderId === f.id && <Check className="w-3.5 h-3.5" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <p className="text-[11px] text-slate-300 mt-0.5">
              Standard Milestones: 21d Property Docs • 44d Pre-Con Permit • 21d Post-Con Permit • 7d FAC (93d Target SLA)
            </p>
          </div>
        </div>

        {/* Warning Metrics Badges */}
        <div className="flex items-center gap-2 flex-wrap">
          {overdueSites.length > 0 && (
            <button
              onClick={() => onFilterTable?.('overdue')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-200 border border-red-500/40 text-xs font-bold transition-colors"
              title="Click to filter overdue sites"
            >
              <AlertCircle className="w-3.5 h-3.5 text-red-400" />
              <span>{overdueSites.length} Overdue SLA</span>
            </button>
          )}

          {approachingWeekSites.length > 0 && (
            <button
              onClick={() => onFilterTable?.('warning')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-500/40 text-xs font-bold transition-colors"
              title="Click to filter 1-week approaching warnings"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>{approachingWeekSites.length} Due in 1-Week</span>
            </button>
          )}

          {stalledSites.length > 0 && (
            <button
              onClick={() => onFilterTable?.('stalled')}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/40 text-xs font-bold transition-colors"
              title="Click to filter sites with no movement in 2 weeks"
            >
              <Clock className="w-3.5 h-3.5 text-rose-400 animate-spin" />
              <span>{stalledSites.length} Stalled (&gt;14d)</span>
            </button>
          )}

          {totalWarnings === 0 && (
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-200 border border-emerald-500/40 text-xs font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>All Sites On Track</span>
            </span>
          )}

          {/* Open Full Day-by-Day Modal */}
          <button
            onClick={onOpenWarningModal}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-sm transition-colors"
            title="Open comprehensive SAQ SLA report and day-by-day site logs"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Day-by-Day Report</span>
          </button>

          {/* Expand/Collapse Toggle */}
          <button
            onClick={toggleExpand}
            className="p-1 rounded text-white/70 hover:text-white hover:bg-white/10 transition-colors"
            title={isExpanded ? 'Collapse SLA Banner' : 'Expand SLA Banner'}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="p-3 sm:p-4 space-y-3 bg-slate-50/60 dark:bg-zinc-900/60 border-t border-slate-200/80 dark:border-zinc-800">
          {/* Stalled Sites Day-by-Day Alert Notice if any stalled */}
          {stalledSites.length > 0 && (
            <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-900 dark:text-rose-200 flex flex-wrap items-center justify-between gap-2.5 text-xs">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0" />
                <span>
                  <strong>2-Week Stalled Activity Alert:</strong> {stalledSites.length} site(s) have had <strong>no recorded movement in over 14 days</strong> ({stalledSites.map(s => s.siteId).slice(0, 3).join(', ')}{stalledSites.length > 3 ? '...' : ''}). Regular day-by-day reports must be filed to prevent milestone slippage.
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsLoggingMovement(!isLoggingMovement)}
                  className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold shadow-2xs"
                >
                  {isLoggingMovement ? 'Close Quick Log' : 'Log Movement Now'}
                </button>
                <button
                  type="button"
                  onClick={onOpenWarningModal}
                  className="px-2.5 py-1 rounded bg-white dark:bg-zinc-800 border border-rose-300 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-zinc-700 text-[11px] font-bold"
                >
                  View Warning Report
                </button>
                {onOpenDayByDay && (
                  <button
                    type="button"
                    onClick={() => {
                      const firstWarningSite = overdueSites[0] || approachingWeekSites[0] || stalledSites[0] || evaluation.reports[0];
                      if (firstWarningSite) {
                        const targetRow = currentTracker.rows.find(
                          r => r.col_site_id === firstWarningSite.siteId || r.id === firstWarningSite.siteId
                        );
                        if (targetRow) onOpenDayByDay(targetRow);
                      }
                    }}
                    className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold shadow-2xs flex items-center gap-1"
                    title="Open per-site Day-by-Day progress tracker"
                  >
                    <Calendar className="w-3 h-3" />
                    <span>Open Day-by-Day Tracker</span>
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Quick Movement Logging Form */}
          {isLoggingMovement && (
            <div className="p-3 rounded-lg bg-white dark:bg-zinc-800 border border-indigo-200 dark:border-indigo-900 shadow-sm space-y-2">
              <div className="text-xs font-bold text-slate-800 dark:text-zinc-100 flex items-center justify-between">
                <span>📝 Log Today's Movement & Update Site Activity</span>
                <button onClick={() => setIsLoggingMovement(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200">✕</button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] uppercase font-bold text-slate-500 dark:text-zinc-400 block mb-0.5">Select Stalled Site</label>
                  <select
                    value={quickSiteId}
                    onChange={e => setQuickSiteId(e.target.value)}
                    className="w-full text-xs p-1.5 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100"
                  >
                    <option value="">-- Choose Site --</option>
                    {stalledSites.map(s => (
                      <option key={s.siteId} value={s.siteId}>
                        {s.siteId} - {s.siteName} ({s.daysSinceLastMovement}d inactive)
                      </option>
                    ))}
                    {evaluation.reports.map(r => (
                      <option key={`all-${r.siteId}`} value={r.siteId}>
                        {r.siteId} - {r.siteName}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="text-[10px] uppercase font-bold text-slate-500 dark:text-zinc-400 block mb-0.5">Daily Movement Progress Note</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. Attended LGU zoning hearing, secured Barangay endorsement..."
                      value={quickMovementNote}
                      onChange={e => setQuickMovementNote(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleQuickLogMovement()}
                      className="flex-1 text-xs p-1.5 rounded border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-slate-900 dark:text-zinc-100 outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleQuickLogMovement}
                      className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0"
                    >
                      Update Date
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 4 SAQ Standard Stage Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
            {SAQ_STAGES.map((stage, idx) => {
              // Count status for this stage across sites
              const stageSites = evaluation.reports.map(r => {
                const m = r.milestones.find(ms => ms.stageId === stage.id);
                return { report: r, milestone: m };
              });
              const overdueCount = stageSites.filter(s => s.milestone?.isOverdue).length;
              const warningCount = stageSites.filter(s => s.milestone?.isApproachingWeek).length;
              const completedCount = stageSites.filter(s => s.milestone?.status === 'completed').length;

              const stageColors = [
                { border: 'border-blue-200 dark:border-blue-900', bg: 'bg-blue-50/50 dark:bg-blue-950/20', text: 'text-blue-700 dark:text-blue-300', badge: 'bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200' },
                { border: 'border-purple-200 dark:border-purple-900', bg: 'bg-purple-50/50 dark:bg-purple-950/20', text: 'text-purple-700 dark:text-purple-300', badge: 'bg-purple-100 dark:bg-purple-900/60 text-purple-800 dark:text-purple-200' },
                { border: 'border-amber-200 dark:border-amber-900', bg: 'bg-amber-50/50 dark:bg-amber-950/20', text: 'text-amber-700 dark:text-amber-300', badge: 'bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200' },
                { border: 'border-emerald-200 dark:border-emerald-900', bg: 'bg-emerald-50/50 dark:bg-emerald-950/20', text: 'text-emerald-700 dark:text-emerald-300', badge: 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200' },
              ][idx % 4];

              return (
                <div
                  key={stage.id}
                  className={`p-3 rounded-xl border ${stageColors.border} ${stageColors.bg} space-y-2`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-bold uppercase text-slate-400">
                      Stage {idx + 1} of 4
                    </span>
                    <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${stageColors.badge}`}>
                      {stage.slaDays} Days SLA
                    </span>
                  </div>

                  <div>
                    <h4 className={`font-bold text-xs ${stageColors.text} truncate`}>
                      {stage.name}
                    </h4>
                    <p className="text-[10px] text-slate-500 dark:text-zinc-400 line-clamp-1 mt-0.5" title={stage.description}>
                      {stage.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 dark:border-zinc-800/80 text-[11px]">
                    <span className="text-slate-500 dark:text-zinc-400">Done: {completedCount}</span>
                    <div className="flex items-center gap-1 font-bold">
                      {overdueCount > 0 && (
                        <span className="text-red-600 dark:text-red-400" title={`${overdueCount} sites overdue in this stage`}>
                          🚨 {overdueCount} Overdue
                        </span>
                      )}
                      {warningCount > 0 && (
                        <span className="text-amber-600 dark:text-amber-400" title={`${warningCount} sites within 1 week of deadline`}>
                          ⚠️ {warningCount} Warn
                        </span>
                      )}
                      {overdueCount === 0 && warningCount === 0 && (
                        <span className="text-emerald-600 dark:text-emerald-400">
                          ✅ Clear
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Filter Pill Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-zinc-400">Quick Filter:</span>
              <button
                type="button"
                onClick={() => onFilterTable?.('')}
                className="px-2 py-0.5 rounded-full bg-white dark:bg-zinc-800 border border-slate-200 dark:border-zinc-700 hover:bg-slate-100 dark:hover:bg-zinc-700 text-slate-700 dark:text-zinc-300 text-[11px]"
              >
                All Sites ({totalSites})
              </button>
              {overdueSites.length > 0 && (
                <button
                  type="button"
                  onClick={() => onFilterTable?.('overdue')}
                  className="px-2 py-0.5 rounded-full bg-red-100 dark:bg-red-950/60 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 text-[11px] font-bold"
                >
                  Overdue SLA ({overdueSites.length})
                </button>
              )}
              {approachingWeekSites.length > 0 && (
                <button
                  type="button"
                  onClick={() => onFilterTable?.('warning')}
                  className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-900 text-amber-700 dark:text-amber-300 text-[11px] font-bold"
                >
                  1-Week Early Warnings ({approachingWeekSites.length})
                </button>
              )}
              {stalledSites.length > 0 && (
                <button
                  type="button"
                  onClick={() => onFilterTable?.('stalled')}
                  className="px-2 py-0.5 rounded-full bg-rose-100 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-[11px] font-bold"
                >
                  Stalled &gt;14 Days ({stalledSites.length})
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onOpenWarningModal}
                className="inline-flex items-center gap-1 text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                <span>View Full Day-by-Day Timeline Audit & Print Report</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
