import React, { useState } from 'react';
import { Sliders, Trash2, Check, Cloud, Database, Wifi, ShieldAlert, Key } from 'lucide-react';
import { AppState, Tracker, User } from '../types/tracker';

interface SettingsModalProps {
  state: AppState;
  activeTracker: Tracker;
  currentUser: User | null;
  isOnline: boolean;
  isDark: boolean;
  onClose: () => void;
  onSaveSettings: (appName: string, appSubtitle: string) => void;
  onDeleteCurrentTracker: () => void;
  onOpenChangePassword?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  state,
  activeTracker,
  currentUser,
  isOnline,
  isDark,
  onClose,
  onSaveSettings,
  onDeleteCurrentTracker,
  onOpenChangePassword
}) => {
  const [appName, setAppName] = useState(state.appName);
  const [appSubtitle, setAppSubtitle] = useState(state.appSubtitle);

  const [confirmDelete, setConfirmDelete] = useState(false);

  const handleSave = () => {
    onSaveSettings(appName.trim() || 'Gaela', appSubtitle.trim());
    onClose();
  };

  const handleDelete = () => {
    if (state.trackers.length <= 1) {
      return;
    }
    if (!confirmDelete) {
      setConfirmDelete(true);
      return;
    }
    onDeleteCurrentTracker();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-lg rounded-2xl border shadow-xl flex flex-col overflow-hidden ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="font-bold text-sm">Tracker & Workspace Settings</h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Customize workspace branding, cloud database and storage
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-slate-600">
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 text-xs">
          {/* Tracker Brand Name */}
          <div>
            <label className="font-bold text-slate-700 dark:text-zinc-300 block mb-1">
              Main Tracker Name
            </label>
            <input
              type="text"
              value={appName}
              onChange={e => setAppName(e.target.value)}
              placeholder="Gaela"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
            />
            <p className="text-[10px] text-slate-400 mt-1">Default branding: <strong>Gaela</strong></p>
          </div>

          <div>
            <label className="font-bold text-slate-700 dark:text-zinc-300 block mb-1">
              Workspace Subtitle
            </label>
            <input
              type="text"
              value={appSubtitle}
              onChange={e => setAppSubtitle(e.target.value)}
              placeholder="Customizable Multi-Tracker Studio"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none"
            />
          </div>

          {/* Cloud Database Info */}
          <div className="p-3.5 rounded-xl border border-slate-200 dark:border-zinc-800 bg-slate-50 dark:bg-zinc-800/50 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-zinc-200">
                <Database className="w-4 h-4 text-emerald-500" />
                <span>Free Cloud Database & Team Sharing</span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                isOnline ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
              }`}>
                {isOnline ? 'Connected & Synced' : 'Offline Cache'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-zinc-400 leading-relaxed">
              Data is automatically shared with team members and friends who open this application. In case of network disconnection, the app switches to local offline storage and synchronizes automatically upon reconnecting.
            </p>
          </div>

          {/* Admin Security: Change Password */}
          {currentUser?.role === 'admin' && (
            <div className="p-3.5 rounded-xl border border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/50 dark:bg-indigo-950/20 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-indigo-950 dark:text-indigo-200">
                  <Key className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>Admin Password & Credentials</span>
                </div>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-900 text-indigo-700 dark:text-indigo-300">
                  Admin Security
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-zinc-400">
                Update or set a new private password for <strong>{currentUser.username && currentUser.username.toLowerCase().includes('malonzo') ? 'Administrator' : (currentUser.username || 'Administrator')}</strong> to restrict administrative control.
              </p>
              {onOpenChangePassword && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenChangePassword();
                    onClose();
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-xs transition-colors"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>Change Admin Password</span>
                </button>
              )}
            </div>
          )}

          {/* Delete active tracker */}
          {currentUser?.role === 'admin' && (
            <div className="p-3.5 rounded-xl border border-red-200 dark:border-red-950/60 bg-red-50/50 dark:bg-red-950/20 space-y-2">
              <div className="flex items-center gap-2 font-bold text-red-700 dark:text-red-400">
                <ShieldAlert className="w-4 h-4" />
                <span>Danger Zone: Delete Active Tracker</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-zinc-400">
                Permanently delete <strong className="text-slate-800 dark:text-zinc-200">{activeTracker.name}</strong> ({activeTracker.rows.length} rows). This action cannot be undone.
              </p>
              <button
                onClick={handleDelete}
                disabled={state.trackers.length <= 1}
                className={`px-3 py-1.5 rounded-lg text-white font-semibold text-xs shadow-xs disabled:opacity-40 transition-colors ${
                  confirmDelete ? 'bg-red-700 hover:bg-red-800 ring-2 ring-red-400' : 'bg-red-600 hover:bg-red-700'
                }`}
              >
                {confirmDelete ? 'Click to Confirm Permanent Deletion' : 'Delete Current Tracker'}
              </button>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-end gap-2 bg-slate-50/50 dark:bg-zinc-800/40">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg text-slate-600 dark:text-zinc-300 hover:bg-slate-200 dark:hover:bg-zinc-700"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs"
          >
            <Check className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </div>
      </div>
    </div>
  );
};
