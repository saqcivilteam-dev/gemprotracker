import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Download,
  Printer,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Building2,
  User,
  MapPin,
  Flame,
  FileSpreadsheet,
  Activity,
  Layers,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Settings2,
  FileText
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Row, Column, DayByDayUpdateEntry, SaqProcessStatus } from '../types/tracker';
import {
  SAQ_PROCESS_STATUS_OPTIONS,
  STATUS_BADGE_STYLES,
  getSuggestedSlaRule,
  getOfficialSlaStartDate,
  calculateDayByDaySla,
  generateDefaultDayByDayLog
} from '../utils/dayByDayUtils';
import { formatDateYMD } from '../utils/saqSlaEngine';

interface DayByDayModalProps {
  isOpen: boolean;
  onClose: () => void;
  siteRow: Row;
  column?: Column;
  onUpdateDayByDay: (updatedLogs: DayByDayUpdateEntry[]) => void;
  onOpenWarningCenter?: () => void;
  onOpenColumnManager?: () => void;
  onNotify?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DayByDayModal: React.FC<DayByDayModalProps> = ({
  isOpen,
  onClose,
  siteRow,
  column,
  onUpdateDayByDay,
  onOpenWarningCenter,
  onOpenColumnManager,
  onNotify
}) => {
  // Extract site identity
  const siteId = String(siteRow.col_site_id || siteRow.id || 'SAQ-SITE-001');
  const siteName = String(siteRow.col_site_name || 'Cell Site Macro Tower');
  const location = String(siteRow.col_location || 'NCR / Metro Manila');
  const pic = String(siteRow.col_responsible || 'JHENG QUINTO');
  const assignedTeam = String(siteRow.col_assigned_team || 'SAQC Civil Team');
  const surveyDateFromRow = String(siteRow.col_survey_date || siteRow.col_saq_hunting_date || '');

  // Parse items from siteRow[column.id]
  const initialItems = useMemo<DayByDayUpdateEntry[]>(() => {
    const colKey = column?.id || 'col_day_by_day';
    const raw = siteRow[colKey];
    if (Array.isArray(raw) && raw.length > 0) {
      return raw;
    }
    if (typeof raw === 'string' && raw.trim().startsWith('[')) {
      try {
        const decoded = JSON.parse(raw);
        if (Array.isArray(decoded) && decoded.length > 0) {
          return decoded;
        }
      } catch {}
    }

    // Default fallback logs initialized starting from Site Hunting date
    const huntingDate = String(siteRow.col_saq_hunting_date || siteRow.col_survey_date || '2026-08-01');
    const defaultStage: SaqProcessStatus =
      siteRow.col_saq_precon_status === 'In Progress' ? 'Pre-Con' :
      siteRow.col_saq_prop_docs_status === 'In Progress' ? 'Pro Docs' :
      siteRow.col_saq_poscon_status === 'In Progress' ? 'Post-Con' : 'Pre-Con';

    return generateDefaultDayByDayLog(siteId, siteName, huntingDate, defaultStage);
  }, [siteRow, column, siteId, siteName]);

  const [items, setItems] = useState<DayByDayUpdateEntry[]>(initialItems);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form inputs for new entry (encoded automatically with real-time date or site survey date)
  const [newDate, setNewDate] = useState<string>(() => formatDateYMD(new Date()));
  const [newStatus, setNewStatus] = useState<SaqProcessStatus>('Pre-Con');
  const [newProgress, setNewProgress] = useState<string>('');
  const [newRemarks, setNewRemarks] = useState<string>('');
  const [newSlaRule, setNewSlaRule] = useState<string>(() => getSuggestedSlaRule('Pre-Con'));
  const [newSurveyDate, setNewSurveyDate] = useState<string>(surveyDateFromRow);

  // Editing draft state
  const [editDate, setEditDate] = useState<string>('');
  const [editStatus, setEditStatus] = useState<SaqProcessStatus>('Pre-Con');
  const [editProgress, setEditProgress] = useState<string>('');
  const [editRemarks, setEditRemarks] = useState<string>('');
  const [editSlaRule, setEditSlaRule] = useState<string>('');

  // Collapsible Entry Form State (default expanded, user can collapse)
  const [isFormCollapsed, setIsFormCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gaela_daybyday_form_collapsed') === 'true';
    } catch {
      return false;
    }
  });

  const toggleFormCollapse = () => {
    setIsFormCollapsed(prev => {
      const next = !prev;
      try {
        localStorage.setItem('gaela_daybyday_form_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  // Collapsible Sample Format Reference
  const [isSampleCollapsed, setIsSampleCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gaela_daybyday_sample_collapsed') === 'true';
    } catch {
      return false;
    }
  });

  const toggleSampleCollapse = () => {
    setIsSampleCollapsed(prev => {
      const next = !prev;
      try {
        localStorage.setItem('gaela_daybyday_sample_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  // Collapsible SLA Milestones Roadmap (6-Stage target bar)
  const [isMilestonesCollapsed, setIsMilestonesCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('gaela_daybyday_milestones_collapsed') === 'true';
    } catch {
      return false;
    }
  });

  const toggleMilestonesCollapse = () => {
    setIsMilestonesCollapsed(prev => {
      const next = !prev;
      try {
        localStorage.setItem('gaela_daybyday_milestones_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  // Collapsible Row Details in Log History
  const [expandedLogIds, setExpandedLogIds] = useState<Record<string, boolean>>({});
  const toggleLogRowExpand = (id: string) => {
    setExpandedLogIds(prev => ({ ...prev, [id]: !prev[id] }));
  };
  const handleExpandAllLogs = () => {
    const next: Record<string, boolean> = {};
    items.forEach(it => { next[it.id] = true; });
    setExpandedLogIds(next);
  };
  const handleCollapseAllLogs = () => {
    setExpandedLogIds({});
  };

  // Search & filter within modal
  const [filterQuery, setFilterQuery] = useState('');

  // Calculate centralized SLA analytics for this site based strictly on Day-by-Day records
  const slaCalc = useMemo(() => {
    return calculateDayByDaySla(siteRow, items, formatDateYMD(new Date()));
  }, [siteRow, items]);

  const saveAndPersist = (updated: DayByDayUpdateEntry[]) => {
    setItems(updated);
    onUpdateDayByDay(updated);
  };

  // Add new day-by-day record
  const handleAddEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProgress.trim()) {
      onNotify?.('Please provide day-by-day progress details', 'error');
      return;
    }

    const entry: DayByDayUpdateEntry = {
      id: `${siteId}-log-${Date.now()}`,
      date: newDate || formatDateYMD(new Date()),
      status: newStatus,
      progressNotes: newProgress.trim(),
      remarks: newRemarks.trim() || undefined,
      slaRuleApplied: newSlaRule.trim() || getSuggestedSlaRule(newStatus),
      surveyDate: newSurveyDate || undefined,
      updatedBy: `PIC: ${pic}`,
      createdAt: new Date().toISOString()
    };

    // Prepend new entry
    const updated = [entry, ...items];
    saveAndPersist(updated);
    onNotify?.(`Recorded Day-by-Day update for ${siteId}! Centralized SAQ SLA updated.`, 'success');

    // Reset inputs
    setNewProgress('');
    setNewRemarks('');
    setNewDate(formatDateYMD(new Date()));
  };

  // Quick Preset Helper for Hunting Start
  const handleAddHuntingPreset = () => {
    const todayStr = formatDateYMD(new Date());
    setNewDate(todayStr);
    setNewStatus('Site Hunting');
    setNewProgress('Conducted technical site survey and validated site coordinates with engineering team.');
    setNewRemarks('Landowner concurrence obtained. Official SLA Day 0 begins from this date.');
    setNewSlaRule(getSuggestedSlaRule('Site Hunting'));
    onNotify?.('Prefilled Site Hunting Start entry. Click "+ Record Day-by-Day Update" to save.', 'info');
  };

  // Delete record
  const handleDeleteEntry = (id: string) => {
    const updated = items.filter(i => i.id !== id);
    saveAndPersist(updated);
    onNotify?.('Removed day-by-day log entry.', 'info');
  };

  // Start editing
  const handleStartEdit = (entry: DayByDayUpdateEntry) => {
    setEditingId(entry.id);
    setEditDate(entry.date);
    setEditStatus(entry.status);
    setEditProgress(entry.progressNotes);
    setEditRemarks(entry.remarks || '');
    setEditSlaRule(entry.slaRuleApplied || '');
  };

  // Save edit
  const handleSaveEdit = (id: string) => {
    const updated = items.map(entry => {
      if (entry.id === id) {
        return {
          ...entry,
          date: editDate,
          status: editStatus,
          progressNotes: editProgress.trim(),
          remarks: editRemarks.trim() || undefined,
          slaRuleApplied: editSlaRule.trim() || getSuggestedSlaRule(editStatus)
        };
      }
      return entry;
    });
    saveAndPersist(updated);
    setEditingId(null);
    onNotify?.('Updated day-by-day progress log entry.', 'success');
  };

  // Export Excel
  const handleExportExcel = () => {
    const dataToExport = items.map(i => ({
      'SITE ID': siteId,
      'SITE NAME': siteName,
      'DATE': i.date,
      'STATUS': i.status,
      'DAY-BY-DAY PROGRESS / UPDATES': i.progressNotes,
      'DETAILS / REMARKS': i.remarks || '',
      'SLA TRACKING RULE': i.slaRuleApplied || '',
      'OFFICIAL SLA START DATE': slaCalc.officialSlaStartDate,
      'UPDATED BY': i.updatedBy || pic
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Day-by-Day Updates');
    XLSX.writeFile(wb, `${siteId}_Day_by_Day_Progress_Report.xlsx`);
    onNotify?.('Downloaded Excel day-by-day report', 'success');
  };

  const filteredItems = useMemo(() => {
    if (!filterQuery.trim()) return items;
    const q = filterQuery.toLowerCase();
    return items.filter(
      i =>
        i.date.toLowerCase().includes(q) ||
        i.status.toLowerCase().includes(q) ||
        i.progressNotes.toLowerCase().includes(q) ||
        (i.remarks && i.remarks.toLowerCase().includes(q)) ||
        (i.slaRuleApplied && i.slaRuleApplied.toLowerCase().includes(q))
    );
  }, [items, filterQuery]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-150">
      <div className="w-full max-w-6xl rounded-2xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#090e17] text-slate-900 dark:text-white shadow-2xl flex flex-col max-h-[96vh] overflow-hidden">
        {/* Top Header */}
        <div className="p-4 sm:px-6 border-b border-slate-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3 bg-slate-50 dark:bg-[#0d131f]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
              <Calendar className="w-5 h-5" />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2.5 py-0.5 rounded-md font-mono font-bold text-xs bg-blue-950/90 text-blue-400 border border-blue-500/40 tracking-wider">
                  {siteId}
                </span>
                <h2 className="font-black text-base sm:text-lg text-slate-900 dark:text-white tracking-wide uppercase">
                  DAY-BY-DAY PROGRESS &amp; SAQ SLA TRACKER
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/15 text-blue-600 dark:text-blue-300 border border-blue-500/30">
                  Per-Site Clickable Log
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate max-w-2xl">
                {siteName} • {location} • Team: <strong className="text-slate-700 dark:text-slate-200">{assignedTeam}</strong> • PIC: <strong className="text-slate-700 dark:text-slate-200">{pic}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {onOpenColumnManager && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenColumnManager();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors shadow-2xs"
                title="Open Customize Columns & Appearance"
              >
                <Settings2 className="w-3.5 h-3.5 text-indigo-500" />
                <span className="hidden sm:inline">Customize Columns</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleExportExcel}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors shadow-2xs"
              title="Download Excel report"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Excel Export</span>
            </button>

            <button
              type="button"
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors shadow-2xs"
              title="Print report"
            >
              <Printer className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Print</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Official SLA Start Date & Health Banner */}
        <div className="p-3.5 sm:px-6 bg-gradient-to-r from-blue-950/40 via-indigo-950/30 to-[#090e17] border-b border-slate-200 dark:border-zinc-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg bg-blue-500/20 text-blue-400 font-bold border border-blue-500/40 flex items-center gap-1.5 font-mono">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span>OFFICIAL SLA START DATE: {slaCalc.officialSlaStartDate}</span>
              </span>
              <span className="text-[11px] text-slate-400 hidden lg:inline">
                (SLA tracking starts ONLY from the actual date when Site Hunting begins)
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">Current Status:</span>
              <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border flex items-center gap-1.5 ${STATUS_BADGE_STYLES[slaCalc.currentStatus].bg} ${STATUS_BADGE_STYLES[slaCalc.currentStatus].text} ${STATUS_BADGE_STYLES[slaCalc.currentStatus].border}`}>
                <span className={`w-2 h-2 rounded-full ${STATUS_BADGE_STYLES[slaCalc.currentStatus].dot}`} />
                <span>{slaCalc.currentStatus}</span>
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-slate-400">SLA Health:</span>
              <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold border ${
                slaCalc.slaHealth === 'completed' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40' :
                slaCalc.slaHealth === 'overdue' ? 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse' :
                slaCalc.slaHealth === 'stalled' ? 'bg-amber-500/20 text-amber-400 border-amber-500/40' :
                slaCalc.slaHealth === 'approaching_warning' ? 'bg-amber-500/20 text-amber-400 border-amber-500/40' :
                'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'
              }`}>
                {slaCalc.badgeLabel}
              </span>
            </div>
          </div>

          {onOpenWarningCenter && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenWarningCenter();
              }}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] transition-colors shadow-2xs"
              title="Open centralized warning center"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Centralized SAQ Warning Center</span>
            </button>
          )}
        </div>

        {/* SLA Milestones Tracker Bar (6 Stages: Site Hunting -> Billing) - Collapsible */}
        <div className="px-4 sm:px-6 py-2 bg-slate-100 dark:bg-[#0d131f] border-b border-slate-200 dark:border-zinc-800 text-[11px]">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="font-bold text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <span>6-Stage SLA Milestones Target Roadmap</span>
              <span className="text-slate-400 font-normal">
                ({isMilestonesCollapsed ? 'Collapsed' : '107 Days Overall Target'})
              </span>
            </span>
            <button
              type="button"
              onClick={toggleMilestonesCollapse}
              className="text-[10px] font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 px-1.5 py-0.5 rounded hover:bg-black/5 dark:hover:bg-white/5 transition-colors cursor-pointer"
              title={isMilestonesCollapsed ? 'Expand 6-Stage SLA Roadmap' : 'Collapse 6-Stage SLA Roadmap'}
            >
              <span>{isMilestonesCollapsed ? 'Expand Roadmap' : 'Collapse Roadmap'}</span>
              {isMilestonesCollapsed ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            </button>
          </div>

          {!isMilestonesCollapsed && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
              {/* 1. Site Hunting */}
              <div className={`p-2 rounded-lg border flex flex-col justify-between ${
                slaCalc.currentStatus === 'Site Hunting'
                  ? 'bg-blue-500/10 border-blue-500/40 text-blue-700 dark:text-blue-300 font-bold'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
              }`}>
                <span className="text-slate-400 font-semibold">1. Site Hunting</span>
                <span className="font-mono font-bold text-blue-500 text-[10px]">{slaCalc.officialSlaStartDate}</span>
                <span className="text-[9px] text-emerald-500 font-bold">Start (Day 0)</span>
              </div>

              {/* 2. Pro Docs (21d) */}
              <div className={`p-2 rounded-lg border flex flex-col justify-between ${
                slaCalc.currentStatus === 'Pro Docs'
                  ? 'bg-indigo-500/10 border-indigo-500/40 text-indigo-700 dark:text-indigo-300 font-bold'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
              }`}>
                <span className="text-slate-400 font-semibold">2. Pro Docs (21d)</span>
                <span className="font-mono font-bold text-indigo-400 text-[10px]">{slaCalc.targets.propDocsTarget}</span>
                <span className="text-[9px] text-slate-500">Day 21 Target</span>
              </div>

              {/* 3. Pre-Con (44d) */}
              <div className={`p-2 rounded-lg border flex flex-col justify-between ${
                slaCalc.currentStatus === 'Pre-Con'
                  ? 'bg-purple-500/10 border-purple-500/40 text-purple-700 dark:text-purple-300 font-bold'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
              }`}>
                <span className="text-slate-400 font-semibold">3. Pre-Con (44d)</span>
                <span className="font-mono font-bold text-purple-400 text-[10px]">{slaCalc.targets.preconTarget}</span>
                <span className="text-[9px] text-slate-500">Day 65 Target</span>
              </div>

              {/* 4. Post-Con (21d) */}
              <div className={`p-2 rounded-lg border flex flex-col justify-between ${
                slaCalc.currentStatus === 'Post-Con'
                  ? 'bg-amber-500/10 border-amber-500/40 text-amber-700 dark:text-amber-300 font-bold'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
              }`}>
                <span className="text-slate-400 font-semibold">4. Post-Con (21d)</span>
                <span className="font-mono font-bold text-amber-400 text-[10px]">{slaCalc.targets.posconTarget}</span>
                <span className="text-[9px] text-slate-500">Day 86 Target</span>
              </div>

              {/* 5. FAC (7d) */}
              <div className={`p-2 rounded-lg border flex flex-col justify-between ${
                slaCalc.currentStatus === 'FAC'
                  ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-700 dark:text-emerald-300 font-bold'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
              }`}>
                <span className="text-slate-400 font-semibold">5. FAC (7d)</span>
                <span className="font-mono font-bold text-emerald-400 text-[10px]">{slaCalc.targets.facTarget}</span>
                <span className="text-[9px] text-slate-500">Day 93 Target</span>
              </div>

              {/* 6. Billing (14d) */}
              <div className={`p-2 rounded-lg border flex flex-col justify-between ${
                slaCalc.currentStatus === 'Billing'
                  ? 'bg-teal-500/10 border-teal-500/40 text-teal-700 dark:text-teal-300 font-bold'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
              }`}>
                <span className="text-slate-400 font-semibold">6. Billing</span>
                <span className="font-mono font-bold text-teal-400 text-[10px]">{slaCalc.targets.billingTarget}</span>
                <span className="text-[9px] text-slate-500">Day 107 Target</span>
              </div>
            </div>
          )}
        </div>

        {/* Content Body: Sample Layout + Add Form + Timeline Table */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 custom-scrollbar bg-slate-50/50 dark:bg-[#090e17]">
          {/* Sample Format Reference Banner - Collapsible */}
          <div className="p-3 rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-zinc-900/60 shadow-2xs space-y-2 text-xs">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={toggleSampleCollapse}
                  className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wide text-[11px] hover:text-blue-500 transition-colors cursor-pointer"
                  title={isSampleCollapsed ? 'Expand sample format guide' : 'Collapse sample format guide'}
                >
                  <FileText className="w-3.5 h-3.5 text-blue-500" />
                  <span>Sample Day-by-Day Tracker Structure</span>
                  {isSampleCollapsed ? <ChevronDown className="w-3.5 h-3.5 text-slate-400" /> : <ChevronUp className="w-3.5 h-3.5 text-slate-400" />}
                </button>
                {isSampleCollapsed && (
                  <span className="text-[10px] text-slate-400 italic">
                    (Format guide collapsed)
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAddHuntingPreset}
                  className="text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <span>+ Prefill Sample Site Hunting (Day 0)</span>
                </button>
                <button
                  type="button"
                  onClick={toggleSampleCollapse}
                  className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 transition-colors cursor-pointer"
                  title={isSampleCollapsed ? 'Expand Sample Layout' : 'Collapse Sample Layout'}
                >
                  {isSampleCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {!isSampleCollapsed && (
              <div className="p-2 rounded-lg bg-slate-50 dark:bg-zinc-800/80 font-mono text-[11px] text-slate-600 dark:text-slate-300 flex flex-wrap gap-3 items-center">
                <span className="bg-slate-200 dark:bg-zinc-700 px-1.5 py-0.5 rounded text-slate-800 dark:text-slate-200 font-bold">
                  Date: {slaCalc.officialSlaStartDate}
                </span>
                <span className="bg-blue-500/20 text-blue-700 dark:text-blue-300 px-1.5 py-0.5 rounded font-bold">
                  Status: Site Hunting
                </span>
                <span className="truncate max-w-xs text-slate-700 dark:text-slate-200">
                  Day-by-Day: Joint site survey &amp; candidate hunting
                </span>
                <span className="text-slate-400 truncate max-w-xs">
                  Remarks: Landlord initial concurrence
                </span>
                <span className="text-blue-500 text-[10px]">
                  SLA Rule: Official SLA Start (Day 0)
                </span>
              </div>
            )}
          </div>

          {/* Add Day-by-Day Update Form - Collapsible */}
          <div className="rounded-xl border border-blue-200 dark:border-blue-900/40 bg-white dark:bg-[#0d131f] shadow-sm overflow-hidden">
            <div
              onClick={toggleFormCollapse}
              className="p-3.5 sm:px-4 flex items-center justify-between flex-wrap gap-2 cursor-pointer bg-blue-50/40 dark:bg-blue-950/20 hover:bg-blue-50/70 dark:hover:bg-blue-950/30 transition-colors border-b border-blue-100 dark:border-blue-900/30 select-none"
            >
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-blue-500" />
                <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white uppercase tracking-wide">
                  Record Day-by-Day Progress &amp; Report Update
                </h3>
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                  {isFormCollapsed ? 'Form Collapsed (Click to Expand)' : 'Collapsible Form'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-blue-600 dark:text-blue-400 font-medium hidden sm:inline">
                  Real-Time Date / Date of Site Survey Auto-Encoded
                </span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFormCollapse();
                  }}
                  className="p-1 rounded text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                  title={isFormCollapsed ? 'Expand Entry Form' : 'Collapse Entry Form'}
                >
                  {isFormCollapsed ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {!isFormCollapsed && (
              <form onSubmit={handleAddEntry} className="p-4 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                  {/* 1. Date */}
                  <div>
                    <div className="flex items-center justify-between mb-0.5">
                      <label className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block">
                        Date (Survey / Real-Time) <span className="text-red-500">*</span>
                      </label>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setNewDate(formatDateYMD(new Date()))}
                          className="text-[9px] text-blue-600 dark:text-blue-400 hover:underline"
                          title="Use today's date"
                        >
                          Today
                        </button>
                        {surveyDateFromRow && (
                          <button
                            type="button"
                            onClick={() => setNewDate(surveyDateFromRow)}
                            className="text-[9px] text-rose-600 dark:text-rose-400 hover:underline ml-1"
                            title="Use site survey date"
                          >
                            Survey Date
                          </button>
                        )}
                      </div>
                    </div>
                    <input
                      type="date"
                      value={newDate}
                      onChange={e => setNewDate(e.target.value)}
                      className="w-full text-xs font-semibold p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-blue-500"
                      required
                    />
                  </div>

                  {/* 2. Status Dropdown Bar */}
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block mb-0.5">
                      Status "Drop Down Status Bar"
                    </label>
                    <select
                      value={newStatus}
                      onChange={e => {
                        const stat = e.target.value as SaqProcessStatus;
                        setNewStatus(stat);
                        setNewSlaRule(getSuggestedSlaRule(stat));
                      }}
                      className="w-full text-xs font-bold p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-blue-500"
                    >
                      {SAQ_PROCESS_STATUS_OPTIONS.map(opt => (
                        <option key={opt} value={opt}>
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* 3. SLA Tracking Rule */}
                  <div className="sm:col-span-2">
                    <label className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block mb-0.5">
                      SLA Tracking Rule (Auto-Applied)
                    </label>
                    <input
                      type="text"
                      value={newSlaRule}
                      onChange={e => setNewSlaRule(e.target.value)}
                      placeholder="SLA Rule applied for this milestone"
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-blue-500"
                    />
                  </div>
                </div>

                {/* Day-by-Day Progress & Remarks */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block mb-0.5">
                      Day-by-Day Progress / Updates <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      rows={2}
                      value={newProgress}
                      onChange={e => setNewProgress(e.target.value)}
                      placeholder="Enter today's ongoing site progress, milestone movements, or survey findings..."
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-blue-500 custom-scrollbar resize-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[10px] uppercase font-bold text-slate-500 dark:text-slate-400 block mb-0.5">
                      Details / Remarks
                    </label>
                    <textarea
                      rows={2}
                      value={newRemarks}
                      onChange={e => setNewRemarks(e.target.value)}
                      placeholder="Stakeholder coordination, LGU feedback, obstacles, or next action steps..."
                      className="w-full text-xs p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:border-blue-500 custom-scrollbar resize-none"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] text-slate-400 italic">
                    Note: The official SLA starts only from the actual date when Site Hunting begins.
                  </span>

                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-colors shadow-sm cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Record Day-by-Day Update</span>
                  </button>
                </div>
              </form>
            )}

            {isFormCollapsed && (
              <div
                onClick={toggleFormCollapse}
                className="p-3 text-center cursor-pointer hover:bg-blue-50/20 text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center justify-center gap-1.5 select-none"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Expand Form to Record New Day-by-Day Update for {siteRow.col_site_id || 'Site'}</span>
              </div>
            )}
          </div>

          {/* Day-by-Day Log Records Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-xs uppercase tracking-wide text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-blue-500" />
                  <span>Site Progress Timeline &amp; History ({items.length} records)</span>
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-700 dark:text-blue-300">
                  Single Source of Truth for SLA Center
                </span>
              </div>

              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => {
                    if (Object.keys(expandedLogIds).length > 0) {
                      handleCollapseAllLogs();
                    } else {
                      handleExpandAllLogs();
                    }
                  }}
                  className="text-xs px-2.5 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-700 dark:text-zinc-200 hover:bg-slate-100 dark:hover:bg-zinc-700 font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                  title={Object.keys(expandedLogIds).length > 0 ? 'Collapse all entry details' : 'Expand all entry details'}
                >
                  {Object.keys(expandedLogIds).length > 0 ? (
                    <>
                      <ChevronUp className="w-3.5 h-3.5 text-blue-500" />
                      <span>Collapse All Details</span>
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-3.5 h-3.5 text-blue-500" />
                      <span>Expand All Details</span>
                    </>
                  )}
                </button>

                <input
                  type="text"
                  placeholder="Search date, status, notes..."
                  value={filterQuery}
                  onChange={e => setFilterQuery(e.target.value)}
                  className="text-xs px-2.5 py-1 rounded-lg border border-slate-300 dark:border-zinc-700 bg-white dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none w-48 sm:w-56"
                />
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-zinc-800 bg-white dark:bg-[#0d131f] overflow-x-auto shadow-sm">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100 dark:bg-slate-900/90 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 text-[10px] font-extrabold uppercase tracking-wider">
                  <tr>
                    <th className="p-2.5 text-center w-12 whitespace-nowrap">#</th>
                    <th className="p-3 whitespace-nowrap">DATE</th>
                    <th className="p-3 whitespace-nowrap">STATUS (DROPDOWN)</th>
                    <th className="p-3 min-w-[240px]">DAY-BY-DAY PROGRESS / UPDATES</th>
                    <th className="p-3 min-w-[180px]">DETAILS / REMARKS</th>
                    <th className="p-3 whitespace-nowrap">SLA TRACKING RULE</th>
                    <th className="p-3 text-center whitespace-nowrap">ACTIONS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {filteredItems.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400 text-xs">
                        No day-by-day progress records matching query. Use the form above to record daily movement.
                      </td>
                    </tr>
                  ) : (
                    filteredItems.map((entry, idx) => {
                      const isEditing = editingId === entry.id;
                      const isExpanded = Boolean(expandedLogIds[entry.id]);
                      const badge = STATUS_BADGE_STYLES[entry.status] || STATUS_BADGE_STYLES['Site Hunting'];
                      const isHuntingStart = entry.status === 'Site Hunting';

                      if (isEditing) {
                        return (
                          <tr key={entry.id} className="bg-blue-500/10 dark:bg-blue-950/20">
                            <td className="p-2 text-center font-mono text-[11px] text-slate-400">
                              {idx + 1}
                            </td>

                            {/* Edit Date */}
                            <td className="p-2 whitespace-nowrap">
                              <input
                                type="date"
                                value={editDate}
                                onChange={e => setEditDate(e.target.value)}
                                className="text-xs p-1.5 rounded border border-blue-400 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                              />
                            </td>

                            {/* Edit Status */}
                            <td className="p-2 whitespace-nowrap">
                              <select
                                value={editStatus}
                                onChange={e => setEditStatus(e.target.value as SaqProcessStatus)}
                                className="text-xs p-1.5 rounded border border-blue-400 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold"
                              >
                                {SAQ_PROCESS_STATUS_OPTIONS.map(opt => (
                                  <option key={opt} value={opt}>
                                    {opt}
                                  </option>
                                ))}
                              </select>
                            </td>

                            {/* Edit Progress */}
                            <td className="p-2">
                              <textarea
                                rows={2}
                                value={editProgress}
                                onChange={e => setEditProgress(e.target.value)}
                                className="w-full text-xs p-1.5 rounded border border-blue-400 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                              />
                            </td>

                            {/* Edit Remarks */}
                            <td className="p-2">
                              <textarea
                                rows={2}
                                value={editRemarks}
                                onChange={e => setEditRemarks(e.target.value)}
                                className="w-full text-xs p-1.5 rounded border border-blue-400 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                              />
                            </td>

                            {/* Edit SLA Rule */}
                            <td className="p-2 whitespace-nowrap">
                              <input
                                type="text"
                                value={editSlaRule}
                                onChange={e => setEditSlaRule(e.target.value)}
                                className="text-xs p-1.5 rounded border border-blue-400 bg-white dark:bg-slate-900 text-slate-900 dark:text-white w-48"
                              />
                            </td>

                            {/* Edit Actions */}
                            <td className="p-2 text-center whitespace-nowrap">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => handleSaveEdit(entry.id)}
                                  className="p-1 rounded bg-emerald-600 text-white hover:bg-emerald-500"
                                  title="Save changes"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingId(null)}
                                  className="p-1 rounded bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-300"
                                  title="Cancel"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      }

                      return (
                        <React.Fragment key={entry.id}>
                          <tr className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                            {/* Expand/Collapse Toggle & Row Index */}
                            <td className="p-2.5 text-center font-mono text-[11px] text-slate-400 whitespace-nowrap">
                              <div className="flex items-center justify-center gap-1">
                                <button
                                  type="button"
                                  onClick={() => toggleLogRowExpand(entry.id)}
                                  className="p-0.5 rounded text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors cursor-pointer"
                                  title={isExpanded ? 'Collapse row details' : 'Expand full details & remarks'}
                                >
                                  {isExpanded ? (
                                    <ChevronDown className="w-3.5 h-3.5 text-blue-500" />
                                  ) : (
                                    <ChevronRight className="w-3.5 h-3.5" />
                                  )}
                                </button>
                                <span>{idx + 1}</span>
                              </div>
                            </td>

                            {/* 1. Date */}
                            <td className="p-3 font-mono font-bold text-slate-800 dark:text-slate-200 whitespace-nowrap">
                              <div className="flex flex-col">
                                <span>{entry.date}</span>
                                {isHuntingStart && (
                                  <span className="text-[9px] text-blue-500 font-bold uppercase tracking-wider">
                                    🎯 Official SLA Start
                                  </span>
                                )}
                              </div>
                            </td>

                            {/* 2. Status Dropdown Bar Pill */}
                            <td className="p-3 whitespace-nowrap">
                              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border inline-flex items-center gap-1.5 ${badge.bg} ${badge.text} ${badge.border}`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                                <span>{entry.status}</span>
                              </span>
                            </td>

                            {/* 3. Day-by-Day Progress / Updates */}
                            <td className="p-3 text-slate-800 dark:text-slate-100 text-xs leading-relaxed">
                              {entry.progressNotes}
                            </td>

                            {/* 4. Details / Remarks */}
                            <td className="p-3 text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed">
                              {entry.remarks || '-'}
                            </td>

                            {/* 5. SLA Tracking Rule */}
                            <td className="p-3 whitespace-nowrap text-[11px] text-blue-600 dark:text-blue-400 font-mono">
                              {entry.slaRuleApplied || '-'}
                            </td>

                            {/* 6. Actions */}
                            <td className="p-3 text-center whitespace-nowrap">
                              <div className="flex items-center justify-center gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => handleStartEdit(entry)}
                                  className="p-1 rounded text-slate-400 hover:text-blue-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                                  title="Edit log entry"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteEntry(entry.id)}
                                  className="p-1 rounded text-slate-400 hover:text-red-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                                  title="Delete log entry"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>

                          {/* Collapsible Expanded Details Drawer */}
                          {isExpanded && (
                            <tr className="bg-blue-50/40 dark:bg-blue-950/20 border-b border-blue-100 dark:border-blue-900/40">
                              <td colSpan={7} className="p-3 sm:px-6">
                                <div className="p-3.5 rounded-xl border border-blue-200 dark:border-blue-900/50 bg-white dark:bg-[#090e17] shadow-2xs space-y-2.5 text-xs">
                                  <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-slate-100 dark:border-zinc-800">
                                    <div className="flex items-center gap-2">
                                      <span className="font-bold text-slate-900 dark:text-white uppercase tracking-wider text-[11px]">
                                        Detailed Log Entry #{idx + 1}
                                      </span>
                                      <span className="font-mono text-[11px] text-blue-600 dark:text-blue-400 font-bold px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">
                                        {entry.date}
                                      </span>
                                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border inline-flex items-center gap-1 ${badge.bg} ${badge.text} ${badge.border}`}>
                                        <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                                        <span>{entry.status}</span>
                                      </span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <button
                                        type="button"
                                        onClick={() => handleStartEdit(entry)}
                                        className="flex items-center gap-1 px-2.5 py-1 rounded bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 text-xs font-semibold"
                                      >
                                        <Edit2 className="w-3 h-3" />
                                        <span>Edit Record</span>
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => toggleLogRowExpand(entry.id)}
                                        className="flex items-center gap-1 px-2 py-1 rounded bg-slate-100 dark:bg-zinc-800 text-slate-600 dark:text-zinc-300 hover:bg-slate-200 text-xs font-semibold"
                                      >
                                        <ChevronUp className="w-3 h-3" />
                                        <span>Collapse</span>
                                      </button>
                                    </div>
                                  </div>

                                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    <div>
                                      <span className="font-bold text-[10px] uppercase text-slate-500 dark:text-slate-400 block mb-1">
                                        Day-by-Day Progress / Updates
                                      </span>
                                      <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 text-slate-800 dark:text-slate-200 leading-relaxed font-sans text-xs">
                                        {entry.progressNotes}
                                      </div>
                                    </div>

                                    <div>
                                      <span className="font-bold text-[10px] uppercase text-slate-500 dark:text-slate-400 block mb-1">
                                        Details, Obstacles &amp; Remarks
                                      </span>
                                      <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-zinc-900 border border-slate-200 dark:border-zinc-800 text-slate-700 dark:text-slate-300 leading-relaxed font-sans text-xs">
                                        {entry.remarks || 'No additional remarks recorded for this day.'}
                                      </div>
                                    </div>
                                  </div>

                                  <div className="p-2 rounded-lg bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/60 dark:border-blue-900/40 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                                    <div className="flex items-center gap-2">
                                      <span className="text-slate-500 dark:text-slate-400 font-semibold">Applied SLA Rule:</span>
                                      <span className="font-mono font-bold text-blue-700 dark:text-blue-300">
                                        {entry.slaRuleApplied || 'Standard SLA Track'}
                                      </span>
                                    </div>
                                    <span className="text-slate-400 font-mono text-[10px]">
                                      Record ID: {entry.id}
                                    </span>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Modal Bottom Footer */}
        <div className="p-4 sm:px-6 border-t border-slate-200 dark:border-zinc-800 flex flex-wrap items-center justify-between gap-3 bg-slate-50 dark:bg-[#0d131f]">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse shrink-0" />
            <span>
              Real-time daily sync active: Official SLA start date tracks from when Site Hunting begins. The SAQ SLA &amp; Early Warning Center is limited strictly to this tracking area.
            </span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors shadow-2xs"
          >
            Close Tracker
          </button>
        </div>
      </div>
    </div>
  );
};
