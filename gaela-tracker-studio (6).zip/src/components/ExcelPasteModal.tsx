import React, { useState, useRef, useEffect } from 'react';
import {
  FileSpreadsheet,
  Check,
  ArrowRight,
  AlertCircle,
  Copy,
  Upload,
  FileUp,
  FileCheck,
  Calendar,
  Shuffle
} from 'lucide-react';
import { Tracker, Row } from '../types/tracker';
import { parseExcelData, parseExcelFile, normalizeExcelDate } from '../utils/storage';

interface ExcelPasteModalProps {
  tracker: Tracker;
  isDark: boolean;
  onClose: () => void;
  onImport: (newRows: Row[], replace: boolean) => void;
}

export const ExcelPasteModal: React.FC<ExcelPasteModalProps> = ({
  tracker,
  isDark,
  onClose,
  onImport
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('upload');
  const [pastedText, setPastedText] = useState('');
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [uploadedGrid, setUploadedGrid] = useState<string[][]>([]);
  const [firstRowIsHeader, setFirstRowIsHeader] = useState(true);
  const [importMode, setImportMode] = useState<'append' | 'replace'>('append');
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Active grid based on tab
  const rawGrid = activeTab === 'upload' ? uploadedGrid : (pastedText ? parseExcelData(pastedText) : []);
  const headerRow = firstRowIsHeader && rawGrid.length > 0 ? rawGrid[0] : null;
  const dataRows = firstRowIsHeader && rawGrid.length > 0 ? rawGrid.slice(1) : rawGrid;

  // Custom column mapping: map each visible tracker column to an imported Excel column index (or 'auto')
  const visibleCols = tracker.columns.filter(c => c.visible);
  const [colMapping, setColMapping] = useState<Record<string, number | 'skip'>>({});

  // Auto-detect matching columns when headers change
  useEffect(() => {
    const newMapping: Record<string, number | 'skip'> = {};

    visibleCols.forEach((col, defIdx) => {
      let matchedIdx: number | 'skip' = defIdx < (rawGrid[0]?.length || 0) ? defIdx : 'skip';

      if (headerRow && headerRow.length > 0) {
        const cleanColName = col.name.trim().toLowerCase();
        // Look for exact or fuzzy name match
        const foundIdx = headerRow.findIndex(h => {
          const cleanH = String(h).trim().toLowerCase();
          return cleanH === cleanColName || cleanH.includes(cleanColName) || cleanColName.includes(cleanH);
        });

        if (foundIdx !== -1) {
          matchedIdx = foundIdx;
        } else if (col.type === 'date') {
          // If it's a date column, look for header containing 'date', 'target', 'sched', 'inspect'
          const dateHIdx = headerRow.findIndex(h => {
            const cleanH = String(h).trim().toLowerCase();
            return cleanH.includes('date') || cleanH.includes('target') || cleanH.includes('sched') || cleanH.includes('inspect') || cleanH.includes('time') || cleanH.includes('day');
          });
          if (dateHIdx !== -1) matchedIdx = dateHIdx;
        }
      }

      newMapping[col.id] = matchedIdx;
    });

    setColMapping(newMapping);
  }, [headerRow?.length, visibleCols.length, rawGrid.length]);

  const handleFileUpload = async (file: File) => {
    setIsLoading(true);
    try {
      setUploadedFileName(file.name);
      const grid = await parseExcelFile(file);
      setUploadedGrid(grid);
    } catch (err) {
      alert('Could not parse Excel file. Please ensure it is a valid .xlsx, .xls, or .csv file.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileUpload(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFileUpload(file);
  };

  const handleProcessImport = () => {
    if (dataRows.length === 0) return;

    const convertedRows: Row[] = dataRows.map((line, rIdx) => {
      const rowObj: Row = { id: 'row-excel-' + Date.now() + '-' + rIdx };

      visibleCols.forEach((col, defIdx) => {
        const mappedIdx = colMapping[col.id] !== undefined ? colMapping[col.id] : defIdx;
        if (mappedIdx === 'skip' || mappedIdx === undefined) return;

        let rawVal = line[mappedIdx] !== undefined ? String(line[mappedIdx]).trim() : '';

        if (col.type === 'amount') {
          const num = parseFloat(rawVal.replace(/[^0-9.-]+/g, '')) || 0;
          rowObj[col.id] = num;
        } else if (col.type === 'percent') {
          const num = parseFloat(rawVal.replace(/[^0-9.-]+/g, '')) || 0;
          rowObj[col.id] = num;
        } else if (col.type === 'date') {
          // Normalize date format from Excel serial number, MM/DD/YYYY, or ISO date
          rowObj[col.id] = normalizeExcelDate(rawVal);
        } else {
          rowObj[col.id] = rawVal;
        }
      });

      return rowObj;
    });

    onImport(convertedRows, importMode === 'replace');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div
        className={`w-full max-w-4xl rounded-2xl border shadow-xl flex flex-col max-h-[92vh] overflow-hidden ${
          isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100' : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Modal Header */}
        <div className="p-4 border-b border-slate-200 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm leading-tight">Import from Microsoft Excel (.xlsx / .csv)</h3>
              <p className="text-xs text-slate-500 dark:text-zinc-400">
                Upload your Excel spreadsheet file or paste copied cells directly into <span className="font-semibold text-emerald-600 dark:text-emerald-400">{tracker.name}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-zinc-200"
          >
            ✕
          </button>
        </div>

        {/* Import Tabs */}
        <div className="grid grid-cols-2 border-b border-slate-200 dark:border-zinc-800 text-xs font-semibold bg-slate-50 dark:bg-zinc-800/50">
          <button
            onClick={() => setActiveTab('upload')}
            className={`py-2.5 flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'upload'
                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-zinc-900'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-zinc-400'
            }`}
          >
            <FileUp className="w-4 h-4" />
            <span>Upload Excel File (.xlsx, .xls, .csv)</span>
          </button>

          <button
            onClick={() => setActiveTab('paste')}
            className={`py-2.5 flex items-center justify-center gap-2 border-b-2 transition-colors ${
              activeTab === 'paste'
                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400 bg-white dark:bg-zinc-900'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-zinc-400'
            }`}
          >
            <Copy className="w-4 h-4" />
            <span>Paste Cells Directly</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'upload' ? (
            <div>
              {/* Drag and Drop Zone */}
              <div
                onDragOver={e => e.preventDefault()}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`p-6 border-2 border-dashed rounded-xl text-center cursor-pointer transition-colors ${
                  uploadedFileName
                    ? 'border-emerald-500 bg-emerald-50/30 dark:bg-emerald-950/20'
                    : 'border-slate-300 dark:border-zinc-700 hover:border-emerald-500 hover:bg-slate-50 dark:hover:bg-zinc-800/40'
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".xlsx,.xls,.csv"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-2">
                  {uploadedFileName ? <FileCheck className="w-6 h-6" /> : <Upload className="w-6 h-6" />}
                </div>
                {uploadedFileName ? (
                  <div>
                    <div className="font-bold text-xs text-emerald-700 dark:text-emerald-300">
                      {uploadedFileName}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-zinc-400 mt-1">
                      {dataRows.length} rows ready for import. Click to choose another file.
                    </div>
                  </div>
                ) : (
                  <div>
                    <div className="font-bold text-xs text-slate-800 dark:text-zinc-200">
                      Click to choose an Excel file or drag & drop here
                    </div>
                    <div className="text-[11px] text-slate-400 mt-1">
                      Supports Microsoft Excel (.xlsx, .xls) and CSV spreadsheets
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div>
              <label className="text-xs font-bold uppercase text-slate-500 mb-1 block">
                Paste Excel Tab-Separated Data
              </label>
              <textarea
                rows={5}
                placeholder="Select rows or columns in Excel, copy with Ctrl+C, and paste here with Ctrl+V..."
                value={pastedText}
                onChange={e => setPastedText(e.target.value)}
                className="w-full text-xs font-mono p-3 rounded-lg border border-slate-300 dark:border-zinc-700 bg-slate-50 dark:bg-zinc-800 text-slate-900 dark:text-zinc-100 outline-none focus:border-emerald-500"
                autoFocus
              />
            </div>
          )}

          {/* Options */}
          <div className="flex flex-wrap items-center justify-between gap-4 text-xs pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-zinc-300">
              <input
                type="checkbox"
                checked={firstRowIsHeader}
                onChange={e => setFirstRowIsHeader(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-0"
              />
              <span>First row is column header (do not import as data row)</span>
            </label>

            <div className="flex items-center gap-3">
              <label className="flex items-center gap-1.5 cursor-pointer font-medium">
                <input
                  type="radio"
                  name="importMode"
                  value="append"
                  checked={importMode === 'append'}
                  onChange={() => setImportMode('append')}
                  className="text-emerald-600 focus:ring-0"
                />
                <span>Append to existing rows</span>
              </label>
              <label className="flex items-center gap-1.5 cursor-pointer text-rose-600 font-medium">
                <input
                  type="radio"
                  name="importMode"
                  value="replace"
                  checked={importMode === 'replace'}
                  onChange={() => setImportMode('replace')}
                  className="text-emerald-600 focus:ring-0"
                />
                <span>Replace all rows</span>
              </label>
            </div>
          </div>

          {/* Column Mapping Selector (Ensures Dates and Columns Match the Imported Excel) */}
          {rawGrid.length > 0 && (
            <div className="p-3 rounded-xl border border-emerald-200 dark:border-emerald-900/60 bg-emerald-50/40 dark:bg-emerald-950/20 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 font-bold text-emerald-900 dark:text-emerald-300">
                  <Shuffle className="w-3.5 h-3.5" />
                  <span>Column Matching & Alignment</span>
                </div>
                <span className="text-[11px] text-slate-500 dark:text-zinc-400">
                  Ensure dates and custom columns match your Excel sheet
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 pt-1 text-xs">
                {visibleCols.map((col, cIdx) => {
                  const currentMapped = colMapping[col.id] !== undefined ? colMapping[col.id] : cIdx;
                  const isDate = col.type === 'date';

                  return (
                    <div
                      key={col.id}
                      className={`p-2 rounded-lg border flex flex-col gap-1 ${
                        isDate
                          ? 'border-rose-300 bg-rose-50/50 dark:border-rose-900 dark:bg-rose-950/20'
                          : 'border-slate-200 dark:border-zinc-700 bg-white dark:bg-zinc-800'
                      }`}
                    >
                      <div className="flex items-center justify-between font-semibold">
                        <span className="truncate flex items-center gap-1">
                          {isDate && <Calendar className="w-3 h-3 text-rose-500" />}
                          {col.name}
                        </span>
                        <span className="text-[10px] text-slate-400 uppercase font-mono">
                          {col.type}
                        </span>
                      </div>

                      <select
                        value={currentMapped}
                        onChange={e => {
                          const val = e.target.value === 'skip' ? 'skip' : parseInt(e.target.value, 10);
                          setColMapping(prev => ({ ...prev, [col.id]: val }));
                        }}
                        className="text-xs px-1.5 py-1 rounded border border-slate-300 dark:border-zinc-600 bg-white dark:bg-zinc-900 text-slate-800 dark:text-zinc-200 outline-none"
                      >
                        <option value="skip">-- Skip this column --</option>
                        {Array.from({ length: Math.max(...rawGrid.map(r => r.length), 0) }).map((_, idx) => {
                          const colHeaderName = headerRow && headerRow[idx] ? String(headerRow[idx]).trim() : `Column ${idx + 1}`;
                          return (
                            <option key={idx} value={idx}>
                              Excel Col {idx + 1}: {colHeaderName}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Data Preview */}
          {rawGrid.length > 0 && (
            <div>
              <div className="text-xs font-bold text-slate-600 dark:text-zinc-400 mb-1 flex items-center justify-between">
                <span>Spreadsheet Preview ({dataRows.length} rows detected)</span>
                <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold">
                  Dates auto-formatted to YYYY-MM-DD
                </span>
              </div>
              <div className="max-h-48 overflow-auto border border-slate-200 dark:border-zinc-700 rounded-lg text-xs">
                <table className="w-full border-collapse">
                  <thead className="bg-slate-100 dark:bg-zinc-800 font-semibold sticky top-0 text-slate-800 dark:text-zinc-200">
                    <tr>
                      <th className="p-1.5 border-b border-r text-center text-slate-400 w-8">#</th>
                      {visibleCols.map((col, idx) => (
                        <th key={col.id} className="p-1.5 border-b border-r text-left truncate">
                          {col.name} <span className="text-[10px] text-slate-400">({col.type})</span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-zinc-800">
                    {dataRows.slice(0, 10).map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-50 dark:hover:bg-zinc-800/50">
                        <td className="p-1.5 border-r text-center text-slate-400 font-mono text-[10px]">{rIdx + 1}</td>
                        {visibleCols.map((col, cIdx) => {
                          const mappedIdx = colMapping[col.id] !== undefined ? colMapping[col.id] : cIdx;
                          let displayVal = mappedIdx !== 'skip' && row[mappedIdx] !== undefined ? String(row[mappedIdx]).trim() : '';
                          if (col.type === 'date' && displayVal) {
                            displayVal = normalizeExcelDate(displayVal);
                          }

                          return (
                            <td key={col.id} className="p-1.5 border-r truncate max-w-[150px]">
                              {displayVal || <span className="text-slate-300 italic">-</span>}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {dataRows.length > 10 && (
                <p className="text-[11px] text-slate-400 mt-1 italic">
                  + {dataRows.length - 10} more rows will be imported.
                </p>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-zinc-800 flex items-center justify-end gap-2 bg-slate-50/50 dark:bg-zinc-800/40">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg text-slate-600 dark:text-zinc-300 hover:bg-slate-200 dark:hover:bg-zinc-700"
          >
            Cancel
          </button>
          <button
            onClick={handleProcessImport}
            disabled={dataRows.length === 0 || isLoading}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs disabled:opacity-40"
          >
            <Check className="w-4 h-4" />
            <span>Import {dataRows.length} Rows</span>
          </button>
        </div>
      </div>
    </div>
  );
};
