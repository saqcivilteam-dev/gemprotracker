import React, { useState, useMemo } from 'react';
import {
  FolderKanban,
  Folder,
  FolderPlus,
  Plus,
  Trash2,
  Edit2,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Download,
  Upload,
  Database,
  Check,
  Building2,
  BadgeDollarSign,
  Wrench,
  FileSpreadsheet,
  Layers,
  HelpCircle,
  Copy,
  FileCheck2,
  Search,
  Pin,
  Archive,
  MoreVertical,
  MoveRight,
  ShieldCheck,
  Hammer,
  BarChart3,
  X
} from 'lucide-react';
import { Tracker, AppState, User, TrackerFolder } from '../types/tracker';

interface SidebarProps {
  state: AppState;
  currentUser: User | null;
  isOpen: boolean;
  onToggle: () => void;
  onSelectTracker: (trackerId: string) => void;
  onAddTracker: (name: string, templateType: 'blank' | 'civil' | 'budget' | 'equipment' | 'bp', folderId?: string) => void;
  onRenameTracker: (trackerId: string, newName: string) => void;
  onDeleteTracker: (trackerId: string) => void;
  onDuplicateTracker: (trackerId: string) => void;
  onExportJSON: () => void;
  onImportJSON: () => void;
  onAddFolder?: (name: string, color?: string, icon?: string) => void;
  onRenameFolder?: (folderId: string, newName: string) => void;
  onDeleteFolder?: (folderId: string) => void;
  onToggleFolderCollapse?: (folderId: string) => void;
  onMoveTrackerToFolder?: (trackerId: string, folderId: string | null) => void;
  onTogglePinTracker?: (trackerId: string) => void;
  onToggleArchiveTracker?: (trackerId: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  state,
  currentUser,
  isOpen,
  onToggle,
  onSelectTracker,
  onAddTracker,
  onRenameTracker,
  onDeleteTracker,
  onDuplicateTracker,
  onExportJSON,
  onImportJSON,
  onAddFolder,
  onRenameFolder,
  onDeleteFolder,
  onToggleFolderCollapse,
  onMoveTrackerToFolder,
  onTogglePinTracker,
  onToggleArchiveTracker
}) => {
  const isDark = state.theme === 'dark';

  // Tracker state
  const [editingTrackerId, setEditingTrackerId] = useState<string | null>(null);
  const [editTrackerName, setEditTrackerName] = useState('');
  const [isAddingTracker, setIsAddingTracker] = useState(false);
  const [newTrackerName, setNewTrackerName] = useState('');
  const [targetFolderForNewTracker, setTargetFolderForNewTracker] = useState<string>('');
  const [selectedTemplate, setSelectedTemplate] = useState<'blank' | 'civil' | 'budget' | 'equipment' | 'bp'>('bp');

  // Folder state
  const [isAddingFolder, setIsAddingFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [newFolderColor, setNewFolderColor] = useState<'blue' | 'amber' | 'emerald' | 'purple' | 'rose' | 'indigo' | 'cyan' | 'slate'>('blue');
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [editFolderName, setEditFolderName] = useState('');

  // Moving tracker modal/menu
  const [movingTrackerId, setMovingTrackerId] = useState<string | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [showArchived, setShowArchived] = useState(false);

  // Local folder collapse cache if not stored in state
  const [collapsedFolders, setCollapsedFolders] = useState<Record<string, boolean>>({});

  const folders: TrackerFolder[] = state.folders || [
    { id: 'folder-saq', name: 'Site Acquisition (SAQ)', icon: 'FolderKanban', color: 'blue' },
    { id: 'folder-legal', name: 'Legal & BP Permitting', icon: 'ShieldCheck', color: 'amber' },
    { id: 'folder-construction', name: 'Construction / Milestones', icon: 'Hammer', color: 'purple' },
    { id: 'folder-reports', name: 'Executive Reports & Summaries', icon: 'BarChart3', color: 'emerald' }
  ];

  // Helper icons
  const getTrackerIcon = (icon?: string) => {
    switch (icon) {
      case 'Building2': return <Building2 className="w-4 h-4 text-blue-500 shrink-0" />;
      case 'BadgeDollarSign': return <BadgeDollarSign className="w-4 h-4 text-emerald-500 shrink-0" />;
      case 'Wrench': return <Wrench className="w-4 h-4 text-purple-500 shrink-0" />;
      case 'FileCheck2': return <FileCheck2 className="w-4 h-4 text-emerald-400 shrink-0" />;
      default: return <FileSpreadsheet className="w-4 h-4 text-indigo-500 shrink-0" />;
    }
  };

  const getFolderIcon = (icon?: string, color = 'blue') => {
    const colorClass = {
      blue: 'text-blue-500',
      amber: 'text-amber-500',
      emerald: 'text-emerald-500',
      purple: 'text-purple-500',
      rose: 'text-rose-500',
      indigo: 'text-indigo-500',
      cyan: 'text-cyan-500',
      slate: 'text-slate-400'
    }[color] || 'text-blue-500';

    switch (icon) {
      case 'ShieldCheck': return <ShieldCheck className={`w-4 h-4 ${colorClass}`} />;
      case 'Hammer': return <Hammer className={`w-4 h-4 ${colorClass}`} />;
      case 'BarChart3': return <BarChart3 className={`w-4 h-4 ${colorClass}`} />;
      case 'FolderKanban': return <FolderKanban className={`w-4 h-4 ${colorClass}`} />;
      default: return <Folder className={`w-4 h-4 ${colorClass}`} />;
    }
  };

  const isFolderCollapsed = (folderId: string) => {
    if (collapsedFolders[folderId] !== undefined) return collapsedFolders[folderId];
    const folder = folders.find(f => f.id === folderId);
    return folder?.isCollapsed || false;
  };

  const toggleFolder = (folderId: string) => {
    if (onToggleFolderCollapse) {
      onToggleFolderCollapse(folderId);
    }
    setCollapsedFolders(prev => ({
      ...prev,
      [folderId]: !isFolderCollapsed(folderId)
    }));
  };

  // Filter trackers
  const filteredTrackers = useMemo(() => {
    let list = state.trackers;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(t =>
        t.name.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q) ||
        t.rows.some(r => Object.values(r).some(v => String(v).toLowerCase().includes(q)))
      );
    }
    return list;
  }, [state.trackers, searchQuery]);

  // Grouped trackers
  const pinnedTrackers = filteredTrackers.filter(t => t.isPinned && !t.isArchived);
  const archivedTrackers = filteredTrackers.filter(t => t.isArchived);
  const unarchivedTrackers = filteredTrackers.filter(t => !t.isArchived);

  // Group trackers by folder
  const trackersByFolder = useMemo(() => {
    const map: Record<string, Tracker[]> = {};
    for (const f of folders) {
      map[f.id] = [];
    }
    const unfiled: Tracker[] = [];

    for (const t of unarchivedTrackers) {
      if (t.folderId && map[t.folderId]) {
        map[t.folderId].push(t);
      } else {
        unfiled.push(t);
      }
    }

    return { map, unfiled };
  }, [folders, unarchivedTrackers]);

  // Handlers
  const handleSaveRenameTracker = (trackerId: string) => {
    if (editTrackerName.trim()) {
      onRenameTracker(trackerId, editTrackerName.trim());
    }
    setEditingTrackerId(null);
  };

  const handleCreateTracker = () => {
    if (!newTrackerName.trim()) return;
    onAddTracker(newTrackerName.trim(), selectedTemplate, targetFolderForNewTracker || undefined);
    setNewTrackerName('');
    setIsAddingTracker(false);
  };

  const handleCreateFolder = () => {
    if (!newFolderName.trim()) return;
    if (onAddFolder) {
      onAddFolder(newFolderName.trim(), newFolderColor);
    }
    setNewFolderName('');
    setIsAddingFolder(false);
  };

  const handleSaveRenameFolder = (folderId: string) => {
    if (editFolderName.trim() && onRenameFolder) {
      onRenameFolder(folderId, editFolderName.trim());
    }
    setEditingFolderId(null);
  };

  const renderTrackerItem = (tracker: Tracker) => {
    const isActive = tracker.id === state.activeTrackerId;
    const isEditing = editingTrackerId === tracker.id;

    if (!isOpen) {
      return (
        <button
          key={tracker.id}
          onClick={() => onSelectTracker(tracker.id)}
          title={`${tracker.name} (${tracker.rows.length} rows)`}
          className={`w-full p-2.5 rounded-lg flex items-center justify-center transition-colors ${
            isActive
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-slate-400 hover:bg-white/5 hover:text-white'
          }`}
        >
          {getTrackerIcon(tracker.icon)}
        </button>
      );
    }

    return (
      <div
        key={tracker.id}
        className={`group relative rounded-lg p-2 transition-all select-none ${
          isActive
            ? 'bg-indigo-600/90 text-white shadow-sm border border-indigo-500/50'
            : 'text-slate-300 hover:bg-white/5 hover:text-white'
        }`}
      >
        {isEditing ? (
          <div className="flex items-center gap-1.5" onClick={e => e.stopPropagation()}>
            <input
              type="text"
              value={editTrackerName}
              onChange={e => setEditTrackerName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSaveRenameTracker(tracker.id)}
              autoFocus
              className="w-full text-xs px-2 py-1 rounded bg-slate-800 text-white border border-indigo-400 outline-none"
            />
            <button
              onClick={() => handleSaveRenameTracker(tracker.id)}
              className="p-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white"
            >
              <Check className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div
            onClick={() => onSelectTracker(tracker.id)}
            className="cursor-pointer flex items-start gap-2.5"
          >
            <div className="mt-0.5">{getTrackerIcon(tracker.icon)}</div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1">
                <span className="font-semibold text-xs truncate leading-snug">
                  {tracker.name}
                </span>
                {tracker.isPinned && (
                  <Pin className="w-2.5 h-2.5 text-amber-400 fill-current shrink-0" />
                )}
              </div>
              <div className="text-[10px] text-slate-400 group-hover:text-slate-300 flex items-center gap-2 mt-0.5">
                <span>{tracker.rows.length.toLocaleString()} rows</span>
                <span>•</span>
                <span>{tracker.columns.filter(c => c.visible).length} cols</span>
              </div>
            </div>
          </div>
        )}

        {/* Tracker Quick Action Bar */}
        {!isEditing && (
          <div className="absolute right-1.5 top-1.5 hidden group-hover:flex items-center gap-0.5 bg-slate-900/95 rounded px-1 py-0.5 shadow-md border border-white/10 z-10">
            {/* Move to folder */}
            {onMoveTrackerToFolder && (
              <button
                onClick={e => {
                  e.stopPropagation();
                  setMovingTrackerId(movingTrackerId === tracker.id ? null : tracker.id);
                }}
                title="Move to Folder"
                className="p-1 text-slate-400 hover:text-indigo-400 rounded"
              >
                <MoveRight className="w-3 h-3" />
              </button>
            )}

            {/* Pin / Unpin */}
            {onTogglePinTracker && (
              <button
                onClick={e => {
                  e.stopPropagation();
                  onTogglePinTracker(tracker.id);
                }}
                title={tracker.isPinned ? 'Unpin Tracker' : 'Pin Tracker to Top'}
                className={`p-1 rounded ${tracker.isPinned ? 'text-amber-400' : 'text-slate-400 hover:text-white'}`}
              >
                <Pin className="w-3 h-3" />
              </button>
            )}

            {/* Rename */}
            <button
              onClick={e => {
                e.stopPropagation();
                setEditingTrackerId(tracker.id);
                setEditTrackerName(tracker.name);
              }}
              title="Rename Tracker"
              className="p-1 text-slate-400 hover:text-white rounded"
            >
              <Edit2 className="w-3 h-3" />
            </button>

            {/* Duplicate */}
            <button
              onClick={e => {
                e.stopPropagation();
                onDuplicateTracker(tracker.id);
              }}
              title="Duplicate Tracker"
              className="p-1 text-slate-400 hover:text-white rounded"
            >
              <Copy className="w-3 h-3" />
            </button>

            {/* Archive / Unarchive */}
            {onToggleArchiveTracker && (
              <button
                onClick={e => {
                  e.stopPropagation();
                  onToggleArchiveTracker(tracker.id);
                }}
                title={tracker.isArchived ? 'Restore from Archive' : 'Archive Tracker'}
                className="p-1 text-slate-400 hover:text-amber-400 rounded"
              >
                <Archive className="w-3 h-3" />
              </button>
            )}

            {/* Delete */}
            {state.trackers.length > 1 && (
              <button
                onClick={e => {
                  e.stopPropagation();
                  onDeleteTracker(tracker.id);
                }}
                title="Delete Tracker"
                className="p-1 text-slate-400 hover:text-red-400 rounded"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            )}
          </div>
        )}

        {/* Move Tracker Menu Dropdown */}
        {movingTrackerId === tracker.id && (
          <div
            onClick={e => e.stopPropagation()}
            className="mt-2 p-2 rounded-lg bg-slate-950 border border-slate-700 shadow-xl space-y-1 text-xs"
          >
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
              <span>Move to Folder:</span>
              <button onClick={() => setMovingTrackerId(null)} className="text-slate-500 hover:text-white">✕</button>
            </div>
            <button
              onClick={() => {
                onMoveTrackerToFolder?.(tracker.id, null);
                setMovingTrackerId(null);
              }}
              className={`w-full text-left px-2 py-1 rounded text-xs transition-colors flex items-center justify-between ${
                !tracker.folderId ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              <span>📂 Unfiled (No Folder)</span>
              {!tracker.folderId && <Check className="w-3 h-3" />}
            </button>
            {folders.map(f => (
              <button
                key={f.id}
                onClick={() => {
                  onMoveTrackerToFolder?.(tracker.id, f.id);
                  setMovingTrackerId(null);
                }}
                className={`w-full text-left px-2 py-1 rounded text-xs transition-colors flex items-center justify-between ${
                  tracker.folderId === f.id ? 'bg-indigo-600 text-white' : 'text-slate-300 hover:bg-white/10'
                }`}
              >
                <span className="truncate">📁 {f.name}</span>
                {tracker.folderId === f.id && <Check className="w-3 h-3" />}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      <aside
        className={`fixed inset-y-0 left-0 top-15 z-20 transition-all duration-300 flex flex-col border-r ${
          isOpen ? 'w-72' : 'w-0 -translate-x-full md:translate-x-0 md:w-16'
        } ${
          isDark
            ? 'bg-zinc-900 border-zinc-800 text-zinc-200'
            : 'bg-slate-900 border-slate-800 text-slate-100 shadow-md'
        }`}
      >
        {/* Sidebar Header */}
        <div className="p-3 border-b border-white/10 flex items-center justify-between min-h-[50px]">
          {isOpen ? (
            <>
              <div className="flex items-center gap-2">
                <FolderKanban className="w-4 h-4 text-indigo-400" />
                <span className="font-bold text-xs uppercase tracking-wider text-slate-300">
                  Folder Explorer ({state.trackers.length})
                </span>
              </div>
              <div className="flex items-center gap-1">
                {/* Create Folder Button */}
                <button
                  onClick={() => setIsAddingFolder(true)}
                  className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
                  title="Create a new folder"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                </button>
                {/* Create Tracker Button */}
                <button
                  onClick={() => {
                    setTargetFolderForNewTracker('');
                    setIsAddingTracker(true);
                  }}
                  className="p-1.5 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
                  title="Create a new custom tracker"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
                {/* Collapse Sidebar Button */}
                <button
                  onClick={onToggle}
                  className="p-1.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors ml-1 cursor-pointer"
                  title="Collapse Sidebar"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
              </div>
            </>
          ) : (
            <button
              onClick={onToggle}
              className="mx-auto p-1.5 text-slate-400 hover:text-white"
              title="Expand Sidebar"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Search Input when open */}
        {isOpen && (
          <div className="p-2 border-b border-white/5">
            <div className="relative">
              <Search className="w-3 h-3 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search trackers, sites, folders..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-7 pr-2.5 py-1 rounded-md bg-slate-800/80 text-white border border-slate-700 placeholder:text-slate-500 outline-none"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
                >
                  ✕
                </button>
              )}
            </div>
          </div>
        )}

        {/* Modal / Inline Add Folder */}
        {isOpen && isAddingFolder && (
          <div className="p-3 m-2 rounded-lg bg-slate-800/95 border border-slate-700 space-y-2 shadow-lg">
            <div className="text-xs font-bold text-white flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <FolderPlus className="w-3.5 h-3.5 text-indigo-400" />
                <span>Create New Folder</span>
              </span>
              <button onClick={() => setIsAddingFolder(false)} className="text-slate-400 hover:text-white text-xs">
                ✕
              </button>
            </div>
            <input
              type="text"
              placeholder="e.g. Site Acquisition, Legal..."
              value={newFolderName}
              onChange={e => setNewFolderName(e.target.value)}
              className="w-full text-xs px-2.5 py-1.5 rounded bg-slate-900 text-white border border-slate-600 focus:border-indigo-500 outline-none"
              autoFocus
            />
            <div className="flex items-center gap-1.5 pt-1">
              <span className="text-[10px] text-slate-400">Color:</span>
              {(['blue', 'amber', 'emerald', 'purple', 'rose', 'indigo'] as const).map(color => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setNewFolderColor(color)}
                  className={`w-4 h-4 rounded-full border transition-all ${
                    newFolderColor === color ? 'scale-125 ring-2 ring-white' : 'opacity-70 hover:opacity-100'
                  } ${{
                    blue: 'bg-blue-500 border-blue-400',
                    amber: 'bg-amber-500 border-amber-400',
                    emerald: 'bg-emerald-500 border-emerald-400',
                    purple: 'bg-purple-500 border-purple-400',
                    rose: 'bg-rose-500 border-rose-400',
                    indigo: 'bg-indigo-500 border-indigo-400'
                  }[color]}`}
                />
              ))}
            </div>
            <div className="flex justify-end gap-1.5 pt-1">
              <button
                onClick={() => setIsAddingFolder(false)}
                className="px-2 py-1 text-xs text-slate-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateFolder}
                disabled={!newFolderName.trim()}
                className="px-2.5 py-1 text-xs font-semibold rounded bg-indigo-600 hover:bg-indigo-500 text-white disabled:opacity-50"
              >
                Add Folder
              </button>
            </div>
          </div>
        )}

        {/* Modal / Inline Add Tracker */}
        {isOpen && isAddingTracker && (
          <div className="p-3 m-2 rounded-lg bg-slate-800/95 border border-slate-700 space-y-2 shadow-lg">
            <div className="text-xs font-bold text-white flex items-center justify-between">
              <span>Create New Tracker</span>
              <button onClick={() => setIsAddingTracker(false)} className="text-slate-400 hover:text-white text-xs">
                ✕
              </button>
            </div>
            <input
              type="text"
              placeholder="e.g. Telecom Site Rollout..."
              value={newTrackerName}
              onChange={e => setNewTrackerName(e.target.value)}
              className="w-full text-xs px-2.5 py-1.5 rounded bg-slate-900 text-white border border-slate-600 focus:border-indigo-500 outline-none"
              autoFocus
            />

            <div className="space-y-1">
              <label className="text-[10px] text-slate-400 uppercase font-bold">Target Folder</label>
              <select
                value={targetFolderForNewTracker}
                onChange={e => setTargetFolderForNewTracker(e.target.value)}
                className="w-full text-xs px-2 py-1 rounded bg-slate-900 text-white border border-slate-600 outline-none"
              >
                <option value="">📂 Unfiled (Root)</option>
                {folders.map(f => (
                  <option key={f.id} value={f.id}>
                    📁 {f.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-slate-400 uppercase font-bold">Template</label>
              <select
                value={selectedTemplate}
                onChange={e => setSelectedTemplate(e.target.value as any)}
                className="w-full text-xs px-2 py-1 rounded bg-slate-900 text-white border border-slate-600 outline-none"
              >
                <option value="bp">Building Permit (BP) & Payment Requests</option>
                <option value="civil">SAQC & Civil Quality Works</option>
                <option value="budget">Budget & Invoice Tracker</option>
                <option value="equipment">Equipment & Maintenance</option>
                <option value="blank">Blank Custom Tracker</option>
              </select>
            </div>

            <div className="flex justify-end gap-1.5 pt-1">
              <button
                onClick={() => setIsAddingTracker(false)}
                className="px-2.5 py-1 text-xs text-slate-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateTracker}
                disabled={!newTrackerName.trim()}
                className="px-3 py-1 text-xs font-semibold rounded bg-indigo-600 hover:bg-indigo-500 text-white disabled:opacity-50"
              >
                Create
              </button>
            </div>
          </div>
        )}

        {/* Trackers Explorer Content */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-3">
          {/* Pinned Trackers Section */}
          {isOpen && pinnedTrackers.length > 0 && (
            <div className="space-y-1">
              <div className="text-[10px] uppercase font-bold text-amber-400/90 px-1.5 flex items-center gap-1">
                <Pin className="w-3 h-3 fill-current" />
                <span>Pinned Trackers ({pinnedTrackers.length})</span>
              </div>
              <div className="space-y-1">
                {pinnedTrackers.map(t => renderTrackerItem(t))}
              </div>
            </div>
          )}

          {/* Folder Groups */}
          <div className="space-y-2">
            {folders.map(folder => {
              const folderTrackers = trackersByFolder.map[folder.id] || [];
              const isCollapsed = isFolderCollapsed(folder.id);
              const isEditing = editingFolderId === folder.id;

              if (!isOpen) {
                // When collapsed sidebar, just show active tracker buttons
                return null;
              }

              return (
                <div key={folder.id} className="rounded-xl border border-white/5 bg-white/2 overflow-hidden">
                  {/* Folder Header */}
                  <div
                    onClick={() => toggleFolder(folder.id)}
                    className="p-2 cursor-pointer flex items-center justify-between gap-1.5 hover:bg-white/5 transition-colors group select-none"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      {isCollapsed ? (
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      )}
                      {getFolderIcon(folder.icon, folder.color)}
                      {isEditing ? (
                        <div
                          className="flex items-center gap-1"
                          onClick={e => e.stopPropagation()}
                        >
                          <input
                            type="text"
                            value={editFolderName}
                            onChange={e => setEditFolderName(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleSaveRenameFolder(folder.id)}
                            autoFocus
                            className="text-xs px-1.5 py-0.5 rounded bg-slate-800 text-white border border-indigo-400 outline-none"
                          />
                          <button
                            onClick={() => handleSaveRenameFolder(folder.id)}
                            className="p-0.5 rounded bg-emerald-600 text-white"
                          >
                            <Check className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <span className="font-bold text-xs text-slate-200 truncate">
                          {folder.name}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      {/* Tracker Count Badge */}
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-400 group-hover:text-slate-200 border border-slate-700">
                        {folderTrackers.length}
                      </span>

                      {/* Folder options */}
                      {!isEditing && (
                        <div className="hidden group-hover:flex items-center gap-0.5">
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              setTargetFolderForNewTracker(folder.id);
                              setIsAddingTracker(true);
                            }}
                            title="Add tracker to this folder"
                            className="p-1 text-slate-400 hover:text-white rounded"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              setEditingFolderId(folder.id);
                              setEditFolderName(folder.name);
                            }}
                            title="Rename Folder"
                            className="p-1 text-slate-400 hover:text-white rounded"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                          {onDeleteFolder && (
                            <button
                              onClick={e => {
                                e.stopPropagation();
                                onDeleteFolder(folder.id);
                              }}
                              title="Delete Folder (Unfiles trackers)"
                              className="p-1 text-slate-400 hover:text-red-400 rounded"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Folder Contents */}
                  {!isCollapsed && (
                    <div className="pl-4 pr-1 pb-1 space-y-1">
                      {folderTrackers.length === 0 ? (
                        <div className="p-2 text-[11px] text-slate-500 italic">
                          No trackers in this folder. Click + to add one.
                        </div>
                      ) : (
                        folderTrackers.map(t => renderTrackerItem(t))
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Unfiled Trackers Section */}
          {trackersByFolder.unfiled.length > 0 && (
            <div className="space-y-1 pt-1">
              {isOpen && (
                <div className="text-[10px] uppercase font-bold text-slate-400 px-1.5 flex items-center justify-between">
                  <span>Unfiled Trackers ({trackersByFolder.unfiled.length})</span>
                </div>
              )}
              <div className="space-y-1">
                {trackersByFolder.unfiled.map(t => renderTrackerItem(t))}
              </div>
            </div>
          )}

          {/* Archived Trackers Section */}
          {archivedTrackers.length > 0 && isOpen && (
            <div className="pt-2 border-t border-white/5 space-y-1">
              <button
                onClick={() => setShowArchived(!showArchived)}
                className="w-full px-1.5 py-1 rounded flex items-center justify-between text-[10px] uppercase font-bold text-slate-400 hover:text-white"
              >
                <span className="flex items-center gap-1.5">
                  <Archive className="w-3 h-3" />
                  <span>Archived Trackers ({archivedTrackers.length})</span>
                </span>
                {showArchived ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              </button>

              {showArchived && (
                <div className="space-y-1 pl-2">
                  {archivedTrackers.map(t => renderTrackerItem(t))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-2 border-t border-white/10 space-y-1">
          {isOpen ? (
            <div className="flex items-center justify-between gap-1">
              <button
                onClick={onExportJSON}
                title="Backup full workspace to JSON file"
                className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded text-xs text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-sky-400" />
                <span>Backup</span>
              </button>
              <button
                onClick={onImportJSON}
                title="Restore workspace from JSON backup"
                className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded text-xs text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
              >
                <Upload className="w-3.5 h-3.5 text-emerald-400" />
                <span>Restore</span>
              </button>
              <button
                onClick={onToggle}
                title="Collapse Sidebar"
                className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onToggle}
              title="Expand Sidebar"
              className="w-full py-2 flex items-center justify-center text-slate-400 hover:text-white"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </aside>
    </>
  );
};
