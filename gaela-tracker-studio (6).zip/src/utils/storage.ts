import * as XLSX from 'xlsx';
import { AppState, Tracker, Row, Column } from '../types/tracker';
import { DEFAULT_LEGAL_CHECKLIST_ITEMS } from '../components/LegalChecklistModal';
import { generateDefaultDayByDayLog } from './dayByDayUtils';

const LOCAL_STORAGE_KEY = 'gaela_tracker_state_v3';
const ACTIVE_USER_KEY = 'gaela_active_user';
const OFFLINE_MODE_KEY = 'gaela_offline_preference';

export const initialDefaultState: AppState = {
  appName: 'Gaela',
  appSubtitle: 'Customizable Multi-Tracker Studio',
  theme: 'slate',
  activeTrackerId: 'tracker-saq',
  folders: [
    {
      id: 'folder-saq',
      name: 'Site Acquisition (SAQ)',
      icon: 'FolderKanban',
      color: 'blue',
      isCollapsed: false,
      createdAt: '2026-09-01T08:00:00.000Z'
    },
    {
      id: 'folder-legal',
      name: 'Legal & BP Permitting',
      icon: 'ShieldCheck',
      color: 'amber',
      isCollapsed: false,
      createdAt: '2026-09-01T08:00:00.000Z'
    },
    {
      id: 'folder-construction',
      name: 'Civil Works & Construction',
      icon: 'Hammer',
      color: 'purple',
      isCollapsed: false,
      createdAt: '2026-09-01T08:00:00.000Z'
    },
    {
      id: 'folder-reports',
      name: 'Executive Reports & Analytics',
      icon: 'BarChart3',
      color: 'emerald',
      isCollapsed: false,
      createdAt: '2026-09-01T08:00:00.000Z'
    }
  ],
  users: [
    {
      id: 'admin-1',
      username: 'Admin',
      email: 'admin@gaela.com',
      password: '',
      role: 'admin',
      status: 'approved',
      permission: 'editor',
      createdAt: '2026-09-01T08:00:00.000Z',
    },
    {
      id: 'staff-david',
      username: 'David Ramos',
      email: 'david.staff@gaela.com',
      password: 'staff123',
      role: 'staff',
      department: 'Site Execution',
      status: 'approved',
      permission: 'editor',
      createdAt: '2026-09-05T09:00:00.000Z',
    },
    {
      id: 'guest-demo',
      username: 'Alex Rivera',
      email: 'alex.rivera@team.com',
      password: 'guest1234',
      role: 'guest',
      department: 'Site Engineering',
      status: 'approved',
      permission: 'editor',
      createdAt: '2026-09-10T09:30:00.000Z',
    },
    {
      id: 'guest-pending',
      username: 'Sarah Chen',
      email: 'sarah.chen@contractor.org',
      password: 'guest1234',
      role: 'guest',
      department: 'Quality Audit',
      status: 'pending',
      permission: 'viewer',
      createdAt: '2026-09-22T14:15:00.000Z',
    }
  ],
  trackers: [
    {
      id: 'tracker-saq',
      name: 'Site Acquisition (SAQ) & SLA Process Tracker',
      description: 'End-to-end telecom SAQ milestones: Site Hunting w/ SAQ Submission, 21d Property Docs, 44d Pre-Con Permit, 21d Post-Con Permit, 7d FAC Submission, 1-week early warnings & 14-day stalled site detection.',
      icon: 'Building2',
      color: 'blue',
      folderId: 'folder-saq',
      isPinned: true,
      summaryCardsCollapsed: false,
      summaryCards: [
        {
          id: 'saq-kpi-1',
          title: 'Total Active Sites',
          columnId: 'col_site_id',
          calcType: 'count',
          format: 'number',
          tag: 'Rollout Pipeline',
          color: 'blue'
        },
        {
          id: 'saq-kpi-2',
          title: 'Average Site SLA Progress',
          columnId: 'col_percent',
          calcType: 'average',
          format: 'percent',
          tag: 'Overall Target',
          color: 'indigo'
        },
        {
          id: 'saq-kpi-3',
          title: 'Total Capex Budget (₱)',
          columnId: 'col_budget',
          calcType: 'sum',
          format: 'currency',
          tag: 'Allocated Capex',
          color: 'emerald'
        },
        {
          id: 'saq-kpi-4',
          title: 'Milestone Disbursed Cost (₱)',
          columnId: 'col_cost',
          calcType: 'sum',
          format: 'currency',
          tag: 'Actual Spent',
          color: 'rose'
        }
      ],
      columns: [
        { id: 'col_site_id', name: 'Site ID', type: 'text', width: 140, visible: true, color: 'blue' },
        { id: 'col_site_name', name: 'Site Name & Operator', type: 'text', width: 230, visible: true, color: 'indigo' },
        { id: 'col_location', name: 'Location / Province', type: 'text', width: 170, visible: true, color: 'slate' },
        { id: 'col_saq_hunting_date', name: 'Site Hunting w/ SAQ Submission', type: 'date', width: 165, visible: true, color: 'blue' },
        { id: 'col_day_by_day', name: 'Day-by-Day Progress & SLA Updates', type: 'day-by-day', width: 250, visible: true, color: 'blue' },
        { id: 'col_saq_prop_docs_target', name: 'Property Docs (21d SLA)', type: 'date', width: 160, visible: true, color: 'indigo' },
        { id: 'col_saq_prop_docs_status', name: 'Property Docs Status', type: 'status', width: 150, visible: true, color: 'indigo', options: ['Completed', 'In Progress', 'Overdue', 'Pending'] },
        { id: 'col_saq_precon_target', name: 'Pre-Con Permit (44d SLA)', type: 'date', width: 160, visible: true, color: 'purple' },
        { id: 'col_saq_precon_status', name: 'Pre-Con Permit Status', type: 'status', width: 155, visible: true, color: 'purple', options: ['Completed', 'In Progress', 'Overdue', 'Pending'] },
        { id: 'col_saq_poscon_target', name: 'Post-Con Permit (21d SLA)', type: 'date', width: 165, visible: true, color: 'amber' },
        { id: 'col_saq_poscon_status', name: 'Post-Con Status', type: 'status', width: 145, visible: true, color: 'amber', options: ['Completed', 'In Progress', 'Overdue', 'Pending'] },
        { id: 'col_saq_fac_target', name: 'FAC Submission (7d SLA)', type: 'date', width: 160, visible: true, color: 'emerald' },
        { id: 'col_saq_fac_status', name: 'FAC Status', type: 'status', width: 140, visible: true, color: 'emerald', options: ['Completed', 'In Progress', 'Overdue', 'Pending'] },
        { id: 'col_saq_last_movement_date', name: 'Last Movement Date', type: 'date', width: 155, visible: true, color: 'rose' },
        { id: 'col_percent', name: 'SLA Progress (%)', type: 'percent', width: 135, visible: true, color: 'amber' },
        { id: 'col_budget', name: 'Capex Budget (₱)', type: 'amount', width: 160, visible: true, color: 'emerald', currencySymbol: '₱' },
        { id: 'col_cost', name: 'Actual Cost (₱)', type: 'amount', width: 160, visible: true, color: 'rose', currencySymbol: '₱' },
        { id: 'col_responsible', name: 'SAQ Officer', type: 'text', width: 160, visible: true, color: 'slate' },
        { id: 'col_assigned_team', name: 'Assigned Team', type: 'text', width: 150, visible: true, color: 'slate' },
        { id: 'col_notes', name: 'Daily Movement Log & Notes', type: 'text', width: 260, visible: true, color: 'slate' },
        { id: 'col_legal_checklist', name: 'Legal Fees & Compliance Checklist', type: 'legal-checklist', width: 230, visible: true, color: 'amber' }
      ],
      rows: [
        {
          id: 'saq-row-1',
          col_site_id: 'SAQ-NCR-001',
          col_site_name: 'DITO - Pasig Kapitolyo Macro',
          col_location: 'NCR, Pasig City',
          col_saq_hunting_date: '2026-08-01',
          col_saq_prop_docs_target: '2026-08-22',
          col_saq_prop_docs_status: 'Completed',
          col_saq_precon_target: '2026-10-05',
          col_saq_precon_status: 'In Progress',
          col_saq_poscon_target: '2026-10-26',
          col_saq_poscon_status: 'Pending',
          col_saq_fac_target: '2026-11-02',
          col_saq_fac_status: 'Pending',
          col_saq_last_movement_date: '2026-10-02',
          col_percent: 65,
          col_budget: 850000,
          col_cost: 480000,
          col_responsible: 'Engr. Arnel Santos',
          col_assigned_team: 'NCR Alpha SAQ Team',
          col_notes: '⚠️ 1-WEEK WARNING: Pre-Con building permit hearing scheduled for Monday with Pasig City Hall.',
          col_legal_checklist: DEFAULT_LEGAL_CHECKLIST_ITEMS
        },
        {
          id: 'saq-row-2',
          col_site_id: 'SAQ-CEB-042',
          col_site_name: 'Globe - Mandaue Central Rooftop',
          col_location: 'Region VII, Cebu',
          col_saq_hunting_date: '2026-07-20',
          col_saq_prop_docs_target: '2026-08-10',
          col_saq_prop_docs_status: 'Completed',
          col_saq_precon_target: '2026-09-23',
          col_saq_precon_status: 'In Progress',
          col_saq_poscon_target: '2026-10-14',
          col_saq_poscon_status: 'Pending',
          col_saq_fac_target: '2026-10-21',
          col_saq_fac_status: 'Pending',
          col_saq_last_movement_date: '2026-09-15',
          col_percent: 45,
          col_budget: 720000,
          col_cost: 320000,
          col_responsible: 'Engr. Maria Santos',
          col_assigned_team: 'Visayas SAQ Unit',
          col_notes: '🚨 STALLED SITE ALERT: No movement recorded in 18 days! Pre-con permit pending zoning variance.',
          col_legal_checklist: DEFAULT_LEGAL_CHECKLIST_ITEMS
        },
        {
          id: 'saq-row-3',
          col_site_id: 'SAQ-DVO-019',
          col_site_name: 'Smart - Davao Buhangin Green Tower',
          col_location: 'Region XI, Davao City',
          col_saq_hunting_date: '2026-09-18',
          col_saq_prop_docs_target: '2026-10-09',
          col_saq_prop_docs_status: 'In Progress',
          col_saq_precon_target: '2026-11-22',
          col_saq_precon_status: 'Pending',
          col_saq_poscon_target: '2026-12-13',
          col_saq_poscon_status: 'Pending',
          col_saq_fac_target: '2026-12-20',
          col_saq_fac_status: 'Pending',
          col_saq_last_movement_date: '2026-10-01',
          col_percent: 25,
          col_budget: 950000,
          col_cost: 210000,
          col_responsible: 'Engr. J. Dela Cruz',
          col_assigned_team: 'Mindanao SAQ South',
          col_notes: '⚠️ 1-WEEK WARNING: Landowner title certified true copy release due this Friday from Davao RoD.',
          col_legal_checklist: DEFAULT_LEGAL_CHECKLIST_ITEMS
        },
        {
          id: 'saq-row-4',
          col_site_id: 'SAQ-LUG-088',
          col_site_name: 'Philtower - Clark Freeport Macro Hub',
          col_location: 'Region III, Pampanga',
          col_saq_hunting_date: '2026-06-15',
          col_saq_prop_docs_target: '2026-07-06',
          col_saq_prop_docs_status: 'Completed',
          col_saq_precon_target: '2026-08-19',
          col_saq_precon_status: 'Completed',
          col_saq_poscon_target: '2026-09-09',
          col_saq_poscon_status: 'Completed',
          col_saq_fac_target: '2026-09-16',
          col_saq_fac_status: 'Completed',
          col_saq_last_movement_date: '2026-09-18',
          col_percent: 100,
          col_budget: 1200000,
          col_cost: 1140000,
          col_responsible: 'Engr. Carlo Villanueva',
          col_assigned_team: 'Central Luzon SAQ',
          col_notes: '✅ 100% COMPLETE: FAC signed, energized, and commercial turnover handed over to carrier.',
          col_legal_checklist: DEFAULT_LEGAL_CHECKLIST_ITEMS
        },
        {
          id: 'saq-row-5',
          col_site_id: 'SAQ-ILO-031',
          col_site_name: 'DITO - Iloilo Mandurriao Monopole',
          col_location: 'Region VI, Iloilo',
          col_saq_hunting_date: '2026-09-01',
          col_saq_prop_docs_target: '2026-09-22',
          col_saq_prop_docs_status: 'Completed',
          col_saq_precon_target: '2026-11-05',
          col_saq_precon_status: 'In Progress',
          col_saq_poscon_target: '2026-11-26',
          col_saq_poscon_status: 'Pending',
          col_saq_fac_target: '2026-12-03',
          col_saq_fac_status: 'Pending',
          col_saq_last_movement_date: '2026-10-02',
          col_percent: 40,
          col_budget: 780000,
          col_cost: 310000,
          col_responsible: 'Engr. Rey Fernandez',
          col_assigned_team: 'Western Visayas SAQ',
          col_notes: 'On track: CAAP height clearance submitted; barangay resolution approved.',
          col_legal_checklist: DEFAULT_LEGAL_CHECKLIST_ITEMS
        }
      ]
    },
    {
      id: 'tracker-civil',
      name: 'SAQC & Civil Project Tracker',
      description: 'Site civil works, structural quality check, bill of quantities & milestone inspections.',
      icon: 'Building2',
      color: 'blue',
      folderId: 'folder-construction',
      isPinned: false,
      summaryCardsCollapsed: false,
      summaryCards: [
        {
          id: 's1',
          title: 'Total Project Value (₱)',
          columnId: 'col-amount',
          calcType: 'sum',
          format: 'currency',
          tag: 'Budget Cap',
          color: 'emerald'
        },
        {
          id: 's2',
          title: 'Avg Quality Progress',
          columnId: 'col-percent',
          calcType: 'average',
          format: 'percent',
          tag: 'Overall Milestone',
          color: 'indigo'
        },
        {
          id: 's3',
          title: 'Total Work Items',
          columnId: 'col-item',
          calcType: 'count',
          format: 'number',
          tag: 'WBS Units',
          color: 'slate'
        },
        {
          id: 's4',
          title: 'Completed Deliverables',
          columnId: 'col-status',
          calcType: 'count-completed',
          format: 'number',
          tag: 'Verified QMS',
          color: 'purple'
        }
      ],
      columns: [
        { id: 'col-item', name: 'Work Item & Description', type: 'text', width: 250, visible: true, color: 'slate' },
        { id: 'col-station', name: 'Station / Zone', type: 'text', width: 140, visible: true, color: 'blue' },
        { id: 'col-status', name: 'Status', type: 'status', width: 140, visible: true, color: 'indigo', options: ['Completed', 'In Progress', 'Review', 'Pending Approval', 'On Hold'] },
        { id: 'col-amount', name: 'Contract Amount (₱)', type: 'amount', width: 170, visible: true, color: 'emerald', currencySymbol: '₱' },
        { id: 'col-percent', name: 'Progress (%)', type: 'percent', width: 140, visible: true, color: 'amber' },
        { id: 'col-date', name: 'Target Inspection', type: 'date', width: 145, visible: true, color: 'rose' },
        { id: 'col-photo', name: 'Site Photo (JPEG)', type: 'jpeg', width: 150, visible: true, color: 'cyan' },
        { id: 'col-pdf', name: 'Inspection Report (PDF)', type: 'pdf', width: 170, visible: true, color: 'purple' },
        { id: 'col-notes', name: 'Engineer Remarks', type: 'text', width: 240, visible: true, color: 'slate' },
      ],
      rows: [
        {
          id: 'row-1',
          'col-item': 'Foundation Excavation & Rebar Reinforcement',
          'col-station': 'Sector A-1',
          'col-status': 'Completed',
          'col-amount': 2250000,
          'col-percent': 100,
          'col-date': '2026-09-15',
          'col-photo': 'https://images.unsplash.com/photo-1541888946425-d0fbb18615f3?w=500&auto=format&fit=crop&q=80',
          'col-pdf': 'SAQC-Excavation-SignOff-v1.pdf',
          'col-notes': 'Tested concrete batch #491. Passed 28-day compression test with 35MPa.'
        },
        {
          id: 'row-2',
          'col-item': 'Main Structural Steel Beam Framing',
          'col-station': 'Tower Core Level 3',
          'col-status': 'In Progress',
          'col-amount': 4125000,
          'col-percent': 75,
          'col-date': '2026-09-28',
          'col-photo': 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=500&auto=format&fit=crop&q=80',
          'col-pdf': 'Steel-Fabrication-NDT-Report.pdf',
          'col-notes': 'Ultrasonic test 100% accepted on joint welding.'
        },
        {
          id: 'row-3',
          'col-item': 'HVAC & MEP Ducting Installation',
          'col-station': 'Basement B2',
          'col-status': 'In Progress',
          'col-amount': 1910000,
          'col-percent': 40,
          'col-date': '2026-10-10',
          'col-photo': 'https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=500&auto=format&fit=crop&q=80',
          'col-pdf': 'MEP-Submittal-Approved.pdf',
          'col-notes': 'Fire damper testing scheduled for next Tuesday.'
        },
        {
          id: 'row-4',
          'col-item': 'Curtain Wall Facade Glazing',
          'col-station': 'North Elevation',
          'col-status': 'Review',
          'col-amount': 4750000,
          'col-percent': 25,
          'col-date': '2026-10-25',
          'col-photo': 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=500&auto=format&fit=crop&q=80',
          'col-pdf': 'Glazing-Water-Penetration-Spec.pdf',
          'col-notes': 'Thermal acoustic tests completed in laboratory.'
        },
        {
          id: 'row-5',
          'col-item': 'Electrical Transformer & Switchgear',
          'col-station': 'Substation Plant',
          'col-status': 'Pending Approval',
          'col-amount': 3100000,
          'col-percent': 10,
          'col-date': '2026-11-05',
          'col-photo': '',
          'col-pdf': 'Switchgear-SingleLineDiagram.pdf',
          'col-notes': 'Awaiting utility provider grid interconnect permit.'
        },
        {
          id: 'row-6',
          'col-item': 'PHILTOWER - St. Rosa Telecom Tower Foundation & Mast Erection',
          'col-station': 'Philtower Site 01',
          'col-status': 'Completed',
          'col-amount': 3850000,
          'col-percent': 100,
          'col-date': '2026-09-18',
          'col-photo': 'https://images.unsplash.com/photo-1541888946425-d0fbb18615f3?w=500&auto=format&fit=crop&q=80',
          'col-pdf': 'Philtower-Civil-Turnover-SignOff.pdf',
          'col-notes': 'Philtower macro tower erection 100% completed and inspected.'
        }
      ]
    },
    {
      id: 'tracker-budget',
      name: 'Department Budget & Expense Monitor',
      description: 'Operating expenditure, contractor invoices, PO tracking and payment milestones.',
      icon: 'BadgeDollarSign',
      color: 'emerald',
      folderId: 'folder-reports',
      summaryCardsCollapsed: false,
      summaryCards: [
        {
          id: 'b1',
          title: 'Total Invoiced Cost (₱)',
          columnId: 'b-amount',
          calcType: 'sum',
          format: 'currency',
          tag: 'Actual vs Budget',
          color: 'emerald'
        },
        {
          id: 'b2',
          title: 'Payment Disbursed %',
          columnId: 'b-percent',
          calcType: 'average',
          format: 'percent',
          tag: 'Cashflow Pace',
          color: 'indigo'
        },
        {
          id: 'b3',
          title: 'Total Line Items',
          columnId: 'b-item',
          calcType: 'count',
          format: 'number',
          tag: 'Vouchers',
          color: 'slate'
        }
      ],
      columns: [
        { id: 'b-item', name: 'Expense Description', type: 'text', width: 230, visible: true, color: 'slate' },
        { id: 'b-vendor', name: 'Vendor / Contractor', type: 'text', width: 180, visible: true, color: 'blue' },
        { id: 'b-status', name: 'Invoice Status', type: 'status', width: 130, visible: true, color: 'indigo', options: ['Completed', 'In Progress', 'Pending Approval', 'On Hold'] },
        { id: 'b-amount', name: 'Invoice Amount (₱)', type: 'amount', width: 160, visible: true, color: 'emerald', currencySymbol: '₱' },
        { id: 'b-percent', name: 'Paid (%)', type: 'percent', width: 130, visible: true, color: 'amber' },
        { id: 'b-date', name: 'Due Date', type: 'date', width: 140, visible: true, color: 'rose' },
        { id: 'b-receipt', name: 'Receipt JPEG', type: 'jpeg', width: 140, visible: true, color: 'cyan' },
        { id: 'b-pdf', name: 'Invoice PDF', type: 'pdf', width: 150, visible: true, color: 'purple' },
      ],
      rows: [
        {
          id: 'brow-1',
          'b-item': 'Heavy Crane Rental (30-day)',
          'b-vendor': 'Apex Machinery Corp',
          'b-status': 'Completed',
          'b-amount': 925000,
          'b-percent': 100,
          'b-date': '2026-09-10',
          'b-receipt': 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?w=500&auto=format&fit=crop&q=80',
          'b-pdf': 'Apex-Crane-Inv-889.pdf'
        },
        {
          id: 'brow-2',
          'b-item': 'Ready-Mix Concrete 300 cu.m',
          'b-vendor': 'Metro Ready-Mix Inc',
          'b-status': 'In Progress',
          'b-amount': 1470000,
          'b-percent': 50,
          'b-date': '2026-09-30',
          'b-receipt': '',
          'b-pdf': 'Metro-BatchReceipts.pdf'
        },
        {
          id: 'brow-3',
          'b-item': 'PHILTOWER - Structural Steel & Generator Sets Billing',
          'b-vendor': 'Philtower Infrastructure / EnerSys',
          'b-status': 'Completed',
          'b-amount': 840000,
          'b-percent': 100,
          'b-date': '2026-09-22',
          'b-receipt': '',
          'b-pdf': 'Philtower-GenSet-Billing-OR44.pdf'
        }
      ]
    },
    {
      id: 'tracker-equipment',
      name: 'Equipment & Tool Inventory',
      description: 'Machinery allocation, inspection validity, maintenance and digital manuals.',
      icon: 'Wrench',
      color: 'purple',
      folderId: 'folder-construction',
      summaryCardsCollapsed: false,
      summaryCards: [
        {
          id: 'e1',
          title: 'Equipment Asset Value (₱)',
          columnId: 'e-value',
          calcType: 'sum',
          format: 'currency',
          tag: 'Fleet Total',
          color: 'emerald'
        },
        {
          id: 'e2',
          title: 'Fleet Operational Health',
          columnId: 'e-health',
          calcType: 'average',
          format: 'percent',
          tag: 'Readiness',
          color: 'indigo'
        },
        {
          id: 'e3',
          title: 'Tracked Assets',
          columnId: 'e-asset',
          calcType: 'count',
          format: 'number',
          tag: 'Active Units',
          color: 'slate'
        }
      ],
      columns: [
        { id: 'e-asset', name: 'Equipment / Tool Name', type: 'text', width: 230, visible: true, color: 'slate' },
        { id: 'e-serial', name: 'Serial / Plate #', type: 'text', width: 140, visible: true, color: 'slate' },
        { id: 'e-status', name: 'Operational State', type: 'status', width: 140, visible: true, color: 'indigo', options: ['Completed', 'In Progress', 'Inspection Required', 'Under Repair'] },
        { id: 'e-value', name: 'Asset Value (₱)', type: 'amount', width: 160, visible: true, color: 'emerald', currencySymbol: '₱' },
        { id: 'e-health', name: 'Condition (%)', type: 'percent', width: 130, visible: true, color: 'amber' },
        { id: 'e-date', name: 'Next Calibration', type: 'date', width: 140, visible: true, color: 'rose' },
        { id: 'e-photo', name: 'Asset Photo (JPEG)', type: 'jpeg', width: 140, visible: true, color: 'cyan' },
        { id: 'e-pdf', name: 'Safety Certificate (PDF)', type: 'pdf', width: 160, visible: true, color: 'purple' },
      ],
      rows: [
        {
          id: 'erow-1',
          'e-asset': 'Total Station Theodolite TS-16',
          'e-serial': 'LEICA-773921',
          'e-status': 'Completed',
          'e-value': 710000,
          'e-health': 98,
          'e-date': '2026-12-01',
          'e-photo': 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=500&auto=format&fit=crop&q=80',
          'e-pdf': 'Leica-Calibration-Cert-2026.pdf'
        },
        {
          id: 'erow-2',
          'e-asset': 'Hydraulic Excavator CAT 320',
          'e-serial': 'CAT-EX-99014',
          'e-status': 'In Progress',
          'e-value': 8250000,
          'e-health': 85,
          'e-date': '2026-10-15',
          'e-photo': 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=500&auto=format&fit=crop&q=80',
          'e-pdf': 'CAT320-Safety-Manual.pdf'
        },
        {
          id: 'erow-3',
          'e-asset': 'PHILTOWER - Mobile Tower Crane 50-Ton (Site Deploy)',
          'e-serial': 'KATO-CR-8821',
          'e-status': 'Completed',
          'e-value': 4600000,
          'e-health': 92,
          'e-date': '2026-11-20',
          'e-photo': 'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?w=500&auto=format&fit=crop&q=80',
          'e-pdf': 'KATO-Crane-Inspection-Report.pdf'
        }
      ]
    },
    {
      id: 'tracker-bp',
      name: 'Building Permit (BP) & Site Payment Tracker',
      description: 'Track site building permit (BP) applications, payment requests, target dates, dates settled, and close dates.',
      icon: 'FileCheck2',
      color: 'emerald',
      folderId: 'folder-legal',
      summaryCardsCollapsed: false,
      summaryCards: [
        {
          id: 'bp-sum1',
          title: 'Total BP Requests (₱)',
          columnId: 'bp-req-amount',
          calcType: 'sum',
          format: 'currency',
          tag: 'Requested Fees',
          color: 'emerald'
        },
        {
          id: 'bp-sum2',
          title: 'Total BP Settled (₱)',
          columnId: 'bp-settled-amount',
          calcType: 'sum',
          format: 'currency',
          tag: 'Settled to LGU',
          color: 'indigo'
        },
        {
          id: 'bp-sum3',
          title: 'Active Sites / Applications',
          columnId: 'bp-site',
          calcType: 'count',
          format: 'number',
          tag: 'Sites',
          color: 'slate'
        }
      ],
      columns: [
        { id: 'bp-site', name: 'SITE NAME / CODE', type: 'text', width: 220, visible: true, color: 'blue' },
        { id: 'bp-purpose', name: 'PURPOSE / SCOPE', type: 'text', width: 200, visible: true, color: 'slate' },
        { id: 'bp-status', name: 'BP STATUS', type: 'status', width: 140, visible: true, color: 'indigo', options: ['Applied', 'Payment Requested', 'Settled', 'Under Evaluation', 'Approved / Closed', 'Delayed'] },
        { id: 'bp-req-amount', name: 'REQUEST PAYMENT FOR BP (₱)', type: 'amount', width: 220, visible: true, color: 'emerald', currencySymbol: '₱' },
        { id: 'bp-date-apply', name: 'DATE APPLY', type: 'date', width: 140, visible: true, color: 'amber' },
        { id: 'bp-date-target', name: 'DATE TARGET', type: 'date', width: 140, visible: true, color: 'rose' },
        { id: 'bp-date-settled', name: 'DATE SETTLED', type: 'date', width: 140, visible: true, color: 'cyan' },
        { id: 'bp-settled-amount', name: 'SETTLED AMOUNT (₱)', type: 'amount', width: 170, visible: true, color: 'emerald', currencySymbol: '₱' },
        { id: 'bp-date-close', name: 'DATE CLOSE', type: 'date', width: 140, visible: true, color: 'purple' },
        { id: 'bp-receipt', name: 'LGU RECEIPT / OR (JPEG)', type: 'jpeg', width: 160, visible: true, color: 'cyan' },
        { id: 'bp-permit-doc', name: 'PERMIT DOCUMENT (PDF)', type: 'pdf', width: 160, visible: true, color: 'purple' },
        { id: 'bp-remarks', name: 'REMARKS', type: 'text', width: 200, visible: true, color: 'slate' }
      ],
      rows: [
        {
          id: 'bp-row-1',
          'bp-site': 'PHILTOWER - ST. ROSA 01',
          'bp-purpose': 'Building Permit & Ancillary Permits (BP)',
          'bp-status': 'Settled',
          'bp-req-amount': 45000,
          'bp-date-apply': '2026-08-10',
          'bp-date-target': '2026-09-30',
          'bp-date-settled': '2026-09-15',
          'bp-settled-amount': 45000,
          'bp-date-close': '2026-09-20',
          'bp-receipt': '',
          'bp-permit-doc': 'BP-Approved-Laguna-01.pdf',
          'bp-remarks': 'City Engineer clearance released and settled.'
        },
        {
          id: 'bp-row-2',
          'bp-site': 'EDGEPOINT - CAVITE MACRO',
          'bp-purpose': 'Zoning & Building Permit Processing',
          'bp-status': 'Payment Requested',
          'bp-req-amount': 38500,
          'bp-date-apply': '2026-09-02',
          'bp-date-target': '2026-10-15',
          'bp-date-settled': '',
          'bp-settled-amount': 0,
          'bp-date-close': '',
          'bp-receipt': '',
          'bp-permit-doc': '',
          'bp-remarks': 'Check payment request forwarded to accounting.'
        },
        {
          id: 'bp-row-3',
          'bp-site': 'UNITY - BATANGAS L2',
          'bp-purpose': 'BP Application & Excavation Filing',
          'bp-status': 'Settled',
          'bp-req-amount': 52000,
          'bp-date-apply': '2026-08-25',
          'bp-date-target': '2026-10-05',
          'bp-date-settled': '2026-09-21',
          'bp-settled-amount': 52000,
          'bp-date-close': '',
          'bp-receipt': '',
          'bp-permit-doc': '',
          'bp-remarks': 'LGU fee settled, awaiting final zoning inspector signoff.'
        }
      ]
    }
  ],
  trackerPermissions: [
    {
      id: 'perm-staff-civil',
      userId: 'staff-david',
      trackerId: 'tracker-civil',
      canView: true,
      canAdd: true,
      canEdit: true,
      canDelete: false,
      canExport: true,
      fieldPermissions: {
        'col-item': 'view',
        'col-station': 'view',
        'col-status': 'edit',
        'col-amount': 'no_access',
        'col-percent': 'edit',
        'col-date': 'view',
        'col-photo': 'edit',
        'col-pdf': 'view',
        'col-notes': 'edit'
      },
      approvedBy: 'Admin (admin@gaela.com)',
      updatedAt: '2026-09-15T10:00:00.000Z'
    },
    {
      id: 'perm-guest-civil',
      userId: 'guest-demo',
      trackerId: 'tracker-civil',
      canView: true,
      canAdd: false,
      canEdit: false,
      canDelete: false,
      canExport: false,
      fieldPermissions: {
        'col-amount': 'view',
        'col-item': 'view',
        'col-station': 'view',
        'col-status': 'view'
      },
      approvedBy: 'Admin (admin@gaela.com)',
      updatedAt: '2026-09-12T08:30:00.000Z'
    }
  ],
  accessRequests: [
    {
      id: 'req-1',
      userId: 'guest-demo',
      userName: 'Alex Rivera',
      userEmail: 'alex.rivera@team.com',
      userRole: 'guest',
      trackerId: 'tracker-civil',
      trackerName: 'SAQC & Civil Project Tracker',
      requestedPermissions: {
        view: true,
        add: false,
        edit: true,
        delete: false,
        export: false
      },
      requestedFields: ['col-status', 'col-percent', 'col-notes'],
      reason: 'Need to record daily milestone progress and punchlist notes for civil works handover.',
      status: 'pending',
      createdAt: '2026-09-29T14:30:00.000Z'
    },
    {
      id: 'req-2',
      userId: 'staff-david',
      userName: 'David Ramos',
      userEmail: 'david.staff@gaela.com',
      userRole: 'staff',
      trackerId: 'tracker-budget',
      trackerName: 'Department Budget & Expense Monitor',
      requestedPermissions: {
        view: true,
        add: true,
        edit: true,
        delete: false,
        export: true
      },
      requestedFields: ['b-status', 'b-percent', 'b-vendor'],
      reason: 'Assigned to reconcile vendor invoice settlements and milestone progress for Q4.',
      status: 'pending',
      createdAt: '2026-09-30T10:15:00.000Z'
    }
  ],
  activityLogs: [
    {
      id: 'log-seed-1',
      userId: 'admin-1',
      userName: 'Admin',
      userEmail: 'admin@gaela.com',
      userRole: 'admin',
      trackerId: 'tracker-civil',
      trackerName: 'SAQC & Civil Project Tracker',
      action: 'APPROVE_PERMISSION',
      changedField: 'Tracker Access & Field Permissions',
      oldValue: 'No Access',
      newValue: 'View, Add, Edit, Export (Amount: No Access, Date: View Only)',
      approvedBy: 'Admin (admin@gaela.com)',
      timestamp: '2026-09-15T10:00:00.000Z',
      details: 'Approved Staff access for David Ramos with field-level restrictions.'
    },
    {
      id: 'log-seed-2',
      userId: 'staff-david',
      userName: 'David Ramos',
      userEmail: 'david.staff@gaela.com',
      userRole: 'staff',
      trackerId: 'tracker-civil',
      trackerName: 'SAQC & Civil Project Tracker',
      action: 'EDIT_CELL',
      changedField: 'Status',
      columnId: 'col-status',
      rowId: 'row-2',
      oldValue: 'Review',
      newValue: 'In Progress',
      approvedBy: 'System (Authorized)',
      timestamp: '2026-09-28T16:20:00.000Z',
      details: 'Updated work milestone status.'
    }
  ]
};

// Get cached state from localStorage
export function getLocalState(): AppState {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.trackers && parsed.trackers.length > 0) {
        // Guarantee tracker-saq exists
        let loadedTrackers: Tracker[] = parsed.trackers;
        const hasSaqTracker = loadedTrackers.some(t => t.id === 'tracker-saq');
        if (!hasSaqTracker) {
          const defaultSaq = initialDefaultState.trackers.find(t => t.id === 'tracker-saq');
          if (defaultSaq) {
            loadedTrackers = [defaultSaq, ...loadedTrackers];
          }
        }

        // Map any missing folderId to appropriate folder
        loadedTrackers = loadedTrackers.map(t => {
          if (t.folderId) return t;
          if (t.id === 'tracker-saq' || t.name.toLowerCase().includes('saq') || t.name.toLowerCase().includes('hunting')) {
            return { ...t, folderId: 'folder-saq' };
          }
          if (t.id === 'tracker-bp' || t.name.toLowerCase().includes('permit') || t.name.toLowerCase().includes('legal')) {
            return { ...t, folderId: 'folder-legal' };
          }
          if (t.id === 'tracker-budget' || t.name.toLowerCase().includes('budget') || t.name.toLowerCase().includes('report')) {
            return { ...t, folderId: 'folder-reports' };
          }
          return { ...t, folderId: 'folder-construction' };
        });

        // Ensure tracker-saq has col_legal_checklist column & rows initialized
        loadedTrackers = loadedTrackers.map(t => {
          if (t.id === 'tracker-saq' || t.name.toLowerCase().includes('saq')) {
            let updated = { ...t };
            const hasLegalCol = updated.columns.some(c => c.id === 'col_legal_checklist' || c.type === 'legal-checklist');
            if (!hasLegalCol) {
              const legalCol: Column = {
                id: 'col_legal_checklist',
                name: 'Legal Fees & Compliance Checklist',
                type: 'legal-checklist',
                width: 230,
                visible: true,
                color: 'amber'
              };
              updated.columns = [...updated.columns, legalCol];
              updated.rows = updated.rows.map(r => ({
                ...r,
                col_legal_checklist: r.col_legal_checklist || DEFAULT_LEGAL_CHECKLIST_ITEMS
              }));
            }

            const hasDayByDayCol = updated.columns.some(c => c.id === 'col_day_by_day' || c.type === 'day-by-day');
            if (!hasDayByDayCol) {
              const dayByDayCol: Column = {
                id: 'col_day_by_day',
                name: 'Day-by-Day Progress & SLA Updates',
                type: 'day-by-day',
                width: 250,
                visible: true,
                color: 'blue'
              };
              // Insert right after hunting date if found
              const huntingIdx = updated.columns.findIndex(c => c.id === 'col_saq_hunting_date');
              if (huntingIdx >= 0) {
                const colsCopy = [...updated.columns];
                colsCopy.splice(huntingIdx + 1, 0, dayByDayCol);
                updated.columns = colsCopy;
              } else {
                updated.columns = [...updated.columns, dayByDayCol];
              }
              updated.rows = updated.rows.map(r => ({
                ...r,
                col_day_by_day: r.col_day_by_day || generateDefaultDayByDayLog(
                  r.col_site_id || r.id,
                  r.col_site_name || 'Site',
                  r.col_saq_hunting_date || '2026-08-01',
                  r.col_saq_precon_status === 'In Progress' ? 'Pre-Con' : 'Pro Docs'
                )
              }));
            }
            return updated;
          }
          return t;
        });

        const activeId = parsed.activeTrackerId && loadedTrackers.some(t => t.id === parsed.activeTrackerId)
          ? parsed.activeTrackerId
          : 'tracker-saq';

        return {
          ...initialDefaultState,
          ...parsed,
          activeTrackerId: activeId,
          folders: (parsed.folders && Array.isArray(parsed.folders) && parsed.folders.length > 0)
            ? parsed.folders
            : initialDefaultState.folders,
          trackers: loadedTrackers,
          trackerPermissions: parsed.trackerPermissions && parsed.trackerPermissions.length > 0
            ? parsed.trackerPermissions
            : initialDefaultState.trackerPermissions,
          accessRequests: parsed.accessRequests && parsed.accessRequests.length > 0
            ? parsed.accessRequests
            : initialDefaultState.accessRequests,
          activityLogs: parsed.activityLogs && parsed.activityLogs.length > 0
            ? parsed.activityLogs
            : initialDefaultState.activityLogs
        };
      }
    }
  } catch (err) {
    console.error('Failed to parse local state:', err);
  }
  return initialDefaultState;
}

import { saveStateToIndexedDB, getStateFromIndexedDB } from './indexedDBStorage';

// Save state to localStorage with IndexedDB fallback for datasets exceeding 5MB
export function saveLocalState(state: AppState) {
  // Always asynchronously persist to IndexedDB (safe for 100,000+ rows)
  saveStateToIndexedDB(state).catch(err => {
    console.warn('Could not persist to IndexedDB:', err);
  });

  try {
    const serialized = JSON.stringify(state);
    // If serialized string is under 4.5MB, save to localStorage for instant synchronous startup
    if (serialized.length < 4.5 * 1024 * 1024) {
      localStorage.setItem(LOCAL_STORAGE_KEY, serialized);
    } else {
      // Store lightweight skeleton in localStorage so startup is never empty
      const lightweightSkeleton: AppState = {
        ...state,
        trackers: state.trackers.map(t => ({
          ...t,
          rows: t.rows.length > 500 ? t.rows.slice(0, 500) : t.rows
        }))
      };
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(lightweightSkeleton));
    }
  } catch (err) {
    console.warn('LocalStorage limit exceeded, full dataset is preserved in IndexedDB:', err);
  }
}

// Asynchronous loader that checks IndexedDB for full high-volume datasets
export async function loadPersistedState(): Promise<AppState> {
  try {
    const idbState = await getStateFromIndexedDB();
    if (idbState && idbState.trackers && idbState.trackers.length > 0) {
      return {
        ...initialDefaultState,
        ...idbState
      };
    }
  } catch (err) {
    console.warn('Could not load from IndexedDB, falling back to localStorage:', err);
  }
  return getLocalState();
}

// Fetch from cloud database with offline fallback
export async function fetchCloudState(): Promise<{ state: AppState; online: boolean }> {
  try {
    const res = await fetch('/api/data', { cache: 'no-store' });
    if (res.ok) {
      const data: AppState = await res.json();
      saveLocalState(data);
      return { state: data, online: true };
    }
  } catch (err) {
    console.warn('Backend unavailable, running in offline mode:', err);
  }
  return { state: getLocalState(), online: false };
}

// Save to cloud database with offline fallback
export async function syncCloudState(state: AppState): Promise<boolean> {
  saveLocalState(state);
  try {
    const savedUser = getSavedUser();
    const res = await fetch('/api/data', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': savedUser?.id || ''
      },
      body: JSON.stringify(state)
    });
    return res.ok;
  } catch (err) {
    console.warn('Could not sync to cloud, saved locally:', err);
    return false;
  }
}

// Active logged in user
export function getSavedUser() {
  try {
    const raw = localStorage.getItem(ACTIVE_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function saveActiveUser(user: any) {
  if (user) {
    localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(ACTIVE_USER_KEY);
  }
}

// Number & Currency formatting - Defaults to Philippine Peso ₱
export function formatCurrency(amount: number, symbol = '₱'): string {
  if (isNaN(amount) || amount === null || amount === undefined) return `${symbol}0.00`;
  return `${symbol}${amount.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatPercent(val: number): string {
  if (isNaN(val) || val === null || val === undefined) return '0%';
  return `${Number(val).toFixed(1).replace(/\.0$/, '')}%`;
}

// Robust date normalizer supporting Excel serial numbers (e.g. 45550), ISO dates, slash dates, Date objects
export function normalizeExcelDate(val: any): string {
  if (val === null || val === undefined || val === '') return '';

  // 1. Direct Date object (when cellDates: true is used in XLSX reader)
  if (val instanceof Date) {
    if (!isNaN(val.getTime())) {
      const y = val.getUTCFullYear();
      const m = String(val.getUTCMonth() + 1).padStart(2, '0');
      const d = String(val.getUTCDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }
    return '';
  }

  const str = String(val).trim();
  if (!str) return '';

  // 2. Numeric Excel serial number (e.g., 45550 or "45550" or "45550.5")
  if (/^\d{4,6}(\.\d+)?$/.test(str)) {
    const serial = parseFloat(str);
    // Excel serial dates: 1 = 1900-01-01, 45550 = 2024-09-15, etc.
    if (serial > 1000 && serial < 150000) {
      if (XLSX.SSF && typeof XLSX.SSF.parse_date_code === 'function') {
        try {
          const parsed = XLSX.SSF.parse_date_code(serial);
          if (parsed && parsed.y && parsed.m && parsed.d) {
            const y = parsed.y;
            const m = String(parsed.m).padStart(2, '0');
            const d = String(parsed.d).padStart(2, '0');
            return `${y}-${m}-${d}`;
          }
        } catch {
          // fallback to JS calculation
        }
      }
      // JS fallback for Excel serial date (Excel 1900 leap-year bug offset = 25569)
      try {
        const utcDays = Math.floor(serial - 25569);
        const utcValue = utcDays * 86400 * 1000;
        const dateInfo = new Date(utcValue);
        if (!isNaN(dateInfo.getTime())) {
          const y = dateInfo.getUTCFullYear();
          const m = String(dateInfo.getUTCMonth() + 1).padStart(2, '0');
          const d = String(dateInfo.getUTCDate()).padStart(2, '0');
          return `${y}-${m}-${d}`;
        }
      } catch {}
    }
  }

  // 3. Already YYYY-MM-DD or YYYY/MM/DD
  const ymdMatch = str.match(/^(\d{4})[-\/\.](\d{1,2})[-\/\.](\d{1,2})/);
  if (ymdMatch) {
    const y = ymdMatch[1];
    const m = ymdMatch[2].padStart(2, '0');
    const d = ymdMatch[3].padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // 4. Common MM/DD/YYYY or DD/MM/YYYY
  const slashMatch = str.match(/^(\d{1,2})[-\/\.](\d{1,2})[-\/\.](\d{2,4})/);
  if (slashMatch) {
    let p1 = parseInt(slashMatch[1], 10);
    let p2 = parseInt(slashMatch[2], 10);
    let year = parseInt(slashMatch[3], 10);
    if (year < 100) year += year < 50 ? 2000 : 1900;

    let month = p1;
    let day = p2;
    // If first number is > 12, it must be DD/MM/YYYY
    if (p1 > 12 && p2 <= 12) {
      day = p1;
      month = p2;
    }

    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
  }

  // 5. Standard date string (e.g. "Sep 15, 2026" or "15 Sep 2026")
  const parsedTs = Date.parse(str);
  if (!isNaN(parsedTs)) {
    const dObj = new Date(parsedTs);
    const y = dObj.getFullYear();
    const m = String(dObj.getMonth() + 1).padStart(2, '0');
    const d = String(dObj.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  return str;
}

// Excel paste parser
export function parseExcelData(text: string): string[][] {
  if (!text) return [];
  const lines = text.trim().split(/\r\n|\r|\n/);
  return lines.map(line => line.split('\t'));
}

// Excel file parser for .xlsx, .xls, .csv files with date preservation
export async function parseExcelFile(file: File): Promise<string[][]> {
  const data = await file.arrayBuffer();
  // cellDates: true converts Excel serial date numbers to Date objects
  const workbook = XLSX.read(data, { type: 'array', cellDates: true });
  const firstSheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[firstSheetName];
  const rows: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });
  
  return rows.map(r =>
    r.map(c => {
      if (c instanceof Date) {
        return normalizeExcelDate(c);
      }
      return String(c ?? '');
    })
  );
}

// Export to genuine Microsoft Excel (.xlsx) file
export function exportToExcel(tracker: Tracker) {
  const visibleCols = tracker.columns.filter(c => c.visible);
  const headers = visibleCols.map(c => c.name);

  const dataRows = tracker.rows.map(r => {
    return visibleCols.map(c => {
      const val = r[c.id];
      if (c.type === 'amount' || c.type === 'percent') {
        const num = typeof val === 'number' ? val : parseFloat(String(val || 0).replace(/[^0-9.-]+/g, '')) || 0;
        return num;
      }
      return val ?? '';
    });
  });

  const worksheet = XLSX.utils.aoa_to_sheet([headers, ...dataRows]);
  
  // Auto column widths
  worksheet['!cols'] = visibleCols.map(c => ({
    wch: Math.max(c.name.length + 4, 15)
  }));

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Gaela Tracker');

  const filename = `${tracker.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, filename);
}

// Export complete search results across all trackers with all columns to Excel (.xlsx)
export function exportSearchResultsToExcel(results: any[], queryTerm = '') {
  if (!results || results.length === 0) return;

  // Collect unique column names in order of appearance
  const standardHeaders = ['Source Sheet', 'CAL / Ref No.', 'Personnel Name', 'Project', 'Week', 'Status / Remarks', 'Scope / Purpose'];
  const extraHeaders = new Set<string>();

  results.forEach(res => {
    (res.allColumnsData || []).forEach((c: any) => {
      const name = c.colName;
      if (!standardHeaders.includes(name)) {
        extraHeaders.add(name);
      }
    });
  });

  const allHeaders = [...standardHeaders, ...Array.from(extraHeaders)];

  const dataRows = results.map(res => {
    return allHeaders.map(header => {
      if (header === 'Source Sheet') return res.trackerName || '';
      if (header === 'CAL / Ref No.') return res.calNo || '';
      if (header === 'Personnel Name') return res.personName || res.primaryTitle || '';
      if (header === 'Project') return res.projectName || '';
      if (header === 'Week') return res.weekName || '';
      if (header === 'Status / Remarks') return res.statusValue || res.remarksValue || '';
      if (header === 'Scope / Purpose') return res.purposeValue || '';

      const colData = (res.allColumnsData || []).find((c: any) => c.colName === header);
      if (!colData) return '';
      if (colData.type === 'amount') {
        const num = typeof colData.rawValue === 'number' ? colData.rawValue : parseFloat(String(colData.rawValue || 0).replace(/[^0-9.-]+/g, '')) || 0;
        return num;
      }
      return colData.formattedValue || colData.rawValue || '';
    });
  });

  const worksheet = XLSX.utils.aoa_to_sheet([allHeaders, ...dataRows]);
  worksheet['!cols'] = allHeaders.map(h => ({ wch: Math.max(h.length + 4, 16) }));

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Search All Data Details');

  const cleanQuery = queryTerm ? `_${queryTerm.replace(/[^a-zA-Z0-9_-]/g, '_')}` : '';
  const filename = `Complete_Search_Data_Details${cleanQuery}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(workbook, filename);
}

// Export CSV
export function exportToCSV(tracker: Tracker) {
  const visibleCols = tracker.columns.filter(c => c.visible);
  const headers = visibleCols.map(c => `"${c.name.replace(/"/g, '""')}"`).join(',');
  
  const rows = tracker.rows.map(r => {
    return visibleCols.map(c => {
      const val = r[c.id] ?? '';
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(',');
  });

  const csvContent = [headers, ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${tracker.name.replace(/[^a-zA-Z0-9_-]/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Export JSON Backup
export function exportToJSON(state: AppState) {
  const json = JSON.stringify(state, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Gaela_Tracker_Backup_${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// Snapshot & Version History for Accidental Delete/Change Protection
export interface SnapshotBackup {
  id: string;
  timestamp: string;
  label: string;
  totalTrackers: number;
  totalRows: number;
  state: AppState;
}

const SNAPSHOTS_KEY = 'gaela_snapshots_history_v2';
let lastSnapshotTime = 0;

export function saveSnapshotBackup(state: AppState, label = 'Auto-Save', force = false): SnapshotBackup[] {
  try {
    const now = Date.now();
    // Throttle automatic auto-saves to at most once every 5 minutes unless forced
    if (!force && label === 'Auto-Save Backup' && now - lastSnapshotTime < 5 * 60 * 1000) {
      return getSnapshotBackups();
    }
    lastSnapshotTime = now;

    const raw = localStorage.getItem(SNAPSHOTS_KEY);
    const existing: SnapshotBackup[] = raw ? JSON.parse(raw) : [];
    const totalRows = (state.trackers || []).reduce((acc, t) => acc + (t.rows ? t.rows.length : 0), 0);
    const newSnapshot: SnapshotBackup = {
      id: 'snap-' + now,
      timestamp: new Date().toISOString(),
      label,
      totalTrackers: (state.trackers || []).length,
      totalRows,
      state
    };
    // Keep up to 3 snapshots to keep localStorage lightweight and instant
    const updated = [newSnapshot, ...existing.slice(0, 2)];
    localStorage.setItem(SNAPSHOTS_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.warn('Could not save snapshot backup to localStorage (quota or size):', err);
    return [];
  }
}

export function getSnapshotBackups(): SnapshotBackup[] {
  try {
    const raw = localStorage.getItem(SNAPSHOTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

