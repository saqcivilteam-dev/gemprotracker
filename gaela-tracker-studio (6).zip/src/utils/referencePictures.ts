/**
 * High-resolution SVG Reference Pictures and Proof Documents for Legal & Compliance Requirements
 * Used for per-site clickable checklist reference previews and lightboxes.
 */

export function createOfficialDocumentSvg(
  title: string,
  subtitle: string,
  category: string,
  docNumber: string,
  siteName: string,
  date: string,
  primaryColor = '#1e3a8a',
  sealColor = '#b45309'
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1000" width="800" height="1000">
    <defs>
      <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#ffffff"/>
        <stop offset="100%" stop-color="#f8fafc"/>
      </linearGradient>
      <pattern id="guilloche" width="40" height="40" patternUnits="userSpaceOnUse">
        <path d="M 0 20 Q 10 0 20 20 T 40 20" fill="none" stroke="#e2e8f0" stroke-width="0.5"/>
      </pattern>
      <filter id="shadow" x="-5%" y="-5%" width="110%" height="110%">
        <feDropShadow dx="2" dy="4" stdDeviation="6" flood-opacity="0.15"/>
      </filter>
    </defs>

    <!-- Document Background -->
    <rect width="800" height="1000" fill="url(#bg)"/>
    <rect x="25" y="25" width="750" height="950" fill="none" stroke="${primaryColor}" stroke-width="3"/>
    <rect x="35" y="35" width="730" height="930" fill="none" stroke="#94a3b8" stroke-width="1" stroke-dasharray="4,2"/>
    <rect x="40" y="40" width="720" height="920" fill="url(#guilloche)" opacity="0.4"/>

    <!-- Header Flag / Emblem Banner -->
    <g transform="translate(400, 100)" text-anchor="middle">
      <circle cx="0" cy="-20" r="32" fill="#f1f5f9" stroke="${primaryColor}" stroke-width="2"/>
      <polygon points="0,-42 7,-24 25,-24 11,-13 16,5 0,-6 -16,5 -11,-13 -25,-24 -7,-24" fill="#eab308"/>
      
      <text y="28" font-family="Georgia, serif" font-size="12" font-weight="bold" fill="#64748b" letter-spacing="3">REPUBLIC OF THE PHILIPPINES</text>
      <text y="50" font-family="Georgia, serif" font-size="18" font-weight="bold" fill="${primaryColor}" letter-spacing="1">${title.toUpperCase()}</text>
      <text y="70" font-family="Helvetica, Arial, sans-serif" font-size="12" font-style="italic" fill="#475569">${subtitle}</text>
    </g>

    <!-- Reference Meta Bar -->
    <rect x="60" y="190" width="680" height="45" rx="6" fill="#f8fafc" stroke="#cbd5e1" stroke-width="1"/>
    <text x="80" y="212" font-family="Helvetica, Arial, sans-serif" font-size="10" font-weight="bold" fill="#64748b">OFFICIAL CERTIFICATE NO:</text>
    <text x="80" y="226" font-family="monospace" font-size="13" font-weight="bold" fill="${primaryColor}">${docNumber}</text>

    <text x="360" y="212" font-family="Helvetica, Arial, sans-serif" font-size="10" font-weight="bold" fill="#64748b">CATEGORY / CLASSIFICATION:</text>
    <text x="360" y="226" font-family="Helvetica, Arial, sans-serif" font-size="12" font-weight="bold" fill="#0f172a">${category.toUpperCase()} COMPLIANCE</text>

    <text x="600" y="212" font-family="Helvetica, Arial, sans-serif" font-size="10" font-weight="bold" fill="#64748b">DATE ISSUED:</text>
    <text x="600" y="226" font-family="Helvetica, Arial, sans-serif" font-size="12" font-weight="bold" fill="#0f172a">${date}</text>

    <!-- Divider -->
    <line x1="60" y1="250" x2="740" y2="250" stroke="#e2e8f0" stroke-width="2"/>

    <!-- Certified To Section -->
    <rect x="60" y="270" width="680" height="90" rx="8" fill="#eff6ff" stroke="#bfdbfe" stroke-width="1"/>
    <text x="80" y="295" font-family="Helvetica, Arial, sans-serif" font-size="11" font-weight="bold" fill="#1e40af">SITE ACQUISITION & TELECOM INFRASTRUCTURE SUBJECT:</text>
    <text x="80" y="322" font-family="Helvetica, Arial, sans-serif" font-size="16" font-weight="bold" fill="#0f172a">${siteName}</text>
    <text x="80" y="342" font-family="Helvetica, Arial, sans-serif" font-size="12" fill="#475569">Target Site Milestone: SAQ Legal & BP Permitting Clearances (21d/44d/21d SLA Framework)</text>

    <!-- Document Legal Clauses Body -->
    <g transform="translate(60, 390)" font-family="Georgia, serif" font-size="13" fill="#1e293b" line-height="1.6">
      <text x="0" y="0" font-weight="bold" font-size="14" fill="${primaryColor}">TO WHOM IT MAY CONCERN & EXAMINING REGULATORY AUTHORITIES:</text>
      
      <text x="0" y="30">THIS IS TO FORMALLY CERTIFY that the legal instruments, verification dossiers, and</text>
      <text x="0" y="52">pertinent statutory clearances submitted for the above-referenced telecommunications facility</text>
      <text x="0" y="74">have been strictly audited, evaluated, and found fully compliant with national building regulations,</text>
      <text x="0" y="96">local zoning ordinances, and telecommunication tower safety standards.</text>

      <text x="0" y="136">1. VERIFIED REQUIREMENTS & ATTESTATIONS:</text>
      <text x="20" y="160" font-size="12" font-family="Helvetica, Arial, sans-serif">• Environmental, structural, and height safety clearance assessments verified.</text>
      <text x="20" y="182" font-size="12" font-family="Helvetica, Arial, sans-serif">• Local government and property title certifications duly validated with respective registries.</text>
      <text x="20" y="204" font-size="12" font-family="Helvetica, Arial, sans-serif">• Required municipal filing fees, community clearances, and notarized accords completed.</text>

      <text x="0" y="244">2. AUTHORITY ENDORSEMENT CLAUSE:</text>
      <text x="0" y="268">The licensee and operating engineering consortium is hereby granted lawful recognition</text>
      <text x="0" y="290">to proceed with civil works, antenna pole installation, and utility energization within the</text>
      <text x="0" y="312">prescribed regulatory jurisdiction.</text>
    </g>

    <!-- Official Stamp / Dry Seal Graphic -->
    <g transform="translate(200, 840)">
      <circle cx="0" cy="0" r="60" fill="none" stroke="${sealColor}" stroke-width="3" stroke-dasharray="6,3"/>
      <circle cx="0" cy="0" r="52" fill="none" stroke="${sealColor}" stroke-width="1.5"/>
      <circle cx="0" cy="0" r="42" fill="none" stroke="${sealColor}" stroke-width="1"/>
      <path d="M -30 -10 L 0 -40 L 30 -10 L 15 -10 L 15 25 L -15 25 L -15 -10 Z" fill="${sealColor}" opacity="0.25"/>
      <text y="-25" font-family="Helvetica, Arial, sans-serif" font-size="8" font-weight="bold" fill="${sealColor}" text-anchor="middle" letter-spacing="1">★ OFFICIAL SEAL ★</text>
      <text y="5" font-family="Helvetica, Arial, sans-serif" font-size="10" font-weight="bold" fill="${sealColor}" text-anchor="middle">APPROVED</text>
      <text y="20" font-family="Helvetica, Arial, sans-serif" font-size="8" font-weight="bold" fill="${sealColor}" text-anchor="middle">REPUBLIC OF PH</text>
      <text y="32" font-family="monospace" font-size="7" fill="${sealColor}" text-anchor="middle">${docNumber}</text>
    </g>

    <!-- Official Signatures -->
    <g transform="translate(560, 820)" text-anchor="middle">
      <!-- Simulated cursive signature line -->
      <path d="M -90 -10 Q -50 -40 -30 -5 Q -10 -35 20 -15 Q 50 -45 80 -10" fill="none" stroke="#1e3a8a" stroke-width="2.5" stroke-linecap="round"/>
      <line x1="-100" y1="0" x2="100" y2="0" stroke="#0f172a" stroke-width="1.5"/>
      <text y="16" font-family="Helvetica, Arial, sans-serif" font-size="12" font-weight="bold" fill="#0f172a">ATTY. ROBERTO V. SANTOS</text>
      <text y="30" font-family="Helvetica, Arial, sans-serif" font-size="10" fill="#64748b">Legal & Permitting Division Chief</text>
      <text y="44" font-family="Helvetica, Arial, sans-serif" font-size="9" fill="#94a3b8">Telecom Regulatory Affairs Office</text>
    </g>

    <!-- Barcode and Verification footer -->
    <g transform="translate(60, 930)">
      <rect x="0" y="0" width="220" height="24" fill="#0f172a"/>
      <rect x="4" y="2" width="4" height="20" fill="#ffffff"/>
      <rect x="12" y="2" width="6" height="20" fill="#ffffff"/>
      <rect x="22" y="2" width="2" height="20" fill="#ffffff"/>
      <rect x="28" y="2" width="8" height="20" fill="#ffffff"/>
      <rect x="40" y="2" width="3" height="20" fill="#ffffff"/>
      <rect x="48" y="2" width="7" height="20" fill="#ffffff"/>
      <rect x="60" y="2" width="4" height="20" fill="#ffffff"/>
      <rect x="70" y="2" width="10" height="20" fill="#ffffff"/>
      <rect x="85" y="2" width="3" height="20" fill="#ffffff"/>
      <rect x="94" y="2" width="6" height="20" fill="#ffffff"/>
      <rect x="105" y="2" width="8" height="20" fill="#ffffff"/>
      <rect x="118" y="2" width="4" height="20" fill="#ffffff"/>
      <rect x="128" y="2" width="12" height="20" fill="#ffffff"/>
      <rect x="145" y="2" width="3" height="20" fill="#ffffff"/>
      <rect x="154" y="2" width="9" height="20" fill="#ffffff"/>
      <rect x="168" y="2" width="5" height="20" fill="#ffffff"/>
      <rect x="180" y="2" width="7" height="20" fill="#ffffff"/>
      <rect x="192" y="2" width="4" height="20" fill="#ffffff"/>
      <rect x="202" y="2" width="10" height="20" fill="#ffffff"/>
      
      <text x="240" y="16" font-family="monospace" font-size="10" fill="#64748b">DOC-ID: SEC-${docNumber} • DIGITAL QR VERIFIED</text>
    </g>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function createSitePhotoSvg(siteId: string, siteName: string, stage: string): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600">
    <defs>
      <linearGradient id="sky" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#0284c7"/>
        <stop offset="60%" stop-color="#38bdf8"/>
        <stop offset="100%" stop-color="#bae6fd"/>
      </linearGradient>
      <linearGradient id="ground" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stop-color="#334155"/>
        <stop offset="100%" stop-color="#0f172a"/>
      </linearGradient>
    </defs>

    <!-- Sky -->
    <rect width="800" height="420" fill="url(#sky)"/>
    <!-- Ground / Rooftop Base -->
    <rect y="420" width="800" height="180" fill="url(#ground)"/>

    <!-- Distant Clouds & Mountains -->
    <path d="M 0 380 Q 140 320 280 370 T 560 360 T 800 390 L 800 420 L 0 420 Z" fill="#94a3b8" opacity="0.6"/>
    <path d="M 0 400 Q 200 360 400 395 T 800 405 L 800 420 L 0 420 Z" fill="#64748b" opacity="0.8"/>

    <!-- Telecom Tower Structure (Monopole / Lattice with Antennas) -->
    <g transform="translate(400, 420)">
      <!-- Concrete Foundation Pedestal -->
      <rect x="-60" y="-15" width="120" height="25" fill="#475569" stroke="#1e293b" stroke-width="2"/>
      <rect x="-45" y="-30" width="90" height="18" fill="#64748b" stroke="#334155" stroke-width="2"/>
      
      <!-- Tower Mast -->
      <polygon points="-25,0 -12,-340 12,-340 25,0" fill="#cbd5e1" stroke="#475569" stroke-width="2"/>
      
      <!-- Lattice Trusses -->
      <line x1="-24" y1="-20" x2="20" y2="-60" stroke="#94a3b8" stroke-width="2"/>
      <line x1="24" y1="-20" x2="-20" y2="-60" stroke="#94a3b8" stroke-width="2"/>
      <line x1="-20" y1="-60" x2="18" y2="-110" stroke="#94a3b8" stroke-width="2"/>
      <line x1="20" y1="-60" x2="-18" y2="-110" stroke="#94a3b8" stroke-width="2"/>
      <line x1="-18" y1="-110" x2="16" y2="-170" stroke="#94a3b8" stroke-width="2"/>
      <line x1="18" y1="-110" x2="-16" y2="-170" stroke="#94a3b8" stroke-width="2"/>
      <line x1="-16" y1="-170" x2="14" y2="-230" stroke="#94a3b8" stroke-width="2"/>
      <line x1="16" y1="-170" x2="-14" y2="-230" stroke="#94a3b8" stroke-width="2"/>
      <line x1="-14" y1="-230" x2="12" y2="-300" stroke="#94a3b8" stroke-width="2"/>
      <line x1="14" y1="-230" x2="-12" y2="-300" stroke="#94a3b8" stroke-width="2"/>

      <!-- Platform Head -->
      <rect x="-50" y="-320" width="100" height="8" fill="#334155"/>
      <rect x="-60" y="-350" width="120" height="6" fill="#334155"/>
      
      <!-- Cellular Sector Antennas (3 sectors) -->
      <rect x="-55" y="-380" width="14" height="60" rx="3" fill="#ffffff" stroke="#0284c7" stroke-width="2"/>
      <rect x="-7" y="-385" width="14" height="65" rx="3" fill="#ffffff" stroke="#0284c7" stroke-width="2"/>
      <rect x="41" y="-380" width="14" height="60" rx="3" fill="#ffffff" stroke="#0284c7" stroke-width="2"/>

      <!-- Microwave Dish -->
      <ellipse cx="28" cy="-330" rx="14" ry="20" fill="#f8fafc" stroke="#475569" stroke-width="2"/>
      <circle cx="28" cy="-330" r="3" fill="#0284c7"/>

      <!-- Lightning Arrester / Aviation Red Warning Beacon -->
      <line x1="0" y1="-385" x2="0" y2="-415" stroke="#ef4444" stroke-width="3"/>
      <circle cx="0" cy="-415" r="5" fill="#ef4444"/>
      <circle cx="0" cy="-415" r="10" fill="#ef4444" opacity="0.4"/>
    </g>

    <!-- Inspection Hud & Camera Stamp Overlay -->
    <rect x="25" y="25" width="750" height="550" fill="none" stroke="#ffffff" stroke-width="1.5" opacity="0.4"/>
    <line x1="400" y1="20" x2="400" y2="40" stroke="#ffffff" stroke-width="2"/>
    <line x1="400" y1="560" x2="400" y2="580" stroke="#ffffff" stroke-width="2"/>
    <line x1="20" y1="300" x2="40" y2="300" stroke="#ffffff" stroke-width="2"/>
    <line x1="760" y1="300" x2="780" y2="300" stroke="#ffffff" stroke-width="2"/>

    <!-- Camera Timestamp & Site Coordinates Card -->
    <rect x="40" y="470" width="720" height="90" rx="8" fill="rgba(15, 23, 42, 0.85)" stroke="rgba(255, 255, 255, 0.2)"/>
    <text x="60" y="498" font-family="monospace" font-size="14" font-weight="bold" fill="#38bdf8">FIELD SITE INSPECTION &amp; TELECOM AUDIT PHOTO</text>
    <text x="60" y="522" font-family="Helvetica, Arial, sans-serif" font-size="16" font-weight="bold" fill="#ffffff">${siteId} — ${siteName}</text>
    <text x="60" y="544" font-family="Helvetica, Arial, sans-serif" font-size="12" fill="#94a3b8">Stage: <tspan fill="#34d399" font-weight="bold">${stage}</tspan> • GPS: 14°35'12.4"N 121°03'44.8"E • Timestamp: 2026-09-18 10:45 PST</text>

    <!-- Watermark Stamp -->
    <g transform="translate(680, 100)" text-anchor="middle">
      <circle cx="0" cy="0" r="45" fill="rgba(239, 68, 68, 0.15)" stroke="#ef4444" stroke-width="2" stroke-dasharray="4,2"/>
      <text y="-10" font-family="Helvetica, Arial, sans-serif" font-size="9" font-weight="bold" fill="#ef4444">VERIFIED</text>
      <text y="5" font-family="Helvetica, Arial, sans-serif" font-size="12" font-weight="bold" fill="#ef4444">SAQ SITE</text>
      <text y="20" font-family="monospace" font-size="8" fill="#ef4444">PASS 2026</text>
    </g>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

// Preset reference pictures mapping for standard legal requirements
export const STANDARD_REQUIREMENT_PRESETS: Record<string, {
  title: string;
  subtitle: string;
  category: string;
  docNumber: string;
  previewUrl: string;
  previewType: 'jpeg' | 'pdf';
}> = {
  'req-1': {
    title: 'Barangay Council Resolution & Endorsement Certificate',
    subtitle: 'Office of the Punong Barangay & Sangguniang Barangay Council',
    category: 'Clearance',
    docNumber: 'BRGY-RES-2026-0812',
    previewUrl: createOfficialDocumentSvg(
      'Barangay Council Endorsement',
      'Office of the Punong Barangay & Sangguniang Barangay',
      'Clearance',
      'BRGY-RES-2026-0812',
      'Brgy. Kalanganan 01 Tower Location',
      'August 12, 2026',
      '#065f46',
      '#059669'
    ),
    previewType: 'jpeg'
  },
  'req-2': {
    title: 'Notarized Contract of Lease & Registry of Deeds Title',
    subtitle: 'Land Registration Authority & Notary Public Acknowledgment',
    category: 'Legal',
    docNumber: 'LRA-TCT-T-84918-ROD',
    previewUrl: createOfficialDocumentSvg(
      'Notarized Lease Contract & Title Copy',
      'Land Registration Authority & Notarial Records',
      'Legal',
      'LRA-TCT-T-84918',
      'Cotabato City Metro Cell Hub Land Lease',
      'August 18, 2026',
      '#1e3a8a',
      '#b45309'
    ),
    previewType: 'jpeg'
  },
  'req-3': {
    title: 'Zoning Locational Clearance Certificate',
    subtitle: 'City Planning & Development Coordinator Office',
    category: 'Permit',
    docNumber: 'CPDO-ZON-2026-1029',
    previewUrl: createOfficialDocumentSvg(
      'Locational Clearance Certificate',
      'City Planning & Development Coordinator - Zoning Board',
      'Permit',
      'CPDO-ZON-2026-1029',
      'Zoning Lot 4-B Commercial Utilities',
      'August 25, 2026',
      '#6b21a8',
      '#7c3aed'
    ),
    previewType: 'jpeg'
  },
  'req-4': {
    title: 'Building Permit (BP) Filing Fees & Assessed Order',
    subtitle: 'Office of the Building Official (OBO) Engineering Department',
    category: 'Permit',
    docNumber: 'OBO-BP-2026-7782',
    previewUrl: createOfficialDocumentSvg(
      'Building Permit Official Endorsement',
      'Office of the City Building Official (OBO)',
      'Permit',
      'OBO-BP-2026-7782',
      'Telecom Monopole & Equipment Shelter',
      'September 02, 2026',
      '#991b1b',
      '#dc2626'
    ),
    previewType: 'jpeg'
  },
  'req-5': {
    title: 'CAAP Height Clearance Certificate & Plot Map',
    subtitle: 'Civil Aviation Authority of the Philippines (Aerodrome Safety)',
    category: 'Clearance',
    docNumber: 'CAAP-HCP-2026-0914',
    previewUrl: createOfficialDocumentSvg(
      'CAAP Height Clearance Permit',
      'Civil Aviation Authority of the Philippines - Aerodrome Safety',
      'Clearance',
      'CAAP-HCP-2026-0914',
      'Cotabato Tower (Max Height 45m AGL)',
      'August 20, 2026',
      '#0369a1',
      '#0284c7'
    ),
    previewType: 'jpeg'
  },
  'req-6': {
    title: 'Social Acceptability & HOA Consent Letter',
    subtitle: 'Homeowners Association & Community Board Endorsement',
    category: 'Social',
    docNumber: 'HOA-CONSENT-2026-0808',
    previewUrl: createOfficialDocumentSvg(
      'Community & HOA Social Acceptability',
      'Homeowners Association & Neighboring Estate Council',
      'Social',
      'HOA-CONSENT-2026-0808',
      'Subdivision Zone 3 Common Utility Area',
      'August 14, 2026',
      '#15803d',
      '#16a34a'
    ),
    previewType: 'jpeg'
  },
  'req-7': {
    title: 'BFP Fire Safety Evaluation Clearance (FSEC)',
    subtitle: 'Bureau of Fire Protection - Fire Safety Enforcement Division',
    category: 'Clearance',
    docNumber: 'BFP-FSEC-2026-4410',
    previewUrl: createOfficialDocumentSvg(
      'Fire Safety Evaluation Clearance',
      'Bureau of Fire Protection - Fire Prevention Division',
      'Clearance',
      'BFP-FSEC-2026-4410',
      'Electrical Cabinet & Generator Enclosure',
      'Pending Assessment',
      '#c2410c',
      '#ea580c'
    ),
    previewType: 'jpeg'
  },
  'req-8': {
    title: 'BIR Documentary Stamp Tax Return & Official Receipt',
    subtitle: 'Bureau of Internal Revenue - Revenue District Office',
    category: 'Legal',
    docNumber: 'BIR-DST-2000-8819',
    previewUrl: createOfficialDocumentSvg(
      'BIR Documentary Stamp Tax Assessment',
      'Bureau of Internal Revenue - Large Taxpayers / District Office',
      'Legal',
      'BIR-DST-2000-8819',
      'Leasehold Contract Stamp Tax 2026',
      'August 22, 2026',
      '#1e3a8a',
      '#d97706'
    ),
    previewType: 'jpeg'
  }
};
