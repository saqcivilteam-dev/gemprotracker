import React from 'react';
import { CheckSquare, Square, AlertCircle, Bookmark, Tag } from 'lucide-react';

export type HighlightColor = 'yellow' | 'green' | 'cyan' | 'pink' | 'amber';

export interface FormattedTextOptions {
  isCompact?: boolean;
  interactiveChecklist?: boolean;
  onToggleTask?: (lineIndex: number, originalLine: string, nextStatus: boolean) => void;
}

// Precompiled regular expressions for ultra-fast matching
const HAS_FORMATTING_CHARS = /[*_=<\[(•\-]|(?:\r?\n)/;
const HAS_INLINE_CHARS = /[*_=<\[(]/;
const UNCHECKED_MATCH_REGEX = /^(\s*)\[\s*\]\s+(.*)$/;
const CHECKED_MATCH_REGEX = /^(\s*)\[[xX]\]\s+(.*)$/;
const NUMBERED_ERRAND_REGEX = /^(\d+)\.\s+(.*)$/;
const BULLET_MATCH_REGEX = /^(\s*)[•\-\*]\s+(.*)$/;

// Precompiled inline formatting token matcher
const COMBINED_INLINE_REGEX =
  /(?:==(.*?)==|<mark(?:\s+color="([^"]+)")?>(.*?)<\/mark>|\[hl(?::(\w+))?\](.*?)\[\/hl\]|\*\*(.*?)\*\*|<b>(.*?)<\/b>|<strong>(.*?)<\/strong>|<u>(.*?)<\/u>|__(.*?)__|\[(IMPORTANT|URGENT|CRITICAL|HIGH PRIORITY|APPROVED|CLOSED CAL|CLOSE CAL|TARGET[^\]]*)\]|\(([^)]*(?:MEAL|CARGO|LBC|SECURING|NOTARY|PRINTING|LOAD|GAS|TRANSPO|DOCS|CTC|PERMIT|LODGING)[^)]*)\))/gi;

// High-speed LRU-style cache for parsed inline elements
const inlineCache = new Map<string, React.ReactNode>();
const MAX_INLINE_CACHE = 1500;

/**
 * Parses and renders rich text containing:
 * - Bold: **text** or <b>text</b>
 * - Underline: <u>text</u> or __text__
 * - Highlights: ==text== or <mark>text</mark> or [hl:color]text[/hl]
 * - Errand / Checkpoints: [ ] item or [x] item
 * - Priority badges: [IMPORTANT], [URGENT], [CLOSED CAL], [OPEN], etc.
 * - Errand tags: (MEAL), (CARGO), (LBC), (NOTARY), (PRINTING), (LOAD), (GAS), (TRANSPORTATION)
 * - Clean multi-line structure
 */
export const renderFormattedContent = (
  rawText: any,
  options: FormattedTextOptions = {}
): React.ReactNode => {
  if (rawText === null || rawText === undefined) return null;
  const str = typeof rawText === 'string' ? rawText : String(rawText);
  if (!str.trim()) return <span className="text-slate-400 italic">Empty</span>;

  // FAST-PATH: If text is single-line plain text with no formatting syntax, return immediately
  if (!HAS_FORMATTING_CHARS.test(str)) {
    return <span className="select-text">{str}</span>;
  }

  // Split lines while preserving newlines
  const lines = str.split(/\r?\n/);

  // If single line without checklist syntax
  if (lines.length === 1 && !str.includes('[') && !str.startsWith('•') && !str.startsWith('-')) {
    return (
      <div className={`font-sans ${options.isCompact ? 'text-[11px] leading-tight' : 'text-xs leading-relaxed'} text-slate-800 dark:text-zinc-200`}>
        {parseInlineFormatting(str)}
      </div>
    );
  }

  return (
    <div className={`space-y-1 font-sans ${options.isCompact ? 'text-[11px] leading-tight' : 'text-xs leading-relaxed'}`}>
      {lines.map((line, lineIdx) => {
        const trimmed = line.trim();
        if (!trimmed) {
          return <div key={lineIdx} className="h-2" />;
        }

        // Fast check for checkbox errand syntax
        if (line.includes('[') && line.includes(']')) {
          const uncheckedMatch = line.match(UNCHECKED_MATCH_REGEX);
          if (uncheckedMatch) {
            const indent = uncheckedMatch[1].length > 0;
            const content = uncheckedMatch[2];
            return (
              <div
                key={lineIdx}
                className={`flex items-start gap-1.5 group/item ${indent ? 'pl-4' : ''}`}
              >
                <button
                  type="button"
                  disabled={!options.interactiveChecklist}
                  onClick={e => {
                    e.stopPropagation();
                    options.onToggleTask?.(lineIdx, line, true);
                  }}
                  className={`mt-0.5 shrink-0 ${
                    options.interactiveChecklist
                      ? 'cursor-pointer text-indigo-500 hover:text-indigo-600 dark:text-indigo-400 hover:scale-110 transition-transform'
                      : 'text-slate-400'
                  }`}
                  title={options.interactiveChecklist ? 'Click to mark errand completed' : 'Pending errand'}
                >
                  <Square className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 text-slate-800 dark:text-zinc-200">
                  {parseInlineFormatting(content)}
                </div>
              </div>
            );
          }

          const checkedMatch = line.match(CHECKED_MATCH_REGEX);
          if (checkedMatch) {
            const indent = checkedMatch[1].length > 0;
            const content = checkedMatch[2];
            return (
              <div
                key={lineIdx}
                className={`flex items-start gap-1.5 group/item ${indent ? 'pl-4' : ''}`}
              >
                <button
                  type="button"
                  disabled={!options.interactiveChecklist}
                  onClick={e => {
                    e.stopPropagation();
                    options.onToggleTask?.(lineIdx, line, false);
                  }}
                  className={`mt-0.5 shrink-0 ${
                    options.interactiveChecklist
                      ? 'cursor-pointer text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 hover:scale-110 transition-transform'
                      : 'text-emerald-500'
                  }`}
                  title={options.interactiveChecklist ? 'Click to mark errand pending' : 'Completed errand'}
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                </button>
                <div className="flex-1 text-slate-500 dark:text-zinc-400 line-through decoration-emerald-500/60">
                  {parseInlineFormatting(content)}
                </div>
              </div>
            );
          }
        }

        // Check for numbered errand list items (e.g., "1. G1304", "12. G4117")
        if (line.charCodeAt(0) >= 48 && line.charCodeAt(0) <= 57) {
          const numberedErrandMatch = line.match(NUMBERED_ERRAND_REGEX);
          if (numberedErrandMatch) {
            const num = numberedErrandMatch[1];
            const itemText = numberedErrandMatch[2];
            return (
              <div key={lineIdx} className="flex items-start gap-1.5 pl-1">
                <span className="shrink-0 px-1.5 py-0.2 rounded bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-mono text-[10px] font-bold border border-indigo-200 dark:border-indigo-800 mt-0.5">
                  {num}
                </span>
                <div className="flex-1 text-slate-800 dark:text-zinc-200">
                  {parseInlineFormatting(itemText)}
                </div>
              </div>
            );
          }
        }

        // Check for bullet list item: • or - or *
        if (trimmed.startsWith('•') || trimmed.startsWith('-') || trimmed.startsWith('*')) {
          const bulletMatch = line.match(BULLET_MATCH_REGEX);
          if (bulletMatch) {
            const indent = bulletMatch[1].length > 0;
            const bulletText = bulletMatch[2];
            return (
              <div key={lineIdx} className={`flex items-start gap-1.5 ${indent ? 'pl-4' : 'pl-1'}`}>
                <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 dark:bg-indigo-400 mt-1.5 shrink-0" />
                <div className="flex-1 text-slate-800 dark:text-zinc-200">
                  {parseInlineFormatting(bulletText)}
                </div>
              </div>
            );
          }
        }

        // Standard line with inline formatting
        return (
          <div key={lineIdx} className="text-slate-800 dark:text-zinc-200">
            {parseInlineFormatting(line)}
          </div>
        );
      })}
    </div>
  );
};

/**
 * Parses inline formatting tags:
 * - Highlights: ==text== or <mark color="...">text</mark> or [hl:color]text[/hl]
 * - Bold: **text** or <b>text</b> or <strong>text</strong>
 * - Underline: <u>text</u> or __text__
 * - Important Badges: [IMPORTANT], [URGENT], [CLOSED CAL], [OPEN], etc.
 * - Errand category tags in parentheses: (MEAL, CARGO, LBC...)
 */
export const parseInlineFormatting = (text: string): React.ReactNode => {
  if (!text) return null;

  // FAST-PATH: If there are no inline formatting trigger characters, return plain text directly
  if (!HAS_INLINE_CHARS.test(text)) {
    return text;
  }

  // Check cache for instant hit
  if (inlineCache.has(text)) {
    return inlineCache.get(text);
  }

  // Reset precompiled regex index
  COMBINED_INLINE_REGEX.lastIndex = 0;

  const elements: React.ReactNode[] = [];
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = COMBINED_INLINE_REGEX.exec(text)) !== null) {
    // Add text before match
    if (match.index > lastIndex) {
      elements.push(text.substring(lastIndex, match.index));
    }

    const key = `inl-${match.index}-${lastIndex}`;

    // Highlight ==text==
    if (match[1] !== undefined) {
      elements.push(renderHighlightSpan(match[1], 'yellow', key));
    }
    // Highlight <mark color="...">text</mark>
    else if (match[3] !== undefined) {
      const color = (match[2] as HighlightColor) || 'yellow';
      elements.push(renderHighlightSpan(match[3], color, key));
    }
    // Highlight [hl:color]text[/hl]
    else if (match[5] !== undefined) {
      const color = (match[4] as HighlightColor) || 'yellow';
      elements.push(renderHighlightSpan(match[5], color, key));
    }
    // Bold **text**
    else if (match[6] !== undefined) {
      elements.push(
        <strong key={key} className="font-extrabold text-slate-900 dark:text-zinc-100">
          {match[6]}
        </strong>
      );
    }
    // Bold <b>text</b>
    else if (match[7] !== undefined) {
      elements.push(
        <strong key={key} className="font-extrabold text-slate-900 dark:text-zinc-100">
          {match[7]}
        </strong>
      );
    }
    // Bold <strong>text</strong>
    else if (match[8] !== undefined) {
      elements.push(
        <strong key={key} className="font-extrabold text-slate-900 dark:text-zinc-100">
          {match[8]}
        </strong>
      );
    }
    // Underline <u>text</u>
    else if (match[9] !== undefined) {
      elements.push(
        <u
          key={key}
          className="underline decoration-indigo-500 decoration-2 underline-offset-2 font-medium"
        >
          {match[9]}
        </u>
      );
    }
    // Underline __text__
    else if (match[10] !== undefined) {
      elements.push(
        <u
          key={key}
          className="underline decoration-indigo-500 decoration-2 underline-offset-2 font-medium"
        >
          {match[10]}
        </u>
      );
    }
    // Important Badges
    else if (match[11] !== undefined) {
      const badgeText = match[11].toUpperCase();
      const isUrgent = badgeText.includes('URGENT') || badgeText.includes('CRITICAL');
      const isClosed = badgeText.includes('CLOSED') || badgeText.includes('APPROVED');
      elements.push(
        <span
          key={key}
          className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-bold mx-0.5 border shadow-2xs ${
            isUrgent
              ? 'bg-rose-100 dark:bg-rose-950/80 text-rose-800 dark:text-rose-200 border-rose-300 dark:border-rose-800'
              : isClosed
              ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-200 border-emerald-300 dark:border-emerald-800'
              : 'bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-200 border-amber-300 dark:border-amber-800'
          }`}
        >
          <Bookmark className="w-2.5 h-2.5 inline-block" />
          <span>{badgeText}</span>
        </span>
      );
    }
    // Errand operations tag in parentheses
    else if (match[12] !== undefined) {
      const tagContent = match[12];
      elements.push(
        <span
          key={key}
          className="inline-flex items-center px-1.5 py-0.5 rounded-md bg-indigo-50/90 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-200 border border-indigo-200 dark:border-indigo-800 text-[11px] font-semibold mx-0.5 shadow-2xs"
        >
          <Tag className="w-2.5 h-2.5 mr-1 text-indigo-500" />
          <span>({tagContent})</span>
        </span>
      );
    }

    lastIndex = COMBINED_INLINE_REGEX.lastIndex;
  }

  // Add trailing text
  if (lastIndex < text.length) {
    elements.push(text.substring(lastIndex));
  }

  const result = <>{elements}</>;

  // Store in cache (manage size)
  if (inlineCache.size > MAX_INLINE_CACHE) {
    // Evict oldest 300 entries
    const iter = inlineCache.keys();
    for (let i = 0; i < 300; i++) {
      const nextKey = iter.next().value;
      if (nextKey) inlineCache.delete(nextKey);
    }
  }
  inlineCache.set(text, result);

  return result;
};

const renderHighlightSpan = (text: string, color: HighlightColor | string, key: string) => {
  let styleClasses = 'bg-yellow-200 text-yellow-950 dark:bg-yellow-400/40 dark:text-yellow-100 border border-yellow-300 dark:border-yellow-600/40';

  if (color === 'green') {
    styleClasses = 'bg-emerald-200 text-emerald-950 dark:bg-emerald-400/30 dark:text-emerald-100 border border-emerald-300 dark:border-emerald-600/40';
  } else if (color === 'cyan') {
    styleClasses = 'bg-cyan-200 text-cyan-950 dark:bg-cyan-400/30 dark:text-cyan-100 border border-cyan-300 dark:border-cyan-600/40';
  } else if (color === 'pink') {
    styleClasses = 'bg-rose-200 text-rose-950 dark:bg-rose-400/30 dark:text-rose-100 border border-rose-300 dark:border-rose-600/40';
  } else if (color === 'amber' || color === 'orange') {
    styleClasses = 'bg-amber-200 text-amber-950 dark:bg-amber-400/30 dark:text-amber-100 border border-amber-300 dark:border-amber-600/40';
  }

  return (
    <mark
      key={key}
      className={`px-1 py-0.5 rounded font-semibold transition-colors mx-0.5 ${styleClasses}`}
    >
      {text}
    </mark>
  );
};

/**
 * Text formatting manipulation helpers for editor textareas
 */
export const insertFormatting = (
  textarea: HTMLTextAreaElement,
  formatType: 'bold' | 'underline' | 'highlight' | 'errand' | 'completedErrand' | 'badge' | 'bullet',
  payload?: string
): { newText: string; newCursor: number } => {
  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const original = textarea.value;
  const selectedText = original.substring(start, end);

  let replacement = '';
  let cursorOffset = 0;

  switch (formatType) {
    case 'bold':
      replacement = `**${selectedText || 'important text'}**`;
      cursorOffset = selectedText ? replacement.length : 2;
      break;

    case 'underline':
      replacement = `<u>${selectedText || 'underlined text'}</u>`;
      cursorOffset = selectedText ? replacement.length : 3;
      break;

    case 'highlight':
      const color = payload || 'yellow';
      replacement = color === 'yellow' ? `==${selectedText || 'highlighted text'}==` : `[hl:${color}]${selectedText || 'highlighted text'}[/hl]`;
      cursorOffset = selectedText ? replacement.length : 2;
      break;

    case 'errand':
      if (selectedText.includes('\n')) {
        // Multi-line prefix
        replacement = selectedText
          .split('\n')
          .map(line => (line.startsWith('[ ] ') ? line.substring(4) : `[ ] ${line}`))
          .join('\n');
      } else {
        replacement = `[ ] ${selectedText || 'New Errand Item'}`;
      }
      cursorOffset = replacement.length;
      break;

    case 'completedErrand':
      replacement = `[x] ${selectedText || 'Completed Task'}`;
      cursorOffset = replacement.length;
      break;

    case 'badge':
      const badge = payload || 'IMPORTANT';
      replacement = `[${badge}] ${selectedText}`;
      cursorOffset = replacement.length;
      break;

    case 'bullet':
      if (selectedText.includes('\n')) {
        replacement = selectedText
          .split('\n')
          .map(line => (line.startsWith('• ') ? line.substring(2) : `• ${line}`))
          .join('\n');
      } else {
        replacement = `• ${selectedText || 'Key Note'}`;
      }
      cursorOffset = replacement.length;
      break;

    default:
      replacement = selectedText;
  }

  const newText = original.substring(0, start) + replacement + original.substring(end);
  const newCursor = start + cursorOffset;

  return { newText, newCursor };
};

/**
 * Strips all markdown and formatting tags for clean search or raw export
 */
export const stripFormattingTags = (text: any): string => {
  if (text === null || text === undefined) return '';
  return String(text)
    .replace(/==(.*?)==/g, '$1')
    .replace(/<mark(?:\s+color="[^"]+")?>(.*?)<\/mark>/gi, '$1')
    .replace(/\[hl(?::\w+)?\](.*?)\[\/hl\]/gi, '$1')
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/<b>(.*?)<\/b>/gi, '$1')
    .replace(/<strong>(.*?)<\/strong>/gi, '$1')
    .replace(/<u>(.*?)<\/u>/gi, '$1')
    .replace(/__(.*?)__/g, '$1')
    .replace(/\[\s*\]\s*/g, '☐ ')
    .replace(/\[[xX]\]\s*/g, '☑ ')
    .replace(/\[(IMPORTANT|URGENT|CRITICAL|HIGH PRIORITY|APPROVED|CLOSED CAL|CLOSE CAL|TARGET[^\]]*)\]/g, '$1');
};
