/**
 * SAQ Process SLA & Warning Engine
 * 
 * Telecom Site Acquisition (SAQ) Standard Process Stages:
 * 1. Site Hunting w/ SAQ Submission (Base start date)
 * 2. Property Documents (SLA: 21 Days)
 * 3. Securing Pre-Con Permit (SLA: 44 Days)
 * 4. Securing Post-Con Permit (SLA: 21 Days)
 * 5. FAC (Final Acceptance Certificate) Submission (SLA: 7 Days)
 * 
 * Rules:
 * - Warning before a week (7 days) for every target process
 * - Overdue alert if target process passes deadline
 * - Stalled notification if NO movement in 2 weeks (14 days)
 * - Day-by-day progression tracking per site
 */

export interface SaqStageConfig {
  id: string;
  name: string;
  slaDays: number;
  description: string;
}

export const SAQ_STAGES: SaqStageConfig[] = [
  {
    id: 'prop_docs',
    name: 'Property Documents',
    slaDays: 21,
    description: 'Securing land owner lease, title verification, tax declarations, and legal rights'
  },
  {
    id: 'precon_permit',
    name: 'Securing Pre-Con Permit',
    slaDays: 44,
    description: 'Securing Barangay resolution, Locational clearance, CAAP, and Building Permit'
  },
  {
    id: 'poscon_permit',
    name: 'Securing Post-Con Permit',
    slaDays: 21,
    description: 'Securing Occupancy permit, BFP Fire Safety Inspection certificate, and Power energization'
  },
  {
    id: 'fac_submission',
    name: 'FAC Submission',
    slaDays: 7,
    description: 'Final Acceptance Certificate (FAC) compilation, punchlist signoff, and carrier handover'
  },
  {
    id: 'billing',
    name: 'Commercial Billing',
    slaDays: 14,
    description: 'PO invoicing, finance release, and commercial turnover'
  }
];

export type WarningSeverity = 'critical' | 'warning' | 'info' | 'stalled' | 'ontrack';

export interface SaqMilestoneStatus {
  stageId: string;
  stageName: string;
  slaDays: number;
  targetDate: string; // YYYY-MM-DD
  actualDate?: string;
  status: 'pending' | 'in_progress' | 'completed' | 'overdue';
  daysRemaining: number; // positive = days until due, negative = days overdue
  isOverdue: boolean;
  isApproachingWeek: boolean; // within 7 days
}

export interface SiteSaqReport {
  siteId: string;
  siteName: string;
  location?: string;
  siteOwner?: string;
  assignedTeam?: string;
  responsiblePerson?: string;
  huntingDate: string; // Base Date
  lastMovementDate: string;
  daysSinceHunting: number;
  daysSinceLastMovement: number;
  isStalled: boolean; // >= 14 days without movement
  currentStageId: string;
  currentStageName: string;
  overallStatus: 'completed' | 'overdue' | 'at_risk' | 'stalled' | 'on_track';
  milestones: SaqMilestoneStatus[];
  warnings: {
    severity: WarningSeverity;
    stageName: string;
    message: string;
    daysCount: number;
  }[];
  dayByDayTimeline: {
    dayNumber: number;
    date: string;
    event: string;
    isMilestone: boolean;
    isToday: boolean;
  }[];
}

/**
 * Format a Date object to YYYY-MM-DD
 */
export function formatDateYMD(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

/**
 * Add days to a given YYYY-MM-DD or Date
 */
export function addDays(base: string | Date, days: number): string {
  const d = new Date(base);
  if (isNaN(d.getTime())) return formatDateYMD(new Date());
  d.setDate(d.getDate() + days);
  return formatDateYMD(d);
}

/**
 * Calculate difference in calendar days between two dates: (target - reference)
 */
export function diffDays(targetDateStr: string, refDateStr: string): number {
  const t = new Date(targetDateStr).getTime();
  const r = new Date(refDateStr).getTime();
  if (isNaN(t) || isNaN(r)) return 0;
  return Math.round((t - r) / (1000 * 60 * 60 * 24));
}

/**
 * Evaluate SAQ SLA and warnings for a single site row
 */
export function evaluateSiteSaq(
  row: Record<string, any>,
  currentDateStr: string = '2026-10-03'
): SiteSaqReport {
  const siteId = String(row.col_site_id || row.site_id || row.id || 'SAQ-001');
  const siteName = String(row.col_site_name || row.site_name || row['bp-site'] || siteId);
  const location = String(row.col_location || row.location || 'Metro Manila');
  const siteOwner = String(row.col_site_owner || row.site_owner || 'TowerCo / Operator');
  const assignedTeam = String(row.col_assigned_team || row.assigned_team || 'SAQC Civil Team');
  const responsiblePerson = String(row.col_responsible || row.responsible || 'Engr. In-Charge');

  // 1. Check Day-by-Day tracking area as the primary single source of truth
  let dayByDayLogs: any[] = [];
  for (const key of Object.keys(row)) {
    const val = row[key];
    if (Array.isArray(val) && val.length > 0 && (val[0]?.status !== undefined && (val[0]?.progressNotes !== undefined || val[0]?.slaRuleApplied !== undefined))) {
      dayByDayLogs = val;
      break;
    }
  }
  if (dayByDayLogs.length === 0) {
    const rawLogs = row.col_day_by_day || row.day_by_day_updates || row.day_by_day;
    if (Array.isArray(rawLogs)) {
      dayByDayLogs = rawLogs;
    } else if (typeof rawLogs === 'string' && rawLogs.trim().startsWith('[')) {
      try {
        dayByDayLogs = JSON.parse(rawLogs);
      } catch {}
    }
  }

  // Determine Official SLA Start Date: The SAQ SLA tracking should start ONLY from the actual date when Site Hunting begins
  let huntingDate: string = String(row.col_saq_hunting_date || row.hunting_date || row.col_survey_date || row.survey_date || '2026-08-01');
  let lastMovementDate: string = String(row.col_saq_last_movement_date || row.last_movement_date || row.updated_at || huntingDate);
  let latestStatusFromLogs: string = 'Pre-Con';

  if (dayByDayLogs.length > 0) {
    // Official SLA begins from the actual date when Site Hunting starts
    const huntingLog = dayByDayLogs.find((l: any) => l.status === 'Site Hunting');
    if (huntingLog && huntingLog.date) {
      huntingDate = String(huntingLog.date);
    } else {
      const sortedAsc = [...dayByDayLogs].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      if (sortedAsc[0] && sortedAsc[0].date) {
        huntingDate = String(sortedAsc[0].date);
      }
    }

    // Determine latest movement date & status from day-by-day updates
    const sortedDesc = [...dayByDayLogs].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    if (sortedDesc[0]) {
      if (sortedDesc[0].date) lastMovementDate = String(sortedDesc[0].date);
      if (sortedDesc[0].status) latestStatusFromLogs = String(sortedDesc[0].status);
    }
  }

  if (huntingDate.includes('T')) {
    huntingDate = huntingDate.split('T')[0];
  }
  if (lastMovementDate.includes('T')) {
    lastMovementDate = lastMovementDate.split('T')[0];
  }

  const daysSinceHunting = Math.max(0, diffDays(currentDateStr, huntingDate));
  const daysSinceLastMovement = Math.max(0, diffDays(currentDateStr, lastMovementDate));
  const isStalled = daysSinceLastMovement >= 14 && latestStatusFromLogs !== 'Billing'; // No movement in 2 weeks

  // Calculate cumulative targets from official Site Hunting Start Date:
  // 1. Property Documents: Hunting + 21d
  const propDocsTarget = addDays(huntingDate, 21);
  // 2. Pre-Con Permit: Prop Docs Target + 44d (Hunting + 65d)
  const preconTarget = addDays(propDocsTarget, 44);
  // 3. Post-Con Permit: Pre-Con Target + 21d (Hunting + 86d)
  const posconTarget = addDays(preconTarget, 21);
  // 4. FAC Submission: Post-Con Target + 7d (Hunting + 93d)
  const facTarget = addDays(posconTarget, 7);
  // 5. Billing Release: FAC Target + 14d (Hunting + 107d)
  const billingTarget = addDays(facTarget, 14);

  // Status mapping derived strictly from Day-by-Day log status:
  // (Site Hunting, Pro Docs, Pre-Con, Post-Con, FAC, Billing)
  let propDocsStatus: 'pending' | 'in_progress' | 'completed' = 'pending';
  let preconStatus: 'pending' | 'in_progress' | 'completed' = 'pending';
  let posconStatus: 'pending' | 'in_progress' | 'completed' = 'pending';
  let facStatus: 'pending' | 'in_progress' | 'completed' = 'pending';
  let billingStatus: 'pending' | 'in_progress' | 'completed' = 'pending';

  switch (latestStatusFromLogs) {
    case 'Site Hunting':
    case 'Pro Docs':
      propDocsStatus = 'in_progress';
      break;
    case 'Pre-Con':
      propDocsStatus = 'completed';
      preconStatus = 'in_progress';
      break;
    case 'Post-Con':
      propDocsStatus = 'completed';
      preconStatus = 'completed';
      posconStatus = 'in_progress';
      break;
    case 'FAC':
      propDocsStatus = 'completed';
      preconStatus = 'completed';
      posconStatus = 'completed';
      facStatus = 'in_progress';
      break;
    case 'Billing':
      propDocsStatus = 'completed';
      preconStatus = 'completed';
      posconStatus = 'completed';
      facStatus = 'completed';
      billingStatus = 'completed';
      break;
    default:
      propDocsStatus = 'in_progress';
  }

  const rawMilestones = [
    { config: SAQ_STAGES[0], target: propDocsTarget, status: propDocsStatus },
    { config: SAQ_STAGES[1], target: preconTarget, status: preconStatus },
    { config: SAQ_STAGES[2], target: posconTarget, status: posconStatus },
    { config: SAQ_STAGES[3], target: facTarget, status: facStatus },
    { config: SAQ_STAGES[4], target: billingTarget, status: billingStatus }
  ];

  const milestones: SaqMilestoneStatus[] = rawMilestones.map(m => {
    const daysRemaining = diffDays(m.target, currentDateStr);
    const isCompleted = m.status === 'completed';
    const isOverdue = !isCompleted && m.status === 'in_progress' && daysRemaining < 0;
    const isApproachingWeek = !isCompleted && m.status === 'in_progress' && daysRemaining >= 0 && daysRemaining <= 7;

    return {
      stageId: m.config.id,
      stageName: m.config.name,
      slaDays: m.config.slaDays,
      targetDate: m.target,
      status: isCompleted ? 'completed' : isOverdue ? 'overdue' : m.status,
      daysRemaining,
      isOverdue,
      isApproachingWeek
    };
  });

  // Current active stage
  const activeMilestone = milestones.find(m => m.status === 'in_progress' || m.status === 'overdue') || milestones[milestones.length - 1];
  const allCompleted = latestStatusFromLogs === 'Billing';

  // Generate centralized warnings (strictly limited to active tracking area to avoid redundant triggers)
  const warnings: SiteSaqReport['warnings'] = [];

  // Check 14-day stalled warning
  if (isStalled && !allCompleted) {
    warnings.push({
      severity: 'stalled',
      stageName: 'Site Activity Monitoring',
      message: `No movement recorded for ${daysSinceLastMovement} days (exceeds 2-week inactivity threshold). Last logged: ${lastMovementDate}.`,
      daysCount: daysSinceLastMovement
    });
  }

  // Check active milestone warnings only (prevents duplicate triggers or overlapping alerts)
  if (!allCompleted && activeMilestone) {
    if (activeMilestone.isOverdue) {
      const daysOver = Math.abs(activeMilestone.daysRemaining);
      warnings.push({
        severity: 'critical',
        stageName: activeMilestone.stageName,
        message: `${activeMilestone.stageName} is OVERDUE by ${daysOver} day${daysOver === 1 ? '' : 's'} (Target SLA: ${activeMilestone.targetDate}). Official SLA Start: ${huntingDate}.`,
        daysCount: daysOver
      });
    } else if (activeMilestone.isApproachingWeek) {
      warnings.push({
        severity: 'warning',
        stageName: activeMilestone.stageName,
        message: `${activeMilestone.stageName} deadline is approaching within 1 week (${activeMilestone.daysRemaining} day${activeMilestone.daysRemaining === 1 ? '' : 's'} remaining - Due: ${activeMilestone.targetDate}).`,
        daysCount: activeMilestone.daysRemaining
      });
    }
  }

  // Determine overall status
  let overallStatus: SiteSaqReport['overallStatus'] = 'on_track';
  if (allCompleted) {
    overallStatus = 'completed';
  } else if (warnings.some(w => w.severity === 'critical')) {
    overallStatus = 'overdue';
  } else if (isStalled) {
    overallStatus = 'stalled';
  } else if (warnings.some(w => w.severity === 'warning')) {
    overallStatus = 'at_risk';
  }

  // Day-by-day progression timeline
  const dayByDayTimeline: SiteSaqReport['dayByDayTimeline'] = [];
  const maxDay = Math.min(100, Math.max(daysSinceHunting + 5, 95));

  for (let d = 0; d <= maxDay; d++) {
    const curDate = addDays(huntingDate, d);
    let event = '';
    let isMilestone = false;

    if (d === 0) {
      event = 'Site Hunting Started & SAQ Submission Form Filed';
      isMilestone = true;
    } else if (d === 21) {
      event = `Day 21 SLA: Property Documents Target (${propDocsTarget})`;
      isMilestone = true;
    } else if (d === 65) {
      event = `Day 65 SLA (44d span): Securing Pre-Con Permit Target (${preconTarget})`;
      isMilestone = true;
    } else if (d === 86) {
      event = `Day 86 SLA (21d span): Securing Post-Con Permit Target (${posconTarget})`;
      isMilestone = true;
    } else if (d === 93) {
      event = `Day 93 SLA (7d span): FAC Submission Deadline (${facTarget})`;
      isMilestone = true;
    } else if (d === daysSinceHunting) {
      event = `Today: Day ${d} of SAQ Process (${daysSinceLastMovement}d since last update)`;
    }

    const matchingLog = dayByDayLogs.find((l: any) => l.date === curDate);
    if (matchingLog) {
      event = `[${matchingLog.status}] ${matchingLog.progressNotes}`;
      isMilestone = true;
    }

    if (event || d % 7 === 0) {
      dayByDayTimeline.push({
        dayNumber: d,
        date: curDate,
        event: event || `Day ${d} Routine SAQ Monitoring Checkpoint`,
        isMilestone,
        isToday: d === daysSinceHunting
      });
    }
  }

  return {
    siteId,
    siteName,
    location,
    siteOwner,
    assignedTeam,
    responsiblePerson,
    huntingDate,
    lastMovementDate,
    daysSinceHunting,
    daysSinceLastMovement,
    isStalled,
    currentStageId: activeMilestone.stageId,
    currentStageName: activeMilestone.stageName,
    overallStatus,
    milestones,
    warnings,
    dayByDayTimeline
  };
}

/**
 * Scan all rows in a tracker to generate summary warnings and SLA health metrics
 */
export function evaluateAllSitesSaq(
  rows: Record<string, any>[],
  currentDateStr: string = '2026-10-03'
) {
  const reports = rows.map(r => evaluateSiteSaq(r, currentDateStr));

  const overdueSites = reports.filter(r => r.overallStatus === 'overdue');
  const approachingWeekSites = reports.filter(r =>
    r.warnings.some(w => w.severity === 'warning') && r.overallStatus !== 'overdue'
  );
  const stalledSites = reports.filter(r => r.isStalled);
  const onTrackSites = reports.filter(r => r.overallStatus === 'on_track');
  const completedSites = reports.filter(r => r.overallStatus === 'completed');

  const totalWarnings = overdueSites.length + approachingWeekSites.length + stalledSites.length;

  return {
    totalSites: reports.length,
    reports,
    overdueSites,
    approachingWeekSites,
    stalledSites,
    onTrackSites,
    completedSites,
    totalWarnings
  };
}
