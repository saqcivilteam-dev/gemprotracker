import { AppTheme } from '../types/tracker';

export interface ThemeConfig {
  id: AppTheme;
  name: string;
  bgClass: string;
  cardClass: string;
  borderClass: string;
  headerBg: string;
  accentClass: string;
  primaryButton: string;
  badgeBg: string;
}

export const themes: Record<AppTheme, ThemeConfig> = {
  slate: {
    id: 'slate',
    name: 'Modern Slate (Default)',
    bgClass: 'bg-slate-100/80',
    cardClass: 'bg-white',
    borderClass: 'border-slate-200',
    headerBg: 'bg-white',
    accentClass: 'text-slate-900',
    primaryButton: 'bg-slate-900 hover:bg-slate-800 text-white',
    badgeBg: 'bg-slate-100 text-slate-800 border-slate-200'
  },
  navy: {
    id: 'navy',
    name: 'Corporate Navy',
    bgClass: 'bg-sky-50/60',
    cardClass: 'bg-white',
    borderClass: 'border-sky-200/80',
    headerBg: 'bg-white',
    accentClass: 'text-blue-900',
    primaryButton: 'bg-blue-600 hover:bg-blue-700 text-white',
    badgeBg: 'bg-blue-50 text-blue-800 border-blue-200'
  },
  emerald: {
    id: 'emerald',
    name: 'Emerald Forest',
    bgClass: 'bg-emerald-50/50',
    cardClass: 'bg-white',
    borderClass: 'border-emerald-200/80',
    headerBg: 'bg-white',
    accentClass: 'text-emerald-950',
    primaryButton: 'bg-emerald-600 hover:bg-emerald-700 text-white',
    badgeBg: 'bg-emerald-50 text-emerald-800 border-emerald-200'
  },
  dark: {
    id: 'dark',
    name: 'Obsidian Dark',
    bgClass: 'bg-zinc-950 text-zinc-100',
    cardClass: 'bg-zinc-900 text-zinc-100',
    borderClass: 'border-zinc-800',
    headerBg: 'bg-zinc-900',
    accentClass: 'text-zinc-100',
    primaryButton: 'bg-indigo-600 hover:bg-indigo-500 text-white',
    badgeBg: 'bg-zinc-800 text-zinc-200 border-zinc-700'
  },
  amber: {
    id: 'amber',
    name: 'Warm Amber Executive',
    bgClass: 'bg-amber-50/40',
    cardClass: 'bg-white',
    borderClass: 'border-amber-200/80',
    headerBg: 'bg-white',
    accentClass: 'text-amber-950',
    primaryButton: 'bg-amber-700 hover:bg-amber-800 text-white',
    badgeBg: 'bg-amber-50 text-amber-900 border-amber-200'
  },
  purple: {
    id: 'purple',
    name: 'Royal Purple',
    bgClass: 'bg-purple-50/40',
    cardClass: 'bg-white',
    borderClass: 'border-purple-200/80',
    headerBg: 'bg-white',
    accentClass: 'text-purple-950',
    primaryButton: 'bg-purple-600 hover:bg-purple-700 text-white',
    badgeBg: 'bg-purple-50 text-purple-800 border-purple-200'
  }
};
