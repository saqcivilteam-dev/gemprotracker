import { DayByDayUpdateEntry, SaqProcessStatus, Row } from '../types/tracker';
import { formatDateYMD, addDays, diffDays } from './saqSlaEngine';

export const SAQ_PROCESS_STATUS_OPTIONS: SaqProcessStatus[] = [
  'Site Hunting',
  'Pro Docs',
  'Pre-Con',
  'Post-Con',
  'FAC',
  'Billing'
];

export const STATUS_BADGE_STYLES: Record<SaqProcessStatus, { bg: string; text: string; border: string; dot: string }> = {
  'Site Hunting': {
    bg: 'bg-blue-500/15 dark:bg-blue-950/40',
    text: 'text-blue-700 dark:text-blue-300',
    border: 'border-blue-500/30',
    dot: 'bg-blue-500'
  },
  'Pro Docs': {
    bg: 'bg-indigo-500/15 dark:bg-indigo-950/40',
    text: 'text-indigo-700 dark:text-indigo-300',
    border: 'border-indigo-500/30',
    dot: 'bg-indigo-500'
  },
  'Pre-Con': {
    bg: 'bg-purple-500/15 dark:bg-purple-950/40',
    text: 'text-purple-700 dark:text-purple-300',
    border: 'border-purple-500/30',
    dot: 'bg-purple-500'
  },
  'Post-Con': {
    bg: 'bg-amber-500/15 dark:bg-amber-950/40',
    text: 'text-amber-700 dark:text-amber-300',
    border: 'border-amber-500/30',
    dot: 'bg-amber-500'
  },
  'FAC': {
    bg: 'bg-emerald-500/15 dark:bg-emerald-950/40',
    text: 'text-emerald-700 dark:text-emerald-300',
    border: 'border-emerald-500/30',
    dot: 'bg-emerald-500'
  },
  'Billing': {
    bg: 'bg-teal-500/15 dark:bg-teal-950/40',
    text: 'text-teal-700 dark:text-teal-300',
    border: 'border-teal-500/30',
    dot: 'bg-teal-500'
  }
};

/**
 * Returns suggested SLA tracking rule text based on status and days
 */
export function getSuggestedSlaRule(status: SaqProcessStatus, huntingDate?: string): string {
  switch (status) {
    case 'Site Hunting':
      return 'Official SLA Start: Day 0 (Site Survey & Candidate Hunting)';
    case 'Pro Docs':
      return 'Property Documents SLA: 21 Days Target (Lease, Title & CTC)';
    case 'Pre-Con':
      return 'Securing Pre-Con Permit SLA: 44 Days Target (Barangay, CAAP, BP Endorsement)';
    case 'Post-Con':
      return 'Securing Post-Con Permit SLA: 21 Days Target (Occupancy, BFP, Power Energization)';
    case 'FAC':
      return 'Final Acceptance Certificate (FAC) SLA: 7 Days Target (Punchlist & Turnover)';
    case 'Billing':
      return 'Commercial Milestone SLA: 14 Days Target (PO Invoicing & Billing Release)';
    default:
      return 'SAQ Process SLA Milestone Tracking';
  }
}

/**
 * Identify the official SLA Start Date for a site from when Site Hunting actually begins
 */
export function getOfficialSlaStartDate(row: Record<string, any>, dayByDayItems?: DayByDayUpdateEntry[]): string {
  if (dayByDayItems && Array.isArray(dayByDayItems) && dayByDayItems.length > 0) {
    // 1. Search for specific Site Hunting entry
    const huntingEntry = dayByDayItems.find(e => e.status === 'Site Hunting');
    if (huntingEntry && huntingEntry.date) {
      return huntingEntry.date;
    }
    // 2. Earliest entry date in the day-by-day log
    const sorted = [...dayByDayItems].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    if (sorted[0] && sorted[0].date) {
      return sorted[0].date;
    }
  }

  // 3. Fallback to row fields: hunting date, site survey date, or created_at
  const candidate = row.col_saq_hunting_date || row.hunting_date || row.col_survey_date || row.survey_date;
  if (candidate) {
    return candidate.includes('T') ? candidate.split('T')[0] : candidate;
  }

  // Default fallback
  return '2026-08-01';
}

/**
 * Generate default realistic day-by-day logs for a site
 */
export function generateDefaultDayByDayLog(
  siteId: string,
  siteName: string,
  huntingDateStr: string = '2026-08-01',
  currentStage: SaqProcessStatus = 'Pre-Con'
): DayByDayUpdateEntry[] {
  const hunting = huntingDateStr;
  const propDocsDate = addDays(hunting, 18);
  const preconDate = addDays(hunting, 45);
  const recentDate = addDays(hunting, 62);

  const logs: DayByDayUpdateEntry[] = [
    {
      id: `${siteId}-log-1`,
      date: hunting,
      status: 'Site Hunting',
      progressNotes: 'Conducted joint technical site survey with engineering team. Site coordinates and tower ground footings validated with landowner.',
      remarks: 'Primary candidate selected; landlord initial concurrence obtained. Began SAQ candidate dossier submission.',
      slaRuleApplied: 'Official SLA Start: Day 0 (Site Survey & Candidate Hunting)',
      updatedBy: 'PIC: JHENG QUINTO',
      surveyDate: hunting
    },
    {
      id: `${siteId}-log-2`,
      date: addDays(hunting, 10),
      status: 'Pro Docs',
      progressNotes: 'Lessor title deed certified true copy secured from Registry of Deeds. Drafted 15-year lease contract with legal counsel.',
      remarks: 'Awaiting tax declaration confirmation and notarization schedule.',
      slaRuleApplied: 'Property Documents SLA: 21 Days Target (Lease, Title & CTC)',
      updatedBy: 'Atty. R. Santos'
    },
    {
      id: `${siteId}-log-3`,
      date: propDocsDate,
      status: 'Pro Docs',
      progressNotes: 'Notarized contract of lease executed and signed. Property documents dossier completed within 18 days (beat 21-day SLA target!).',
      remarks: 'Certified true copy package turned over to permitting engineers.',
      slaRuleApplied: 'Property Documents Milestone Achieved (Day 18 / 21d SLA)',
      updatedBy: 'PIC: JHENG QUINTO'
    },
    {
      id: `${siteId}-log-4`,
      date: preconDate,
      status: 'Pre-Con',
      progressNotes: 'Secured Barangay Council resolution with unanimous approval. CAAP height clearance assessment filed with aerodrome safety board.',
      remarks: 'Locational clearance and structural plan submitted to Office of Building Official (OBO).',
      slaRuleApplied: 'Securing Pre-Con Permit SLA: 44 Days Target (Barangay, CAAP, BP Endorsement)',
      updatedBy: 'Engr. Villanueva'
    },
    {
      id: `${siteId}-log-5`,
      date: recentDate,
      status: currentStage,
      progressNotes: `Ongoing follow-up with City Building Official. Structural clearance approved; electrical assessment pending release.`,
      remarks: 'Daily movement logged. Coordination meeting scheduled with LGU zoning board this Thursday.',
      slaRuleApplied: 'Pre-Con Permit In-Progress Tracking',
      updatedBy: 'PIC: JHENG QUINTO'
    }
  ];

  return logs;
}

export interface DayByDaySlaCalculation {
  officialSlaStartDate: string;
  lastUpdateDate: string;
  daysSinceHunting: number;
  daysSinceLastUpdate: number;
  isStalled: boolean; // >= 14 days without update
  currentStatus: SaqProcessStatus;
  totalLogsCount: number;
  latestLog?: DayByDayUpdateEntry;
  // SLA Target milestones from hunting start date
  targets: {
    propDocsTarget: string; // Hunting + 21d
    preconTarget: string;   // PropDocs + 44d (Hunting + 65d)
    posconTarget: string;   // PreCon + 21d (Hunting + 86d)
    facTarget: string;      // PosCon + 7d (Hunting + 93d)
    billingTarget: string;  // FAC + 14d (Hunting + 107d)
  };
  currentStageTargetDate: string;
  daysRemaining: number;
  isOverdue: boolean;
  isApproachingWeek: boolean;
  slaHealth: 'on_track' | 'approaching_warning' | 'overdue' | 'stalled' | 'completed';
  badgeLabel: string;
}

/**
 * Calculates central SAQ SLA health exclusively based on Day-by-Day tracking records
 */
export function calculateDayByDaySla(
  row: Record<string, any>,
  dayByDayItems: DayByDayUpdateEntry[],
  currentDateStr: string = '2026-10-04'
): DayByDaySlaCalculation {
  const officialSlaStartDate = getOfficialSlaStartDate(row, dayByDayItems);

  // Targets from official hunting start date
  const propDocsTarget = addDays(officialSlaStartDate, 21);
  const preconTarget = addDays(propDocsTarget, 44);
  const posconTarget = addDays(preconTarget, 21);
  const facTarget = addDays(posconTarget, 7);
  const billingTarget = addDays(facTarget, 14);

  // Sort logs by date descending (latest first)
  const sorted = Array.isArray(dayByDayItems)
    ? [...dayByDayItems].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    : [];

  const latestLog = sorted[0];
  const lastUpdateDate = latestLog?.date || officialSlaStartDate;
  const currentStatus: SaqProcessStatus = latestLog?.status || 'Site Hunting';

  const daysSinceHunting = Math.max(0, diffDays(currentDateStr, officialSlaStartDate));
  const daysSinceLastUpdate = Math.max(0, diffDays(currentDateStr, lastUpdateDate));
  const isStalled = daysSinceLastUpdate >= 14 && currentStatus !== 'Billing';

  // Determine current active target based on current status
  let currentStageTargetDate = propDocsTarget;
  if (currentStatus === 'Site Hunting') {
    currentStageTargetDate = addDays(officialSlaStartDate, 7);
  } else if (currentStatus === 'Pro Docs') {
    currentStageTargetDate = propDocsTarget;
  } else if (currentStatus === 'Pre-Con') {
    currentStageTargetDate = preconTarget;
  } else if (currentStatus === 'Post-Con') {
    currentStageTargetDate = posconTarget;
  } else if (currentStatus === 'FAC') {
    currentStageTargetDate = facTarget;
  } else if (currentStatus === 'Billing') {
    currentStageTargetDate = billingTarget;
  }

  const daysRemaining = diffDays(currentStageTargetDate, currentDateStr);
  const isOverdue = daysRemaining < 0 && currentStatus !== 'Billing';
  const isApproachingWeek = !isOverdue && daysRemaining >= 0 && daysRemaining <= 7 && currentStatus !== 'Billing';

  let slaHealth: DayByDaySlaCalculation['slaHealth'] = 'on_track';
  let badgeLabel = `Day ${daysSinceHunting}`;

  if (currentStatus === 'Billing') {
    slaHealth = 'completed';
    badgeLabel = '✅ Completed';
  } else if (isOverdue) {
    slaHealth = 'overdue';
    badgeLabel = `🚨 Overdue (+${Math.abs(daysRemaining)}d)`;
  } else if (isStalled) {
    slaHealth = 'stalled';
    badgeLabel = `⏳ Stalled (${daysSinceLastUpdate}d)`;
  } else if (isApproachingWeek) {
    slaHealth = 'approaching_warning';
    badgeLabel = `⚠️ 1-Wk Warning (${daysRemaining}d left)`;
  } else {
    slaHealth = 'on_track';
    badgeLabel = `🟢 On Track (${daysRemaining}d left)`;
  }

  return {
    officialSlaStartDate,
    lastUpdateDate,
    daysSinceHunting,
    daysSinceLastUpdate,
    isStalled,
    currentStatus,
    totalLogsCount: sorted.length,
    latestLog,
    targets: {
      propDocsTarget,
      preconTarget,
      posconTarget,
      facTarget,
      billingTarget
    },
    currentStageTargetDate,
    daysRemaining,
    isOverdue,
    isApproachingWeek,
    slaHealth,
    badgeLabel
  };
}
