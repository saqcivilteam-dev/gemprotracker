import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut,
  User as FirebaseUser
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App instance
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

// Configure Google Auth Provider with Google Drive Scopes
const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/drive.file');
provider.addScope('https://www.googleapis.com/auth/drive.readonly');
provider.setCustomParameters({
  prompt: 'select_account'
});

// Flag to track ongoing sign in flow
let isSigningIn = false;
// In-memory access token cache ONLY (Never store in localStorage or sessionStorage per security guidelines)
let cachedAccessToken: string | null = null;
let currentGoogleUser: FirebaseUser | null = null;

export interface GoogleDriveFile {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime?: string;
  size?: string;
  webViewLink?: string;
  iconLink?: string;
}

export function initGoogleDriveAuth(
  onSuccess?: (user: FirebaseUser, token: string) => void,
  onFailure?: () => void
) {
  return onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
    currentGoogleUser = user;
    if (user) {
      if (cachedAccessToken) {
        onSuccess?.(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // Token needs refresh on fresh load
        onFailure?.();
      }
    } else {
      cachedAccessToken = null;
      onFailure?.();
    }
  });
}

export async function signInToGoogleDrive(): Promise<{ user: FirebaseUser; accessToken: string }> {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Google Drive access token was not returned.');
    }
    cachedAccessToken = credential.accessToken;
    currentGoogleUser = result.user;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Drive sign in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
}

export async function signOutGoogleDrive(): Promise<void> {
  await signOut(auth);
  cachedAccessToken = null;
  currentGoogleUser = null;
}

export function getDriveAccessToken(): string | null {
  return cachedAccessToken;
}

export function getCurrentGoogleUser(): FirebaseUser | null {
  return currentGoogleUser || auth.currentUser;
}

/**
 * List files stored in user's Google Drive created by or accessible to this app
 */
export async function listDriveFiles(searchTerm = ''): Promise<GoogleDriveFile[]> {
  const token = getDriveAccessToken();
  if (!token) throw new Error('Not connected to Google Drive. Please sign in with Google.');

  let q = "trashed = false";
  if (searchTerm) {
    q += ` and name contains '${searchTerm.replace(/'/g, "\\'")}'`;
  }

  const url = new URL('https://www.googleapis.com/drive/v3/files');
  url.searchParams.set('q', q);
  url.searchParams.set('fields', 'files(id, name, mimeType, modifiedTime, size, webViewLink, iconLink)');
  url.searchParams.set('orderBy', 'modifiedTime desc');
  url.searchParams.set('pageSize', '30');

  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Drive API error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  return data.files || [];
}

/**
 * Upload a JSON or CSV file to user's Google Drive via multipart upload
 */
export async function uploadFileToDrive(
  fileName: string,
  content: string,
  mimeType = 'application/json',
  description = 'Gaela Tracker Studio Export'
): Promise<GoogleDriveFile> {
  const token = getDriveAccessToken();
  if (!token) throw new Error('Not connected to Google Drive. Please sign in with Google.');

  const metadata = {
    name: fileName,
    mimeType,
    description
  };

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const multipartRequestBody =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) +
    delimiter +
    `Content-Type: ${mimeType}\r\n\r\n` +
    content +
    closeDelimiter;

  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink,size,modifiedTime', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': `multipart/related; boundary=${boundary}`
    },
    body: multipartRequestBody
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Failed to upload to Google Drive (${res.status}): ${errText}`);
  }

  return await res.json();
}

/**
 * Download a file's content directly from Google Drive
 */
export async function downloadDriveFile(fileId: string): Promise<string> {
  const token = getDriveAccessToken();
  if (!token) throw new Error('Not connected to Google Drive. Please sign in with Google.');

  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Failed to read file from Google Drive (${res.status}): ${errText}`);
  }

  return await res.text();
}

/**
 * Delete a file in Google Drive (must be called after explicit user confirmation in UI)
 */
export async function deleteDriveFile(fileId: string): Promise<void> {
  const token = getDriveAccessToken();
  if (!token) throw new Error('Not connected to Google Drive.');

  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!res.ok && res.status !== 204) {
    const errText = await res.text();
    throw new Error(`Failed to delete Google Drive file: ${errText}`);
  }
}
