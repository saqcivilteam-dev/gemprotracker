import { Column, Row, SummaryCard, Tracker } from '../types/tracker';

export const SITE_TRACKER_COLUMNS: Column[] = [
  { id: 'col_site_id', name: 'Site ID', type: 'text', width: 140, visible: true, color: 'blue' },
  { id: 'col_site_name', name: 'Site Name', type: 'text', width: 240, visible: true, color: 'indigo' },
  { id: 'col_location', name: 'Location / Region', type: 'text', width: 180, visible: true, color: 'slate' },
  { id: 'col_site_owner', name: 'Site Owner / TowerCo', type: 'text', width: 170, visible: true, color: 'slate' },
  { id: 'col_acq_status', name: 'Acquisition Status', type: 'status', width: 160, visible: true, color: 'emerald', options: ['Acquired', 'Under Negotiation', 'Legal Review', 'Initial Assessment', 'Site Activation', 'Delayed', 'At Risk'] },
  { id: 'col_acq_target', name: 'Acq Target Date', type: 'date', width: 135, visible: true, color: 'rose' },
  { id: 'col_acq_actual', name: 'Acq Actual Date', type: 'date', width: 135, visible: true, color: 'emerald' },
  { id: 'col_legal_status', name: 'Legal Status', type: 'status', width: 150, visible: true, color: 'indigo', options: ['Approved', 'Contract Signed', 'Due Diligence', 'Pending Review', 'Legal Escalation'] },
  { id: 'col_legal_rep', name: 'Legal Representative', type: 'text', width: 160, visible: true, color: 'slate' },
  { id: 'col_legal_fee', name: 'Legal Fee (₱)', type: 'amount', width: 150, visible: true, color: 'emerald', currencySymbol: '₱' },
  { id: 'col_contract_status', name: 'Contract Status', type: 'status', width: 140, visible: true, color: 'indigo', options: ['Signed', 'Under Review', 'Drafting', 'Pending Signature'] },
  { id: 'col_contract_date', name: 'Contract Date', type: 'date', width: 135, visible: true, color: 'slate' },
  { id: 'col_milestone', name: 'Current Milestone', type: 'text', width: 190, visible: true, color: 'blue' },
  { id: 'col_milestone_status', name: 'Milestone Status', type: 'status', width: 150, visible: true, color: 'indigo', options: ['Completed', 'In Progress', 'Pending', 'Delayed', 'At Risk'] },
  { id: 'col_target_date', name: 'Target Date', type: 'date', width: 135, visible: true, color: 'rose' },
  { id: 'col_actual_date', name: 'Actual Date', type: 'date', width: 135, visible: true, color: 'emerald' },
  { id: 'col_budget', name: 'Approved Budget (₱)', type: 'amount', width: 170, visible: true, color: 'emerald', currencySymbol: '₱' },
  { id: 'col_actual_cost', name: 'Actual Cost (₱)', type: 'amount', width: 170, visible: true, color: 'rose', currencySymbol: '₱' },
  { id: 'col_remaining_budget', name: 'Remaining Budget (₱)', type: 'amount', width: 170, visible: true, color: 'emerald', currencySymbol: '₱' },
  { id: 'col_variance', name: 'Variance (₱)', type: 'amount', width: 150, visible: true, color: 'amber', currencySymbol: '₱' },
  { id: 'col_responsible', name: 'Responsible Person', type: 'text', width: 170, visible: true, color: 'slate' },
  { id: 'col_assigned_team', name: 'Assigned Team', type: 'text', width: 160, visible: true, color: 'slate' },
  { id: 'col_priority', name: 'Priority', type: 'status', width: 120, visible: true, color: 'amber', options: ['Critical', 'High', 'Medium', 'Normal'] },
  { id: 'col_risk_level', name: 'Risk Level', type: 'status', width: 120, visible: true, color: 'rose', options: ['Low', 'Medium', 'High', 'Critical'] },
  { id: 'col_next_action', name: 'Next Action', type: 'text', width: 220, visible: true, color: 'slate' },
  { id: 'col_remarks', name: 'Engineer Remarks', type: 'text', width: 220, visible: true, color: 'slate' }
];

export const SITE_TRACKER_KPIS: SummaryCard[] = [
  {
    id: 'kpi-sites-total',
    title: 'Total Sites',
    columnId: 'col_site_id',
    calcType: 'count',
    format: 'number',
    tag: 'National Rollout',
    color: 'slate'
  },
  {
    id: 'kpi-sites-budget',
    title: 'Total Approved Budget (₱)',
    columnId: 'col_budget',
    calcType: 'sum',
    format: 'currency',
    tag: 'Capex Allocation',
    color: 'indigo'
  },
  {
    id: 'kpi-sites-cost',
    title: 'Actual Spending (₱)',
    columnId: 'col_actual_cost',
    calcType: 'sum',
    format: 'currency',
    tag: 'Disbursed Cost',
    color: 'rose'
  },
  {
    id: 'kpi-sites-balance',
    title: 'Remaining Budget (₱)',
    columnId: 'col_remaining_budget',
    calcType: 'sum',
    format: 'currency',
    tag: 'Remaining Funds',
    color: 'emerald'
  },
  {
    id: 'kpi-sites-legal',
    title: 'Total Legal Fees (₱)',
    columnId: 'col_legal_fee',
    calcType: 'sum',
    format: 'currency',
    tag: 'Legal Expenses',
    color: 'purple'
  },
  {
    id: 'kpi-sites-acquired',
    title: 'Sites Acquired / Completed',
    columnId: 'col_acq_status',
    calcType: 'count-completed',
    format: 'number',
    tag: '57% Target Pace',
    color: 'emerald'
  }
];

const PROVINCES = [
  'Cebu City, Central Visayas',
  'Makati City, Metro Manila',
  'Quezon City, Metro Manila',
  'Davao City, Davao Region',
  'Pampanga, Central Luzon',
  'Cavite, CALABARZON',
  'Laguna, CALABARZON',
  'Batangas, CALABARZON',
  'Iloilo City, Western Visayas',
  'Cagayan de Oro, Northern Mindanao',
  'Baguio City, Cordillera',
  'General Santos, SOCCSKSARGEN',
  'Bacolod City, Western Visayas',
  'Zamboanga City, Zamboanga Peninsula',
  'Taguig City, Metro Manila'
];

const OPERATORS = [
  'Philtower Consortium',
  'Globe Telecom',
  'Smart Communications',
  'DITO Telecommunity',
  'Unity Digital Infrastructure',
  'EdgePoint Towers'
];

const ENGINEERS = [
  'Engr. Mark Gaela',
  'Sarah Jenkins',
  'Michael Tan',
  'David Ramos',
  'Alex Rivera',
  'Maria Santos',
  'Kevin Bautista',
  'Clarisse Reyes'
];

const TEAMS = [
  'Site Acquisition Alpha',
  'Civil Works Team 1',
  'Legal Team Beta',
  'LGU Permitting Team',
  'Turnover & Commissioning',
  'Fast-Track Deployment'
];

const MILESTONES = [
  'Site Identification',
  'Initial Assessment',
  'Negotiation',
  'Due Diligence',
  'Legal Review',
  'Contract Preparation',
  'Contract Signing',
  'Acquisition Completion',
  'Site Activation',
  'Final Completion'
];

const LEGAL_REPS = [
  'Atty. R. Santos',
  'Atty. M. Dela Cruz',
  'Atty. J. Ramos',
  'Atty. C. Villanueva',
  'Atty. B. Hernandez'
];

const NEXT_ACTIONS = [
  'Execute lessor lease contract',
  'Submit LGU zoning clearance',
  'Perform boundary re-survey',
  'Sign notarized deed of lease',
  'Release initial payment to owner',
  'Awaiting barangay clearance',
  'Mobilize civil contractor for tower erection',
  'Submit title verification to Registry of Deeds',
  'Final structural sign-off'
];

/**
 * High-speed chunked site generator.
 * Generates 1,000 to 100,000 realistic records with non-blocking UI ticks.
 */
export async function generateSiteBatch(
  count: number,
  startIndex = 1,
  onProgress?: (progress: { current: number; total: number; percent: number }) => void
): Promise<Row[]> {
  const CHUNK_SIZE = 5000;
  const rows: Row[] = [];
  const total = count;

  let current = 0;

  while (current < total) {
    const chunkEnd = Math.min(current + CHUNK_SIZE, total);

    for (let i = current; i < chunkEnd; i++) {
      const idx = startIndex + i;
      const numStr = String(idx).padStart(5, '0');
      const siteId = `SAQ-${numStr}`;

      const op = OPERATORS[idx % OPERATORS.length];
      const prov = PROVINCES[idx % PROVINCES.length];
      const eng = ENGINEERS[idx % ENGINEERS.length];
      const team = TEAMS[idx % TEAMS.length];
      const milestone = MILESTONES[idx % MILESTONES.length];
      const legalRep = LEGAL_REPS[idx % LEGAL_REPS.length];
      const nextAction = NEXT_ACTIONS[idx % NEXT_ACTIONS.length];

      // Match the 57% acquisition completion target from specification
      const isAcquired = (idx % 100) < 57;
      let acqStatus = 'Acquired';
      let milestoneStatus = 'Completed';
      let legalStatus = 'Approved';
      let contractStatus = 'Signed';
      let riskLevel = 'Low';
      let priority = 'Normal';

      if (!isAcquired) {
        const mod = idx % 5;
        if (mod === 0) {
          acqStatus = 'Under Negotiation';
          milestoneStatus = 'In Progress';
          legalStatus = 'Pending Review';
          contractStatus = 'Drafting';
          riskLevel = 'Medium';
          priority = 'High';
        } else if (mod === 1) {
          acqStatus = 'Legal Review';
          milestoneStatus = 'In Progress';
          legalStatus = 'Due Diligence';
          contractStatus = 'Under Review';
          riskLevel = 'Medium';
          priority = 'High';
        } else if (mod === 2) {
          acqStatus = 'Initial Assessment';
          milestoneStatus = 'Pending';
          legalStatus = 'Pending Review';
          contractStatus = 'Pending Signature';
          riskLevel = 'Low';
          priority = 'Normal';
        } else if (mod === 3) {
          acqStatus = 'At Risk';
          milestoneStatus = 'At Risk';
          legalStatus = 'Legal Escalation';
          contractStatus = 'Under Review';
          riskLevel = 'Critical';
          priority = 'Critical';
        } else {
          acqStatus = 'Delayed';
          milestoneStatus = 'Delayed';
          legalStatus = 'Pending Review';
          contractStatus = 'Drafting';
          riskLevel = 'High';
          priority = 'High';
        }
      }

      // Base Capex Budget (₱350,000 - ₱1,200,000)
      const budgetBase = 350000 + ((idx * 37) % 850000);
      const budget = Math.round(budgetBase / 1000) * 1000;

      // Actual Cost
      let costRatio = isAcquired ? 0.92 : 0.45;
      if (acqStatus === 'At Risk') costRatio = 1.15; // Over budget test case
      const actualCost = Math.round((budget * costRatio) / 1000) * 1000;
      const remainingBudget = Math.max(0, budget - actualCost);
      const variance = actualCost - budget; // Variance = Actual - Budget

      // Legal fee (₱25,000 - ₱85,000)
      const legalFee = 25000 + ((idx * 17) % 60000);

      const targetMonth = String(((idx % 12) + 1)).padStart(2, '0');
      const targetDay = String(((idx % 28) + 1)).padStart(2, '0');
      const targetDate = `2026-${targetMonth}-${targetDay}`;
      const actualDate = isAcquired ? `2026-${targetMonth}-${targetDay}` : '';

      rows.push({
        id: `site-row-${idx}`,
        col_site_id: siteId,
        col_site_name: `${op} - ${prov.split(',')[0]} #${numStr}`,
        col_location: prov,
        col_site_owner: op,
        col_acq_status: acqStatus,
        col_acq_target: targetDate,
        col_acq_actual: actualDate,
        col_legal_status: legalStatus,
        col_legal_rep: legalRep,
        col_legal_fee: legalFee,
        col_contract_status: contractStatus,
        col_contract_date: isAcquired ? '2026-08-15' : '',
        col_milestone: milestone,
        col_milestone_status: milestoneStatus,
        col_target_date: targetDate,
        col_actual_date: actualDate,
        col_budget: budget,
        col_actual_cost: actualCost,
        col_remaining_budget: remainingBudget,
        col_variance: variance,
        col_responsible: eng,
        col_assigned_team: team,
        col_priority: priority,
        col_risk_level: riskLevel,
        col_next_action: nextAction,
        col_remarks: isAcquired ? 'Site acquired & lease confirmed.' : 'In active acquisition pipeline.'
      });
    }

    current = chunkEnd;
    if (onProgress) {
      onProgress({
        current,
        total,
        percent: Math.round((current / total) * 100)
      });
    }

    // Yield control to let React/UI repaint smoothly without freezing the browser
    if (current < total) {
      await new Promise(resolve => setTimeout(resolve, 0));
    }
  }

  return rows;
}

/**
 * Creates a brand new dedicated Site Acquisition & Milestone Tracker
 */
export function createDedicatedSiteTracker(rows: Row[]): Tracker {
  return {
    id: `tracker-sites-100k-${Date.now()}`,
    name: 'EM RPO Site Acquisition & Milestone Tracker',
    description: `Enterprise site management tracker catering up to 100,000 sites with real-time acquisition KPIs, legal fee tracking, and budget variance monitoring. (${rows.length.toLocaleString()} active records).`,
    icon: 'Radio',
    color: 'emerald',
    summaryCardsCollapsed: false,
    summaryCards: SITE_TRACKER_KPIS,
    columns: SITE_TRACKER_COLUMNS,
    rows
  };
}
