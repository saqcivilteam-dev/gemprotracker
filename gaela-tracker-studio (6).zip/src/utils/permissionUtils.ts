import { User, Tracker, TrackerPermission, FieldAccessLevel, ActivityLog, AccessRequest, Column } from '../types/tracker';

/**
 * Resolves the effective permissions for a user on a given tracker.
 * Admin always has full control over all trackers and fields.
 * Staff only has access to approved trackers with their designated permissions.
 * Guest has view-only access unless specifically approved for other permissions.
 */
export function getEffectiveTrackerPermission(
  user: User | null,
  trackerId: string,
  allPermissions: TrackerPermission[] = []
): TrackerPermission {
  // If user is Admin, they have full control
  if (user?.role === 'admin') {
    return {
      id: `admin_${trackerId}`,
      userId: user.id,
      trackerId,
      canView: true,
      canAdd: true,
      canEdit: true,
      canDelete: true,
      canExport: true,
      fieldPermissions: {},
      approvedBy: 'System (Super Admin)',
      updatedAt: new Date().toISOString()
    };
  }

  if (!user) {
    return {
      id: `anon_${trackerId}`,
      userId: 'anonymous',
      trackerId,
      canView: false,
      canAdd: false,
      canEdit: false,
      canDelete: false,
      canExport: false,
      fieldPermissions: {},
      updatedAt: new Date().toISOString()
    };
  }

  // Find explicit tracker permission in the registry
  const found = allPermissions.find(p => p.userId === user.id && p.trackerId === trackerId);
  if (found) {
    return found;
  }

  // Staff: Access ONLY to approved trackers. If not explicitly approved, Staff has NO access
  if (user.role === 'staff') {
    return {
      id: `staff_unapproved_${user.id}_${trackerId}`,
      userId: user.id,
      trackerId,
      canView: false,
      canAdd: false,
      canEdit: false,
      canDelete: false,
      canExport: false,
      fieldPermissions: {},
      updatedAt: new Date().toISOString()
    };
  }

  // Guest: View-only by default unless approved
  return {
    id: `guest_default_${user.id}_${trackerId}`,
    userId: user.id,
    trackerId,
    canView: user.status === 'approved', // Only approved guests can view
    canAdd: false,
    canEdit: false,
    canDelete: false,
    canExport: false,
    fieldPermissions: {},
    updatedAt: new Date().toISOString()
  };
}

/**
 * Resolves the field-level access level for a specific column in a tracker.
 * Returns 'edit', 'view', or 'no_access'.
 */
export function getFieldAccess(
  columnId: string,
  user: User | null,
  effectivePerm: TrackerPermission,
  columns: Column[] = []
): FieldAccessLevel {
  // Admin has unconditional edit access to all fields
  if (user?.role === 'admin') {
    return 'edit';
  }

  // If user cannot even view the tracker, no access to fields
  if (!effectivePerm.canView) {
    return 'no_access';
  }

  // Check explicit column permission if defined
  if (effectivePerm.fieldPermissions && effectivePerm.fieldPermissions[columnId]) {
    return effectivePerm.fieldPermissions[columnId];
  }

  // Default behavior if field not explicitly specified:
  // If user has tracker-level canEdit, they can edit unless restricted
  if (effectivePerm.canEdit) {
    return 'edit';
  }

  // Otherwise, read-only
  return 'view';
}

/**
 * Generates an ActivityLog entry
 */
export function makeActivityLog(
  user: User | null,
  action: string,
  params: {
    trackerId?: string;
    trackerName?: string;
    changedField?: string;
    columnId?: string;
    rowId?: string;
    oldValue?: string | number | null;
    newValue?: string | number | null;
    approvedBy?: string;
    details?: string;
  }
): ActivityLog {
  return {
    id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    userId: user ? user.id : 'system',
    userName: user ? user.username : 'System',
    userEmail: user?.email,
    userRole: user?.role,
    trackerId: params.trackerId,
    trackerName: params.trackerName,
    action,
    changedField: params.changedField,
    columnId: params.columnId,
    rowId: params.rowId,
    oldValue: params.oldValue !== undefined ? params.oldValue : null,
    newValue: params.newValue !== undefined ? params.newValue : null,
    approvedBy: params.approvedBy || (user?.role === 'admin' ? user.username : undefined),
    timestamp: new Date().toISOString(),
    details: params.details
  };
}
