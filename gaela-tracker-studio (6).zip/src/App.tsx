import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  AppState,
  Tracker,
  User,
  Row,
  Column,
  SummaryCard,
  AppTheme
} from './types/tracker';
import {
  getLocalState,
  saveLocalState,
  loadPersistedState,
  fetchCloudState,
  syncCloudState,
  getSavedUser,
  saveActiveUser,
  exportToCSV,
  exportToExcel,
  exportToJSON,
  normalizeExcelDate,
  saveSnapshotBackup,
  getSnapshotBackups
} from './utils/storage';
import { themes } from './utils/theme';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardSummary } from './components/DashboardSummary';
import { TrackerTable } from './components/TrackerTable';
import { ExcelPasteModal } from './components/ExcelPasteModal';
import { ColumnManagerModal } from './components/ColumnManagerModal';
import { GuestApprovalModal } from './components/GuestApprovalModal';
import { ReportModal } from './components/ReportModal';
import { LightboxModal } from './components/LightboxModal';
import { SettingsModal } from './components/SettingsModal';
import { ThemeModal } from './components/ThemeModal';
import { ShareModal } from './components/ShareModal';
import { AuthModal } from './components/AuthModal';
import { ChangePasswordModal } from './components/ChangePasswordModal';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { GoogleDriveModal } from './components/GoogleDriveModal';
import { SiteGeneratorModal } from './components/SiteGeneratorModal';
import { SaqWarningReportModal } from './components/SaqWarningReportModal';
import { SaqProcessWarningBanner } from './components/SaqProcessWarningBanner';
import { LegalChecklistModal, DEFAULT_LEGAL_CHECKLIST_ITEMS } from './components/LegalChecklistModal';
import { DayByDayModal } from './components/DayByDayModal';
import { generateDefaultDayByDayLog } from './utils/dayByDayUtils';
import { TrackerFolder } from './types/tracker';
import { evaluateAllSitesSaq } from './utils/saqSlaEngine';

export default function App() {
  // App State initialized from local storage cache
  const [state, setState] = useState<AppState>(() => getLocalState());
  const [currentUser, setCurrentUser] = useState<User | null>(() => getSavedUser());

  // Connection & sync state
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(true);

  // Undo & Redo History System (Protects data from accidental deletes or changes)
  const [undoStack, setUndoStack] = useState<AppState[]>([]);
  const [redoStack, setRedoStack] = useState<AppState[]>([]);

  // Workspace-wide Data Protection Mode (Prevents accidental typing, deletes, and type changes)
  const [isDataProtected, setIsDataProtected] = useState<boolean>(true);

  // Modals state
  const [showAuthModal, setShowAuthModal] = useState<boolean>(!currentUser);
  const [showChangePasswordModal, setShowChangePasswordModal] = useState<boolean>(false);
  const [showExcelPaste, setShowExcelPaste] = useState<boolean>(false);
  const [showColumnManager, setShowColumnManager] = useState<boolean>(false);
  const [showGuestApprovals, setShowGuestApprovals] = useState<boolean>(false);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [reportModalMode, setReportModalMode] = useState<'report' | 'presentation'>('report');
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showThemeModal, setShowThemeModal] = useState<boolean>(false);
  const [showShareModal, setShowShareModal] = useState<boolean>(false);
  const [showGlobalSearch, setShowGlobalSearch] = useState<boolean>(false);
  const [showGoogleDriveModal, setShowGoogleDriveModal] = useState<boolean>(false);
  const [showSiteGeneratorModal, setShowSiteGeneratorModal] = useState<boolean>(false);
  const [showSaqWarningModal, setShowSaqWarningModal] = useState<boolean>(false);
  const [legalChecklistTarget, setLegalChecklistTarget] = useState<{ row: Row; column?: Column } | null>(null);
  const [dayByDayTarget, setDayByDayTarget] = useState<{ row: Row; column?: Column } | null>(null);
  const [highlightedRowId, setHighlightedRowId] = useState<string | null>(null);
  const [searchFocusTerm, setSearchFocusTerm] = useState<string>('');
  const [activeMedia, setActiveMedia] = useState<{
    type: 'jpeg' | 'pdf';
    url: string;
    title: string;
  } | null>(null);

  // Notification Toast with optional Undo action button
  const [toast, setToast] = useState<{
    message: string;
    type: 'success' | 'info' | 'error';
    action?: { label: string; onClick: () => void };
  } | null>(null);

  const showToast = (
    message: string,
    type: 'success' | 'info' | 'error' = 'success',
    action?: { label: string; onClick: () => void }
  ) => {
    setToast({ message, type, action });
    setTimeout(() => setToast(null), action ? 5000 : 3500);
  };

  // Restore JSON ref
  const jsonFileInputRef = useRef<HTMLInputElement>(null);

  // Network online/offline listener & initial cloud fetch
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      handleCloudSync();
      showToast('Reconnected to internet. Cloud database synchronized.', 'success');
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast('You are offline. Changes will save locally.', 'info');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial sync
    fetchCloudState().then(({ state: cloudState, online }) => {
      setIsOnline(online);
      if (cloudState && cloudState.trackers && cloudState.trackers.length > 0) {
        const { cleaned } = sanitizeTrackers(cloudState.trackers);
        setState({ ...cloudState, trackers: cleaned });
      }
    });

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Update document title dynamically
  useEffect(() => {
    document.title = `${state.appName} · Gaela Tracker Studio`;
  }, [state.appName]);

  // Purge any synthetic subtotal rows to maintain 100% accurate data
  const sanitizeTrackers = (trackers: Tracker[]): { cleaned: Tracker[]; removedCount: number } => {
    let removedCount = 0;
    const cleaned = trackers.map(t => {
      const validRows = t.rows.filter(r => {
        if (
          r.id &&
          (r.id.startsWith('subtotal') ||
            r.id.startsWith('row-subtotal') ||
            r.id.includes('opencal') ||
            r.id.includes('subtotal'))
        ) {
          removedCount++;
          return false;
        }
        for (const key of Object.keys(r)) {
          if (key === 'id') continue;
          const val = String(r[key] || '');
          if (
            val.includes('∑ SUBTOTAL') ||
            val.includes('∑ Subtotal') ||
            val.includes('∑ SUB-TOTAL') ||
            val.includes('∑ REMAINING OPEN CAL') ||
            val.toLowerCase().startsWith('subtotal')
          ) {
            removedCount++;
            return false;
          }
        }
        return true;
      });
      return { ...t, rows: validRows };
    });
    return { cleaned, removedCount };
  };

  // Run cleanup once on initial mount to guarantee accurate data
  useEffect(() => {
    const { cleaned, removedCount } = sanitizeTrackers(state.trackers);
    if (removedCount > 0) {
      setState(prev => ({ ...prev, trackers: cleaned }));
      saveLocalState({ ...state, trackers: cleaned });
      showToast(`Cleaned ${removedCount} inaccurate subtotal row(s). Calculations are now 100% accurate!`, 'info');
    }
    // Take an initial backup snapshot
    saveSnapshotBackup(state, 'Initial Session Backup');

    // Hydrate full large-scale datasets (up to 100,000 sites) from IndexedDB
    loadPersistedState().then(persisted => {
      if (persisted && persisted.trackers && persisted.trackers.length > 0) {
        const persistedTotalRows = persisted.trackers.reduce((sum, t) => sum + (t.rows?.length || 0), 0);
        const currentTotalRows = state.trackers.reduce((sum, t) => sum + (t.rows?.length || 0), 0);
        if (persistedTotalRows > currentTotalRows) {
          setState(persisted);
        }
      }
    });
  }, []);

  // Debounce refs for high-speed responsiveness
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const syncTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Persist state changes with debounced background writes for instant UI speed
  const updateState = (
    updater: (prev: AppState) => AppState,
    shouldSync = true,
    recordHistory = true
  ) => {
    setState(prev => {
      const next = updater(prev);

      // Record to undo stack if trackers or data changed
      if (recordHistory && prev !== next) {
        setUndoStack(stack => [...stack.slice(-30), prev]);
        setRedoStack([]);
      }

      // Debounce saving to localStorage (300ms) to keep UI ultra responsive
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = setTimeout(() => {
        saveLocalState(next);
      }, 300);

      // Debounce sync to cloud database (800ms)
      if (shouldSync && isOnline) {
        if (syncTimeoutRef.current) clearTimeout(syncTimeoutRef.current);
        syncTimeoutRef.current = setTimeout(() => {
          syncCloudState(next);
        }, 800);
      }

      return next;
    });
  };

  // Undo Handler
  const handleUndo = () => {
    if (undoStack.length === 0) {
      showToast('Nothing to undo', 'info');
      return;
    }
    const prevSnapshot = undoStack[undoStack.length - 1];
    setUndoStack(prev => prev.slice(0, -1));
    setRedoStack(prev => [...prev, state]);
    setState(prevSnapshot);
    saveLocalState(prevSnapshot);
    if (isOnline) syncCloudState(prevSnapshot);
    showToast('Undid last action (Ctrl+Z)', 'info');
  };

  // Redo Handler
  const handleRedo = () => {
    if (redoStack.length === 0) {
      showToast('Nothing to redo', 'info');
      return;
    }
    const nextSnapshot = redoStack[redoStack.length - 1];
    setRedoStack(prev => prev.slice(0, -1));
    setUndoStack(prev => [...prev, state]);
    setState(nextSnapshot);
    saveLocalState(nextSnapshot);
    if (isOnline) syncCloudState(nextSnapshot);
    showToast('Redid action (Ctrl+Y)', 'info');
  };

  // Toggle Data Protection Mode
  const handleToggleDataProtection = () => {
    setIsDataProtected(prev => {
      const next = !prev;
      if (next) {
        showToast('🔒 Data Protection Active: Accidental edits & deletes are blocked.', 'success');
      } else {
        showToast('✏️ Edit Mode Unlocked: Cell edits and row operations are now active.', 'info');
      }
      return next;
    });
  };

  // Global Keyboard Shortcuts for Undo (Ctrl+Z) and Redo (Ctrl+Y)
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      const isInput =
        activeEl &&
        (activeEl.tagName === 'INPUT' ||
          activeEl.tagName === 'TEXTAREA' ||
          (activeEl as HTMLElement).isContentEditable);

      if (isInput) return;

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (e.shiftKey) {
          e.preventDefault();
          handleRedo();
        } else {
          e.preventDefault();
          handleUndo();
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
      }
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [undoStack, redoStack, state]);

  // Manual Cloud Sync trigger
  const handleCloudSync = async () => {
    setIsSyncing(true);
    try {
      const success = await syncCloudState(state);
      if (success) {
        showToast('Successfully synchronized with Free Cloud Database!', 'success');
      } else {
        showToast('Running in local mode. State saved locally.', 'info');
      }
    } catch {
      showToast('Cloud sync pending. Local storage up to date.', 'info');
    } finally {
      setIsSyncing(false);
    }
  };

  // Active tracker
  const currentTracker =
    state.trackers.find(t => t.id === state.activeTrackerId) || state.trackers[0];

  // SAQ Process SLA Health Evaluation & Active Warning Count
  const saqEvaluation = useMemo(() => {
    return evaluateAllSitesSaq(currentTracker?.rows || [], '2026-10-03');
  }, [currentTracker?.rows]);
  const saqWarningCount = saqEvaluation.totalWarnings;

  // Auth Handlers
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    saveActiveUser(user);
    setShowAuthModal(false);
    showToast(`Welcome back, ${user.username}! Signed in as ${user.role}.`, 'success');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    saveActiveUser(null);
    setShowAuthModal(true);
    showToast('Signed out successfully.', 'info');
  };

  const handleRegisterGuest = async (
    username: string,
    email: string,
    password: string,
    department: string
  ) => {
    try {
      const res = await fetch('/api/auth/register-guest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password, department })
      });
      const data = await res.json();
      if (res.ok) {
        // Also update local state
        const newUser: User = {
          id: 'guest-' + Date.now(),
          username,
          email,
          role: 'guest',
          status: 'pending',
          permission: 'viewer',
          department,
          createdAt: new Date().toISOString()
        };
        updateState(prev => ({
          ...prev,
          users: [...prev.users.filter(u => u.email.toLowerCase() !== email.toLowerCase()), newUser]
        }));
        return { success: true, message: data.message };
      }
      return { success: false, message: data.error || 'Registration failed' };
    } catch {
      // Local fallback
      const newUser: User = {
        id: 'guest-' + Date.now(),
        username,
        email,
        role: 'guest',
        status: 'pending',
        permission: 'viewer',
        department,
        createdAt: new Date().toISOString()
      };
      updateState(prev => ({
        ...prev,
        users: [...prev.users, newUser]
      }));
      return {
        success: true,
        message: 'Account registered and submitted for Administrator approval.'
      };
    }
  };

  const handleChangePassword = async (
    username: string,
    newPassword: string,
    currentPassword?: string
  ): Promise<{ success: boolean; message: string }> => {
    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, newPassword, currentPassword })
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, message: data.error || 'Failed to update password' };
      }

      // Update locally in users
      updateState(prev => ({
        ...prev,
        users: prev.users.map(u => {
          if (
            u.username.toLowerCase() === username.toLowerCase() ||
            u.email.toLowerCase() === username.toLowerCase()
          ) {
            return { ...u, password: newPassword };
          }
          return u;
        })
      }));

      if (
        currentUser &&
        (currentUser.username.toLowerCase() === username.toLowerCase() ||
          currentUser.email.toLowerCase() === username.toLowerCase())
      ) {
        const updated = { ...currentUser, password: newPassword };
        setCurrentUser(updated);
        saveActiveUser(updated);
      }

      showToast('Admin password changed successfully!', 'success');
      return { success: true, message: data.message || 'Password changed successfully!' };
    } catch {
      // Local fallback
      updateState(prev => ({
        ...prev,
        users: prev.users.map(u => {
          if (
            u.username.toLowerCase() === username.toLowerCase() ||
            u.email.toLowerCase() === username.toLowerCase()
          ) {
            return { ...u, password: newPassword };
          }
          return u;
        })
      }));

      if (
        currentUser &&
        (currentUser.username.toLowerCase() === username.toLowerCase() ||
          currentUser.email.toLowerCase() === username.toLowerCase())
      ) {
        const updated = { ...currentUser, password: newPassword };
        setCurrentUser(updated);
        saveActiveUser(updated);
      }

      showToast('Password updated locally and queued for sync.', 'success');
      return { success: true, message: 'Password updated successfully!' };
    }
  };

  const handleManageGuest = (
    userId: string,
    action: 'approve' | 'reject' | 'delete' | 'change-permission',
    permission?: 'editor' | 'viewer'
  ) => {
    updateState(prev => {
      const updatedUsers = [...prev.users];
      const idx = updatedUsers.findIndex(u => u.id === userId);
      if (idx !== -1) {
        if (action === 'approve') {
          updatedUsers[idx].status = 'approved';
          if (permission) updatedUsers[idx].permission = permission;
        } else if (action === 'reject') {
          updatedUsers[idx].status = 'rejected';
        } else if (action === 'delete') {
          updatedUsers.splice(idx, 1);
        } else if (action === 'change-permission') {
          updatedUsers[idx].permission = permission || 'viewer';
        }
      }
      return { ...prev, users: updatedUsers };
    });

    // Notify backend
    fetch('/api/auth/manage-guest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, action, permission })
    }).catch(console.warn);

    showToast(`Guest account ${action}d successfully.`);
  };

  // Tracker CRUD
  const handleSelectTracker = (trackerId: string) => {
    updateState(prev => ({ ...prev, activeTrackerId: trackerId }));
  };

  const handleAddTracker = (
    name: string,
    templateType: 'blank' | 'civil' | 'budget' | 'equipment' | 'bp',
    folderId?: string
  ) => {
    const id = 'tracker-' + Date.now();
    let newTracker: Tracker;

    if (templateType === 'bp') {
      newTracker = {
        id,
        name,
        description: 'Building Permit (BP), Payment Requests, Settlement, Target and Close Dates tracker.',
        icon: 'FileCheck2',
        color: 'emerald',
        summaryCardsCollapsed: false,
        summaryCards: [
          {
            id: 'bp-sum1',
            title: 'Total BP Requests (₱)',
            columnId: 'bp-req-amount',
            calcType: 'sum',
            format: 'currency',
            tag: 'Requested Fees',
            color: 'emerald'
          },
          {
            id: 'bp-sum2',
            title: 'Total BP Settled (₱)',
            columnId: 'bp-settled-amount',
            calcType: 'sum',
            format: 'currency',
            tag: 'Settled to LGU',
            color: 'indigo'
          },
          {
            id: 'bp-sum3',
            title: 'Active Sites / Applications',
            columnId: 'bp-site',
            calcType: 'count',
            format: 'number',
            tag: 'Sites',
            color: 'slate'
          }
        ],
        columns: [
          { id: 'bp-site', name: 'SITE NAME / CODE', type: 'text', width: 220, visible: true, color: 'blue' },
          { id: 'bp-purpose', name: 'PURPOSE / SCOPE', type: 'text', width: 200, visible: true, color: 'slate' },
          { id: 'bp-status', name: 'BP STATUS', type: 'status', width: 140, visible: true, color: 'indigo', options: ['Applied', 'Payment Requested', 'Settled', 'Under Evaluation', 'Approved / Closed', 'Delayed'] },
          { id: 'bp-req-amount', name: 'REQUEST PAYMENT FOR BP (₱)', type: 'amount', width: 210, visible: true, color: 'emerald', currencySymbol: '₱' },
          { id: 'bp-date-apply', name: 'DATE APPLY', type: 'date', width: 140, visible: true, color: 'amber' },
          { id: 'bp-date-target', name: 'DATE TARGET', type: 'date', width: 140, visible: true, color: 'rose' },
          { id: 'bp-date-settled', name: 'DATE SETTLED', type: 'date', width: 140, visible: true, color: 'cyan' },
          { id: 'bp-settled-amount', name: 'SETTLED AMOUNT (₱)', type: 'amount', width: 170, visible: true, color: 'emerald', currencySymbol: '₱' },
          { id: 'bp-date-close', name: 'DATE CLOSE', type: 'date', width: 140, visible: true, color: 'purple' },
          { id: 'bp-receipt', name: 'LGU RECEIPT / OR (JPEG)', type: 'jpeg', width: 160, visible: true, color: 'cyan' },
          { id: 'bp-permit-doc', name: 'PERMIT DOCUMENT (PDF)', type: 'pdf', width: 160, visible: true, color: 'purple' },
          { id: 'bp-remarks', name: 'REMARKS', type: 'text', width: 200, visible: true, color: 'slate' }
        ],
        rows: [
          {
            id: 'bp-demo-1',
            'bp-site': 'PHILTOWER - ST. ROSA 01',
            'bp-purpose': 'Building Permit & Ancillary Permits (BP)',
            'bp-status': 'Settled',
            'bp-req-amount': 45000,
            'bp-date-apply': '2026-08-10',
            'bp-date-target': '2026-09-30',
            'bp-date-settled': '2026-09-15',
            'bp-settled-amount': 45000,
            'bp-date-close': '2026-09-20',
            'bp-receipt': '',
            'bp-permit-doc': 'BP-Approved-Laguna-01.pdf',
            'bp-remarks': 'City Engineer clearance released and settled.'
          },
          {
            id: 'bp-demo-2',
            'bp-site': 'EDGEPOINT - CAVITE MACRO',
            'bp-purpose': 'Zoning & Building Permit Processing',
            'bp-status': 'Payment Requested',
            'bp-req-amount': 38500,
            'bp-date-apply': '2026-09-02',
            'bp-date-target': '2026-10-15',
            'bp-date-settled': '',
            'bp-settled-amount': 0,
            'bp-date-close': '',
            'bp-receipt': '',
            'bp-permit-doc': '',
            'bp-remarks': 'Check payment request forwarded to accounting.'
          }
        ]
      };
    } else if (templateType === 'civil') {
      newTracker = {
        id,
        name,
        description: 'Site civil works, structural quality check & inspections.',
        icon: 'Building2',
        color: 'blue',
        summaryCardsCollapsed: false,
        summaryCards: [
          {
            id: 'c-sum1',
            title: 'Total Contract Value',
            columnId: 'col-amount',
            calcType: 'sum',
            format: 'currency',
            tag: 'Contract Cap',
            color: 'emerald'
          },
          {
            id: 'c-sum2',
            title: 'Avg Progress',
            columnId: 'col-percent',
            calcType: 'average',
            format: 'percent',
            tag: 'Timeline',
            color: 'indigo'
          },
          {
            id: 'c-sum3',
            title: 'Work Items',
            columnId: 'col-item',
            calcType: 'count',
            format: 'number',
            tag: 'Items',
            color: 'slate'
          }
        ],
        columns: [
          { id: 'col-item', name: 'Work Item', type: 'text', width: 240, visible: true, color: 'slate' },
          { id: 'col-station', name: 'Station / Zone', type: 'text', width: 140, visible: true, color: 'blue' },
          { id: 'col-status', name: 'Status', type: 'status', width: 140, visible: true, color: 'indigo', options: ['Completed', 'In Progress', 'Review', 'Pending Approval'] },
          { id: 'col-amount', name: 'Amount (₱)', type: 'amount', width: 160, visible: true, color: 'emerald', currencySymbol: '₱' },
          { id: 'col-percent', name: 'Progress (%)', type: 'percent', width: 130, visible: true, color: 'amber' },
          { id: 'col-date', name: 'Target Date', type: 'date', width: 140, visible: true, color: 'rose' },
          { id: 'col-photo', name: 'Site Photo (JPEG)', type: 'jpeg', width: 140, visible: true, color: 'cyan' },
          { id: 'col-pdf', name: 'Report (PDF)', type: 'pdf', width: 150, visible: true, color: 'purple' },
        ],
        rows: [
          {
            id: 'r-' + Date.now(),
            'col-item': 'Site Clearing & Grading',
            'col-station': 'Zone 1',
            'col-status': 'Completed',
            'col-amount': 150000,
            'col-percent': 100,
            'col-date': '2026-09-18',
            'col-photo': '',
            'col-pdf': ''
          }
        ]
      };
    } else if (templateType === 'budget') {
      newTracker = {
        id,
        name,
        description: 'Budget monitoring, disbursements and purchase invoices.',
        icon: 'BadgeDollarSign',
        color: 'emerald',
        summaryCardsCollapsed: false,
        summaryCards: [
          {
            id: 'b-sum1',
            title: 'Total Disbursed (₱)',
            columnId: 'b-amount',
            calcType: 'sum',
            format: 'currency',
            tag: 'Disbursements',
            color: 'emerald'
          },
          {
            id: 'b-sum2',
            title: 'Average Paid %',
            columnId: 'b-percent',
            calcType: 'average',
            format: 'percent',
            tag: 'Pacing',
            color: 'indigo'
          }
        ],
        columns: [
          { id: 'b-item', name: 'Item Description', type: 'text', width: 220, visible: true, color: 'slate' },
          { id: 'b-vendor', name: 'Vendor', type: 'text', width: 160, visible: true, color: 'blue' },
          { id: 'b-status', name: 'Status', type: 'status', width: 130, visible: true, color: 'indigo', options: ['Completed', 'In Progress', 'Pending Approval'] },
          { id: 'b-amount', name: 'Amount (₱)', type: 'amount', width: 160, visible: true, color: 'emerald', currencySymbol: '₱' },
          { id: 'b-percent', name: 'Paid (%)', type: 'percent', width: 130, visible: true, color: 'amber' },
          { id: 'b-date', name: 'Due Date', type: 'date', width: 140, visible: true, color: 'rose' },
          { id: 'b-receipt', name: 'Receipt JPEG', type: 'jpeg', width: 140, visible: true, color: 'cyan' },
          { id: 'b-pdf', name: 'Invoice PDF', type: 'pdf', width: 150, visible: true, color: 'purple' },
        ],
        rows: []
      };
    } else if (templateType === 'equipment') {
      newTracker = {
        id,
        name,
        description: 'Machinery and technical calibration logs.',
        icon: 'Wrench',
        color: 'purple',
        summaryCardsCollapsed: false,
        summaryCards: [
          {
            id: 'e-sum1',
            title: 'Fleet Assets',
            columnId: 'e-asset',
            calcType: 'count',
            format: 'number',
            tag: 'Units',
            color: 'slate'
          }
        ],
        columns: [
          { id: 'e-asset', name: 'Equipment Name', type: 'text', width: 220, visible: true, color: 'slate' },
          { id: 'e-serial', name: 'Serial #', type: 'text', width: 140, visible: true, color: 'slate' },
          { id: 'e-status', name: 'Condition', type: 'status', width: 140, visible: true, color: 'indigo', options: ['Operational', 'Under Repair', 'Inspection Required'] },
          { id: 'e-value', name: 'Value (₱)', type: 'amount', width: 160, visible: true, color: 'emerald', currencySymbol: '₱' },
          { id: 'e-health', name: 'Health (%)', type: 'percent', width: 130, visible: true, color: 'amber' },
          { id: 'e-date', name: 'Next Test', type: 'date', width: 140, visible: true, color: 'rose' },
          { id: 'e-photo', name: 'Photo (JPEG)', type: 'jpeg', width: 140, visible: true, color: 'cyan' },
          { id: 'e-pdf', name: 'Manual (PDF)', type: 'pdf', width: 150, visible: true, color: 'purple' },
        ],
        rows: []
      };
    } else {
      // Blank
      newTracker = {
        id,
        name,
        description: 'Custom blank tracker',
        icon: 'FileSpreadsheet',
        color: 'indigo',
        summaryCardsCollapsed: false,
        summaryCards: [],
        columns: [
          { id: 'col-1', name: 'Item', type: 'text', width: 200, visible: true, color: 'slate' },
          { id: 'col-2', name: 'Status', type: 'status', width: 140, visible: true, color: 'indigo', options: ['In Progress', 'Completed'] },
          { id: 'col-3', name: 'Amount (₱)', type: 'amount', width: 160, visible: true, color: 'emerald', currencySymbol: '₱' },
        ],
        rows: []
      };
    }

    if (folderId) {
      newTracker.folderId = folderId;
    }

    updateState(prev => ({
      ...prev,
      trackers: [...prev.trackers, newTracker],
      activeTrackerId: id
    }));
    showToast(`Created new tracker: "${name}"`, 'success');
  };

  const handleRenameTracker = (trackerId: string, newName: string) => {
    updateState(prev => ({
      ...prev,
      trackers: prev.trackers.map(t => (t.id === trackerId ? { ...t, name: newName } : t))
    }));
    showToast(`Tracker renamed to "${newName}"`, 'success');
  };

  const handleDeleteTracker = (trackerId: string) => {
    if (state.trackers.length <= 1) {
      showToast('You must keep at least one tracker.', 'error');
      return;
    }
    updateState(prev => {
      const remaining = prev.trackers.filter(t => t.id !== trackerId);
      return {
        ...prev,
        trackers: remaining,
        activeTrackerId:
          prev.activeTrackerId === trackerId ? remaining[0].id : prev.activeTrackerId
      };
    });
    showToast('Tracker deleted.', 'info');
  };

  const handleDuplicateTracker = (trackerId: string) => {
    const original = state.trackers.find(t => t.id === trackerId);
    if (!original) return;
    const cloned: Tracker = {
      ...JSON.parse(JSON.stringify(original)),
      id: 'tracker-' + Date.now(),
      name: `${original.name} (Copy)`
    };
    updateState(prev => ({
      ...prev,
      trackers: [...prev.trackers, cloned],
      activeTrackerId: cloned.id
    }));
    showToast(`Duplicated "${original.name}"`, 'success');
  };

  // Folder & Organization System Handlers
  const handleAddFolder = (name: string, color = 'blue', icon = 'Folder') => {
    const newFolder: TrackerFolder = {
      id: `folder-${Date.now()}`,
      name,
      color: color as any,
      icon,
      isCollapsed: false,
      createdAt: new Date().toISOString()
    };
    updateState(prev => ({
      ...prev,
      folders: [...(prev.folders || []), newFolder]
    }));
    showToast(`Folder "${name}" created!`, 'success');
  };

  const handleRenameFolder = (folderId: string, newName: string) => {
    updateState(prev => ({
      ...prev,
      folders: (prev.folders || []).map(f => f.id === folderId ? { ...f, name: newName } : f)
    }));
    showToast('Folder renamed successfully!', 'success');
  };

  const handleDeleteFolder = (folderId: string) => {
    updateState(prev => ({
      ...prev,
      folders: (prev.folders || []).filter(f => f.id !== folderId),
      trackers: prev.trackers.map(t => t.folderId === folderId ? { ...t, folderId: undefined } : t)
    }));
    showToast('Folder deleted (contained trackers moved to unfiled).', 'info');
  };

  const handleToggleFolderCollapse = (folderId: string) => {
    updateState(prev => ({
      ...prev,
      folders: (prev.folders || []).map(f => f.id === folderId ? { ...f, isCollapsed: !f.isCollapsed } : f)
    }));
  };

  const handleMoveTrackerToFolder = (trackerId: string, folderId: string | null) => {
    updateState(prev => ({
      ...prev,
      trackers: prev.trackers.map(t => t.id === trackerId ? { ...t, folderId: folderId || undefined } : t)
    }));
    showToast(folderId ? 'Tracker moved to folder!' : 'Tracker moved to unfiled.', 'success');
  };

  const handleTogglePinTracker = (trackerId: string) => {
    updateState(prev => ({
      ...prev,
      trackers: prev.trackers.map(t => t.id === trackerId ? { ...t, isPinned: !t.isPinned } : t)
    }));
  };

  const handleToggleArchiveTracker = (trackerId: string) => {
    updateState(prev => ({
      ...prev,
      trackers: prev.trackers.map(t => t.id === trackerId ? { ...t, isArchived: !t.isArchived } : t)
    }));
  };

  // SAQ Process Site Movement Handler (Updates activity date and un-stalls site)
  const handleUpdateSiteMovement = (siteId: string, note?: string) => {
    const today = '2026-10-03';
    updateState(prev => {
      const updatedTrackers = prev.trackers.map(t => {
        const rowIdx = t.rows.findIndex(r => String(r.col_site_id || r.site_id || r.id) === siteId);
        if (rowIdx === -1) return t;
        const newRows = [...t.rows];
        newRows[rowIdx] = {
          ...newRows[rowIdx],
          col_saq_last_movement_date: today,
          last_movement_date: today,
          col_next_action: note || newRows[rowIdx].col_next_action || 'Progress checkpoint recorded',
          updated_at: new Date().toISOString()
        };
        return { ...t, rows: newRows };
      });
      return { ...prev, trackers: updatedTrackers };
    });
  };

  // Update current tracker
  const handleUpdateTracker = (updated: Tracker) => {
    updateState(prev => ({
      ...prev,
      trackers: prev.trackers.map(t => (t.id === updated.id ? updated : t))
    }));
  };

  // Summary cards update
  const handleUpdateSummaryCards = (cards: SummaryCard[]) => {
    handleUpdateTracker({ ...currentTracker, summaryCards: cards });
  };

  const handleToggleSummaryCollapse = () => {
    handleUpdateTracker({
      ...currentTracker,
      summaryCardsCollapsed: !currentTracker.summaryCardsCollapsed
    });
  };

  // Excel paste import
  const handleExcelImport = (newRows: Row[], replace: boolean) => {
    const updatedRows = replace ? newRows : [...currentTracker.rows, ...newRows];
    handleUpdateTracker({ ...currentTracker, rows: updatedRows });
    showToast(`Imported ${newRows.length} rows from Excel!`, 'success');
  };

  // Column manager update
  const handleUpdateColumns = (updatedCols: Column[]) => {
    // If any column type changed to 'date' or is a 'date' column, normalize any existing date values
    const dateColIds = new Set(updatedCols.filter(c => c.type === 'date').map(c => c.id));
    const legalColIds = new Set(updatedCols.filter(c => c.type === 'legal-checklist').map(c => c.id));
    const dayByDayColIds = new Set(updatedCols.filter(c => c.type === 'day-by-day').map(c => c.id));
    let cleanedRows = currentTracker.rows;

    if (dateColIds.size > 0 || legalColIds.size > 0 || dayByDayColIds.size > 0) {
      cleanedRows = currentTracker.rows.map(row => {
        let changed = false;
        const newRow = { ...row };
        dateColIds.forEach(colId => {
          if (newRow[colId] !== undefined && newRow[colId] !== null && newRow[colId] !== '') {
            const formatted = normalizeExcelDate(newRow[colId]);
            if (formatted !== newRow[colId]) {
              newRow[colId] = formatted;
              changed = true;
            }
          }
        });
        legalColIds.forEach(colId => {
          if (!newRow[colId] || (Array.isArray(newRow[colId]) && newRow[colId].length === 0)) {
            newRow[colId] = DEFAULT_LEGAL_CHECKLIST_ITEMS;
            changed = true;
          }
        });
        dayByDayColIds.forEach(colId => {
          if (!newRow[colId] || (Array.isArray(newRow[colId]) && newRow[colId].length === 0)) {
            newRow[colId] = generateDefaultDayByDayLog(newRow.col_site_id || newRow.id, newRow.col_site_name || 'Site');
            changed = true;
          }
        });
        return changed ? newRow : row;
      });
    }

    handleUpdateTracker({ ...currentTracker, columns: updatedCols, rows: cleanedRows });
    showToast('Columns updated successfully.', 'success');
  };

  // Settings update
  const handleSaveSettings = (appName: string, appSubtitle: string) => {
    updateState(prev => ({ ...prev, appName, appSubtitle }));
    showToast('Workspace settings saved.', 'success');
  };

  // Theme update
  const handleSelectTheme = (theme: AppTheme) => {
    updateState(prev => ({ ...prev, theme }));
    showToast(`Theme changed to ${themes[theme].name}.`, 'success');
  };

  // Restore JSON
  const handleRestoreJSONFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result as string);
        if (parsed.trackers && Array.isArray(parsed.trackers)) {
          updateState(() => parsed);
          showToast('Workspace restored successfully from JSON backup!', 'success');
        } else {
          alert('Invalid Gaela Tracker backup file format.');
        }
      } catch {
        alert('Could not parse JSON file.');
      }
    };
    reader.readAsText(file);
    // Reset input
    e.target.value = '';
  };

  const currentTheme = themes[state.theme] || themes.slate;
  const isDark = state.theme === 'dark';

  return (
    <div className={`min-h-screen flex flex-col ${currentTheme.bgClass} text-slate-900 transition-colors`}>
      {/* Top Navigation */}
      <Navbar
        state={state}
        currentUser={currentUser}
        isSidebarOpen={sidebarOpen}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        isOnline={isOnline}
        isSyncing={isSyncing}
        canUndo={undoStack.length > 0}
        canRedo={redoStack.length > 0}
        onUndo={handleUndo}
        onRedo={handleRedo}
        isDataProtected={isDataProtected}
        onToggleDataProtection={handleToggleDataProtection}
        onSync={handleCloudSync}
        onOpenGlobalSearch={() => setShowGlobalSearch(true)}
        onOpenGoogleDrive={() => setShowGoogleDriveModal(true)}
        onOpenSiteGenerator={() => setShowSiteGeneratorModal(true)}
        onOpenSaqWarnings={() => setShowSaqWarningModal(true)}
        saqWarningCount={saqWarningCount}
        onOpenGuestApprovals={() => setShowGuestApprovals(true)}
        onOpenReport={() => {
          setReportModalMode('report');
          setShowReportModal(true);
        }}
        onOpenPresentation={() => {
          setReportModalMode('presentation');
          setShowReportModal(true);
        }}
        onOpenTheme={() => setShowThemeModal(true)}
        onOpenSettings={() => setShowSettingsModal(true)}
        onOpenShare={() => setShowShareModal(true)}
        onOpenChangePassword={() => setShowChangePasswordModal(true)}
        onLogout={handleLogout}
      />

      {/* Main Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          state={state}
          currentUser={currentUser}
          isOpen={sidebarOpen}
          onToggle={() => setSidebarOpen(!sidebarOpen)}
          onSelectTracker={handleSelectTracker}
          onAddTracker={handleAddTracker}
          onRenameTracker={handleRenameTracker}
          onDeleteTracker={handleDeleteTracker}
          onDuplicateTracker={handleDuplicateTracker}
          onExportJSON={() => exportToJSON(state)}
          onImportJSON={() => jsonFileInputRef.current?.click()}
          onAddFolder={handleAddFolder}
          onRenameFolder={handleRenameFolder}
          onDeleteFolder={handleDeleteFolder}
          onToggleFolderCollapse={handleToggleFolderCollapse}
          onMoveTrackerToFolder={handleMoveTrackerToFolder}
          onTogglePinTracker={handleTogglePinTracker}
          onToggleArchiveTracker={handleToggleArchiveTracker}
        />

        {/* Workspace Content */}
        <main
          className={`flex-1 transition-all duration-300 overflow-y-auto custom-scrollbar p-3 sm:p-5 ${
            sidebarOpen ? 'md:ml-72' : 'md:ml-16'
          }`}
        >
          {/* Active Tracker Title and Details */}
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-zinc-800">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 dark:text-zinc-100">
                  {currentTracker.name}
                </h1>
                <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  {currentTracker.rows.length} rows
                </span>
                {isDataProtected ? (
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 flex items-center gap-1">
                    <span>🔒 Data Protected</span>
                  </span>
                ) : (
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-bold bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 flex items-center gap-1">
                    <span>✏️ Edit Mode Active</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-zinc-400 mt-0.5">
                {currentTracker.description || 'Generic customizable tracker for engineering, SAQC civil and team tracking'}
              </p>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => exportToExcel(currentTracker)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 text-xs font-semibold text-emerald-800 dark:text-emerald-200 shadow-2xs"
                title="Download genuine Microsoft Excel file"
              >
                <span>Export Excel (.xlsx)</span>
              </button>
              <button
                onClick={() => {
                  setReportModalMode('presentation');
                  setShowReportModal(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-indigo-300 dark:border-indigo-800 bg-indigo-50 dark:bg-indigo-950/40 hover:bg-indigo-100 text-xs font-semibold text-indigo-700 dark:text-indigo-300 shadow-2xs"
                title="Launch executive presentation deck for meetings"
              >
                <span>Presentation Deck</span>
              </button>
              <button
                onClick={() => {
                  setReportModalMode('report');
                  setShowReportModal(true);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 hover:bg-white dark:hover:bg-zinc-800 text-xs font-semibold text-slate-700 dark:text-zinc-200 shadow-2xs"
                title="Print executive audit report with preserved highlights"
              >
                <span>Print PDF</span>
              </button>
              <button
                onClick={() => exportToCSV(currentTracker)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-zinc-700 hover:bg-white dark:hover:bg-zinc-800 text-xs font-semibold text-slate-700 dark:text-zinc-200 shadow-2xs"
              >
                <span>CSV</span>
              </button>
            </div>
          </div>

          {/* SAQ Process SLA & Early Warning Notification Banner */}
          <SaqProcessWarningBanner
            currentTracker={currentTracker}
            state={state}
            onOpenWarningModal={() => setShowSaqWarningModal(true)}
            onOpenDayByDay={(row) => {
              const col = currentTracker.columns.find(c => c.type === 'day-by-day') || currentTracker.columns[0];
              setDayByDayTarget({ row, column: col });
            }}
            onFilterTable={(term) => setSearchFocusTerm(term)}
            onUpdateSiteMovement={handleUpdateSiteMovement}
            onMoveTrackerToFolder={handleMoveTrackerToFolder}
            onNotify={showToast}
          />

          {/* Collapsible Executive Summary Dashboard */}
          <DashboardSummary
            tracker={currentTracker}
            allTrackers={state.trackers}
            isDark={isDark}
            onUpdateSummaryCards={handleUpdateSummaryCards}
            onToggleCollapse={handleToggleSummaryCollapse}
            activeFilterTerm={searchFocusTerm}
            onFilterChange={(term) => setSearchFocusTerm(term)}
          />

          {/* Excel-Like Table */}
          <TrackerTable
            tracker={currentTracker}
            currentUser={currentUser}
            isDark={isDark}
            highlightedRowId={highlightedRowId}
            initialSearchTerm={searchFocusTerm}
            canUndo={undoStack.length > 0}
            canRedo={redoStack.length > 0}
            onUndo={handleUndo}
            onRedo={handleRedo}
            isDataProtected={isDataProtected}
            onToggleDataProtection={handleToggleDataProtection}
            onSearchChange={(term) => setSearchFocusTerm(term)}
            onUpdateTracker={handleUpdateTracker}
            onOpenExcelPaste={() => setShowExcelPaste(true)}
            onOpenColumnManager={() => setShowColumnManager(true)}
            onPreviewImage={(url, title) => setActiveMedia({ type: 'jpeg', url, title })}
            onPreviewPdf={(url, title) => setActiveMedia({ type: 'pdf', url, title })}
            onExportCSV={() => exportToCSV(currentTracker)}
            onOpenReport={() => {
              setReportModalMode('report');
              setShowReportModal(true);
            }}
            onOpenPresentation={() => {
              setReportModalMode('presentation');
              setShowReportModal(true);
            }}
            onOpenLegalChecklist={(row, column) => setLegalChecklistTarget({ row, column })}
            onOpenDayByDay={(row, column) => setDayByDayTarget({ row, column })}
            onNotify={showToast}
          />
        </main>
      </div>

      {/* Hidden file input for Restore JSON */}
      <input
        type="file"
        ref={jsonFileInputRef}
        accept=".json"
        className="hidden"
        onChange={handleRestoreJSONFile}
      />

      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-4 right-4 z-50 animate-bounce">
          <div
            className={`px-4 py-2.5 rounded-xl shadow-lg border text-xs font-semibold flex items-center gap-3 ${
              toast.type === 'error'
                ? 'bg-red-600 text-white border-red-700'
                : toast.type === 'info'
                ? 'bg-slate-900 text-white border-slate-800'
                : 'bg-emerald-600 text-white border-emerald-700'
            }`}
          >
            <span>{toast.message}</span>
            {toast.action && (
              <button
                onClick={() => {
                  toast.action?.onClick();
                  setToast(null);
                }}
                className="px-2.5 py-1 rounded bg-white text-slate-900 font-bold hover:bg-slate-100 shadow-xs cursor-pointer text-xs"
              >
                {toast.action.label}
              </button>
            )}
          </div>
        </div>
      )}

      {/* Modals */}
      {showAuthModal && (
        <AuthModal
          users={state.users}
          onLogin={handleLogin}
          onRegisterGuest={handleRegisterGuest}
          onChangePassword={handleChangePassword}
        />
      )}

      {showChangePasswordModal && currentUser && (
        <ChangePasswordModal
          currentUser={currentUser}
          isDark={isDark}
          onClose={() => setShowChangePasswordModal(false)}
          onChangePassword={handleChangePassword}
        />
      )}

      {showExcelPaste && (
        <ExcelPasteModal
          tracker={currentTracker}
          isDark={isDark}
          onClose={() => setShowExcelPaste(false)}
          onImport={handleExcelImport}
        />
      )}

      {showColumnManager && (
        <ColumnManagerModal
          tracker={currentTracker}
          isDark={isDark}
          onClose={() => setShowColumnManager(false)}
          onUpdateColumns={handleUpdateColumns}
        />
      )}

      {showGuestApprovals && (
        <GuestApprovalModal
          users={state.users}
          isDark={isDark}
          onClose={() => setShowGuestApprovals(false)}
          onManageGuest={handleManageGuest}
        />
      )}

      {showReportModal && (
        <ReportModal
          tracker={currentTracker}
          allTrackers={state.trackers}
          appName={state.appName}
          currentUser={currentUser}
          initialMode={reportModalMode}
          onClose={() => setShowReportModal(false)}
        />
      )}

      {activeMedia && (
        <LightboxModal media={activeMedia} onClose={() => setActiveMedia(null)} />
      )}

      {showSettingsModal && (
        <SettingsModal
          state={state}
          activeTracker={currentTracker}
          currentUser={currentUser}
          isOnline={isOnline}
          isDark={isDark}
          onClose={() => setShowSettingsModal(false)}
          onSaveSettings={handleSaveSettings}
          onDeleteCurrentTracker={() => handleDeleteTracker(currentTracker.id)}
          onOpenChangePassword={() => setShowChangePasswordModal(true)}
        />
      )}

      {showThemeModal && (
        <ThemeModal
          currentTheme={state.theme}
          isDark={isDark}
          onClose={() => setShowThemeModal(false)}
          onSelectTheme={handleSelectTheme}
        />
      )}

      {showShareModal && (
        <ShareModal isDark={isDark} onClose={() => setShowShareModal(false)} />
      )}

      {showGlobalSearch && (
        <GlobalSearchModal
          state={state}
          isDark={isDark}
          onClose={() => setShowGlobalSearch(false)}
          onPreviewImage={(url, title) => setActiveMedia({ type: 'jpeg', url, title })}
          onPreviewPdf={(url, title) => setActiveMedia({ type: 'pdf', url, title })}
          onSelectResult={(trackerId, rowId, term) => {
            handleSelectTracker(trackerId);
            setHighlightedRowId(rowId);
            if (term) setSearchFocusTerm(term);
            showToast(`Navigated to record in ${state.trackers.find(t => t.id === trackerId)?.name || 'tracker'}`);
            // Clear highlight after 5 seconds
            setTimeout(() => setHighlightedRowId(null), 5000);
          }}
        />
      )}

      {showGoogleDriveModal && (
        <GoogleDriveModal
          isOpen={showGoogleDriveModal}
          onClose={() => setShowGoogleDriveModal(false)}
          state={state}
          onRestoreState={(restoredState: AppState) => {
            updateState(() => restoredState);
            showToast('Tracker state restored from Google Drive!', 'success');
          }}
          onNotify={showToast}
        />
      )}

      {showSiteGeneratorModal && (
        <SiteGeneratorModal
          isOpen={showSiteGeneratorModal}
          onClose={() => setShowSiteGeneratorModal(false)}
          state={state}
          onTrackerGenerated={(updatedState: AppState, message: string) => {
            updateState(() => updatedState);
            showToast(message, 'success');
          }}
          onNotify={showToast}
        />
      )}

      {showSaqWarningModal && (
        <SaqWarningReportModal
          isOpen={showSaqWarningModal}
          onClose={() => setShowSaqWarningModal(false)}
          state={state}
          onOpenDayByDay={(row) => {
            const col = currentTracker.columns.find(c => c.type === 'day-by-day') || currentTracker.columns[0];
            setDayByDayTarget({ row, column: col });
          }}
          onUpdateSiteMovement={handleUpdateSiteMovement}
          onNotify={showToast}
        />
      )}

      {legalChecklistTarget && (
        <LegalChecklistModal
          isOpen={Boolean(legalChecklistTarget)}
          onClose={() => setLegalChecklistTarget(null)}
          siteRow={legalChecklistTarget.row}
          column={legalChecklistTarget.column}
          onUpdateSiteChecklist={(updatedItems) => {
            const targetColId = legalChecklistTarget.column?.id || 'col_legal_checklist';
            const updatedRows = currentTracker.rows.map(r =>
              r.id === legalChecklistTarget.row.id
                ? { ...r, [targetColId]: updatedItems }
                : r
            );
            handleUpdateTracker({ ...currentTracker, rows: updatedRows });
            setLegalChecklistTarget(prev =>
              prev ? { ...prev, row: { ...prev.row, [targetColId]: updatedItems } } : null
            );
          }}
          onNotify={showToast}
          onPreviewMedia={setActiveMedia}
        />
      )}

      {dayByDayTarget && (
        <DayByDayModal
          isOpen={Boolean(dayByDayTarget)}
          onClose={() => setDayByDayTarget(null)}
          siteRow={dayByDayTarget.row}
          column={dayByDayTarget.column}
          onOpenWarningCenter={() => setShowSaqWarningModal(true)}
          onOpenColumnManager={() => setShowColumnManager(true)}
          onUpdateDayByDay={(updatedLogs) => {
            const targetColId = dayByDayTarget.column?.id || 'col_day_by_day';
            const latestLog = updatedLogs[0];
            const updatedRows = currentTracker.rows.map(r => {
              if (r.id === dayByDayTarget.row.id) {
                const updated: Row = {
                  ...r,
                  [targetColId]: updatedLogs,
                  col_saq_last_movement_date: latestLog?.date || r.col_saq_last_movement_date,
                  col_notes: latestLog?.progressNotes || r.col_notes
                };
                // If a hunting entry is present, link official hunting date
                const huntingLog = updatedLogs.find(l => l.status === 'Site Hunting');
                if (huntingLog && huntingLog.date) {
                  updated.col_saq_hunting_date = huntingLog.date;
                }
                return updated;
              }
              return r;
            });
            handleUpdateTracker({ ...currentTracker, rows: updatedRows });
            setDayByDayTarget(prev =>
              prev ? { ...prev, row: { ...prev.row, [targetColId]: updatedLogs } } : null
            );
          }}
          onNotify={showToast}
        />
      )}
    </div>
  );
}
